package top.fols.box.reflect.re.middleware;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import top.fols.box.reflect.re.Re;
import top.fols.box.reflect.re.Re_Class;
import top.fols.box.reflect.re.Re_ClassFunction;
import top.fols.box.reflect.re.Re_ClassInstance;

public class Re__XC_MethodReplacement extends XC_MethodReplacement {
	Re re;
	Re_Class reClass;
	Re_ClassInstance reClassInstance;
	public Re__XC_MethodReplacement(Re re, Re_ClassInstance reInstance) {
		this.re = re;
		this.reClass = reInstance.getReClass();
		this.reClassInstance = reInstance;
	}

	@Override
	protected Object replaceHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {
		// TODO: Implement this method
		String name = "replaceHookedMethod"; Object[] p  = {param};
		Re_ClassFunction v = Re_Class.Unsafes.directGetFunctionValue(reClass, reClassInstance, name);
		return Re_Class.Unsafes.directExecuteFunction(re, reClass, reClassInstance, v, p);
	}

}
