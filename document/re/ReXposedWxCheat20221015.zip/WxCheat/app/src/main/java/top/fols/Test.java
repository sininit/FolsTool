package top.fols;
import android.app.Application;
import de.robv.android.xposed.XposedBridge;
import top.fols.atri.io.file.Filez;
import android.os.Environment;
import de.robv.android.xposed.XposedHelpers;


public class Test
{
	public static void main(){
		XposedHelpers.findAndHookMethod(null,null).unhook();
	}
}
