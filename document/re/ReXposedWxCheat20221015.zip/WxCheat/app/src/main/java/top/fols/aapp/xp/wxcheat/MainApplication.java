package top.fols.aapp.xp.wxcheat;

import android.app.Application;
import me.weishu.reflection.Reflection;

public class MainApplication extends Application {
	public static Application 		application;
	public static String 			packageName;
	
	
	@Override
	public void onCreate() {
		// TODO: Implement this method
		super.onCreate();
		Reflection.exemptAll();
		
		MainApplication.application = this;
		MainApplication.packageName = this.getApplicationContext().getPackageName();
	}
}
