package top.fols.box.reflect.re.middleware;

import de.robv.android.xposed.XC_MethodHook;
import top.fols.box.reflect.re.Re;
import top.fols.box.reflect.re.Re_Class;
import top.fols.box.reflect.re.Re_ClassInstance;
import top.fols.box.reflect.re.Re_ClassFunction;

public class Re__XC_MethodHook extends XC_MethodHook {
	Re re;
	Re_Class reClass;
	Re_ClassInstance reClassInstance;
	public Re__XC_MethodHook(Re re, Re_ClassInstance reInstance) {
		this.re = re;
		this.reClass = reInstance.getReClass();
		this.reClassInstance = reInstance;
	}

	@Override
	protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
		String name = "beforeHookedMethod"; Object[] p  = {param};
		Object v = Re_Class.Unsafes.directGetInstanceOrClassValue(reClass, reClassInstance, name);
		if (null != v) {
			Re_Class.Unsafes.directExecuteFunction(re, reClass, reClassInstance, (Re_ClassFunction) v, p);
		}
	}
	@Override
	protected void afterHookedMethod(MethodHookParam param) throws Throwable {
		String name = "afterHookedMethod"; Object[] p  = {param};
		Object v = Re_Class.Unsafes.directGetInstanceOrClassValue(reClass, reClassInstance, name);
		if (null != v) {
			Re_Class.Unsafes.directExecuteFunction(re, reClass, reClassInstance, (Re_ClassFunction) v, p);
		}
	}

}
