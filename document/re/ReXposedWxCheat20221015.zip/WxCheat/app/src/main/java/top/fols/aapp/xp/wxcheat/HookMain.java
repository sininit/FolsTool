package top.fols.aapp.xp.wxcheat;

import android.content.pm.ApplicationInfo;
import android.os.UserHandle;
import android.util.Log;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.IXposedHookZygoteInit;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import me.weishu.reflection.Reflection;
import top.fols.atri.io.Streams;
import top.fols.atri.io.file.Filez;
import top.fols.atri.lang.Objects;
import top.fols.atri.util.Throwables;
import top.fols.box.io.os.FilePermissions;
import top.fols.box.reflect.Systems;
import top.fols.box.reflect.re.Re;
import top.fols.box.reflect.re.Re_Class;
import top.fols.box.reflect.re.Re_ClassFunction;
import top.fols.box.reflect.re.Re_ClassLoader;
import top.fols.box.reflect.re.Re_KeywordFindResource;
import top.fols.box.reflect.re.Re_KeywordJClassInjection;
import top.fols.box.reflect.re.Re_KeywordXCMethodHook;
import top.fols.box.reflect.re.Re_KeywordXCMethodReplacement;
import top.fols.box.reflect.re.resource.Re_DirectoryResource;
import top.fols.box.reflect.re.resource.Re_IResource;

public class HookMain implements IXposedHookLoadPackage, IXposedHookZygoteInit {
	public static final String TAG = HookMain.class.getName();
	public static void loge(Throwable text) {
		Log.e(TAG, Throwables.toString(text));
	}
	public static void loge(String text) {
		Log.e(TAG, text);
	}


	static boolean isReplaceSystemStream;
	static boolean isLoadedByteBuddy;
	static boolean isLoadedRe;


	static final String moduleResourceByteBuddyPath = "byte-buddy-android_1.0.apk";


	static final String  reResourceDirectory = "/storage/emulated/0/_appprojects/x/folsTool/re/remote";
	static final String  reResourceMainClass = "hook";
	static final String  reResourceMainFun   = "handleLoadPackage";
	static Re_IResource  reResource;

	static Re re;
	static Re.AppReClassLoader reClassLoader;


	static final File  		      logDirectory   = new File(reResourceDirectory, "/log/");
	static final String 		  logFile        = new SimpleDateFormat("yyyy-MM-dd").format(new Date()) + ".log";
	static final SimpleDateFormat logPrefix 	 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	static final OutputStream     logStream 	 = new OutputStream() {
		@Override
		public void write(int p1) throws IOException {
			// TODO: Implement this method
			write(new byte[]{(byte) p1});
		}
		public void write(byte[] b, int off, int len) throws java.io.IOException {
			FileOutputStream fos = null;
			try {
				fos = new FileOutputStream(new File(logDirectory, logFile), true);
				fos.write(logPrefix.format(System.currentTimeMillis()).getBytes());
				fos.write(":    ".getBytes());

				fos.write(b, off, len);
				if (len > 0 && b[off + len - 1] != '\n') {
					fos.write("\n".getBytes());
				}
			} finally {
				Streams.close(fos);
			}
		}
	};
	static public synchronized void loadReplaceSystemStream() {
		if (isReplaceSystemStream) {
			return;
		} else {
			logDirectory.mkdirs();
			Systems.ReplaceOutputStream.replaceSout(logStream);
			Systems.ReplaceOutputStream.replaceSerr(logStream);
			isReplaceSystemStream = true;
		}
	}









	static public synchronized void loadByeBuddy(ApplicationInfo info) throws FileNotFoundException, IOException {
		if (isLoadedByteBuddy) {
			return;
		} else {
			String unzipBytebuddy;
			U: try {
				final String localName  = HookMain.class.getPackage().getName().hashCode() + "byte-buddy-android.apk";
				InputStream input = getModuleResource(moduleResourceByteBuddyPath);
				File dir = getMasterFilesDir_Re(info);
				File localFile = new File(dir, localName);
				unzipBytebuddy = localFile.getAbsolutePath();
				if  (localFile.exists()) {
					ZipEntry entiy = getModuleResourceFromZip(moduleResourceByteBuddyPath);
					long remoteSize = entiy.getSize();
					if  (remoteSize == localFile.length()) {
						break U;
					}
				}
				dir.mkdirs();
				OutputStream output = new FileOutputStream(localFile);
				Streams.copy(input, output);
				output.flush();
				output.close();
				FilePermissions.openFile(localFile, true);
			} catch (IOException e) {
				unzipBytebuddy = null;
				throw e;
			}
			Re_KeywordJClassInjection.loadAndroidLib(new File(unzipBytebuddy).getAbsolutePath());
			Re_KeywordJClassInjection.injection();
			isLoadedByteBuddy = true;
		}
	}
	static public synchronized Re_ClassLoader loadRe() {
		if (isLoadedRe) {
			return HookMain.reClassLoader;
		} else {
			Re_KeywordFindResource.injection();

			Re_KeywordXCMethodHook.injection();
			Re_KeywordXCMethodReplacement.injection();

			Re re = new Re();

			Re_IResource res = new Re_DirectoryResource(new File(reResourceDirectory));

			Re.AppReClassLoader defaultClassLoader;
			defaultClassLoader = new Re.AppReClassLoader(re);
			defaultClassLoader.addSourceManager(res);

			HookMain.re = re;
			HookMain.reResource    = res;
			HookMain.reClassLoader = defaultClassLoader;
		}
		isLoadedRe = true;
		return HookMain.reClassLoader;
	}
	static public synchronized Re_ClassLoader getReClassLoader() {
		return loadRe();
	}



	@Override
	public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam p1) throws Throwable {
		// TODO: Implement this method
		try {

			if ("com.tencent.mm".equals(p1.packageName)) {
				loge("join: " + p1.packageName);

				Reflection.exemptAll();

				loadReplaceSystemStream();

				loadByeBuddy(p1.appInfo);
				loadRe();

				try {
					Re_ClassLoader   reCl    = getReClassLoader();
					Re_Class         reC     = reCl.loadClass(reResourceMainClass);
					Re_ClassFunction reCFun  = Re_Class.Unsafes.directGetFunctionValue(reC, null, reResourceMainFun);

					Object[] p = {p1};
					Re_Class.Unsafes
						.directExecuteFunction(re, reC, null, reCFun, p);
				} catch (Throwable e) {
					e.printStackTrace();
					return;
				}
			} 

		} catch (Throwable e) {
			loge(e);
			e.printStackTrace();
			return;
		}
	}







	static public File getMasterFilesDir(ApplicationInfo info) {
		String dataDir = info.dataDir;
		return new File(dataDir, "files");
	}
	static public File getMasterFilesDir_Re(ApplicationInfo info) {
		return new File(getMasterFilesDir(info),  HookMain.class.getPackage().getName().hashCode() + "_re");
	}





	static String  		modulePath;
	static ZipFile 		moduleZFile;

	@Override
	public void initZygote(IXposedHookZygoteInit.StartupParam startupParam) throws Throwable {
		// TODO: Implement this method
		modulePath = startupParam.modulePath;
		moduleZFile = new ZipFile(modulePath);
	}
	static public ZipEntry    getModuleResourceFromZip(String path) {
		return Objects.requireNonNull(moduleZFile)
			.getEntry("assets/" + path);
	}
	static public InputStream getModuleResource(String path) {
		try {
			return moduleZFile.getInputStream(getModuleResourceFromZip(path));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}












	public static File createCodeDirectory(String currentApp) {
		try {
			String[] baseDir = {
				"/storage/emulated/" + UserHandle.class.getMethod("getIdentifier").invoke(android.os.Process.myUserHandle()) + "/",
				"/sdcard/", 
				"/storage/self/primary/"
			};
			for (String bd: baseDir) {
				Filez fz; File f;
				fz = Filez.wrap(bd + "/Android/data/" + currentApp + "/");
				fz.createsDir();
				if (fz.exists()) {
					if ((f = fz.innerFile()).canRead()) {
						return f;
					}
				}
			}
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
		throw new UnsupportedOperationException();
	}





}
		
