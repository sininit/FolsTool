package top.fols.box.reflect.re;

import bytebuddysmian.ByteBuddysDynamic;
import bytebuddysmian.ByteBuddysMain;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.concurrent.Callable;
import top.fols.atri.lang.Finals;
import top.fols.atri.reflect.ReflectCache;
import top.fols.box.reflect.re.Re_CodeLoader;
import top.fols.box.reflect.re.Re_Variable;
import top.fols.box.reflect.re.interfaces.Re_IReInnerVariableMap;
import top.fols.box.reflect.re.interfaces.Re_IReObject;
import top.fols.box.reflect.re.variables.Re_VariableMap;

import static top.fols.box.reflect.re.Re_CodeLoader.*;
import static top.fols.box.reflect.re.Re_Keywords.*;


public class Re_KeywordJClassInjection {
	
	static ByteBuddysDynamic util;
	
	public static void loadAndroidLib(String dex) {
		util = ByteBuddysDynamic.loadForDex(dex);
	}
	public static void loadJarLib(String[] dex) {
		util = ByteBuddysDynamic.loadForJar(dex);
	}
	public static void loadClassLoader(ClassLoader c) {
		util = ByteBuddysDynamic.loadForClassLoader(c);
	}
	
	
	
	public static ByteBuddysDynamic getLib() {
		if (null == util)
			throw new NullPointerException("no load lib");
		return util;
	}

	
	
	
	
	public static class VariableMapBuilder {
		Callable<?> superCall; Object superObject;
		Object thisObject;
		Method method; Object[] args;




		public void setSuperCall(Callable<?> superCall) {
			this.superCall = superCall;
		}
		public Callable<?> getSuperCall() {
			return superCall;
		}

		public void setSuperObject(Object superObject) {
			this.superObject = superObject;
		}
		public Object getSuperObject() {
			return superObject;
		}

		public void setThisObject(Object thisObject) {
			this.thisObject = thisObject;
		}
		public Object getThisObject() {
			return thisObject;
		}

		public void setMethod(Method method) {
			this.method = method;
		}
		public Method getMethod() {
			return method;
		}

		public void setArgs(Object[] args) {
			this.args = args;
		}
		public Object[] getArgs() {
			return args;
		}

		public Object[] buildArguments() {
			return null == args ?Finals.EMPTY_OBJECT_ARRAY: args;
		}

		public Re_IReInnerVariableMap buildVariableMap() {
			Re_IReInnerVariableMap variableMap;
			variableMap = new Re_VariableMap();
			variableMap.innerPutVariable("superCall",   Re_Variable.createVar(superCall));
			variableMap.innerPutVariable("superObject", Re_Variable.createVar(superObject));

			variableMap.innerPutVariable("thisObject",  Re_Variable.createVar(thisObject));

			variableMap.innerPutVariable("method",	   Re_Variable.createVar(method));
			variableMap.innerPutVariable("args", 	   Re_Variable.createVar(args));
			return variableMap;
		}

	}

	static final ReflectCache cache = new ReflectCache();


	public static void setBindReClassInstance(Object javaClassInstance, Re_ClassInstance reClassInstance) throws IllegalArgumentException, IllegalAccessException {
		Field  field = cache.field(javaClassInstance.getClass(), "BIND_OBJECT");
		field.set(javaClassInstance, reClassInstance);
	}
	public static Re_ClassInstance getBindReClassInstance(Object javaClassInstance) throws IllegalArgumentException, IllegalAccessException {
		Field  field = cache.field(javaClassInstance.getClass(), "BIND_OBJECT");
		return (Re_ClassInstance) field.get(javaClassInstance);
	}


	public static void setBindReClass(Class<?> javaClass, Re_Class reClass) throws IllegalArgumentException, IllegalAccessException {
		Field  field = cache.field(javaClass, "BIND_CLASS");
		field.set(null, reClass);
	}


	public static Class createClass(Class subclass, Class[] interfaces,
									final Re_Executor executor, final Re_Class reClass) throws Throwable {
		ByteBuddysDynamic util = Re_KeywordJClassInjection.getLib();
		Class dynamic   = util.createClass(
			subclass, interfaces,

			new ByteBuddysMain.FieldElement[] {
				new ByteBuddysMain.FieldElement("BIND_CLASS",  Modifier.PUBLIC | Modifier.STATIC),
				new ByteBuddysMain.FieldElement("BIND_OBJECT", Modifier.PUBLIC)
			},
			new ByteBuddysMain.ConstructorInterceptor() {
				@Override
				public Object intercept(Object thisObject, Object[] args) throws Throwable {
					// TODO: Implement this method
					VariableMapBuilder builder = new VariableMapBuilder();
					builder.setThisObject(thisObject);
					builder.setArgs(args);

					Re_ClassInstance instance = Re_Class.Unsafes.directCreateInstance(executor.re, reClass, 
																					 builder.buildArguments(),					
																					 builder.buildVariableMap());
					setBindReClassInstance(thisObject, instance);
					return null;
				}
			}, 
			new ByteBuddysMain.MethodInterceptor() {
				@Override
				public Object intercept(
					Callable<?> superCall, Object superObject,
					Object thisObject, 
					Method method, Object[] args) throws Throwable {
					// TODO: Implement this method

					Re_ClassInstance reClassInstance = getBindReClassInstance(thisObject);
					String name = method.getName();
					Object value = Re_Class.Unsafes.directGetInstanceOrClassValue(null, reClassInstance, name);
					if (null == value) {
						return superCall.call();
					}

					if (!Re_Utilities.isReFunction(value)) {
						throw new IllegalStateException("not a function: " + Re_Utilities.getName(value));
					}
					Re_ClassFunction function = (Re_ClassFunction) value;

					VariableMapBuilder builder = new VariableMapBuilder();
					builder.setSuperCall(superCall); 
					builder.setSuperObject(superObject);
					builder.setThisObject(thisObject);
					builder.setMethod(method);
					builder.setArgs(args);

					Object result = Re_Class.Unsafes.directExecuteFunction(executor.re, reClass, reClassInstance, function,
																		  builder.buildArguments(),					
																		  builder.buildVariableMap());
					return result;								 
				}
			}, 
			new ByteBuddysMain.InterfaceInterceptor() {
				@Override
				public Object invoke(Object thisObject, Method method, Object[] args) throws Throwable {
					// TODO: Implement this method
					Re_ClassInstance reClassInstance = getBindReClassInstance(thisObject);
					String name = method.getName();
					Object value = Re_Class.Unsafes.directGetInstanceOrClassValue(null, reClassInstance, name);
					if (null == value) {
						throw new IllegalStateException("undefined a function: " + name);
					}

					if (!Re_Utilities.isReFunction(value)) {
						throw new IllegalStateException("not a function: " + Re_Utilities.getName(value));
					}
					Re_ClassFunction function = (Re_ClassFunction) value;

					VariableMapBuilder builder = new VariableMapBuilder();
					builder.setThisObject(thisObject);
					builder.setMethod(method);
					builder.setArgs(args);

					Object result = Re_Class.Unsafes.directExecuteFunction(executor.re, reClass, reClassInstance, function,
																		  builder.buildArguments(),					
																		  builder.buildVariableMap());
					return result;								 
				}
			}
		);
		setBindReClass(dynamic, reClass);
		return dynamic;
	}


	public static void injection() {
		String name = Re_Keywords.INNER_FUNCTION__JNEW_CLASS;


		Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(name) {
				@Override
				public Object executeThis(Re_Executor executor, String var_name, Re_CodeLoader.Call call) throws Throwable {
					// TODO: Implement this method
					int pCount = call.getParamExpressionCount();
					if (pCount == 4 || pCount == 3) {
						int nameIndex       = pCount == 3 ?-1: 0;
						int subclassIndex   = nameIndex + 1;
						int interfacesIndex = subclassIndex + 1;
						int bindIndex       = interfacesIndex + 1;

						Object _name 	   = -1 == nameIndex ?null: executor.getExpressionValue(call, nameIndex);
						if (executor.isReturnOrThrow()) return null;
						
						Object _subclass   = executor.getExpressionValue(call, subclassIndex);
						if (executor.isReturnOrThrow()) return null;
						
						Object _interfaces = executor.getExpressionValue(call, interfacesIndex);
						if (executor.isReturnOrThrow()) return null;
						
						Object _bind       = executor.getExpressionValue(call, bindIndex);
						if (executor.isReturnOrThrow()) return null;

						String name         = null == _name ?null: Re_Utilities.toJString(_name);
						Class subclass      = Re_Utilities.castJavaObjectToJavaClass(_subclass);

						Object[] interfaces0 = Re_Utilities.toarray(executor, _interfaces);
						if (executor.isReturnOrThrow()) return null;
						Class[] interfaces  = Re_Utilities.jforNameFindClasss(interfaces0);

						Re_Class bind       = Re_Utilities.getReClass(_bind);


						if (null != name) {
							executor.setThrow("unsupported set name: " + name);
							return null;
						}
						if (null == bind) {
							executor.setThrow("need bind reClass");
							return null;
						}

						return createClass(subclass, interfaces,
										   executor, bind);
					}
					executor.setThrow(Re_Accidents.unable_to_process_parameters(var_name, pCount));
					return null;
				}
			}, Re_Keywords.keyword);
	}
}
