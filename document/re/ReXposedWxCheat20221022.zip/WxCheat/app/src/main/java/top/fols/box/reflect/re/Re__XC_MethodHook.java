package top.fols.box.reflect.re;

import de.robv.android.xposed.XC_MethodHook;
import top.fols.box.reflect.re.Re;
import top.fols.box.reflect.re.Re_Class;
import top.fols.box.reflect.re.Re_ClassInstance;
import top.fols.box.reflect.re.Re_ClassFunction;
import top.fols.box.reflect.re.Re_NativeStack;

public class Re__XC_MethodHook extends XC_MethodHook {
	Re re;
	Re_Class reClass;
	Re_ClassInstance reClassInstance;
	public Re__XC_MethodHook(Re re, Re_ClassInstance reInstance) {
		this.re = re;
		this.reClass 		 = reInstance.getReClass();
		this.reClassInstance = reInstance;
	}

	@Override
	protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
		String name = "beforeHookedMethod";
		Object[] p  = {param};
		Re_ClassFunction function = Re_Class.Unsafes.getFunctionValueOrThrowEx(reClass, reClassInstance, name);
		Re_Class.Unsafes.executeFunctionOrThrowEx(re, Re_NativeStack.newStack(), 
												  reClass, reClassInstance, function,
												  p, null);
	}
	@Override
	protected void afterHookedMethod(MethodHookParam param) throws Throwable {
		String name = "afterHookedMethod"; 
		Object[] p  = {param};
		Re_ClassFunction function = Re_Class.Unsafes.getFunctionValueOrThrowEx(reClass, reClassInstance, name);
		Re_Class.Unsafes.executeFunctionOrThrowEx(re, Re_NativeStack.newStack(), 
												  reClass, reClassInstance, function,
												  p, null);
	}

}
