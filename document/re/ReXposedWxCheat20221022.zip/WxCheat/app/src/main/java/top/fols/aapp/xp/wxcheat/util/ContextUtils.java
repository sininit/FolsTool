package top.fols.aapp.xp.wxcheat.util;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import java.lang.reflect.Constructor;

public class ContextUtils 
{
	@SuppressLint("PrivateApi")
    public static Context createAppContext(ApplicationInfo ai) throws Throwable {
        Constructor<?> ctor = Class.forName("android.app.ContextImpl").getDeclaredConstructors()[0];
        ctor.setAccessible(true);

        Context contextImpl;
        Object activityThread = Class.forName("android.app.ActivityThread").getMethod("currentActivityThread").invoke(null);
        Object loadedApk      = Class.forName("android.app.ActivityThread").getMethod("getPackageInfoNoCheck", 
																					  Class.forName("android.content.pm.ApplicationInfo"), 
																					  Class.forName("android.content.res.CompatibilityInfo"))
			.invoke(null, new Object[]{ai, null});
        switch (Build.VERSION.SDK_INT) {
            case 31:
            case 30:
                /*
				 *  private ContextImpl(@Nullable ContextImpl container, @NonNull ActivityThread mainThread,
				 @NonNull LoadedApk packageInfo, @Nullable String attributionTag,
				 @Nullable String splitName, @Nullable IBinder activityToken, @Nullable UserHandle user,
				 int flags, @Nullable ClassLoader classLoader, @Nullable String overrideOpPackageName)
				 * */
                contextImpl = (Context) ctor.newInstance(null, activityThread, loadedApk,
														 null, null, null, null, 0, null, null);
                break;
            case 29:
                /*
				 *  Android 10
				 private ContextImpl(@Nullable ContextImpl container, @NonNull ActivityThread mainThread,
				 @NonNull LoadedApk packageInfo, @Nullable String splitName,
				 @Nullable IBinder activityToken, @Nullable UserHandle user, int flags,
				 @Nullable ClassLoader classLoader, @Nullable String overrideOpPackageName)
				 *
				 * */
                contextImpl = (Context) ctor.newInstance(null, activityThread, loadedApk, null, null, null, 0, null, null);
                break;
            case 28:
            case 27:
            case 26:
                /*
				 * private ContextImpl(@Nullable ContextImpl container, @NonNull ActivityThread mainThread,
				 @NonNull LoadedApk packageInfo, @Nullable String splitName,
				 @Nullable IBinder activityToken, @Nullable UserHandle user, int flags,
				 @Nullable ClassLoader classLoader)
				 * */
                contextImpl = (Context) ctor.newInstance(null, activityThread, loadedApk, null, null, null, 0, null);
                break;
            case 25:
            case 24:
                /*
				 * private ContextImpl(ContextImpl container, ActivityThread mainThread,
				 LoadedApk packageInfo, IBinder activityToken, UserHandle user, int flags,
				 Display display, Configuration overrideConfiguration, int createDisplayWithId)
				 * */
                contextImpl = (Context) ctor.newInstance(null, activityThread, loadedApk, null, null, 0, null, null, -1);
                break;
            case 23:
                /*
				 * private ContextImpl(ContextImpl container, ActivityThread mainThread,
				 LoadedApk packageInfo, IBinder activityToken, UserHandle user, boolean restricted,
				 Display display, Configuration overrideConfiguration, int createDisplayWithId)
				 * */
                contextImpl = (Context) ctor.newInstance(null, activityThread, loadedApk, null, null, false, null, null, -1);
                break;
            case 22:
            case 21:
                /*
				 * private ContextImpl(ContextImpl container, ActivityThread mainThread,
				 LoadedApk packageInfo, IBinder activityToken, UserHandle user, boolean restricted,
				 Display display, Configuration overrideConfiguration)
				 * */
                contextImpl = (Context) ctor.newInstance(null, activityThread, loadedApk, null, null, false, null, null);
                break;
            default:
                throw new UnsupportedOperationException("Unsupported version " + Build.VERSION.SDK_INT);

        }

        return contextImpl;
    }
}
