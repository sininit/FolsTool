package top.fols.box.reflect.re;

import de.robv.android.xposed.XC_MethodReplacement;
import top.fols.box.reflect.re.interfaces.Re_IReObject;

public class Re__KeywordXCMethodReplacement {
	public static void injection() {
		String name = "_" + XC_MethodReplacement.class.getSimpleName();

		Re_Variable.Unsafes.addBuiltinValueInternOrThrowEx(new Re_IReObject.IPrimitiveCall(name) {
				@Override
				public Object executeThis(Re_Executor executor, String var_name, Re_CodeLoader.Call call) throws Throwable {
					// TODO: Implement this method
					int pCount = call.getParamExpressionCount();
					if (pCount == 1) {
						Object path 	   = executor.getExpressionValue(call, 0);
						if (executor.isReturnOrThrow()) return null;

						if (Re_Utilities.isReClassInstance(path)) {
							Re_ClassInstance instance = (Re_ClassInstance) path;
							return new Re__XC_MethodReplacement(executor.getRe(), instance);
						} else {
							executor.setThrow("param[0] not a ReClassInstance");
							return null;
						}
					}
					executor.setThrow(Re_Accidents.unable_to_process_parameters(var_name, pCount));
					return null;
				}
			}, Re_Keywords.keyword);
	}
}
