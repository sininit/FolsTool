package top.fols.box.reflect.re;
import top.fols.box.reflect.re.interfaces.Re_IReObject;
import top.fols.box.reflect.re.resource.Re_IResourceFile;

public class Re_KeywordFindResource {
	public static void injection() {
		String name = "find_resource_str";

		Re_Variable.Unsafes.addBuiltinValueInternOrThrowEx(new Re_IReObject.IPrimitiveCall(name) {
				@Override
				public Object executeThis(Re_Executor executor, String var_name, Re_CodeLoader.Call call) throws Throwable {
					// TODO: Implement this method
					int pCount = call.getParamExpressionCount();
					if (pCount == 1) {
						Object path 	   = executor.getExpressionValue(call, 0);
						if (executor.isReturnOrThrow()) return null;

						String str = Re_Utilities.toJString(path);
						Re_Class    rc = executor.getReClass();
						if (null == rc) {
							return null;
						}
						Re_ClassLoader rcl    = rc.getReClassLoader();
						Re_IResourceFile file = rcl.getFileResource(str);
						String content = null ==  file ? null: file.string();
						return content;
					}
					executor.setThrow(Re_Accidents.unable_to_process_parameters(var_name, pCount));
					return null;
				}
			}, Re_Keywords.keyword);
	}
}

