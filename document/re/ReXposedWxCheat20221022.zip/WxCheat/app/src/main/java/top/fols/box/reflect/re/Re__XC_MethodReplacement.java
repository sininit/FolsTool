package top.fols.box.reflect.re;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import top.fols.box.reflect.re.Re;
import top.fols.box.reflect.re.Re_Class;
import top.fols.box.reflect.re.Re_ClassInstance;
import top.fols.box.reflect.re.Re_NativeStack;

public class Re__XC_MethodReplacement extends XC_MethodReplacement {
	Re re;
	Re_Class reClass;
	Re_ClassInstance reClassInstance;
	public Re__XC_MethodReplacement(Re re, Re_ClassInstance reInstance) {
		this.re = re;
		this.reClass = reInstance.getReClass();
		this.reClassInstance = reInstance;
	}

	@Override
	protected Object replaceHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {
		// TODO: Implement this method
		String name = "replaceHookedMethod"; 
		Object[] p  = {param};
		Re_ClassFunction function = Re_Class.Unsafes.getFunctionValueOrThrowEx(reClass, reClassInstance, name);
		return Re_Class.Unsafes.executeFunctionOrThrowEx(re, Re_NativeStack.newStack(), 
														 reClass, reClassInstance, function,
														 p, null);
	}

}
