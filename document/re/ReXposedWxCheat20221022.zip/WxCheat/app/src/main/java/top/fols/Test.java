package top.fols;
import android.app.Application;
import de.robv.android.xposed.XposedBridge;
import top.fols.atri.io.file.Filez;
import android.os.Environment;
import de.robv.android.xposed.XposedHelpers;
import top.fols.box.reflect.re.Re_Class;
import top.fols.box.reflect.re.Re_ClassFunction;


public class Test
{
	public static void main(){
		XposedHelpers.findAndHookMethod(null,null).unhook();
	}
}
