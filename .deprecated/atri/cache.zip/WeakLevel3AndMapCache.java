package top.fols.atri.cache;

import java.util.Map;
import java.util.WeakHashMap;

import top.fols.atri.interfaces.annotations.ThreadSafe;
import top.fols.atri.interfaces.interfaces.IReleasable;
import top.fols.atri.cache.WeakMapCache.WrapValue;

@ThreadSafe
public abstract class WeakLevel3AndMapCache<K, V, EX extends Throwable> extends WeakLevel3Cache<K, V, EX> implements IReleasable {
	@Override
	public boolean release() {
		synchronized (map) {
			map.clear();
			return super.release() && map.size() == 0;
		}
	}
	@Override
	public boolean released() {
		return super.released() && map.size() == 0;
	}


	
	final Map<K, WrapValue <V> > map = new WeakHashMap<K, WrapValue <V> >() {
		@Override
		public WrapValue <V>  get(Object key) {
			// TODO: Implement this method
			return super.get(key);
		}

		@Override
		public WrapValue <V>  put(K key, WrapValue <V> value) {
			// TODO: Implement this method
			synchronized (this) {
				return super.put(key, value);
			}
		}
	};

	protected abstract V newValueCache(K key) throws RuntimeException;

	@Override
	protected final V newLookupCache(K key) throws RuntimeException {
		// TODO: Implement this method 
		WrapValue <V> cache = map.get(key);
		if (null == cache) {
			synchronized (map) {
				map.put(key, cache = new WrapValue<>(newValueCache(key)));
			}
		}
		return cache.value;
	}
}


