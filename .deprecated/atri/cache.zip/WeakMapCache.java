package top.fols.atri.cache;

import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.util.Map;
import top.fols.atri.interfaces.annotations.NotNull;
import top.fols.atri.interfaces.annotations.ThreadSafe;
import top.fols.atri.interfaces.interfaces.IInnerMap;
import top.fols.atri.interfaces.interfaces.IReleasable;
import top.fols.atri.lang.Value;
import top.fols.atri.interfaces.annotations.UnsafeOperate;

@ThreadSafe
public abstract class WeakMapCache<K, V, Ex extends Throwable> implements IInnerMap<K, WeakMapCache.WrapValue<V>>, IReleasable {
	protected abstract Map<K, WrapValue<V>> buildMap();

	
	public static class WrapValue <V> {
		V value;

		public WrapValue(V v) {
			this.value = v;
		}
	}
	
	
	Reference<Value<Map<K, WrapValue<V>>>> createReference(Value<Map<K, WrapValue<V>>> value) {
        return new WeakReference<>(value);
    }
    Reference<Value<Map<K, WrapValue<V>>>> reference = createReference(null);

	@Override
    public final Map<K, WrapValue<V>> getInnerMap() {
        Value<Map<K, WrapValue<V>>> vWrap;
        if (null == (vWrap = reference.get())) {
            reference = createReference(vWrap = new Value<>(buildMap()));
        }
        return vWrap.get();
    }

	
	public V get(K k) throws Ex {
        Map<K, WrapValue<V>> map = getInnerMap();
        WrapValue<V>   lastCache;
        if (null ==   (lastCache = map.get(k))) {
            //noinspection SynchronizationOnLocalVariableOrMethodParameter
            synchronized (map) {
                map.put(k, lastCache = new WrapValue<>(newCache(k)));
            }
        }
        return lastCache.value;
    }

	public final int size() {
        return getInnerMap().size();
    }

    @Override
    public final boolean release() {
        reference.clear();
        return true;
    }
    @Override
    public boolean released() {
        return getInnerMap().size() == 0;
    }

    public abstract V newCache(K k) throws Ex;
}
