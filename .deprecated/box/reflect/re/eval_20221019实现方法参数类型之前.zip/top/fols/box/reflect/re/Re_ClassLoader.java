package top.fols.box.reflect.re;

import java.util.LinkedHashMap;
import java.util.Map;

import top.fols.atri.io.file.Filex;
import top.fols.atri.util.annotation.NotException;
import top.fols.box.reflect.re.resource.Re_IResource;
import top.fols.atri.util.DoubleLinkedList;
import top.fols.box.reflect.re.resource.Re_IResourceFile;

/**
 * 类加载不是必须的 没有加载器 类也能炮
 */
@SuppressWarnings({"BooleanMethodIsAlwaysInverted"})
public abstract class Re_ClassLoader {
	protected final Object lock = new Object();
	protected final Re re;
	protected final Re_ClassLoader parent;


	final Map<String, Re_Class>         loaded = new LinkedHashMap<>();	//锁
	final DoubleLinkedList<Re_IResource> source = new DoubleLinkedList<>();//锁


	Re_ClassLoader(Re re, Re_ClassLoader parent) {
		this.re     = re;
		this.parent = parent;
	}

	public static String formatClassName(String name) {
		if (null == name)
			return null;
		if (name.length() == 0)
			return null;

		int st = 0;
		int len = name.length();
		for (int i = 0; i < len; i++) {
			char ch = name.charAt(i);
			if (ch == Filex.NAME_CURRENT_DIRECTORY) {
				st++;
			} else {
				A:{
					for (char c : Re_CodeLoader.SYSTEM_FILE_SEPARATOR) {
						if (ch == c) {
							st++;
							break A;
						}
					}
					break;
				}
			}
		}
		if (st != 0) {
			return name.substring(st, name.length());
		}
		return name;
	}

	/**
	 * @param path 文件路径 支持 \ / 扩展名
	 * @return 将文件路径转换为类名
	 */
	public static String pathToClassName(String path) {
		if ((null == path) || path.length() == 0) {
			return null;
		}

		int len = path.length();
		String extendName = Filex.getExtensionName(path, Re_CodeLoader.FILE_EXTENSION_SYMBOL);
		if (null != extendName) {
			len = len - extendName.length() - Re_CodeLoader.FILE_EXTENSION_SYMBOL.length();
		}

		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < len; i++){
			char ch = path.charAt(i);
			boolean sep = false;
			for (char c : Re_CodeLoader.SYSTEM_FILE_SEPARATOR) {
				if (ch == c){
					sep = true;
					break;
				}
			}
			if (sep) {
				int b_length = stringBuilder.length();
				if (b_length != 0) {
					char last = stringBuilder.charAt(b_length - 1);
					if  (last != ch) {
						stringBuilder.append(Re_CodeLoader.PACKAGE_SEPARATOR);
					}
				}
			} else {
				if (ch == Re_CodeLoader.PACKAGE_SEPARATOR) {
					throw new UnsupportedOperationException("invalid name: " + path+ Re_CodeLoader.CODE_BLANK_SPACE_CHARS + Re_CodeLoader.CODE_BLANK_SPACE_CHARS +"["+i+"]");
				}
				stringBuilder.append(ch);
			}
		}
		return stringBuilder.toString();
	}

	public static String classNameToPath(String name) {
		if ((null == name) || name.length() == 0) {
			return null;
		}

		int len = name.length();
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < len; i++){
			char ch = name.charAt(i);
			boolean sep = false;
			for (char c : Re_CodeLoader.SYSTEM_FILE_SEPARATOR) {
				if (ch == c){
					sep = true;
					break;
				}
			}
			if (sep) {
				throw new UnsupportedOperationException("invalid name: " + name+ Re_CodeLoader.CODE_BLANK_SPACE_CHARS + Re_CodeLoader.CODE_BLANK_SPACE_CHARS +"["+i+"]");
			} else {
				if (ch == Re_CodeLoader.PACKAGE_SEPARATOR) {
					stringBuilder.append(Filex.system_separator);
					continue;
				}
				stringBuilder.append(ch);
			}
		}
		return stringBuilder
				.append(Re_CodeLoader.FILE_EXTENSION_SYMBOL).append(Re_CodeLoader.RE_FILE_EXTENSION_NAME).toString();
	}






	public Re getRe() {
		return this.re;
	}

	public Re_ClassLoader getParent() {
		return parent;
	}

	/**
	 * @param name 完全限定名
	 */
	public Re_Class findLoadedClass(String name) {
		synchronized (lock) {
			return loaded.get(name);
		}
	}








	/*
	 * 遍历寻类找源
	 * 越后面添加则等级越高
	 */
	protected Re_IResourceFile getClassResource(String className) {
		synchronized (lock) {
			for (DoubleLinkedList.Element<Re_IResource> element = this.source.getFirst(); null != element; element = (DoubleLinkedList.Element<Re_IResource>) element.getNext()) {
				Re_IResource resource = element.content();
				Re_IResourceFile data = resource.findClassResource(className);
				if (null != data) {
					return  data;
				}
			}
			return null;
		}
	}

	public Re_IResourceFile getFileResource(String filePath) {
		synchronized (lock) {
			for (DoubleLinkedList.Element<Re_IResource> element = this.source.getFirst(); null != element; element = (DoubleLinkedList.Element<Re_IResource>) element.getNext()) {
				Re_IResource resource = element.content();
				Re_IResourceFile data = resource.findFileResource(filePath);
				if (null != data) {
					return  data;
				}
			}
			return null;
		}
	}







	protected Re_IResource[] getSources() {
		return this.source.toArray(new Re_IResource[]{});
	}



	protected boolean removeSourceManager(Re_IResource resource) {
		synchronized (lock) {
			DoubleLinkedList.Element<Re_IResource> find = source.indexOf(resource);
			if (null != find) {
				source.remove(find);
				return true;
			}
			return false;
		}
	}
	protected void addSourceManager(Re_IResource resource) {
		synchronized (lock) {
			DoubleLinkedList.Element<Re_IResource> find = source.indexOf(resource);
			if (null != find) {
				source.remove(find);
			}
			this.source.addFirst(new DoubleLinkedList.Element<>(resource));//将资源管理器推到第一个
		}
	}
	protected boolean hasSourceManager(Re_IResource resource) {
		synchronized (lock) {
			return null != source.indexOf(resource);
		}
	}







	public Re_Class loadClass(String className) {
		Re_NativeStack stack = Re_NativeStack.newStack();
		Re_Class reClass = fromReInnerLoadClass(stack, className);
		if (null == reClass && !stack.isThrow()) {
			stack.setThrow(Re_Accidents.not_found_reclass(className));
		}
		if (stack.isThrow())
			Re.throwStackException(stack);
		return reClass;
	}















	/**
	 * @param className 完全限定名
	 * 如果已经记载了将会返回已加载结果
	 * 会先向父类记载类 如果不存在再从 本加载器所有资源里找
	 *
	 * *****最好不要抛出异常，如果异常应该是内部异常
	 */
	Re_Class fromReInnerLoadClass(Re_NativeStack stack, String className)  {
		synchronized (lock) {
			if (stack.isThrow()) return null;

			className = formatClassName(className);

			//对原始名称判断
			Re_Class    re_class = loaded.get(className);
			if (null != re_class) {
				return  re_class;
			}

			if (null != parent) {
				re_class = parent.fromReInnerLoadClass(stack, className);
				if (stack.isThrow()) return null;
				if (null != re_class)
					return  re_class;
			} else {
				//bootstrap loader...
				Re_ClassLoader bootstrapClassLoader = re.getBootstrapClassLoader();
				if (null !=    bootstrapClassLoader && this != bootstrapClassLoader) {
					re_class = bootstrapClassLoader.fromReInnerLoadClass(stack, className);
					if (stack.isThrow()) return null;
					if (null != re_class)
						return  re_class;
				}
			}
			//获取类
			Re_IResourceFile classSource = this.getClassResource(className);
			if (null == classSource) {
				return null;
			}

			//统一名称
			re_class = loaded.get(className = classSource.name());
			if (null != re_class) {
				return  re_class;
			}


			//编译代码
			String code = classSource.string();
			Re_CodeFile classFile = this.compileFile(stack, classSource.absolutePath(), code);
			if (stack.isThrow())
				return null;

			//创建类
			Re_Class define;
			define = Re_Class.createReClass(null, className, classFile, null);	//不可用出现错误
			define.setReClassLoader(this);	//不可用出现错误
			className = define.getName();


			//初始化类
			loaded.put(className, define);	//可以导入自己，防止死循环

			this.initReClass(stack, define);
			if (stack.isThrow()) {
				loaded.remove(className);
				return null;
			}

			return define;
		}
	}



	/**
	 * 定义一个顶级类
	 *
	 * @param filePath 文件路径
	 * @param code     代码字节
	 */
	@NotException
	protected abstract Re_CodeFile compileFile(Re_NativeStack stack, String filePath, String code);

	@NotException
	protected abstract void initReClass(Re_NativeStack stack, Re_Class define);
}

