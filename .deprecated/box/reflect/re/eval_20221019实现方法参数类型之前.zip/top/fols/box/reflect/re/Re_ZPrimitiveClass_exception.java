package top.fols.box.reflect.re;

import top.fols.box.reflect.re.interfaces.Re_IReInnerVariableMap;
import top.fols.box.reflect.re.variables.Re_ObjectVariableMap;

import static top.fols.box.reflect.re.Re_NativeStack.toLineAddressString;

public class Re_ZPrimitiveClass_exception extends Re_PrimitiveClass {

    @SuppressWarnings("SpellCheckingInspection")
    public static final Re_ZPrimitiveClass_exception reclass = new Re_ZPrimitiveClass_exception(Re_Keywords.INNER_CLASS__EXCEPTION);

    protected Re_ZPrimitiveClass_exception(String className) {
        super(className, new InitBefore() {
            @Override
            public void init(Re_PrimitiveClass thatClass) {
                thatClass.setInitFunction(new Re_PrimitiveClassFunction.PrimitiveClassInitFunction(thatClass, null) {
                    @Override
                    public Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) throws Throwable {
                        int length = arguments.length;
                        if (length == 1) {
                            String throwReason = Re_Utilities.toJString(arguments[0]);

                            Instance eInstance = (Instance) runInInstance;
                            eInstance.setThrowReason(throwReason);
                            Re_NativeStack.fillExceptionInstanceTraceElements(executor, eInstance);
                            return null;
                        }
                        executor.setThrow(Re_Accidents.unable_to_process_parameters(getName(), length));
                        return null;
                    }
                });
            }
        });


        {
            final String name = "message";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) {
                    int length = arguments.length;
                    if (length == 0) {
                        Instance e = (Instance) runInInstance;
                        return e.getReason();
                    }
                    executor.setThrow(Re_Accidents.unable_to_process_parameters(name, length));
                    return null;
                }
            });
        }
        {
            final String name = "stack";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) {
                    int length = arguments.length;
                    if (length == 0) {
                        Instance e = (Instance) runInInstance;
                        return e.getStackElements();
                    }
                    executor.setThrow(Re_Accidents.unable_to_process_parameters(name, length));
                    return null;
                }
            });
        }

    }








    @Override
    public Instance createInstance() {
        return createInstance(this);
    }
    @Override
    public Instance createInstance(Re_Class reClass) {
        return new Instance(reClass, new Re_ObjectVariableMap());
    }



    public static class TraceElement implements Cloneable, Re_NativeStack.ITraceElement {
        protected String filePath;
        protected int line;

        public TraceElement(Re_NativeStack.ITraceElement iTrace) {
            this.filePath = iTrace.getFilePath();
            this.line     = iTrace.getLine();
        }
        public TraceElement(String filePath, int line) {
            this.filePath = filePath;
            this.line     = line;
        }


        public void setFilePath(String reName) {
            this.filePath = reName;
        }

        public String getFilePath() {
            return filePath;
        }


        public void setLine(int line) {
            this.line = line;
        }

        public int getLine() {
            return line;
        }


        @Override
        public String toString() {
            // TODO: Implement this method
            return toLineAddressString(this.filePath, this.line);
        }

        @Override
        public TraceElement clone() {
            // TODO: Implement this method
            try {
                return (TraceElement) super.clone();
            } catch (CloneNotSupportedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public static class Instance extends Re_PrimitiveClassInstance {
        protected Instance(Re_Class reClass, Re_IReInnerVariableMap map) {
            super(reClass, map);
        }

        @Override
        public Instance clone() {
            Instance instance = (Instance) super.clone();
            instance.throwReason = this.throwReason;
            instance.traces = new TraceElement[this.traces.length];
            for (int i = 0; i < this.traces.length; i++) {
                instance.traces[i] = this.traces[i].clone();
            }
            return instance;
        }

        //reason
        String throwReason;

        //safe
        TraceElement[] traces;

        public void setThrowReason(String throwReason) {
            this.throwReason = throwReason;
        }
        public void setStackElements(TraceElement[] traces) {
            this.traces = traces;
        }

        public String getReason() {
            return throwReason;
        }
        public TraceElement[] getStackElements() {
            return traces;
        }

        public String buildExceptionString() {
            return Re_NativeStack.buildExceptionString(this.throwReason, traces);
        }

        @Override
        public String toString() {
            return buildExceptionString();
        }
    }
}
