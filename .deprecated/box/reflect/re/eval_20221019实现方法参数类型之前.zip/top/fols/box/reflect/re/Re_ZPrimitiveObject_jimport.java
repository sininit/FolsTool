package top.fols.box.reflect.re;

import top.fols.atri.lang.Objects;
import top.fols.box.reflect.re.interfaces.Re_IJavaClassWrap;
import top.fols.box.reflect.re.interfaces.Re_IReObject;

/**
 * java class static opt
 * 这玩意是一个很重要的类
 * 数组也是通过它创建的
 *
 * @see Re_IReObject
 */
@SuppressWarnings("rawtypes")
public class Re_ZPrimitiveObject_jimport extends Re_IReObject.IPrimitiveObject implements Re_IJavaClassWrap {

    @Override
    public boolean containsVariable(Re_Executor executor, Object key) throws Throwable {
        String s = Re_Utilities.toJString(key);
        return Re_Utilities.hasJavaClassVariable(executor, __class__, s);
    }

    @Override
    public boolean removeVariable(Re_Executor executor, Object key) throws Throwable {
        String s = Re_Utilities.toJString(key);
        return Re_Utilities.removeJavaClassValue(executor, __class__, s);
    }

    @Override
    public Object getVariableValue(Re_Executor executor, Object key) throws Throwable {
        // TODO: Implement this method
        String s = Re_Utilities.toJString(key);
        return Re_Utilities.getJavaClassValue(executor, __class__, s);
    }

    @Override
    public void putVariableValue(Re_Executor executor, Object key, Object value) throws Throwable {
        // TODO: Implement this method
        String s = Re_Utilities.toJString(key);
        Re_Utilities.setJavaClassValue(executor, __class__, s, value);
    }



    @Override
    public int getVariableCount(Re_Executor executor) throws Throwable {
        return Re_Utilities.getJavaClassSize(executor,__class__);
    }

    @Override
    public Iterable getVariableKeys(Re_Executor executor) throws Throwable {
        return Re_Utilities.getJavaClassKeys(executor, __class__);
    }




    @Override
    public Object executePoint(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
        // TODO: Implement this method
        Object[] callParam = executor.getExpressionValues(call, 0, call.getParamExpressionCount());
        if (executor.isReturnOrThrow()) return null;

        return Re_Utilities.invokeJavaClassMethod(executor, __class__, point_key, callParam);
    }


    @Override
    public Object executeThis(Re_Executor executor, String that_key, Re_CodeLoader.Call call) throws Throwable {
        if (__ia_array__) {
            return Re_Utilities.newJArrayFromElement(executor, __class__, call);
        } else {
            Object[] callParam = executor.getExpressionValues(call, 0, call.getParamExpressionCount());
            if (executor.isReturnOrThrow()) return null;

            return Re_Utilities.newJavaInstance(executor, __class__, callParam);
        }
    }



    @Override
    public String getName() {
        return Re_Keywords.INNER_FUNCTION__JIMPORT + "{" + (__class__.getName()) + '}';
    }







    public final boolean  __ia_array__;
    public final Class<?> __class__;

    public Re_ZPrimitiveObject_jimport(Class<?> type) {
        this.__class__    = type;
        this.__ia_array__ = null != __class__ && __class__.isArray();
    }

    @Override
    public Class getJavaClass() {
        return __class__;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Re_ZPrimitiveObject_jimport re_import = (Re_ZPrimitiveObject_jimport) o;
        return Objects.equals(__class__, re_import.__class__);
    }

    @Override
    public int hashCode() {
        return __class__ != null ? __class__.hashCode() : 0;
    }
    @Override
    public String toString() {
        return "Re_JImport{" + __class__ + '}';
    }


    @Override
    public boolean isPrimitive() {
        return true;
    }





}
