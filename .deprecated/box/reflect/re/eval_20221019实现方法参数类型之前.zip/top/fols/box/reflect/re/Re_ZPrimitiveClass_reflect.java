package top.fols.box.reflect.re;

import top.fols.atri.lang.Finals;
import top.fols.box.reflect.re.interfaces.Re_IReInnerVariableMap;
import top.fols.box.reflect.re.interfaces.Re_IReObject;
import top.fols.box.reflect.re.variables.Re_ObjectVariableMap;

import static top.fols.box.reflect.re.Re_Variable.TRUE;

public class Re_ZPrimitiveClass_reflect extends Re_PrimitiveClass {

    @SuppressWarnings("SpellCheckingInspection")
    public static final Re_ZPrimitiveClass_reflect reclass = new Re_ZPrimitiveClass_reflect(Re_Keywords.INNER_CLASS__REFLECT);

    protected Re_ZPrimitiveClass_reflect(String className) {
        super(className);

        {
            final String name = "getName";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) {
                    int length = arguments.length;
                    if (length == 1) {
                        Object clsOrFun = arguments[0];
                        if (null == clsOrFun)
                            return null;

                        if (clsOrFun instanceof Re_IReObject)
                            return ((Re_IReObject)clsOrFun).getName();

                        executor.setThrow(Re_Accidents.unsupported_type(Re_Utilities.getName(clsOrFun)));
                        return null;
                    }
                    executor.setThrow(Re_Accidents.unable_to_process_parameters(name, length));
                    return null;
                }
            });
        }

        {
            final String name = "getPackageName";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) {
                    int length = arguments.length;
                    if (length == 1) {
                        Object ClsOrFun = arguments[0];
                        if (null == ClsOrFun)
                            return null;

                        if (Re_Utilities.isReClass(ClsOrFun))
                            return ((Re_Class)ClsOrFun).getReClassPackageName();

                        executor.setThrow(Re_Accidents.unsupported_type(Re_Utilities.getName(ClsOrFun)));
                        return null;
                    }
                    executor.setThrow(Re_Accidents.unable_to_process_parameters(name, length));
                    return null;
                }
            });
        }

        {
            final String name = "getFunctionParams";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) {
                    int length = arguments.length;
                    if (length == 1) {
                        Object ClsOrFun = arguments[0];
                        if (null == ClsOrFun)
                            return null;

                        if (Re_Utilities.isReFunction(ClsOrFun)) {
                            Re_ClassFunction function = ((Re_ClassFunction) ClsOrFun);
                            String[] strings = new String[function.getParamCount()];
                            for (int i = 0; i< strings.length; i++){
                                strings[i] = function.getParamName(i);
                            }
                            return strings;
                        }

                        executor.setThrow(Re_Accidents.unsupported_type(Re_Utilities.getName(ClsOrFun)));
                        return null;
                    }
                    executor.setThrow(Re_Accidents.unable_to_process_parameters(name, length));
                    return null;
                }
            });
        }

        {
            final String name = "getFunctionParent";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) {
                    int length = arguments.length;
                    if (length == 1) {
                        Object ClsOrFun = arguments[0];
                        if (null == ClsOrFun)
                            return null;

                        if (Re_Utilities.isReFunction(ClsOrFun)) {
                            Re_ClassFunction function = ((Re_ClassFunction) ClsOrFun);
                            return function.getParent();
                        }

                        executor.setThrow(Re_Accidents.unsupported_type(Re_Utilities.getName(ClsOrFun)));
                        return null;
                    }
                    executor.setThrow(Re_Accidents.unable_to_process_parameters(name, length));
                    return null;
                }
            });
        }

        {
            final String name = "getConstructor";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) {
                    int length = arguments.length;
                    if (length == 1) {
                        Object ClsOrFun = arguments[0];
                        if (null == ClsOrFun)
                            return null;

                        if (Re_Utilities.isReClass(ClsOrFun)) {
                            Re_Class reClass = ((Re_Class) ClsOrFun);
                            return reClass.getInitFunction();
                        }

                        executor.setThrow(Re_Accidents.unsupported_type(Re_Utilities.getName(ClsOrFun)));
                        return null;
                    }
                    executor.setThrow(Re_Accidents.unable_to_process_parameters(name, length));
                    return null;
                }
            });
        }


        {
            final String name = "copyAttr";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) throws Throwable {
                    Re_Class runClass = executor.getReClass();
                    if (null == runClass) {
                        executor.setThrow(Re_Accidents.executor_no_bind_class());
                        return null;
                    }
                    for (Object argument : arguments) {
                        Re_Class reClass = Re_Utilities.getReClassFromIReGetClass(argument);
                        if (null == reClass)
                            continue;

                        Iterable<?> variableKeys = reClass.getVariableKeys(executor);
                        if (executor.isReturnOrThrow()) return null;

                        for (Object k : variableKeys) {
                            Re_Variable<?> variable = Re_Variable.Unsafes.cloneVariable(k, reClass);

                            Re_Variable.accessPutNewVariable(executor, k, variable, runClass);
                            if (executor.isReturnOrThrow()) return null;
                        }
                    }
                    return TRUE.get();
                }
            });
        }


        {
            final String name = "invokeInit";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) throws Throwable {
                    int length = arguments.length;
                    if (length == 2) {
                        Re_Class runClass = executor.getReClass();
                        if (null == runClass) {
                            executor.setThrow(Re_Accidents.executor_no_bind_class());
                            return null;
                        }
                        Re_ClassInstance runInstance = executor.getReClassInstance();
                        if (null == runInstance) {
                            executor.setThrow(Re_Accidents.executor_no_bind_class_instance());
                            return null;
                        }

                        //需要执行的特定的类构造器
                        Re_Class findClass = Re_Utilities.getReClassFromIReGetClass(arguments[0]);
                        if (null != arguments[0] && !Re_Utilities.isReClass(findClass)) {
                            executor.setThrow("not a reClass: " + Re_Utilities.getName(arguments[0]));
                            return null;
                        }
                        Re_ClassFunction findInitFunction = findClass.getInitFunction();
                        if (null == findInitFunction) {
                            return null;
                        }

                        Object[] argumentArr;
                        Object   argumentArr0 = arguments[1];
                        if (null == argumentArr0) {
                            argumentArr = Finals.EMPTY_OBJECT_ARRAY;
                        } else {
                            argumentArr = Re_Utilities.toarray(executor, argumentArr0);
                            if (executor.isReturnOrThrow()) return null;
                        }

                        Re_IReInnerVariableMap variableMap = Re_ClassFunction.getArgumentsArrayAsVariableMap(argumentArr, findInitFunction);
                        return findInitFunction.invoke(executor, runClass, runInstance, argumentArr, variableMap);
                    }
                    executor.setThrow(Re_Accidents.unable_to_process_parameters(name, length));
                    return null;
                }
            });
        }
        {
            final String name = "invokeFunction";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) throws Throwable {
                    int length = arguments.length;
                    if (length == 4) {

                        Re_Class reClass = Re_Utilities.getReClassFromIReGetClass(arguments[0]);
                        if (null != arguments[0] && !Re_Utilities.isReClass(reClass)) {
                            executor.setThrow("not a reClass: " + Re_Utilities.getName(arguments[0]));
                            return null;
                        }

                        Re_ClassInstance reInstance;
                        if (null != arguments[1] && !Re_Utilities.isReClassInstance(arguments[1])) {
                            executor.setThrow("not a reClassInstance: " + Re_Utilities.getName(arguments[1]));
                            return null;
                        } else {
                            reInstance = (Re_ClassInstance)arguments[1];
                        }

                        Re_ClassFunction reFunction;
                        if (null == arguments[2])
                            return null;
                        if (!Re_Utilities.isReFunction(arguments[2])) {
                            executor.setThrow("not a reClassFunction: " + Re_Utilities.getName(arguments[2]));
                            return null;
                        } else {
                            reFunction = (Re_ClassFunction) arguments[2];
                        }

                        Object[] argumentArr;
                        Object   argumentArr0 = arguments[3];
                        if (null == argumentArr0) {
                            argumentArr = Finals.EMPTY_OBJECT_ARRAY;
                        } else {
                            argumentArr = Re_Utilities.toarray(executor, argumentArr0);
                            if (executor.isReturnOrThrow()) return null;
                        }

                        Re_IReInnerVariableMap variableMap = Re_ClassFunction.getArgumentsArrayAsVariableMap(argumentArr, reFunction);
                        return reFunction.invoke(executor, reClass, reInstance, argumentArr, variableMap);
                    }
                    executor.setThrow(Re_Accidents.unable_to_process_parameters(name, length));
                    return null;
                }
            });
        }






        {
            final String name = "invoke";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) throws Throwable {
                    int length = arguments.length;
                    if (length == 3) {
                        //(instance, name, arguments);

                        Object pFunction = arguments[1];
                        String fName;
                        if (Re_Utilities.isReFunction(pFunction)) {
                            fName = ((Re_ClassFunction) pFunction).getName();
                        } else if (Re_Utilities.isJString(pFunction)) {
                            fName = (String) pFunction;
                        } else {
                            executor.setThrow("invalid name type: " + Re_Utilities.getName(pFunction));
                            return null;
                        }

                        Re_Class reClass;
                        Re_ClassInstance reClassInstance;
                        Re_ClassFunction function;

                        Object pInstance = arguments[0];
                        if (Re_Utilities.isReClass(pInstance)) {
                            reClassInstance = null;
                            reClass = (Re_Class) pInstance;
                            Object o = Re_Variable.accessGetClassValue(executor, fName, reClass);
                            if (Re_Utilities.isReFunction(o)) {
                                function = (Re_ClassFunction) o;
                            } else {
                                executor.setThrow(Re_Accidents.undefined(reClass, fName));
                                return null;
                            }
                        } else if (Re_Utilities.isReClassInstance(pInstance)) {
                            reClassInstance = (Re_ClassInstance) pInstance;
                            reClass = reClassInstance.getReClass();
                            Object o = Re_Variable.accessGetInstanceValue(executor, fName, reClassInstance);
                            if (Re_Utilities.isReFunction(o)) {
                                function = (Re_ClassFunction) o;
                            } else {
                                executor.setThrow(Re_Accidents.undefined(reClassInstance, fName));
                                return null;
                            }
                        } else {
                            executor.setThrow("not a reClass or reClassInstance: "+ Re_Utilities.getName(pInstance));
                            return null;
                        }

                        Object   pArgs_  = arguments[2];
                        Object[] args;
                        if (null == pArgs_) {
                            args = Finals.EMPTY_OBJECT_ARRAY;
                        } else {
                            args = Re_Utilities.toarray(executor, pArgs_);
                            if (executor.isReturnOrThrow()) return null;
                        }
                        Re_IReInnerVariableMap variableMap = Re_ClassFunction.getArgumentsArrayAsVariableMap(args, function);
                        return function.invoke(executor, reClass, reClassInstance, args, variableMap);
                    }
                    executor.setThrow(Re_Accidents.unable_to_process_parameters(name, length));
                    return null;
                }
            });
        }

    }


    @Override
    public Re_PrimitiveClassInstance createInstance() {
        return createInstance(this);
    }
    @Override
    public Re_PrimitiveClassInstance createInstance(Re_Class reClass) {
        return new Re_PrimitiveClassInstance(reClass, new Re_ObjectVariableMap());
    }
}
