package top.fols.box.reflect.re.primitive.iterable;

import top.fols.box.reflect.re.Re_Executor;
import top.fols.box.reflect.re.Re_Variable;

@SuppressWarnings("rawtypes")
public abstract class Re_AReIterator {
    public abstract Re_Variable key_variable();
    public abstract Re_Variable value_variable();

    public abstract boolean hasNext();


    //每次 next都会 设置key和value
    public abstract void next(Re_Executor executor) throws Throwable;
}
