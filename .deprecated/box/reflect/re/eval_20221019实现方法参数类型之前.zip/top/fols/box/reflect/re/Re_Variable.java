package top.fols.box.reflect.re;

import top.fols.atri.lang.Objects;
import top.fols.atri.util.annotation.Nullable;
import top.fols.box.reflect.re.interfaces.Re_IReInnerVariableMap;
import top.fols.box.reflect.re.interfaces.Re_IReObject;
import top.fols.atri.util.annotation.NotNull;

import java.util.Map;

import static top.fols.box.reflect.re.Re_CodeLoader._CompileTimeCodeSourceReader.getBaseDataToDeclareString;

/**
 * 变量存储器，和对象不是一个概念
 * 变量是用来存储对象的
 *
 * 不能继承变量
 * 不能继承变量
 * 不能继承变量
 *
 * ，所有变量类型都预置好了
 */
@SuppressWarnings({"StaticInitializerReferencesSubClass", "rawtypes", "unchecked", "JavadocDeclaration", "JavaDoc", "ConstantConditions"})
public class Re_Variable<E> implements Cloneable {
    static final Object  VALUE_NULL  = null;
    static final Boolean VALUE_TRUE  = true;
    static final Boolean VALUE_False = false;


    static public final Compile_Null_Variable    Null  = new Compile_Null_Variable();
    static public final Compile_Boolean_Variable TRUE  = new Compile_Boolean_Variable(VALUE_TRUE);
    static public final Compile_Boolean_Variable FALSE = new Compile_Boolean_Variable(VALUE_False);


    public static <T> Re_Variable<T>   createVar(T object)   {return new Re_Variable<>(object);}

    public static BuiltinReusingTempIntegerVariable createReusingTempIntegerVariable(int javavalue)  {return new BuiltinReusingTempIntegerVariable(javavalue);}
    public static BuiltinReusingTempObjectVariable  createReusingTempObjectVariable(Object javavalue){return new BuiltinReusingTempObjectVariable(javavalue);}


    public static Compile_Null_Variable     createCompileNull()                 {return Null;}
    public static Compile_Boolean_Variable  createCompileBoolean(boolean value) {return value? TRUE : FALSE;}
    public static Compile_Long_Variable     createCompileLong(long value)       {return new Compile_Long_Variable(value);}
    public static Compile_Float_Variable    createCompileFloat(float value)     {return new Compile_Float_Variable(value);}
    public static Compile_Double_Variable   createCompileDouble(double value)   {return new Compile_Double_Variable(value);}
    public static Compile_Short_Variable    createCompileShort(short value)     {return new Compile_Short_Variable(value);}
    public static Compile_Byte_Variable     createCompileByte(byte value)       {return new Compile_Byte_Variable(value);}
    public static Compile_Char_Variable     createCompileChar(char value)       {return new Compile_Char_Variable(value);}
    public static Compile_Int_Variable      createCompileInt(int value)         {return new Compile_Int_Variable(value);}
    public static Compile_String_Variable   createCompileString(String value)   {return new Compile_String_Variable(value);}

    public static Compile_DynamicVariable_Environment               createCompileEnvironment()               {return Compile_DynamicVariable_Environment.DEFAULT;}
    public static Compile_DynamicVariable_InheritExecutorArguments  createCompileInheritExecutorArguments()  {return Compile_DynamicVariable_InheritExecutorArguments.DEFAULT;}
    public static Compile_DynamicVariable_Arguments                 createCompileArguments()                 {return Compile_DynamicVariable_Arguments.DEFAULT;}
    public static Compile_DynamicVariable_Space                     createCompileSpace()                     {return Compile_DynamicVariable_Space.DEFAULT;}
    public static Compile_DynamicVariable_This                      createCompileThis()                      {return Compile_DynamicVariable_This.DEFAULT;}
    public static Compile_DynamicVariable_Static                    createCompileStatic()                    {return Compile_DynamicVariable_Static.DEFAULT;}



    /**
     * 在Java里执行
     */
    static abstract class InnerAccessor {
        public abstract Object get(Re_Variable variable);
        public abstract void   set(Re_Variable variable, Object value);
        public abstract Re_Variable cloneVariable(Re_Variable variable);

        static final InnerAccessor STATIC_VARIABLE = new InnerAccessor() {
            @Override
            public Object get(Re_Variable variable) {
                return variable.__value__;
            }
            @Override
            public void   set(Re_Variable variable, Object value) {
                variable.__value__ = value;
            }

            @Override
            public Re_Variable cloneVariable(Re_Variable variable) {
                return variable.superClone();
            }
        };


        static final InnerAccessor STATIC_VARIABLE__BUILTIN = new InnerAccessor() {
            @Override
            public Object get(Re_Variable variable) {
                return variable.__value__;
            }
            @Override public void set(Re_Variable variable, Object value) {}

            @Override
            public Re_Variable cloneVariable(Re_Variable variable) {
                return variable.superClone();
            }
        };
        static final InnerAccessor STATIC_VARIABLE__COMPILE_NATIVE = new InnerAccessor() {
            @Override
            public Object get(Re_Variable variable) {
                return variable.__value__;
            }
            @Override public void set(Re_Variable variable, Object value) {}

            @Override
            public Re_Variable cloneVariable(Re_Variable variable) {
                return variable.superClone();
            }
        };
    }
    static class ____________{}

    /**
     * 静态变量必须具备一个 内部服务器
     * 动态变量（运行时变量）是没有 内部访问器， 比如 arguments 和 this static 都是根据Re_Executor获取的
     */
    protected  InnerAccessor getInnerAccessor() {
        return InnerAccessor.STATIC_VARIABLE;
    }
    protected boolean isStaticVariable() {
        return null != getInnerAccessor();
    }
    protected boolean isDynamicVariable() {
        return null == getInnerAccessor();
    }




    protected E __value__;




    private Re_Variable() {}
    private Re_Variable(E __value__) {
        this.__value__ = __value__;
    }


    /**
     * 不能直接在
     * {@link Re_Variable#get(Re_Executor)}
     * {@link Re_Variable#set(Re_Executor, Object)}}
     * 直接判断权限
     */
    protected Object    get(Re_Executor executor) {
        return this.__value__;
    }
    /**
     * 不能直接在
     * {@link Re_Variable#get(Re_Executor)}
     * {@link Re_Variable#set(Re_Executor, Object)}}
     * 直接判断权限
     */
    protected void   set(Re_Executor executor, E value0) {
        this.__value__ = value0;
    }

    /**
     * 注意，这个非常重要 如果返回true 证明它是可以被修改和删除的
     *
     * final变量应该返回false 并将set直接重写为抛出异常
     */
    protected boolean modifiable() {
        return true;
    }


    @SuppressWarnings("MethodDoesntCallSuperMethod")
    @Override
    public Re_Variable clone() {
        if (isStaticVariable()) {
            InnerAccessor innerAccessor1 = this.getInnerAccessor();
            return innerAccessor1.cloneVariable(this);
        }
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (isStaticVariable()) {
            if (o instanceof Re_Variable) {
                Re_Variable other = (Re_Variable) o;
                if (other.isStaticVariable()) {
                    InnerAccessor innerAccessor1 = this. getInnerAccessor();
                    InnerAccessor innerAccessor2 = other.getInnerAccessor();
                    Object o1 = innerAccessor1.get(this);
                    Object o2 = innerAccessor2.get(other);
                    return Objects.equals(o1, o2);
                }
            }
        }
        return false;
    }
    @Override
    public int hashCode() {
        if (isStaticVariable()) {
            InnerAccessor innerAccessor1 = this. getInnerAccessor();
            Object o1 = innerAccessor1.get(this);
            return o1.hashCode();
        }
        return super.hashCode();
    }
    @Override
    public String toString() {
        return super.toString();
    }












    //no use

    /**
     *  合并所有key
     *
     * @param map1  @NotNull
     */
    public static Iterable key(@NotNull Re_IReInnerVariableMap map1) {
        return map1.innerGetVariableKeys();
    }

//    public static Iterable margeKey(@NotNull Re_IReInnerVariableMap... map1) {
//        if (null == map1) {
//            return new LinkedHashSet();
//        } else {
//            if (map1.length == 1) {
//                return map1[0].innerGetVariableKeys();
//            }
//            Set list = new LinkedHashSet();
//            for (int i = map1.length-1; i > 0; i--) {
//                for (Object o : map1[i].innerGetVariableKeys()) {
//                    list.add(o);
//                }
//            }
//            return list;
//        }
//    }
//    public static Iterable key(@NotNull Re_IReInnerVariableMap map1, @NotNull Re_IReInnerVariableMap map2) {
//        return margeKey(map1, map2);
//    }
//    public static Iterable key(@NotNull Re_IReInnerVariableMap map1, @NotNull Re_IReInnerVariableMap map2, @NotNull Re_IReInnerVariableMap map3) {
//        return margeKey(map1, map2, map3);
//    }
//    public static Iterable key(@NotNull Re_IReInnerVariableMap map1, @NotNull Re_IReInnerVariableMap map2, @NotNull Re_IReInnerVariableMap map3, @NotNull Re_IReInnerVariableMap map4) {
//        return margeKey(map1, map2, map3, map4);
//    }



    public static int size(@NotNull Re_IReInnerVariableMap map1) {
        return map1.innerGetVariableCount();
    }




    /**
     * @param key @NotNull
     * @param map1  @NotNull
     *
     * 不会向上查找
     */
    public static boolean has(@NotNull Object key,
                              @NotNull Re_IReInnerVariableMap map1) {
        return map1.innerContainsVariable(key);
    }




    public static void accessClear(Re_Executor executor, @NotNull Re_IReInnerVariableMap map1) {
        for (Object key: map1.innerGetVariableKeys()) {
            Re_Variable.accessRemove(executor, key, map1);
            if (executor.isThrow()) return;
        }
    }


    /**
     *  @see Re_Variable#set(Re_Executor, Object)
     * @param key @NotNull
     * @param map1  @NotNull
     *
     * 不会向上查找
     */
    public static boolean accessRemove(Re_Executor executor, @NotNull Object key, @NotNull Re_IReInnerVariableMap map1) {
        Re_Variable variable = map1.innerGetVariable(key);
        if (null != variable && variable.modifiable()) {
            map1.innerRemoveVariable(key);
            return true;
        }
        return false;
    }


    /**
     * @see Re_Variable#set(Re_Executor, Object)
     * 如果已经存在变量 会 执行{@link Re_Variable#set(Re_Executor, Object)}
     *
     * 应该由执行时设置 因为
     * 变量名执行前都是经过 {@link String#intern()} 的
     *
     * 在 {@link Re_IReObject} 或者 {@link Re_IReInnerVariableMap} 方法中如果name没有被你改变可以直接执行该方法
     *
     * 不规则方法
     *  {@link Re_Executor#executeGVFromReObject(Re_IReObject, Re_CodeLoader.Call)}
     *  {@link Re_Executor#executeGVFromJavaArray(Object, Re_CodeLoader.Call)}
     *
     *  不会向上查找
     */
    public static void accessSetValue(Re_Executor executor, @NotNull Object key, Object value, @NotNull Re_IReInnerVariableMap map) {
        Re_Variable variable = map.innerGetVariable(key);
        if (null != variable) {
            variable.set(executor, value);
        } else {
            map.innerPutVariable(key, new Re_Variable(value));
        }
    }




    /**
     * 一般为动态添加的时候使用
     *
     * 如果不存在变量才会创建新的变量，Key将会被转换为 {@link Re_CodeLoader#intern(Object)}
     * 如果已存在将不会 {@link Re_CodeLoader#intern(Object)} 变量中的原始key将不会变化
     *
     *  不会向上查找
     */

    public static void accessPutNewVariable(Re_Executor executor, @NotNull Object key, @NotNull Re_Variable newVariable, @NotNull Re_IReInnerVariableMap map) {
        //var name not null
        Re_Variable variable = map.innerGetVariable(key);
        if (null != variable) {
            if (variable.modifiable()) {
                map.innerPutVariable(key, newVariable);
            } else {
                String s = Re_Utilities.toJString(key);
                executor.setThrow("unmodifiable variable: " + s);
            }
        } else {
            map.innerPutVariable(key, newVariable);
        }
    }




    public static Object accessGetValue(Re_Executor executor, @NotNull Object key,
                                        @NotNull Re_IReInnerVariableMap variableMap) {
        Re_Variable re_variable = variableMap.innerGetVariable(key);
        return re_variable.get(executor);
    }



    /**
     * 不会向上查询
     */
    public static Object accessGetClassValue(Re_Executor executor,
                                             @NotNull Object key,
                                             @NotNull Re_Class reClass) {
        if (Re_Utilities.isReClass(reClass)) {
            Re_Variable variable = reClass.innerGetVariable(key);
            if (null != variable) {
                return  variable.get(executor);
            }
        }
        throw new Re_Accidents.ExecuteException("not a reClass: " + Re_Utilities.getName(reClass));
    }
    /**
     * 会向上查询 实例变量和类变量表
     */
    public static Object accessGetInstanceValue(Re_Executor executor,
                                                @NotNull Object key,
                                                @NotNull Re_ClassInstance instance) {
        Re_Variable variable = instance.innerGetVariable(key);
        if (null == variable) {
            variable = instance.getReClass().innerGetVariable(key);
            if (null == variable) {
                return null;
            }
        }
        return variable.get(executor);
    }






    /**
     * 如果不存在将会设置 {@link Re_Executor#setThrow(String)} }
     * 会向上查询
     */
    public static Object accessFindMapOrParentValueRequire(@NotNull Re_Executor executor, @NotNull Object key,
                                                           @NotNull Re_IReInnerVariableMap map1) {
        Re_Variable variable = map1.innerFindMapOrParentVariable(key);
        if (null != variable) {
            return variable.get(executor);
        }
        String s = Re_Utilities.toJString(key);
        executor.setThrow(Re_Accidents.undefined(s));
        return null;
    }
    /**
     * 如果不存在将会设置 {@link Re_Executor#setThrow(String)} }
     * 会向上查询
     */
    public static Object accessFindMapOrParentValueRequire(@NotNull Re_Executor executor, @NotNull Object key,
                                                           @NotNull Re_IReInnerVariableMap map1, @NotNull Re_IReInnerVariableMap map2) {
        Re_Variable variable = map1.innerFindMapOrParentVariable(key);
        if (null != variable) {
            return variable.get(executor);
        } else {
            variable = map2.innerFindMapOrParentVariable(key);
            if (null != variable) {
                return variable.get(executor);
            }
        }
        String s = Re_Utilities.toJString(key);
        executor.setThrow(Re_Accidents.undefined(s));
        return null;
    }







    /**
     * @param key @NotNull
     * @param map1  @NotNull
     *
     *  会向上查找
     */
    public static Object accessFindMapValue(Re_Executor executor, @NotNull Object key,
                                                    @NotNull Re_IReInnerVariableMap map1) {
        Re_Variable variable = map1.innerFindMapVariable(key);
        if (null != variable) {
            return  variable.get(executor);
        }
        return null;
    }



    /**
     * 不可修改
     */
    protected static class Builtin<E> extends Re_Variable<E> {
        private Builtin() {}
        private Builtin(E value0) {
            super(value0);
        }

        @Override
        protected  InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__BUILTIN;
        }

        @Override
        protected void set(Re_Executor executor, Object value0) {
            executor.setThrow("unmodifiable builtin variable");
        }
        @Override
        protected boolean modifiable() {
            return false;
        }
    }



    @SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class BuiltinReusingTempIntegerVariable extends Builtin<Integer> {
        public int cache;

        private BuiltinReusingTempIntegerVariable(int javavalue) {
            cache = javavalue;
            __value__ = new Integer(javavalue);
        }

        @Override
        protected Object get(Re_Executor executor) {
            return (__value__.intValue() == cache)?__value__:(__value__ = new Integer(cache));
        }

        public Object get() {
            return (__value__.intValue() == cache)?__value__:(__value__ = new Integer(cache));
        }
    }



    @SuppressWarnings("unchecked")
    public static class BuiltinReusingTempObjectVariable extends Builtin {
        private BuiltinReusingTempObjectVariable(Object value) {
            super(value);
        }

        public Object get() {
            return super.__value__;
        }
        public void set(Object value) {
            super.__value__ = value;
        }
    }




    static class ______________{}









    public static class Compile_Null_Variable extends Builtin<Object> implements Re_CodeFile.IRe_CompileVariable {
        private Compile_Null_Variable() {
            super(VALUE_NULL);
        }
        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__COMPILE_NATIVE;
        }


        @Override
        protected Object get(Re_Executor executor) {
            return VALUE_NULL;
        }

        public Object get() {
            return VALUE_NULL;
        }

        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }


    @SuppressWarnings({"BooleanConstructorCall", "UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Compile_Boolean_Variable extends Builtin<Boolean> implements Re_CodeFile.IRe_CompileVariable {
        private static final Boolean JAVA_CACHE_TRUE  = true;  //java auto boxing cache
        private static final Boolean JAVA_CACHE_FALSE = false; //java auto boxing cache

        final boolean cache;

        private Compile_Boolean_Variable(boolean javavalue) {
            cache = javavalue;
            __value__ = javavalue? JAVA_CACHE_TRUE : JAVA_CACHE_FALSE;
        }
        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__COMPILE_NATIVE;
        }


        @Override
        protected Boolean get(Re_Executor executor) {
            return (__value__.booleanValue() == cache)?__value__:(__value__ = new Boolean(cache));
        }

        public Boolean get() {
            return (__value__.booleanValue() == cache)?__value__:(__value__ = new Boolean(cache));
        }



        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }


    @SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Compile_Long_Variable extends Builtin<Long> implements Re_CodeFile.IRe_CompileVariable {
        final long cache;

        private Compile_Long_Variable(long javavalue) {
            cache = javavalue;
            __value__ = new Long(javavalue);
        }

        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__COMPILE_NATIVE;
        }


        @Override
        protected Long get(Re_Executor executor) {
            return (__value__.longValue() == cache)?__value__:(__value__ = new Long(cache));
        }

        public Long get() {
            return (__value__.longValue() == cache)?__value__:(__value__ = new Long(cache));
        }

        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }
    @SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Compile_Float_Variable extends Builtin<Float> implements Re_CodeFile.IRe_CompileVariable {
        final float cache;

        private Compile_Float_Variable(float javavalue) {
            cache = javavalue;
            __value__ = new Float(javavalue);
        }

        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__COMPILE_NATIVE;
        }


        @Override
        protected Float get(Re_Executor executor) {
            return (__value__.floatValue() == cache)?__value__:(__value__ = new Float(cache));
        }

        public Float get() {
            return (__value__.floatValue() == cache)?__value__:(__value__ = new Float(cache));
        }


        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }
    @SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Compile_Double_Variable extends Builtin<Double> implements Re_CodeFile.IRe_CompileVariable {
        final double cache;

        private Compile_Double_Variable(double javavalue) {
            cache = javavalue;
            __value__ = new Double(javavalue);
        }

        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__COMPILE_NATIVE;
        }


        @Override
        protected Double get(Re_Executor executor) {
            return (__value__.doubleValue() == cache)?__value__:(__value__ = new Double(cache));
        }

        public Double get() {
            return (__value__.doubleValue() == cache)?__value__:(__value__ = new Double(cache));
        }

        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }

    @SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Compile_Short_Variable extends Builtin<Short> implements Re_CodeFile.IRe_CompileVariable {
        final short cache;

        private Compile_Short_Variable(short javavalue) {
            cache = javavalue;
            __value__ = new Short(javavalue);
        }

        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__COMPILE_NATIVE;
        }


        @Override
        protected Short get(Re_Executor executor) {
            return (__value__.shortValue() == cache)?__value__:(__value__ = new Short(cache));
        }

        public Short get() {
            return (__value__.shortValue() == cache)?__value__:(__value__ = new Short(cache));
        }


        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }


    @SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Compile_Byte_Variable extends Builtin<Byte> implements Re_CodeFile.IRe_CompileVariable {
        final byte cache;
        private Compile_Byte_Variable(byte javavalue) {
            cache = javavalue;
            __value__ = new Byte(javavalue);
        }

        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__COMPILE_NATIVE;
        }


        @Override
        protected Byte get(Re_Executor executor) {
            return (__value__.byteValue() == cache)?__value__:(__value__ = new Byte(cache));
        }
        public Byte get() {
            return (__value__.byteValue() == cache)?__value__:(__value__ = new Byte(cache));
        }


        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }

    @SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Compile_Char_Variable extends Builtin<Character> implements Re_CodeFile.IRe_CompileVariable {
        final char cache;

        private Compile_Char_Variable(char javavalue) {
            cache = javavalue;
            __value__ = new Character(javavalue);
        }

        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__COMPILE_NATIVE;
        }


        @Override
        protected Character get(Re_Executor executor) {
            return (__value__.charValue() == cache)?__value__:(__value__ = new Character(cache));
        }

        public Character get() {
            return (__value__.charValue() == cache)?__value__:(__value__ = new Character(cache));
        }


        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }



    @SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Compile_Int_Variable extends Builtin<Integer> implements Re_CodeFile.IRe_CompileVariable {
        final int cache;

        private Compile_Int_Variable(int javavalue) {
            cache = javavalue;
            __value__ = new Integer(javavalue);
        }
        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__COMPILE_NATIVE;
        }


        @Override
        protected Integer get(Re_Executor executor) {
            return (__value__.intValue() == cache)?__value__:(__value__ = new Integer(cache));
        }

        public Integer get() {
            return (__value__.intValue() == cache)?__value__:(__value__ = new Integer(cache));
        }

        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }




    public static class Compile_String_Variable extends Builtin<String> implements Re_CodeFile.IRe_CompileVariable {
        private Compile_String_Variable(String string) {
            super(string);
        }
        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__COMPILE_NATIVE;
        }


        @Override
        protected String get(Re_Executor executor) {
            return __value__;
        }
        public String get() {
            return __value__;
        }

        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }














    public static class Compile_DynamicVariable_Environment extends Builtin implements Re_CodeFile.IRe_CompileVariable {
        private static final Compile_DynamicVariable_Environment DEFAULT = new Compile_DynamicVariable_Environment();

        private Compile_DynamicVariable_Environment() {}
        @Override
        protected InnerAccessor getInnerAccessor() {
            return null;
        }

        /**
         * @param executor 默认无意义
         */
        @Override
        protected Object get(Re_Executor executor) {
            return executor.re.getEnvironmentMap();
        }

        @Override
        public String getCompileDeclareValue() {
            return Re_Keywords.INNER_VAR__ENVIRONMENT;
        }
    }

    public static class Compile_DynamicVariable_InheritExecutorArguments extends Builtin implements Re_CodeFile.IRe_CompileVariable {
        private static final Compile_DynamicVariable_InheritExecutorArguments DEFAULT = new Compile_DynamicVariable_InheritExecutorArguments();


        private Compile_DynamicVariable_InheritExecutorArguments() {}
        @Override
        protected InnerAccessor getInnerAccessor() {
            return null;
        }


        @Override
        protected Object get(Re_Executor  executor) {
            return Re_Executor.findInheritArguments(executor);
        }

        @Override
        public String getCompileDeclareValue() {
            return Re_Keywords.INNER_VAR__INHERIT_FUN_ARGUMENTS_ARGUMENTS;
        }
    }

    public static class Compile_DynamicVariable_Arguments extends Builtin implements Re_CodeFile.IRe_CompileVariable {
        private static final Compile_DynamicVariable_Arguments DEFAULT = new Compile_DynamicVariable_Arguments();

        private Compile_DynamicVariable_Arguments() {
        }
        @Override
        protected InnerAccessor getInnerAccessor() {
            return null;
        }


        @Override
        protected Object get(Re_Executor executor) {
            return executor.getArguments();
        }

        @Override
        public String getCompileDeclareValue() {
            return Re_Keywords.INNER_VAR__FUN_ARGUMENTS_ARGUMENTS;
        }
    }

    public static class Compile_DynamicVariable_Space extends Builtin implements Re_CodeFile.IRe_CompileVariable {
        private static final Compile_DynamicVariable_Space DEFAULT = new Compile_DynamicVariable_Space();

        private Compile_DynamicVariable_Space() {}
        @Override
        protected InnerAccessor getInnerAccessor() {
            return null;
        }


        @Override
        protected Object get(Re_Executor executor) {
            return executor;
        }

        @Override
        public String getCompileDeclareValue() {
            return Re_Keywords.INNER_VAR__SPACE;
        }
    }

    public static class Compile_DynamicVariable_This extends Builtin implements Re_CodeFile.IRe_CompileVariable {
        private static final Compile_DynamicVariable_This DEFAULT = new Compile_DynamicVariable_This();

        private Compile_DynamicVariable_This() {}
        @Override
        protected InnerAccessor getInnerAccessor() {
            return null;
        }

        /**
         * @param executor 默认无意义
         */
        @Override
        protected Object get(Re_Executor executor) {
            Re_ClassInstance reClassInstance = executor.reClassInstance;
            if (null != reClassInstance) {
                return  reClassInstance;
            }
            executor.setThrow(Re_Accidents.executor_no_bind_class_instance());
            return null;
        }


        @Override
        public String getCompileDeclareValue() {
            return Re_Keywords.INNER_VAR__THIS;
        }
    }

    public static class Compile_DynamicVariable_Static extends Builtin implements Re_CodeFile.IRe_CompileVariable {
        private static final Compile_DynamicVariable_Static DEFAULT = new Compile_DynamicVariable_Static();


        private Compile_DynamicVariable_Static() {}
        @Override
        protected InnerAccessor getInnerAccessor() {
            return null;
        }


        /**
         * @param executor 默认无意义
         */
        @Override
        protected Object get(Re_Executor executor) {
            Re_Class reClass = executor.reClass;
            if (null != reClass) {
                return  reClass;
            }
            executor.setThrow(Re_Accidents.executor_no_bind_class());
            return null;
        }


        @Override
        public String getCompileDeclareValue() {
            return Re_Keywords.INNER_VAR__STATIC;
        }
    }



    static class _____________{}






    /**
     * 在Java里执行
     */
    @SuppressWarnings({"rawtypes", "SpellCheckingInspection"})
    public static class Unsafes {
        private Unsafes(){}

        public static <T extends Re_IReInnerVariableMap> T clone(T variableMap)  {
            return (T) variableMap.innerCloneVariableMap();
        }

        public static <K> Map<K, Re_Variable> copy(Map<K, Re_Variable> from, Map<K, Re_Variable> to) {
            for (K k : from.keySet()) {
                Re_Variable v = from.get(k);
                v = v.clone(); //克隆变量

                to.put(k, v);
            }
            return to;
        }

        /**
         * 一般为动态添加的时候使用
         *
         * 如果不存在 Key将会被转换为 {@link Re_CodeLoader#intern(Object)} 再提交
         * 如果已存在将不会 {@link Re_CodeLoader#intern(Object)} 变量中的原始key将不会变化
         */
        public static void setVariableIntern(@NotNull Object key, @NotNull Re_Variable variable, @NotNull Re_IReInnerVariableMap map1) {
            map1.innerPutVariable(Re_CodeLoader.intern(key), variable);
        }
        public static void putVariable(@NotNull Object key, @NotNull Re_Variable variable, @NotNull Re_IReInnerVariableMap map1) {
            map1.innerPutVariable(key, variable);
        }

        /**
         * @see Re_Variable#set(Re_Executor, Object)
         * 如果已经存在变量 会异常
         *
         * 一般为动态添加的时候使用
         * 如果不存在 Key将会被转换为 {@link Re_CodeLoader#intern(Object)} 再提交
         *
         * 不会向上查询
         */
        public static void addVariableIntern(@NotNull Object key, @NotNull Re_Variable value, @NotNull Re_IReInnerVariableMap map) {
            //var name not null
            Re_Variable variable = map.innerGetVariable(key);
            if (null != variable) {
                String s = Re_Utilities.toJString(key);
                throw new Re_Accidents.ExecuteException("already set variable: " + s);
            } else {
                map.innerPutVariable(Re_CodeLoader.intern(key), value);
            }
        }

        /**
         * @see Re_Variable#set(Re_Executor, Object)
         * 如果已经存在变量 会 执行{@link Re_Variable#set(Re_Executor, Object)}
         *
         * 应该由执行时设置 因为
         * 变量名执行前都是经过 {@link String#intern()} 的
         * 如果你从 {@link Re_IReObject} 中的回调中 不改变name名称 可以直接使用该方法而不使用 intern
         *
         * 不会向上查询
         */
        public static void addVariable(@NotNull Object key, @NotNull Re_Variable value, @NotNull Re_IReInnerVariableMap map) {
            Re_Variable variable = map.innerGetVariable(key);
            if (null != variable) {
                String s = Re_Utilities.toJString(key);
                throw new Re_Accidents.ExecuteException("already set variable: " + s);
            } else {
                map.innerPutVariable(key, value);
            }
        }

        /**
         * 不会向上查找
         */
        public static boolean removeVariable(@NotNull Object key,
                                             @NotNull Re_IReInnerVariableMap map1) {
            return null != map1.innerRemoveVariable(key);
        }



        /**
         * @see Re_Variable#set(Re_Executor, Object)
         * 如果已经存在变量 会抛出异常
         *
         * 一般为动态添加的时候使用
         * 如果不存在 Key将会被转换为 {@link Re_CodeLoader#intern(Object)} 再提交
         *
         * 不会向上查找
         */
        protected static void addBuiltinValueIntern(@NotNull Object key, @Nullable Object value, @NotNull Re_IReInnerVariableMap map) {
            //var name not null
            Re_Variable variable = map.innerGetVariable(key);
            if (null != variable) {
                String s = Re_Utilities.toJString(key);
                throw new Re_Accidents.ExecuteException("already set variable: " +s);
            } else {
                map.innerPutVariable(Re_CodeLoader.intern(key), new Builtin(value));
            }
        }
        protected static void addBuiltinValueIntern(@Nullable Re_IReObject.IPrimitiveCall primitiveCall, @NotNull Re_IReInnerVariableMap map) {
            addBuiltinValueIntern(primitiveCall.getName(),primitiveCall, map);
        }




        /**
         * 不会向上查找
         */
        public static boolean isStaticVariable(@NotNull Object key, @NotNull Re_IReInnerVariableMap map) {
            Re_Variable variable = map.innerGetVariable(key);
            if (null != variable) {
                return  variable.isStaticVariable();
            }
            return false;
        }
        /**
         * 不会向上查找
         */
        public static boolean isDynamicVariable(@NotNull Object key, @NotNull Re_IReInnerVariableMap map) {
            Re_Variable variable = map.innerGetVariable(key);
            if (null != variable) {
                return  variable.isDynamicVariable();
            }
            return false;
        }



        public static Re_Variable getKeywordVariable(@NotNull Object key) {
            return Re_Keywords.keyword.innerGetVariable(key);
        }

        /**
         * 不会向上搜索
         */
        public static Re_Variable getVariable(@NotNull Object key, @NotNull Re_IReInnerVariableMap map) {
            return map.innerGetVariable(key);
        }



        public static Re_Variable cloneVariable(@NotNull Object key, @NotNull Re_IReInnerVariableMap map) {
            Re_Variable re_variable = map.innerGetVariable(key);
            return null == re_variable?null:re_variable.clone();
        }











        public static Object fromUnsafeAccessorGetValue(@Nullable Object key, Re_IReInnerVariableMap map) {
            Re_Variable variable = map.innerGetVariable(key);
            if (null == variable) {
                return null;
            } else {
                InnerAccessor innerAccessor = variable.getInnerAccessor();
                if (null == innerAccessor) {
                    throw new Re_Accidents.ExecuteException("variable is not direct accessor: " + Re_Utilities.getName(variable));
                }
                return innerAccessor.get(variable);
            }
        }

        /**
         * 不会向上查询
         */
        public static Object fromUnsafeAccessorGetClassValue(@Nullable Object key,
                                                             @NotNull Re_Class reClass) {
            if (Re_Utilities.isReClass(reClass)) {
                Re_Variable variable = reClass.innerGetVariable(key);
                if (null != variable) {
                    return fromUnsafeAccessorGetValue(variable);
                }
                return null;
            }  else {
                throw new Re_Accidents.ExecuteException("not a reClass: " + Re_Utilities.getName(reClass));
            }
        }
        /**
         * 会向上查询 实例变量和类变量表
         */
        public static Object fromUnsafeAccessorGetInstanceValue(@Nullable Object key,
                                                                @NotNull Re_ClassInstance instance) {
            Re_Variable variable = instance.innerGetVariable(key);
            if (null == variable) {
                variable = instance.getReClass().innerGetVariable(key);
                if (null == variable) {
                    return null;
                }
            }
            return fromUnsafeAccessorGetValue(variable);
        }




        public static Object fromUnsafeAccessorGetValue(Re_Variable variable) {
            InnerAccessor innerAccessor = variable.getInnerAccessor();
            if (null == innerAccessor) {
                throw new Re_Accidents.ExecuteException("variable is not direct accessor: " + Re_Utilities.getName(variable));
            }
            return innerAccessor.get(variable);
        }

        public static void fromUnsafeAccessorSetValue(Re_Variable variable, Object v) {
            InnerAccessor innerAccessor = variable.getInnerAccessor();
            if (null == innerAccessor) {
                throw new Re_Accidents.ExecuteException("variable is not direct accessor: " + Re_Utilities.getName(variable));
            }
            innerAccessor.set(variable, v);
        }




        /**
         * 一般为动态添加的时候使用
         *
         * 如果不存在变量才会创建新的变量，Key将会被转换为 {@link Re_CodeLoader#intern(Object)}
         * 如果已存在将不会 {@link Re_CodeLoader#intern(Object)} 变量中的原始key将不会变化
         *
         * 不会向上查询
         */
        public static void fromUnsafeAccessorSetValueIntern(Object key, Object v, Re_IReInnerVariableMap map) {
            Re_Variable variable = map.innerGetVariable(key);
            if (null == variable) {
                map.innerPutVariable(Re_CodeLoader.intern(key), new Re_Variable(v));
            } else {
                InnerAccessor innerAccessor = variable.getInnerAccessor();
                if (null == innerAccessor) {
                    throw new Re_Accidents.ExecuteException("variable is not direct accessor: " + Re_Utilities.getName(variable));
                }
                innerAccessor.set(variable, v);
            }
        }
        /**
         * 不会向上查询
         */
        public static void fromUnsafeAccessorSetValue(Object key, Object v, Re_IReInnerVariableMap map) {
            Re_Variable variable = map.innerGetVariable(key);
            if (null == variable) {
                map.innerPutVariable(key, new Re_Variable(v));
            } else {
                InnerAccessor innerAccessor = variable.getInnerAccessor();
                if (null == innerAccessor) {
                    throw new Re_Accidents.ExecuteException("variable is not direct accessor: " + Re_Utilities.getName(variable));
                }
                innerAccessor.set(variable, v);
            }
        }
    }


    protected Re_Variable superClone() {
        try {
            return (Re_Variable) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }

}
