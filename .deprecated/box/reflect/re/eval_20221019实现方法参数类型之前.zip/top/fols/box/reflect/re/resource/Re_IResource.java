package top.fols.box.reflect.re.resource;

import top.fols.atri.lang.Finals;
import top.fols.atri.util.annotation.Nullable;

import java.nio.charset.Charset;

@SuppressWarnings({"UnnecessaryModifier", "UnnecessaryInterfaceModifier"})
public interface Re_IResource {
	public static final Charset DEFAULT_CONTENT_CHARSET = Finals.Charsets.UTF_8;
	public Charset contentCharset()              ; //默认charset


	/**
	 *
	 * @param path 文件路径
	 * @return 为空则代表没有这个资源或者没有办法读取
	 */
	@Nullable
	public Re_IResourceFile findFileResource(String path); //为空则找不到该资源



	/**
	 *
	 * @param className 类名
	 * @return 为空则代表没有这个资源或者没有办法读取
	 */
	@Nullable
	public Re_IResourceFile findClassResource(String className); //为空则找不到该资源

}
