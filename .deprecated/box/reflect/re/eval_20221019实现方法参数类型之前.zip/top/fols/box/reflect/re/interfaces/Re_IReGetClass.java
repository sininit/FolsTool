package top.fols.box.reflect.re.interfaces;

import top.fols.box.reflect.re.Re_Class;

@SuppressWarnings("UnnecessaryModifier")
public interface Re_IReGetClass {
    public Re_Class getReClass();
}