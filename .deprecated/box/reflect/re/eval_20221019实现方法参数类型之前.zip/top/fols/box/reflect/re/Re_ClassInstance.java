package top.fols.box.reflect.re;

import top.fols.box.reflect.re.interfaces.*;
import top.fols.box.reflect.re.variables.Re_VariableMap;

import java.util.Objects;

import static top.fols.box.reflect.re.Re_ClassFunction.getArgumentsArrayAsVariableMap;

/**
 * 请勿重写
 */
@SuppressWarnings("rawtypes")
public class Re_ClassInstance implements Re_IReObject, Re_IReInnerVariableMap, Re_IReGetDeclaringClass, Re_IReGetClass {
    protected Re_Class reClass;
    protected Re_IReInnerVariableMap variable;
    private String instanceName0;


    /**
     * 克隆实例
     */
    public Re_ClassInstance clone() {
        try {
            Re_ClassInstance clone = (Re_ClassInstance) super.clone();
            clone.reClass = this.reClass;
            clone.variable = Re_Variable.Unsafes.clone(this.variable);
            clone.instanceName0 = null;
            return clone;
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }






    protected Re_ClassInstance(Re_Class reClass) {
        Re_Class.createInstanceAfter(reClass, this, new Re_VariableMap());
    }
    protected Re_ClassInstance(Re_Class reClass, Re_IReInnerVariableMap variableMap) {
        Re_Class.createInstanceAfter(reClass, this, variableMap);
    }







    @Override
    public Re_Class getReClass() {
        return reClass;
    }

    @Override
    public Re_Class getReDeclareClass() {
        return reClass;
    }


    @Override
    public String getName() {
        return getInstanceName();
    }


    public final String getInstanceName() {
        if (null != instanceName0)
            return  instanceName0;
        return instanceName0 = reClass.getName() + "@" + System.identityHashCode(this);
    }




    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Re_ClassInstance)) return false;

        Re_ClassInstance that = (Re_ClassInstance) o;
        return Objects.equals(reClass,  that.reClass)  &&
               Objects.equals(variable, that.variable);
    }

    @Override
    public int hashCode() {
        int result = reClass != null ? reClass.hashCode() : 0;
        result = 31 * result + (variable != null ? variable.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return getInstanceName();
    }


    @Override
    public boolean isPrimitive() {
        return false;
    }









    /**
     * 原始获取
     * 理论上你必须使用 {@link Re_Variable} 而不是自己操作， 这些方法主要 {@link Re_Variable} 调用
     *
     *            递归获取
     */
    @Override
    public Re_Variable innerFindMapOrParentVariable(Object key) {
        Re_Variable re_variable = variable.innerFindMapOrParentVariable(key);
        if (null == re_variable)
            re_variable = reClass.innerFindMapOrParentVariable(key);
        return re_variable;
    }

    @Override
    public Re_Variable innerFindMapVariable(Object key) {
        Re_Variable re_variable = variable.innerFindMapVariable(key);
        if (null == re_variable)
            re_variable = reClass.innerFindMapVariable(key);
        return re_variable;
    }

    @Override
    public Re_Variable innerGetVariable(Object key) {
        return variable.innerGetVariable(key);
    }


    /**
     * 直接删除
     * 理论上你必须使用 {@link Re_Variable} 而不是自己操作， 这些方法主要 {@link Re_Variable} 调用
     *
     */
    @Override
    public Re_Variable innerRemoveVariable(Object key) {
        return variable.innerRemoveVariable(key);
    }

    /**
     * 原始提交
     * 理论上你必须使用 {@link Re_Variable} 而不是自己操作， 这些方法主要 {@link Re_Variable} 调用
     */
    @Override
    public Re_Variable innerPutVariable(Object key, Re_Variable value) {
        return variable.innerPutVariable(key, value);
    }

    @Override
    public boolean innerContainsVariable(Object key) {
        return variable.innerContainsVariable(key);
    }

    /**
     * 数量
     */
    @Override
    public int innerGetVariableCount() {
        return variable.innerGetVariableCount();
    }

    /**
     * @return 变量名
     * 返回不可修改的集合， 或者克隆
     */
    @Override
    public Iterable<?> innerGetVariableKeys() {
        return variable.innerGetVariableKeys();
    }

    @Override
    public Re_IReInnerVariableMap innerCloneVariableMap() {
        return variable.innerCloneVariableMap();
    }





    /**
     * 获取子变量，不是获取自己
     * 只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
     */
    @Override
    public final Object getVariableValue(Re_Executor executor, Object key) {
        return Re_Variable.accessFindMapValue(executor, key, this);
    }


    @Override
    public final boolean containsVariable(Re_Executor executor, Object key) {
        return Re_Variable.has(key, this);
    }

    /**
     * 只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
     */
    @Override
    public final boolean removeVariable(Re_Executor executor, Object key) throws Throwable {
        return Re_Variable.accessRemove(executor, key, this);
    }


    /**
     * 设置子变量，不是设置自己
     * 只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
     */
    @Override
    public final void putVariableValue(Re_Executor executor, Object key, Object value) throws Throwable {
        Re_Variable.accessSetValue(executor, key, value, this);
    }

    @Override
    public final int getVariableCount(Re_Executor executor) throws Throwable {
        return Re_Variable.size(this);
    }

    @Override
    public final Iterable getVariableKeys(Re_Executor executor) throws Throwable {
        return Re_Variable.key(this);
    }

    //方法如果设置名称 的话则设置为final


    /**
     * 执行之前不可能已经return， 如果中间有执行了表达式应该判断表达式是否已经return 如果已经return 则返回return数据 而不是继续操作, 如果已经return返回的任何数据都是无效的
     * <p>
     * 只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
     * <p>
     * 如果你不想处理，建议使用 {@link Re_IReObject#executePoint(Re_Executor, String, Re_CodeLoader.Call)}
     * <p>
     * 假定本对象名称x
     * 那么执行的是 x.x()
     * @param point_key          指子变量名称，假设这是个map里面有个a
     *                            执行的就是map.a();
     * @param call 如果是true 则callParam 为空 ，如果false则 callParam会经过计算后传入
     */
    @Override
    public final Object executePoint(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
        Object funCall = Re_Variable.accessFindMapValue(executor, point_key, this);
        if (executor.isReturnOrThrow()) return null;

        if (Re_Utilities.isReFunction(funCall)) {
            Re_ClassFunction function = (Re_ClassFunction) funCall;

            Object[] arguments = executor.getExpressionValues(call);
            if (executor.isReturnOrThrow()) return null;

            return invoke(executor, function, arguments);
        }
        if (null == funCall) {
            executor.setThrow(Re_Accidents.undefined(this, point_key));
            return null;
        }
        return executor.executeCallThis(funCall, point_key, call);
    }

    /**
     * 已经是实例了 你还要执行？
     */
    @Override
    public final Object executeThis(Re_Executor executor, String that_key, Re_CodeLoader.Call call) throws Throwable {
        return executor.executeGVFromReObject(this, call);
    }




    protected Object invoke(Re_Executor executor, Re_ClassFunction function, Object[] arguments) throws Throwable {
        Re_IReInnerVariableMap variableMap = getArgumentsArrayAsVariableMap(arguments, function);
        //最后一行 不需要判断return
        //指定某个实例运行特定方法, 这个方法不一定是在这个类声明的 但是可以强制运行
        return function.invoke(executor, reClass, this, arguments, variableMap);
    }

}
