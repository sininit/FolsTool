package top.fols.box.reflect.re;


public class Re_PrimitiveClassFunction extends Re_ClassFunction {
    public Re_PrimitiveClassFunction(String name,
                                     Re_Class declaringReClass, Re_ClassInstance declaringReClassInstance) {
        this(name,null,
                declaringReClass, declaringReClassInstance);
    }
    public Re_PrimitiveClassFunction(String name, String[] param,
                                     Re_Class declaringReClass, Re_ClassInstance declaringReClassInstance) {
        Re_CodeFile codeBlock;
        codeBlock = new Re_CodeFile();
        codeBlock.filePath = getClass().getName();

        Re_ClassFunction.createAfter(this, codeBlock, name, param, null,
                declaringReClass, declaringReClassInstance);
    }


    public static class PrimitiveClassInitFunction extends Re_PrimitiveClassFunction {
        public PrimitiveClassInitFunction(Re_Class declaringReClass, Re_ClassInstance declaringReClassInstance) {
            this(null,
                    declaringReClass, declaringReClassInstance);
        }
        public PrimitiveClassInitFunction(String[] param,
                                          Re_Class reDeclaringClass, Re_ClassInstance declaringReClassInstance) {
            super(Re_Keywords.INNER_EXPRESSION_CALL__SET_INIT_FUNCTION, param,
                    reDeclaringClass, declaringReClassInstance);
        }
    }
}
