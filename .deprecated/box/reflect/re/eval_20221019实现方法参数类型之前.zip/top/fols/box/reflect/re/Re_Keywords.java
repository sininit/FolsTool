package top.fols.box.reflect.re;

import top.fols.atri.lang.Classz;
import top.fols.atri.lang.Finals;
import top.fols.box.lang.Classx;
import top.fols.box.reflect.re.interfaces.Re_IReObject;
import top.fols.box.reflect.re.primitive.iterable.Re_ReIterables;
import top.fols.box.reflect.re.variables.Re_KeywordVariableMap;

import java.lang.reflect.*;

import static top.fols.box.reflect.re.Re_CodeLoader.*;
import static top.fols.box.reflect.re.Re_Variable.FALSE;
import static top.fols.box.reflect.re.Re_Variable.TRUE;

@SuppressWarnings({"DanglingJavadoc", "UnnecessaryBoxing", "BooleanConstructorCall", "rawtypes"})
public class Re_Keywords {
    Re_Keywords(){}

    //-----------------------------------------------表达式
    static public final String INNER_EXPRESSION_CALL__IMPORT            = "import";
    static public final String INNER_EXPRESSION_CALL__CLASS             = "class";
    static public final String INNER_EXPRESSION_CALL__SET_INIT_FUNCTION = "init";
    static public final String INNER_EXPRESSION_CALL__FUNCTION          = "function";
    static public final String INNER_EXPRESSION_CALL__INHERIT           = "inherit";

    static public final String INNER_EXPRESSION_CALL__WHILE             = "while";
    static public final String INNER_EXPRESSION_CALL__FOR               = "for";
    static public final String INNER_EXPRESSION_CALL__FOREACH           = "foreach";

    static public final String INNER_EXPRESSION_CALL__TRY               = "try";
    static public final String INNER_EXPRESSION_CALL__CATCH             = "catch";
    static public final String INNER_EXPRESSION_CALL__FINALLY           = "finally";

    static public final String INNER_EXPRESSION_CALL__IF                = "if";
    static public final String INNER_EXPRESSION_CALL__ELSE              = "else";
    //-----------------------------------------------


    //-----------------------------------------------表达式-关键词
    public static final String INNER_EXPRESSION_VAR__DEBUGGER   = "debugger";
    public static final String INNER_EXPRESSION_VAR__BREAK      = "break";
    public static final String INNER_EXPRESSION_VAR__CONTINUE   = "continue";
    //-----------------------------------------------






    // (true, false) --> false 空名字方法 全部执行 返回最后一个值（如果return 将会中断）
    public static final String INNER_FUNCTION__             = "";

    //-----------------------------------------------计算和自动转换
    public static final String INNER_FUNCTION__TILDE        = "~";      //不会自动转换

    /**
     * 内置自动符号转换计算方法  {@link Re_Math#getAutomaticConversionOperator()}
     */
    public static final String INNER_MATH_FUNCTION__AAND            = "&&";
    public static final String INNER_MATH_FUNCTION__AND             = "&";

    public static final String INNER_MATH_FUNCTION__OR              = "|";
    public static final String INNER_MATH_FUNCTION__OOR             = "||";

    public static final String INNER_MATH_FUNCTION__XOR             = "^";

    public static final String INNER_MATH_FUNCTION__SHIFT_RIGHT             = ">>";
    public static final String INNER_MATH_FUNCTION__SHIFT_LEFT              = "<<";
    public static final String INNER_MATH_FUNCTION__UNSIGNED_SHIFT_RIGHT    = ">>>";

    public static final String INNER_MATH_FUNCTION__ADD             = "+";
    public static final String INNER_MATH_FUNCTION__SUBTRACT        = "-";
    public static final String INNER_MATH_FUNCTION__MULTIPLY        = "*";
    public static final String INNER_MATH_FUNCTION__DIVICE          = "/";
    public static final String INNER_MATH_FUNCTION__MOD             = "%";

    public static final String INNER_MATH_FUNCTION__NE              = "!=";
    public static final String INNER_MATH_FUNCTION__EQ              = "==";

    public static final String INNER_MATH_FUNCTION__EQO             = "===";
    public static final String INNER_MATH_FUNCTION__NEQO            = "!==";

    public static final String INNER_MATH_FUNCTION__GREATER         = ">";
    public static final String INNER_MATH_FUNCTION__LESS            = "<";
    public static final String INNER_MATH_FUNCTION__LESS_EQ         = "<=";
    public static final String INNER_MATH_FUNCTION__EQ_LESS         = "=<";
    public static final String INNER_MATH_FUNCTION__EQ_GREATER      = "=>";
    public static final String INNER_MATH_FUNCTION__GREATER_EQ      = ">=";

    //----------

    public static final String INNER_MATH_FUNCTION__COLON_SET_VALUE          = ":";
    //-----------------------------------------------



    //-----------------------------------------------内置类
    public static final String INNER_CLASS__OBJECT      = "object";
    public static final String INNER_CLASS__LIST        = "list";
    public static final String INNER_CLASS__JSON        = "json";
    public static final String INNER_CLASS__REFLECT     = "reflect";
    public static final String INNER_CLASS__EXCEPTION   = "exception";
    //-----------------------------------------------





    static public final String INNER_VAR__THIS      = "this";
    static public final String INNER_VAR__STATIC    = "static";
    //返回原始对象//
    static public final String INNER_VAR__ENVIRONMENT = "env";
    //返回原始对象//
    static public final String INNER_VAR__SPACE       = "space";


    static public final String INNER_VAR__TRUE      = "true";
    static public final String INNER_VAR__FALSE     = "false";
    static public final String INNER_VAR__NULL      = "null";

    static public final String INNER_VAR__FUN_ARGUMENTS_ARGUMENTS           = "arguments";        //function 参数
    static public final String INNER_VAR__FUN_ARGUMENTS_ARGUMENTS_$         = "$";              //function 参数

    static public final String INNER_VAR__INHERIT_FUN_ARGUMENTS_ARGUMENTS   = "arguments_inherit";      //eval or inherit 参数
    static public final String INNER_VAR__INHERIT_FUN_ARGUMENTS_$           = "$inherit";               //eval or inherit 参数

    public static final String INNER_VAR__INT_MAX       = "int_max";
    public static final String INNER_VAR__INT_MIN       = "int_min";
    public static final String INNER_VAR__CHAR_MAX      = "char_max";
    public static final String INNER_VAR__CHAR_MIN      = "char_min";
    public static final String INNER_VAR__FLOAT_MAX     = "float_max";
    public static final String INNER_VAR__FLOAT_MIN     = "float_min";
    public static final String INNER_VAR__DOUBLE_MAX    = "double_max";
    public static final String INNER_VAR__DOUBLE_MIN    = "double_min";
    public static final String INNER_VAR__SHORT_MAX     = "short_max";
    public static final String INNER_VAR__SHORT_MIN     = "short_min";
    public static final String INNER_VAR__LONG_MAX      = "long_max";
    public static final String INNER_VAR__LONG_MIN      = "long_min";
    public static final String INNER_VAR__BOOLEAN_MAX   = "boolean_max";
    public static final String INNER_VAR__BOOLEAN_MIN   = "boolean_min";
    public static final String INNER_VAR__BYTE_MAX      = "byte_max";
    public static final String INNER_VAR__BYTE_MIN      = "byte_min";




    static public final String INNER_FUNCTION__THROW  = "throw";
    static public final String INNER_FUNCTION__RETURN = "return";

    //变量操作
    public static final String INNER_FUNCTION__GETATTR   = "getattr";
    public static final String INNER_FUNCTION__SETATTR   = "setattr";
    public static final String INNER_FUNCTION__HASATTR   = "hasattr";
    public static final String INNER_FUNCTION__DELATTR   = "delattr";
    public static final String INNER_FUNCTION__LENATTR   = "lenattr";
    public static final String INNER_FUNCTION__KEYATTR   = "keyattr";


    /**
     * 判断是否为 Re_IObject
     * 所有实现都以 Re_IObject 为基础
     */
    static public final String INNER_FUNCTION__IS_RE_OBJECT         = "is_re";
    static public final String INNER_FUNCTION__IS_JAVA_OBJECT       = "is_java";

    static public final String INNER_FUNCTION__IS_SPACE     = "is_space";       //判断是否为space(Executor)

    static public final String INNER_FUNCTION__IS_TRUE      = "is_true";
    static public final String INNER_FUNCTION__IS_FALSE     = "is_false";


    static public final String INNER_FUNCTION__EVAL                 = "eval";
    static public final String INNER_FUNCTION__LOAD                 = "load";           //导入re 类

    //返回原始对象//
    static public final String INNER_FUNCTION__FIND_CLASS           = "find_class";
    //返回原始对象//
    static public final String INNER_FUNCTION__GET_CLASS            = "get_class";      //如果是实例则获取类
    //返回原始对象//
    static public final String INNER_FUNCTION__GET_DECLARE_CLASS    = "get_declare_class";      //如果是实例则获取类




    static public final String INNER_FUNCTION__ARRAY        = "array";
    static public final String INNER_FUNCTION__ARRAYOF      = "arrayof";
    static public final String INNER_FUNCTION__IS_ARRAY     = "is_array";
    static public final String INNER_FUNCTION__TO_ARRAY     = "to_array";

    static public final String INNER_CONVERT_FUNCTION__CREATE_OBJECT    = "_instance";          //{"key": tip}; 语法自动转换为方法 创建一个对象实例
    static public final String INNER_FUNCTION__IS_CLASS_INSTANCE        = "is_instance";      //判断是否为re class 实例
    static public final String INNER_FUNCTION__TO_CLASS_INSTANCE        = "to_instance";

    static public final String INNER_CONVERT_FUNCTION__CREATE_LIST      = "_list";              //["key"]; 语法自动转换为方法 创建一个列表
    static public final String INNER_FUNCTION__IS_LIST_INSTANCE         = "is_list";          //判断是否为re class 实例
    static public final String INNER_FUNCTION__TO_LIST_INSTANCE         = "to_list";

    static public final String INNER_FUNCTION__IS_CLASS             = "is_class";       //判断是否为re class
    static public final String INNER_FUNCTION__IS_FUNCTION          = "is_function";    //判断是否为re function



    static public final String INNER_FUNCTION__LIST_KEYWORD      = "list_keyword";
    static public final String INNER_FUNCTION__IS_KEYWORD_KEY    = "is_keyword_key";
    static public final String INNER_FUNCTION__IS_KEYWORD        = "is_keyword";
    static public final String INNER_FUNCTION__GET_KEYWORD_KEY   = "get_keyword_key";

    static public final String INNER_FUNCTION__IS_RUNTIME_KEYWORD_KEY   = "is_runtime_keyword_key";


    static public final String INNER_FUNCTION__IS_PRIMITIVE   = "is_primitive";//判断变量是否为primitive



    static public final String INNER_FUNCTION__NOT          = "not";
    //返回原始对象, 只能在foreach中使用//
    static public final String INNER_FUNCTION__RANGE        = "range";

    public static final String INNER_FUNCTION__PRINT       = "print";
    public static final String INNER_FUNCTION__PRINTLN     = "println";
    public static final String INNER_FUNCTION__TIME        = "time";
    public static final String INNER_FUNCTION__SLEEP       = "sleep";







    //内置数据转换
    public static final String INNER_FUNCTION__STR      = "str";
    public static final String INNER_FUNCTION__INT      = "int";
    public static final String INNER_FUNCTION__LONG     = "long";
    public static final String INNER_FUNCTION__CHAR     = "char";
    public static final String INNER_FUNCTION__FLOAT    = "float";
    public static final String INNER_FUNCTION__DOUBLE   = "double";
    public static final String INNER_FUNCTION__SHORT    = "short";
    public static final String INNER_FUNCTION__BYTE     = "byte";
    public static final String INNER_FUNCTION__BOOLEAN  = "boolean";


    public static final String INNER_FUNCTION__ISSTR      = "is_str";
    public static final String INNER_FUNCTION__ISINT      = "is_int";
    public static final String INNER_FUNCTION__ISLONG     = "is_long";
    public static final String INNER_FUNCTION__ISCHAR     = "is_char";
    public static final String INNER_FUNCTION__ISFLOAT    = "is_float";
    public static final String INNER_FUNCTION__ISDOUBLE   = "is_double";
    public static final String INNER_FUNCTION__ISSHORT    = "is_short";
    public static final String INNER_FUNCTION__ISBYTE     = "is_byte";
    public static final String INNER_FUNCTION__ISBOOLEAN  = "is_boolean";




    public static final String INNER_FUNCTION__JIMPORT                  = "jimport";   //直接把对象作为了类对象操作    [创建实例/静态方法/静态字段]
    public static final String INNER_FUNCTION__JOPERATE                 = "joperate";  //直接把对象作为Java对象操作   [方法/字段]

    static public final String INNER_FUNCTION__JNEW                     = "jnew";
    static public final String INNER_FUNCTION__JINVOKE                  = "jinvoke";
    static public final String INNER_FUNCTION__JSET                     = "jset";
    static public final String INNER_FUNCTION__JGET                     = "jget";

    public static final String INNER_FUNCTION__JGETCLASS                = "jgetclass";
    public static final String INNER_FUNCTION__JFORNAME                 = "jforname";
    public static final String INNER_FUNCTION__JINSTANCEOF              = "jinstanceof";




    public static final String INNER_FUNCTION__JNEW_PROXY               = "jproxy"; //创建Java自定义实例(代理)
    public static final String INNER_FUNCTION__JNEW_CLASS               = "jclass"; //创建Java自定义类 （不实现）











    public static boolean is_runtime_keyword_key(Object key) {
        return keyword.isRuntimeKeyword(key);
    }
    public static Object  get_runtime_keyword(Re_Executor executor, Object key) {
        return keyword.findRuntimeKeyword(executor, key);
    }


    public static boolean is_keyword_key(Object key) {
        return keyword.isKeywordKey(key);
    }
    public static boolean is_keyword(Object value) {
        return keyword.isKeywordValue(value);
    }
    public static Object get_keyword_key(Object value) {
        return keyword.getKeywordKey(value);
    }
    public static Object get_keyword(Object key) {
        return keyword.findKeyword(key);
    }
    public static String[] get_keyword_keys() {
        return keyword.getKeywordNames();
    }




    //导入最基础的 ***
    static final Re_KeywordVariableMap keyword = new Re_KeywordVariableMap();
    static {
        Re_Variable.Unsafes.addVariableIntern(INNER_VAR__NULL,                               Re_Variable.createCompileNull(), keyword);
        Re_Variable.Unsafes.addVariableIntern(INNER_VAR__TRUE,                               Re_Variable.createCompileBoolean(true), keyword);
        Re_Variable.Unsafes.addVariableIntern(INNER_VAR__FALSE,                              Re_Variable.createCompileBoolean(false), keyword);
        Re_Variable.Unsafes.addVariableIntern(INNER_VAR__ENVIRONMENT,                        Re_Variable.createCompileEnvironment(),       keyword);
        Re_Variable.Unsafes.addVariableIntern(INNER_VAR__SPACE,                              Re_Variable.createCompileSpace(),        keyword);
        Re_Variable.Unsafes.addVariableIntern(INNER_VAR__FUN_ARGUMENTS_ARGUMENTS,            Re_Variable.createCompileArguments(),    keyword);
        Re_Variable.Unsafes.addVariableIntern(INNER_VAR__FUN_ARGUMENTS_ARGUMENTS_$,          Re_Variable.createCompileArguments(),    keyword);


        Re_Variable.Unsafes.addVariableIntern(INNER_VAR__INHERIT_FUN_ARGUMENTS_ARGUMENTS,    Re_Variable.createCompileInheritExecutorArguments(),    keyword);
        Re_Variable.Unsafes.addVariableIntern(INNER_VAR__INHERIT_FUN_ARGUMENTS_$,            Re_Variable.createCompileInheritExecutorArguments(),    keyword);





        // (true, false) --> false 空名字方法 全部执行 返回最后一个值（如果return 将会中断）
        //这是个非常重要的东西
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                //最后一行不需要判断isReturn
                return executor.getExpressionLastValue(call, 0, call.getParamExpressionCount());
            }
        }, keyword);









        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__TILDE) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object x0 = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Math.hash1(INNER_FUNCTION__TILDE, x0);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__NOT) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object expressionValue = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Math.hash11("-", expressionValue);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);






        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__THROW) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                Object result = executor.getExpressionLastValue(call, 0, call.getParamExpressionCount());
                if (executor.isReturnOrThrow()) return null;

                if (Re_Utilities.isReClassInstance_exception(result)) {
                    Re_ZPrimitiveClass_exception.Instance instance = (Re_ZPrimitiveClass_exception.Instance) result;
                    executor.setThrow(instance);
                } else {
                    String reason = Re_Utilities.toJString(result);
                    executor.setThrow(reason);
                }
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__RETURN) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                Object result = executor.getExpressionLastValue(call, 0, call.getParamExpressionCount());
                if (executor.isReturnOrThrow()) return null; // throw or return();

                executor.setReturn(result);
                return result;
            }
        }, keyword);






        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__IS_TRUE) {

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.ifTrue(temp)? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__IS_FALSE) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.ifFalse(temp)? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__RANGE) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                // TODO: Implement this method
                int paramCount = call.getParamExpressionCount();
                if (paramCount == 1) {
                    Object end = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;
                    if (end instanceof Integer) {
                        return Re_ReIterables.wrapRange(executor, 0, (Integer) end);
                    }
                    executor.setThrow(Re_Accidents.unsupported_type(Re_Utilities.getName(end)));
                    return null;
                }
                if (paramCount == 2) {
                    Object start = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    Object end = executor.getExpressionValue(call, 1);
                    if (executor.isReturnOrThrow()) return null;

                    if (start instanceof Integer && end instanceof Integer) {
                        return Re_ReIterables.wrapRange(executor, (Integer) start, (Integer) end);
                    }
                    executor.setThrow(Re_Accidents.unsupported_type(Re_Utilities.getName(start)));
                    return null;
                }
                if (paramCount == 3) {
                    Object start = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    Object end = executor.getExpressionValue(call, 1);
                    if (executor.isReturnOrThrow()) return null;

                    Object step = executor.getExpressionValue(call, 2);
                    if (executor.isReturnOrThrow()) return null;

                    if (start instanceof Integer && end instanceof Integer && step instanceof Integer) {
                        return Re_ReIterables.wrapRange(executor, (Integer) start, (Integer) end, (Integer) step);
                    }
                    executor.setThrow(Re_Accidents.unsupported_type(Re_Utilities.getName(start)));
                    return null;
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramCount));
                return null;
            }
        }, keyword);








        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__EVAL) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount > 0) {
                    String code = Re_Utilities.toJString(executor.getExpressionValue(call, 0));
                    if (executor.isReturnOrThrow()) return null;

                    if (paramExpressionCount == 1) {
                        Object[] argumentArr = Finals.EMPTY_OBJECT_ARRAY;

                        return executor.eval(code, argumentArr);
                    } else if (paramExpressionCount == 2) {
                        Object[] argumentArr;
                        Object   argumentArr0 = executor.getExpressionValue(call, 1);
                        if (executor.isReturnOrThrow()) return null;

                        if (null == argumentArr0) {
                            argumentArr = Finals.EMPTY_OBJECT_ARRAY;
                        } else {
                            argumentArr = Re_Utilities.toarray(executor, argumentArr0);
                            if (executor.isReturnOrThrow()) return null;
                        }

                        return executor.eval(code, argumentArr);
                    }
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);









        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__GETATTR) {
            String text = "(object, key)";
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 2) {
                    Object object = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    Object key = executor.getExpressionValue(call, 1);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.getattr(executor, object, key);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__SETATTR) {
            String text = "(object, key, value)";
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 3) {
                    Object object = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    Object key = executor.getExpressionValue(call, 1);
                    if (executor.isReturnOrThrow()) return null;

                    Object value = executor.getExpressionValue(call, 2);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.setattr(executor, object, key, value)? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__HASATTR) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 2) {
                    Object object = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    Object key = executor.getExpressionValue(call, 1);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.hasattr(executor, object, key)? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__DELATTR) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 2) {
                    Object object = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    Object key = executor.getExpressionValue(call, 1);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.delattr(executor, object, key)? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__LENATTR) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object object = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.lenattr(executor, object);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__KEYATTR) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object object = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.keyattr(executor, object);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
    }









    static {
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__IS_PRIMITIVE) {
            String text = "use "+ INNER_FUNCTION__IS_PRIMITIVE +"()";
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isRePrimitive(temp)? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);



        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__IS_SPACE) {
            String text = "use "+ INNER_FUNCTION__IS_SPACE +"()";
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isSpace(temp)? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);


        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__IS_RE_OBJECT) {
            String text = "use "+ INNER_FUNCTION__IS_RE_OBJECT +"()";
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isIReObject(temp)? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__IS_JAVA_OBJECT) {
            String text = "use "+ INNER_FUNCTION__IS_JAVA_OBJECT +"()";
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isJavaObject(temp) ? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
    }




    //类和方法 this static eval import final
    static {

        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_CONVERT_FUNCTION__CREATE_OBJECT) {
            final String text = "m = { \"key\": tip }; ";

            /**
             * 控制参数 代码由自己执行
             */@Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                return Re_Executor.createReDict(executor, call);
            }
        }, keyword);

        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_CONVERT_FUNCTION__CREATE_LIST) {
            final String text = "m = [1, 2, 3]; ";

            /**
             * 控制参数 代码由自己执行
             */@Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                return Re_Executor.createReList(executor, call);
            }
        }, keyword);







        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__IS_CLASS_INSTANCE) {
            String text = "use "+ INNER_FUNCTION__IS_CLASS_INSTANCE +"()";
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isReClassInstance(temp)? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__TO_CLASS_INSTANCE) {
            String text = "use "+ INNER_FUNCTION__TO_CLASS_INSTANCE +"()";
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.toinstance(executor, temp);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);



        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__IS_LIST_INSTANCE) {
            String text = "use "+ INNER_FUNCTION__IS_LIST_INSTANCE +"()";
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isReClassInstance_list(temp)? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__TO_LIST_INSTANCE) {
            final String text = "use "+ INNER_FUNCTION__TO_LIST_INSTANCE +"()";
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.tolist(executor, temp);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);


        Re_Variable.Unsafes.addVariableIntern(INNER_VAR__THIS,     Re_Variable.createCompileThis(),        keyword);
        Re_Variable.Unsafes.addVariableIntern(INNER_VAR__STATIC,   Re_Variable.createCompileStatic(),      keyword);


        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__LOAD) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    String name = Re_Utilities.toJString(executor.getExpressionValue(call, 0));
                    if (executor.isReturnOrThrow()) return null;

                    Re_Class re_class = Re_Utilities.loadClass(executor, name);
                    if (executor.isReturnOrThrow()) return null;

                    String simpleName = re_class.getReClassSimpleName();
                    executor.localValue(simpleName, re_class);
                    return   re_class;
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, call.getParamExpressionCount()));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__FIND_CLASS) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                if (call.getParamExpressionCount() == 1) {
                    String name = Re_Utilities.toJString(executor.getExpressionValue(call, 0));
                    if (executor.isReturnOrThrow()) return null;

                    Re_Class re_class = Re_Utilities.loadClass(executor, name);
                    if (executor.isReturnOrThrow()) return null;

                    return   re_class;
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, call.getParamExpressionCount()));
                return null;
            }

        }, keyword);





        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__GET_CLASS) {
            String text = "use "+ INNER_FUNCTION__GET_CLASS +"()";
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.getReClassFromIReGetClass(temp);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__GET_DECLARE_CLASS) {
            String text = "use "+ INNER_FUNCTION__GET_DECLARE_CLASS +"()";
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.getDeclareReClassFromIReGetDeclaringClass(temp);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);



        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__IS_CLASS) {
            String text = "use "+ INNER_FUNCTION__IS_CLASS +"()";
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isReClass(temp)? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__IS_FUNCTION) {
            String text = "use "+ INNER_FUNCTION__IS_FUNCTION +"()";
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isReFunction(temp)? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
    };


    //核心-数据转换方法 ***
    static {
        //str(), int(), char(), float(), double)(, short(), boolean(), long(), byte()
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__STR,       new Re_ZPrimitiveObject_jimportCall(String.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.toJString(obj);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__INT,       new Re_ZPrimitiveObject_jimportCall(int.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.toJInt(obj);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__LONG,      new Re_ZPrimitiveObject_jimportCall(long.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.toJLong(obj);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__CHAR,      new Re_ZPrimitiveObject_jimportCall(char.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.toJChar(obj);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__FLOAT,     new Re_ZPrimitiveObject_jimportCall(float.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.toJFloat(obj);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__DOUBLE,    new Re_ZPrimitiveObject_jimportCall(double.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.toJDouble(obj);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__SHORT,     new Re_ZPrimitiveObject_jimportCall(short.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.toJShort(obj);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__BYTE,      new Re_ZPrimitiveObject_jimportCall(byte.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.toJByte(obj);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__BOOLEAN,   new Re_ZPrimitiveObject_jimportCall(boolean.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.toJBoolean(obj);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
    }


    static {
        //is_str(), is_int(), is_char(), is_float(), is_double)(, is_short(), is_boolean(), is_long(), is_byte()
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__ISSTR,       new Re_ZPrimitiveObject_jimportCall(String.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isJString(obj) ? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__ISINT,       new Re_ZPrimitiveObject_jimportCall(int.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isJInt(obj) ? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__ISLONG,      new Re_ZPrimitiveObject_jimportCall(long.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isJLong(obj) ? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__ISCHAR,      new Re_ZPrimitiveObject_jimportCall(char.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isJChar(obj) ? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__ISFLOAT,     new Re_ZPrimitiveObject_jimportCall(float.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isJFloat(obj) ? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__ISDOUBLE,    new Re_ZPrimitiveObject_jimportCall(double.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isJDouble(obj) ? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__ISSHORT,     new Re_ZPrimitiveObject_jimportCall(short.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isJShort(obj) ? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__ISBYTE,      new Re_ZPrimitiveObject_jimportCall(byte.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isJByte(obj) ? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_FUNCTION__ISBOOLEAN,   new Re_ZPrimitiveObject_jimportCall(boolean.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isJBoolean(obj) ? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
    }
















    //核心-数据结构 ***
    static {
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_CLASS__OBJECT,     Re_ZPrimitiveClass_object.reclass,       keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_CLASS__LIST,       Re_ZPrimitiveClass_list.reclass,         keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_CLASS__JSON,       Re_ZPrimitiveClass_json.reclass,         keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_CLASS__REFLECT,    Re_ZPrimitiveClass_reflect.reclass,      keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_CLASS__EXCEPTION,  Re_ZPrimitiveClass_exception.reclass,    keyword);
    }




    //核心-符号方法 ***
    static {
        //symbol method + - * / ...
        Re_Math.addMethodToKeyword(keyword);
    }

    //核心- ***
    static {
        //创建 Object数组
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__ARRAY) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                return Re_Utilities.newJArrayFromArrayCall(executor, call);
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__ARRAYOF) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                return Re_Utilities.newJArrayForLength(executor, call);
            }
        }, keyword);

        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__IS_ARRAY) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.isJArray(obj);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);


        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__TO_ARRAY) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.toarray(executor, obj);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__LIST_KEYWORD) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                Object[] callParam = executor.getExpressionValues(call);
                if (executor.isReturnOrThrow()) return null;

                return get_keyword_keys();
            }
        }, keyword);


        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__IS_KEYWORD_KEY) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Keywords.is_keyword_key(obj) ? TRUE.get() : FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__IS_KEYWORD) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Keywords.is_keyword(obj) ? TRUE.get() : FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__GET_KEYWORD_KEY) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Keywords.get_keyword_key(obj);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__IS_RUNTIME_KEYWORD_KEY) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Keywords.is_runtime_keyword_key(obj) ? TRUE.get() : FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);
    }




    static {
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__PRINT) {
            /**
             * @see Re_IReObject#executeThis(Re_Executor, String, Call)
             * @see Re_IReObject#executePoint(Re_Executor, String, Call)
             * <p>
             * 如果返回 true  则需要自己获取参数 执行器不会获取参数	所以传入参数 (Object[] callParam) 为null
             * 如果返回 false 执行器会自动执行获取参数并传入(Object[] callParam)
             * <p>
             * 千万要注意执行后判断是否已经return了，如果return应该立即返回return数据而不是继续执行
             * <p>
             * 只要用了{@link Re_Executor#getExpressionValue(Call, int)} 后都要手动检测是否return
             */@Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount != 0) {
                    for (int i = 0; i < paramExpressionCount; i++) {
                        Object value = executor.getExpressionValue(call, i);
                        if (executor.isReturnOrThrow()) return null;

                        String str = Re_Utilities.toJString(value);
                        executor.re.print(str);
                    }
                }
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__PRINTLN) {
            /**
             * @see Re_IReObject#executeThis(Re_Executor, String, Call)
             * @see Re_IReObject#executePoint(Re_Executor, String, Call)
             * <p>
             * 如果返回 true  则需要自己获取参数 执行器不会获取参数	所以传入参数 (Object[] callParam) 为null
             * 如果返回 false 执行器会自动执行获取参数并传入(Object[] callParam)
             * <p>
             * 千万要注意执行后判断是否已经return了，如果return应该立即返回return数据而不是继续执行
             * <p>
             * 只要用了{@link Re_Executor#getExpressionValue(Call, int)} 后都要手动检测是否return
             */@Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 0) {
                    executor.re.println();
                } else {
                    for (int i = 0; i < paramExpressionCount; i++) {
                        Object value = executor.getExpressionValue(call, i);
                        if (executor.isReturnOrThrow()) return null;

                        String str = Re_Utilities.toJString(value);
                        executor.re.println(str);
                    }
                }
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__TIME) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                if (call.getParamExpressionCount() == 0) {
                    return System.currentTimeMillis();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, call.getParamExpressionCount()));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__SLEEP) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                if (call.getParamExpressionCount() == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;
                    Thread.sleep(Re_Utilities.toJLong(obj));

                    return TRUE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, call.getParamExpressionCount()));
                return null;
            }
        }, keyword);
    }



    /**
     * 导入java反射
     */
    static {
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__JNEW) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramCount = call.getParamExpressionCount();
                if (paramCount == 2) {
                    Object classValue = executor.getExpressionValue(call,0);
                    if (executor.isReturnOrThrow()) return null;

                    Object argsValue = executor.getExpressionValue(call,1);
                    if (executor.isReturnOrThrow()) return null;
                    Object[] array = Re_Utilities.toarray(executor, argsValue);

                    return Re_Utilities.newJavaInstance(executor, Re_Utilities.getJavaClassFromJavaClassOrIJavaClassWrapOrJavaObject(classValue), array);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__JINVOKE) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramCount = call.getParamExpressionCount();
                if (paramCount == 3) {
                    Object variableValue = executor.getExpressionValue(call,0);
                    if (executor.isReturnOrThrow()) return null;

                    Object nameValue = executor.getExpressionValue(call,1);
                    if (executor.isReturnOrThrow()) return null;

                    Object argsValue = executor.getExpressionValue(call,2);
                    if (executor.isReturnOrThrow()) return null;
                    Object[] array = Re_Utilities.toarray(executor, argsValue);

                    return Re_Utilities.invokeJavaMethod(executor, variableValue, Re_Utilities.toJString(nameValue), array);
                }
                if (paramCount == 4) {
                    Object classValue = executor.getExpressionValue(call,0);
                    if (executor.isReturnOrThrow()) return null;

                    Object variableValue = executor.getExpressionValue(call,1);
                    if (executor.isReturnOrThrow()) return null;

                    Object nameValue = executor.getExpressionValue(call,2);
                    if (executor.isReturnOrThrow()) return null;

                    Object argsValue = executor.getExpressionValue(call,3);
                    if (executor.isReturnOrThrow()) return null;
                    Object[] array = Re_Utilities.toarray(executor, argsValue);

                    return Re_Utilities.invokeJavaMethod(executor, Re_Utilities.getJavaClassFromJavaClassOrIJavaClassWrapOrJavaObject(classValue), variableValue, null, Re_Utilities.toJString(nameValue), array);
                }
                if (paramCount == 5) {
                    Object classValue = executor.getExpressionValue(call,0);
                    if (executor.isReturnOrThrow()) return null;

                    Object variableValue = executor.getExpressionValue(call,1);
                    if (executor.isReturnOrThrow()) return null;

                    Object returnClass = executor.getExpressionValue(call,2);
                    if (executor.isReturnOrThrow()) return null;

                    Object nameValue = executor.getExpressionValue(call,3);
                    if (executor.isReturnOrThrow()) return null;

                    Object argsValue = executor.getExpressionValue(call,4);
                    if (executor.isReturnOrThrow()) return null;
                    Object[] array = Re_Utilities.toarray(executor, argsValue);

                    return Re_Utilities.invokeJavaMethod(executor, Re_Utilities.getJavaClassFromJavaClassOrIJavaClassWrapOrJavaObject(classValue), variableValue, Re_Utilities.getJavaClassFromJavaClassOrIJavaClassWrapOrJavaObject(returnClass), Re_Utilities.toJString(nameValue), array);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__JSET) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramCount = call.getParamExpressionCount();
                if (paramCount == 3) {
                    Object variableValue = executor.getExpressionValue(call,0);
                    if (executor.isReturnOrThrow()) return null;

                    Object nameValue = executor.getExpressionValue(call,1);
                    if (executor.isReturnOrThrow()) return null;

                    Object argsValue = executor.getExpressionValue(call,2);
                    if (executor.isReturnOrThrow()) return null;

                    Re_Utilities.setJavaValue(executor, variableValue.getClass(), variableValue, Re_Utilities.toJString(nameValue), argsValue);
                    return argsValue;
                }
                if (paramCount == 4) {
                    Object classValue = executor.getExpressionValue(call,0);
                    if (executor.isReturnOrThrow()) return null;

                    Object variableValue = executor.getExpressionValue(call,1);
                    if (executor.isReturnOrThrow()) return null;

                    Object nameValue = executor.getExpressionValue(call,2);
                    if (executor.isReturnOrThrow()) return null;

                    Object argsValue = executor.getExpressionValue(call,3);
                    if (executor.isReturnOrThrow()) return null;

                    Re_Utilities.setJavaValue(executor, Re_Utilities.getJavaClassFromJavaClassOrIJavaClassWrapOrJavaObject(classValue), variableValue, Re_Utilities.toJString(nameValue), argsValue);
                    return argsValue;
                }
                if (paramCount == 5) {
                    Object classValue = executor.getExpressionValue(call,0);
                    if (executor.isReturnOrThrow()) return null;

                    Object variableValue = executor.getExpressionValue(call,1);
                    if (executor.isReturnOrThrow()) return null;

                    Object returnClass = executor.getExpressionValue(call,2);
                    if (executor.isReturnOrThrow()) return null;

                    Object nameValue = executor.getExpressionValue(call,2);
                    if (executor.isReturnOrThrow()) return null;

                    Object argsValue = executor.getExpressionValue(call,3);
                    if (executor.isReturnOrThrow()) return null;

                    Re_Utilities.setJavaValue(executor, Re_Utilities.getJavaClassFromJavaClassOrIJavaClassWrapOrJavaObject(classValue), variableValue, Re_Utilities.getJavaClassFromJavaClassOrIJavaClassWrapOrJavaObject(returnClass), Re_Utilities.toJString(nameValue), argsValue);
                    return argsValue;
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__JGET) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramCount = call.getParamExpressionCount();
                if (paramCount == 3) {
                    Object variableValue = executor.getExpressionValue(call,0);
                    if (executor.isReturnOrThrow()) return null;

                    Object nameValue = executor.getExpressionValue(call,1);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.getJavaValue(executor, variableValue.getClass(), variableValue, Re_Utilities.toJString(nameValue));
                }
                if (paramCount == 4) {
                    Object classValue = executor.getExpressionValue(call,0);
                    if (executor.isReturnOrThrow()) return null;

                    Object variableValue = executor.getExpressionValue(call,1);
                    if (executor.isReturnOrThrow()) return null;

                    Object nameValue = executor.getExpressionValue(call,2);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.getJavaValue(executor, Re_Utilities.getJavaClassFromJavaClassOrIJavaClassWrapOrJavaObject(classValue), variableValue, Re_Utilities.toJString(nameValue));
                }
                if (paramCount == 5) {
                    Object classValue = executor.getExpressionValue(call,0);
                    if (executor.isReturnOrThrow()) return null;

                    Object variableValue = executor.getExpressionValue(call,1);
                    if (executor.isReturnOrThrow()) return null;

                    Object returnClass = executor.getExpressionValue(call,2);
                    if (executor.isReturnOrThrow()) return null;

                    Object nameValue = executor.getExpressionValue(call,2);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.getJavaValue(executor, Re_Utilities.getJavaClassFromJavaClassOrIJavaClassWrapOrJavaObject(classValue), variableValue, Re_Utilities.getJavaClassFromJavaClassOrIJavaClassWrapOrJavaObject(returnClass), Re_Utilities.toJString(nameValue));
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramCount));
                return null;
            }
        }, keyword);







        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__JFORNAME) {
            String text =   "use @Deprecated jforname(java.lang.String:ClassName);\n"+
                            "use jforname(java.lang.Class:AClassInALoader, java.lang.String:ClassName);\n"+
                            "use jforname(java.lang.ClassLoader:ClassLoader, java.lang.String:ClassName);\n";

            /**
             * @param that_key toReJImport
             * @param call
             */
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                Object[] callParam = executor.getExpressionValues(call);
                if (executor.isReturnOrThrow()) return null;

                if (callParam.length == 1) {
                    return Re_Utilities.jforNameFindClass(callParam[0]);
                }
                if (callParam.length == 2) {
                    String name = Re_Utilities.toJString(callParam[1]);

                    if (callParam[0] instanceof ClassLoader) {
                        return Re_Utilities.jforNameFindClass(name, true, (ClassLoader) callParam[0]);
                    } else  {
                        Class callClass  = Re_Utilities.jforNameFindClass(callParam[0]);//解包，最好不要用
                        ClassLoader loader = callClass.getClassLoader();
                        return Re_Utilities.jforNameFindClass(name, true, loader);
                    }
                }
                executor.setThrow(text);
                return null;
            }
        }, keyword);


        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__JNEW_PROXY) {
            final String text =
                    "(  [java.lang.Class: class, ...], re_object_instance  ); //the first parameter must be a list";
            @Override
            public Object executeThis(final Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 2) {
                    Object interfaceListObject = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;
                    Object[] interfaceListArray = Re_Utilities.toarray(executor, interfaceListObject);
                    if (executor.isReturnOrThrow()) return null;

                    Object reClassInstanceObject = executor.getExpressionValue(call, 1);
                    if (executor.isReturnOrThrow()) return null;
                    if (!Re_Utilities.isReClassInstance(reClassInstanceObject)) {
                        executor.setThrow(text);
                        return null;
                    }
                    final Re_ClassInstance classInstance = (Re_ClassInstance) reClassInstanceObject;
                    final Re_Class cls   = classInstance.getReClass();

                    final Re_NativeStack cloneStack = executor.getStack().clone();
                    InvocationHandler invocationHandler = new InvocationHandler() {
                        @SuppressWarnings("UnnecessaryLocalVariable")
                        @Override
                        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                            String name = method.getName();
                            Object result = Re_Class.Unsafes.directAnonymousExecutePointFunction(executor.re, cloneStack, cls, classInstance, name, args);
                            return result;
                        }
                    };

                    Class[] interfaceList = Re_Utilities.jforNameFindClasss(interfaceListArray);
                    Object proxy = null;
                    Throwable ex = null;
                    for (Class anInterface : interfaceList) {
                        try {
                            ClassLoader classLoader = anInterface.getClassLoader();
                            proxy = Proxy.newProxyInstance(
                                    classLoader,
                                    interfaceList,
                                    invocationHandler);
                            break;
                        } catch (Throwable e) {
                            ex = e;
                        }
                    }
                    if (null == proxy) {
                        executor.setThrow(null == ex? " new proxy error" : ex.getMessage());
                        return null;
                    }
                    return proxy;
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__JGETCLASS) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object value = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.getJavaClassFromJavaClassOrIJavaClassWrapOrJavaObject(value);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__JINSTANCEOF) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 2) {
                    Object value = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    Object cls = executor.getExpressionValue(call, 1);
                    if (executor.isReturnOrThrow()) return null;

                    Class<?> aClass = Re_Utilities.jforNameFindClass(cls);
                    return Classz.isInstance(value, aClass, false)? TRUE.get(): FALSE.get();
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
                return null;
            }
        }, keyword);


        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__JIMPORT) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
                Object[] callParam = executor.getExpressionValues(call);
                if (executor.isReturnOrThrow()) return null;

                if (callParam.length == 1) {
                    Re_ZPrimitiveObject_jimport re_import = Re_Utilities.toReJImport(callParam[0]);
                    String simpleName = Classx.findSimpleName(re_import.getJavaClass());
                    executor.localValue(simpleName, re_import);
                    return re_import;
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, callParam.length));
                return null;
            }
        }, keyword);




        Re_Variable.Unsafes.addBuiltinValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__JOPERATE) {
            @Override
            public Object executeThis(Re_Executor executor, String that_key, Call call) {
                Object[] callParam = executor.getExpressionValues(call);
                if (executor.isReturnOrThrow()) return null;

                if (callParam.length == 1) {
                    Object value = executor.getExpressionValue(call, 0);
                    if (executor.isReturnOrThrow()) return null;

                    return Re_Utilities.toReJObject(value);
                }
                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, callParam.length));
                return null;
            }
        }, keyword);

    }





    //辅助变量
    //导入最大值，和基础类 ***
    static {
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_VAR__INT_MAX,      new Integer(Integer.MAX_VALUE),     keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_VAR__INT_MIN,      new Integer(Integer.MIN_VALUE),     keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_VAR__CHAR_MAX,     new Character(Character.MAX_VALUE), keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_VAR__CHAR_MIN,     new Character(Character.MIN_VALUE), keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_VAR__FLOAT_MAX,    new Float(Float.MAX_VALUE),         keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_VAR__FLOAT_MIN,    new Float(Float.MIN_VALUE),         keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_VAR__DOUBLE_MAX,   new Double(Double.MAX_VALUE),       keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_VAR__DOUBLE_MIN,   new Double(Double.MIN_VALUE),       keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_VAR__SHORT_MAX,    new Short(Short.MAX_VALUE),         keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_VAR__SHORT_MIN,    new Short(Short.MIN_VALUE),         keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_VAR__LONG_MAX,     new Long(Long.MAX_VALUE),           keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_VAR__LONG_MIN,     new Long(Long.MIN_VALUE),           keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_VAR__BOOLEAN_MAX,  new Boolean(true),            keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_VAR__BOOLEAN_MIN,  new Boolean(false),           keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_VAR__BYTE_MAX,     new Byte(Byte.MAX_VALUE),           keyword);
        Re_Variable.Unsafes.addBuiltinValueIntern(INNER_VAR__BYTE_MIN,     new Byte(Byte.MIN_VALUE),           keyword);
    }


}
