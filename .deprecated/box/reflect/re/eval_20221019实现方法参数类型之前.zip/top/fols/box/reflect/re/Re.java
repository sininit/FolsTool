package top.fols.box.reflect.re;

import top.fols.atri.lang.Objects;
import top.fols.box.reflect.re.interfaces.Re_IJavaReflector;
import top.fols.box.reflect.re.interfaces.Re_IReInnerVariableMap;
import top.fols.box.reflect.re.resource.Re_IResource;
import top.fols.box.reflect.re.resource.Re_IResourceFile;
import top.fols.box.reflect.re.variables.Re_VariableMap;

import java.io.Closeable;
import java.io.IOException;
import java.util.*;

/**
 *
 * 2021/11/12 - 2021/11/30
 * @author GXin <a href="http://github.com/sininit">http://github.com/sininit</a>
 *
 *
 *
 *
 *
 * thread safe
 *
 * $("$1.out.println($2)", import_java_class("java.lang.System"), 666)    >> System.out.println(666)
 */
public class Re implements Closeable {
    /*@Override */protected void finalize() {this.close();}


    @Override
    public void close() {
        this.close_debugger();
    }


    @SuppressWarnings("TryFinallyCanBeTryWithResources")
    public static Object $(String expression, Object... params) throws Re_Accidents.CompileTimeGrammaticalException, Re_Accidents.ExecuteException {
        Re re = new Re();
        try {
            return re.execute(expression, params);
        } finally {
            re.close();
        }
    }
    @SuppressWarnings("TryFinallyCanBeTryWithResources")
    public static Object $(String expression, Re_IReInnerVariableMap variableMap, Object... params) throws Re_Accidents.CompileTimeGrammaticalException, Re_Accidents.ExecuteException {
        Re re = new Re();
        try {
            return re.execute(expression, variableMap, params);
        } finally {
            re.close();
        }
    }
    public static Re_CodeFile compile(String expression, String filePath, int lineOffset) throws Re_Accidents.CompileTimeGrammaticalException {
        Re_CodeLoader re_codeLoader = new Re_CodeLoader();
        return re_codeLoader.load(expression, filePath ,lineOffset);
    }



    /**
     * return class point object
     * @param type class name
     */
    public static Re_ZPrimitiveObject_jimport jimport(String type) throws ClassNotFoundException {
        return jimport(Re_Utilities.jforNameFindClass(type));
    }
    /**
     * return class point object
     * @param type class
     */
    public static Re_ZPrimitiveObject_jimport jimport(Class<?> type) {
        return Re_Utilities.toReJImport(type);
    }

    public static Re_ZPrimitiveObject_jobject jobject(Class<?> type) {
        return Re_Utilities.toReJObject(type);
    }






    public static void throwStackException(Re_Executor executor) throws Re_Accidents.ExecuteException {
        throwStackException(executor.getStack());
    }
    public static void throwStackException(Re_NativeStack reStack) throws Re_Accidents.ExecuteException {
        if (reStack.isThrow()) {
            Re_ZPrimitiveClass_exception.Instance aThrow = reStack.getThrow();
            String stacksString = aThrow.buildExceptionString();
            throw new Re_Accidents.ExecuteException(stacksString);
        }
    }










    private static final Re_IJavaReflector DEFAULT_REFLECTOR    = new Re_Reflector();
    private static final Map<String, Re_CodeFile>   compile     = new WeakHashMap<>();//写锁
    private static final Object                     compileLock = new Object();








    protected Re_IJavaReflector       reflector;          //Java反射器, 不要返回任何对象（Field,Method,Constructor）给用户,仅用于内部执行,防止用户setAccessible
    protected boolean                 noUseCompileCache;


    protected Re_PrimitiveClassInstance     env = Re_ZPrimitiveClass_object.reclass.createInstance();
    protected BootstrapReClassLoader        bootstrapReClassLoader;
    protected volatile Re_ZDebuggerServer debuggerServer;


    public Re() {
        this(DEFAULT_REFLECTOR);
    }
    public Re(Re_IJavaReflector reflector) {
        this.reflector = Objects.requireNonNull(reflector, "reflector");
    }




    /**
     * env.xxx
     */
    public Object getEnvironment(String name)               { return Re_Variable.Unsafes.fromUnsafeAccessorGetValue(name, env); }
    public void setEnvironment(String name, Object value)   { Re_Variable.Unsafes.fromUnsafeAccessorSetValueIntern(name, value, env); }
    public boolean hasEnvironment(String name)              { return Re_Variable.has(name, env); }
    public Re_PrimitiveClassInstance getEnvironmentMap()    { return env; }



    /**
     * 默认不使用缓存
     * 因为缓存无法保证代码是否被修改了
     */
    public void setNoUseCompileCache(boolean useCompileCache) {
        this.noUseCompileCache = useCompileCache;
    }
    public boolean isNoUseCompileCache() {
        return noUseCompileCache;
    }



    public Re_CodeFile compileCode(String expression) throws Re_Accidents.CompileTimeGrammaticalException {
        return compileCode(expression, Re_CodeFile.FILE_NAME__JAVA_SOURCE);
    }
    public Re_CodeFile compileCode(String expression, String filePath) throws Re_Accidents.CompileTimeGrammaticalException {
        return compileCode(expression, filePath, 1);
    }

    /**
     *
     * @param expression     表达式
     * @param filePath      表达式所在文件
     * @param lineOffset    表达式所在文件行
     * @return 每次返回的数据可能都不一样
     */
    public Re_CodeFile compileCode(String expression, String filePath, int lineOffset) throws Re_Accidents.CompileTimeGrammaticalException {
        if (noUseCompileCache)
            return compile(expression, filePath, lineOffset);

        Re_CodeFile query = compile.get(expression);
        if (null == query) {
            synchronized (compileLock) {
                compile.put(expression, query = compile(expression, filePath, lineOffset <= 0 ? 1 : lineOffset));
            }
        }
        /*
         * 为了防止对比字符串需要的性能，直接判断是否地址相等就行了
         */
        //noinspection StringEquality
        if (filePath != query.filePath || query.lineOffset != lineOffset) {
            query = query.clone();  //克隆代码但是不克隆文件信息
            query.filePath = filePath;
            query.lineOffset = lineOffset <= 0 ? 1 : lineOffset;
        }
        return query;
    }






    public Object execute(final String expression, Object... params) throws Re_Accidents.CompileTimeGrammaticalException, Re_Accidents.ExecuteException {
        Re_CodeFile block = compileCode(expression);
        return execute(block, null, new Re_VariableMap(), params);
    }
    public Object execute(final Re_CodeFile block, Object... params) throws Re_Accidents.CompileTimeGrammaticalException, Re_Accidents.ExecuteException {
        return execute(block, null, new Re_VariableMap(), params);
    }
    public Object execute(final String expression, Re_IReInnerVariableMap variableMap, Object... params) throws Re_Accidents.CompileTimeGrammaticalException, Re_Accidents.ExecuteException {
        Re_CodeFile block = compileCode(expression);
        return execute(block, null, variableMap, params);
    }
    public Object execute(final Re_CodeFile block, Re_IReInnerVariableMap variableMap, Object... params) throws Re_Accidents.CompileTimeGrammaticalException, Re_Accidents.ExecuteException {
        return execute(block, null, variableMap, params);
    }
    public Object execute(final Re_CodeFile block, Re_NativeStack stack, Re_IReInnerVariableMap variableMap, Object... params) throws Re_Accidents.CompileTimeGrammaticalException, Re_Accidents.ExecuteException {
        Re_Executor executor = Re_Executor.createReRootExecutor(this, stack , block, params, variableMap);
        Object result  = executor.run();
        throwStackException(executor);
        return result;
    }








    public void print(String str)  {
        System.out.print(str);
    }

    public void println() {
        println("");
    }
    public void println(String content) {
        print(content + "\n");
    }



    //默认引导类加载器
    public static class BootstrapReClassLoader extends AppReClassLoader {
        public BootstrapReClassLoader(Re re) {
            super(re, null);
        }
    }

    @SuppressWarnings("unused")
    public Re_ClassLoader getBootstrapClassLoader() {
        return bootstrapReClassLoader;
    }
    public void addBootstrapClassLoaderResource(Re_IResource resource) {
        if (null != resource) {
            if (null == bootstrapReClassLoader) {
                bootstrapReClassLoader = createBootstrapReClassLoader();
            }
            bootstrapReClassLoader.addSourceManager(resource);
        }
    }
    public boolean removeBootstrapClassLoaderResource(Re_IResource resource) {
        if (null == bootstrapReClassLoader) {
            return false;
        } else {
            return bootstrapReClassLoader.removeSourceManager(resource);
        }
    }
    public Re_IResource[] getBootstrapClassLoaderResources() {
        if (null == bootstrapReClassLoader) {
            return null;
        } else {
            return bootstrapReClassLoader.getSources();
        }
    }
    protected BootstrapReClassLoader createBootstrapReClassLoader() {
        return new BootstrapReClassLoader(this);
    }







    /**
     * 使用re 进行类编译
     */
    public static class AppReClassLoader extends Re_ClassLoader {
        public AppReClassLoader(Re re) {
            this(Objects.requireNonNull(re, "host"), null);
        }
        public AppReClassLoader(Re re, Re_ClassLoader parent) {
            super(re, parent);
        }

        //顶级类
        @SuppressWarnings("SpellCheckingInspection")
        @Override
        protected final Re_CodeFile compileFile(Re_NativeStack stack, String filePath, String code) {
            if (stack.isThrow()) return null;
            try {
                return re.compileCode(code, filePath);
            } catch (Re_Accidents.CompileTimeGrammaticalException e) {
                stack.setThrow("compiletime expression error: " + e.getMessage() + " in " + Re_NativeStack.toLineAddressString(e.getFilePath(), e.getLine()) + "");
                return null;
            }
        }

        @Override
        protected void initReClass(Re_NativeStack stack, Re_Class define) {
            if (stack.isThrow()) return;
            Re_Class.runReClassInitialize0(re, stack, define.getCodeBlock(), define);
        }


        @Override
        public void addSourceManager(Re_IResource resource) {
            super.addSourceManager(resource);
        }
        @Override
        public boolean removeSourceManager(Re_IResource resource) {
            return super.removeSourceManager(resource);
        }
        @Override
        public boolean hasSourceManager(Re_IResource resource) {
            return super.hasSourceManager(resource);
        }
        @Override
        public Re_IResourceFile getClassResource(String className) {
            return super.getClassResource(className);
        }
        @Override
        public Re_IResourceFile getFileResource(String filePath) {
            return super.getFileResource(filePath);
        }
        @Override
        public Re_IResource[] getSources() {
            return super.getSources();
        }
    }





    public boolean is_debugger() {
        return null != debuggerServer;
    }
    public Re_ZDebuggerServer get_debugger() {
        synchronized (this) {
            if (null == debuggerServer) {
                debuggerServer = new Re_ZDebuggerServer(this);
            }
            return debuggerServer;
        }
    }
    public void close_debugger() {
        synchronized (this) {
            if (null != debuggerServer) {
                debuggerServer.close();
                debuggerServer = null;
            }
        }
    }
    public Re_ZDebuggerServer open_debugger() throws IOException, InterruptedException {
        Re_ZDebuggerServer debugger;
        debugger = get_debugger();
        debugger.start();
        return debugger;
    }

}