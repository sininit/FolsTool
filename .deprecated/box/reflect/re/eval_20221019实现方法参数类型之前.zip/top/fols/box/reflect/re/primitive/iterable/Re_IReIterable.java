package top.fols.box.reflect.re.primitive.iterable;


@SuppressWarnings({"UnnecessaryModifier", "UnnecessaryInterfaceModifier"})
public interface Re_IReIterable {
    /**
     * 每次执行都可以获取一个元素遍历器
     */
    public abstract Re_AReIterator iterator();
}
