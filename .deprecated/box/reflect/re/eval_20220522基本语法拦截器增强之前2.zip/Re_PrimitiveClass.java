package top.fols.box.reflect.re;

public class Re_PrimitiveClass extends Re_Class {
    protected Re_PrimitiveClass(String className) {
        this(className, null);
    }
    protected Re_PrimitiveClass(String className,
                             Re_Class reDeclaringClass) {
        Re_CodeFile codeBlock;
        codeBlock = new Re_CodeFile();
        codeBlock.filePath = getClass().getName();

        Re_Class.createClassAfter(this, null, className, codeBlock, reDeclaringClass);
        Re_Class.setPrimitiveClassInitialized(this, this);
    }

    @Override
    protected void setInitFunction(Re_ClassFunction initFunction) {
        super.setInitFunction(initFunction);
    }

    @Override
    public boolean isPrimitive() {
        return true;
    }


}
