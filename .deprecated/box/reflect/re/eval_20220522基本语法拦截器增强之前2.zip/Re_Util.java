package top.fols.box.reflect.re;

import top.fols.atri.lang.Arrayz;
import top.fols.atri.lang.Finals;
import top.fols.box.reflect.re.interfaces.Re_IJavaClassObject;
import top.fols.box.reflect.re.interfaces.Re_IObject;
import top.fols.box.reflect.re.primitive.classes.Re_PrimitiveClass_object;
import top.fols.box.reflect.re.primitive.lang.Re_Iterables;
import top.fols.box.reflect.re.primitive.classes.Re_PrimitiveClass_list;
import top.fols.box.reflect.re.primitive.objects.Re_PrimitiveObject_JImport;
import top.fols.box.reflect.re.primitive.objects.Re_PrimitiveObject_JObject;
import top.fols.box.lang.Classx;

import java.lang.reflect.*;
import java.util.*;

import static top.fols.atri.reflect.ReflectMatcher.buildNoSuchMatch;

@SuppressWarnings({"SuspiciousSystemArraycopy", "SpellCheckingInspection", "rawtypes"})
public class Re_Util {
    Re_Util() {}

    public static boolean ifTrue(Object v) {
        if (null == v) return false;
        if (v instanceof Boolean) return (Boolean) v;
        return true;
    }
    public static boolean ifFalse(Object v) {
        if (null == v) return true;
        if (v instanceof Boolean) return !((Boolean) v);
        return false;
    }
    public static boolean ifAnd(Object v, Object v2) {
        return ifTrue(v) && ifTrue(v2) ;
    }
    public static boolean ifOr(Object v, Object v2) {
        return ifTrue(v) || ifTrue(v2);
    }


    public static Boolean isArray(Object array) {
        return null != array && array.getClass().isArray();
    }

    public static boolean isSpace(Object o) {
        return o instanceof Re_Executor;
    }





    public static String toString(Object obj) {
        if (null == obj) return "null";
        return obj.toString();
    }

    public static char toChar(Object obj) {
        if (null == obj) {return (char)0;}
        if (obj instanceof Character) {return (Character) obj;}
        if (obj instanceof Number) {return (char) ((Number) obj).intValue();}
        return (char)0;
    }

    public static boolean toBoolean(Object obj) {
        if (null == obj) {return false;}
        if (obj instanceof Character) {return (Character) obj != 0;}
        if (obj instanceof Boolean) {return (Boolean) obj;}
        return Boolean.parseBoolean(obj.toString());
    }



    public static byte toByte(Object obj) {
        if (null == obj) {return 0;}
        if (obj instanceof Character) { return (byte) ((Character) obj).charValue(); }
        if (obj instanceof Number) {return ((Number) obj).byteValue();}
        return Byte.parseByte(obj.toString());
    }

    public static int toInt(Object obj) {
        if (null == obj) {return 0;}
        if (obj instanceof Character) { return (int) ((Character) obj).charValue(); }
        if (obj instanceof Number) {return ((Number) obj).intValue();}
        return Integer.parseInt(obj.toString());
    }

    public static long toLong(Object obj) {
        if (null == obj) {return 0;}
        if (obj instanceof Character) { return (long) ((Character) obj).charValue(); }
        if (obj instanceof Number) {return ((Number) obj).longValue();}
        return Long.parseLong(obj.toString());
    }

    public static short toShort(Object obj) {
        if (null == obj) {return 0;}
        if (obj instanceof Character) { return (short) ((Character) obj).charValue(); }
        if (obj instanceof Number) {return ((Number) obj).shortValue();}
        return Short.parseShort(obj.toString());
    }

    /**
     * xx.xxx
     **/
    public static double toDouble(Object obj) {
        if (null == obj) {return 0;}
        if (obj instanceof Character) { return (double) ((Character) obj).charValue(); }
        if (obj instanceof Number) {return ((Number) obj).doubleValue();}
        return Double.parseDouble(obj.toString());
    }

    /**
     * xx.xxx
     **/
    public static float toFloat(Object obj) {
        if (null == obj) {return 0;}
        if (obj instanceof Character) { return (float) ((Character) obj).charValue(); }
        if (obj instanceof Number) {return ((Number) obj).floatValue();}
        return Float.parseFloat(obj.toString());
    }






    public static boolean isString(Object obj) {
        return obj instanceof String;
    }
    public static boolean isChar(Object obj) {
        return obj instanceof Character;
    }
    public static boolean isBoolean(Object obj) {
        return obj instanceof Boolean;
    }
    public static boolean isByte(Object obj) {
        return obj instanceof Byte;
    }
    public static boolean isInt(Object obj) {
        return obj instanceof Integer;
    }
    public static boolean isLong(Object obj) {
        return obj instanceof Long;
    }
    public static boolean isShort(Object obj) {
        return obj instanceof Short;
    }
    public static boolean isDouble(Object obj) {
        return obj instanceof Double;
    }
    public static boolean isFloat(Object obj) {
        return obj instanceof Float;
    }


    /**
     * return class point object
     * no set var
     *
     * @param nameOrClass class name， or java object
     */
    public static Re_PrimitiveObject_JImport jimport(Object nameOrClass) throws ClassNotFoundException {
        return jimport(jforNameFindClass(nameOrClass));
    }


    /**
     * return class point object
     * no set var
     *
     * @param cls class
     */
    public static Re_PrimitiveObject_JImport jimport(Class<?> cls) {
        return new Re_PrimitiveObject_JImport(cls);
    }
    public static boolean is_jimport(Object object) {
        return object instanceof Re_PrimitiveObject_JImport;
    }


    public static Re_PrimitiveObject_JObject jobject(Object object) {
        return new Re_PrimitiveObject_JObject(object);
    }
    public static boolean is_jobject(Object object) {
        return object instanceof Re_PrimitiveObject_JObject;
    }



    public static boolean is_IGetJavaClass(Object object) {
        return object instanceof Re_IJavaClassObject;
    }






    /**
     * @param object 如果是Class直接返回
     *               如果是Jimport则返回import的类
     *               否者执行 object.getClass();
     */
    public static Class<?> jObjectToJClass(Object object) {
        if (object instanceof Class) {
            return ((Class<?>) object);
        } else if (is_IGetJavaClass(object)) {
            return ((Re_IJavaClassObject) object).getJavaClass();
        } else {
            return null == object ? null : object.getClass();
        }
    }




    /**
     * 不建议使用本方法
     * 因为{@link Class#forName(String)} 是根据获取了调用该方法的类来确定加载器，
     * 由于你用了这个方法所有 调用的类永远不是你的类而是{@link Re_Util} 也就是说永远是从本工具类的加载器中寻找你要找的类
     */
    @SuppressWarnings("SpellCheckingInspection")
    public static Class<?> jforNameFindClass(String name) throws ClassNotFoundException {
        return Classx.forName(name);
    }

    /**
     * @param name 类名
     * @param callerClass 你从哪个地方调用了这个方法 直接传入getClass即可
     */
    public static Class<?> jforNameFindClass(String name, Class<?> callerClass) throws ClassNotFoundException {
        return Classx.forName(name, callerClass);
    }

    @SuppressWarnings("SpellCheckingInspection")
    public static Class<?> jforNameFindClass(String name, boolean initialize,
                                             ClassLoader loader) throws ClassNotFoundException {
        return Classx.forName(name, initialize, loader);
    }




    public static Class<?> jforNameFindClass(Object ele) throws ClassNotFoundException {
        if (null == ele)
            return null;

        if (ele instanceof Class)
            return (Class<?>) ele;

        if (Re_Util.is_IGetJavaClass(ele))
            return ((Re_IJavaClassObject) ele).getJavaClass();

        return jforNameFindClass(Re_Util.toString(ele));
    }
    public static Class<?>[] jforNameFindClasss(Object[] value) throws ClassNotFoundException {
        return jforNameFindClasss(value, 0,null == value?0:value.length);
    }
    public static Class<?>[] jforNameFindClasss(Object[] value, int off, int len) throws ClassNotFoundException {
        if (value instanceof Class[]) {
            if (off <= 0 && len >= value.length) {
                return (Class<?>[])value;
            } else {
                Class<?>[] nvalue = new Class[Math.max(len, 0)];
                System.arraycopy(value, Math.max(off, 0), nvalue,0,nvalue.length);
                return nvalue;
            }
        }
        Class<?>[] nvalue = new Class[Math.max(len, 0)];
        for (int i = 0; i < len; i++) {
            Object ele = value[off+i];
            if (ele instanceof Class) {
                nvalue[i] = (Class<?>) ele;
            } else if (Re_Util.is_IGetJavaClass(ele)) {
                nvalue[i] = ((Re_IJavaClassObject) ele).getJavaClass();
            } else {
                Class<?> cls;
                if (null == ele) {
                    continue;
                }
                cls = jforNameFindClass(Re_Util.toString(ele));
                nvalue[i] = cls;
            }
        }
        return nvalue;
    }




    public static class SimpleArray<E> {
        private static final Object[] DEFAULTCAPACITY_EMPTY_ELEMENTDATA = {};
        Object[] elementData;
        private int size;
        private static final int MAX_ARRAY_SIZE = Integer.MAX_VALUE - 8;
        private static final int DEFAULT_CAPACITY = 10;

        public SimpleArray() {
            this.elementData = DEFAULTCAPACITY_EMPTY_ELEMENTDATA;
        }
        public SimpleArray(E[] value) {
            this.elementData = null == value?DEFAULTCAPACITY_EMPTY_ELEMENTDATA:value;
        }

        private static int hugeCapacity(int minCapacity) {
            if (minCapacity < 0) // overflow
                throw new OutOfMemoryError();
            return (minCapacity > MAX_ARRAY_SIZE) ?
                    Integer.MAX_VALUE :
                    MAX_ARRAY_SIZE;
        }
        private void grow(int minCapacity) {
            // overflow-conscious code
            int oldCapacity = elementData.length;
            int newCapacity = oldCapacity + (oldCapacity >> 1);
            if (newCapacity - minCapacity < 0)
                newCapacity = minCapacity;
            if (newCapacity - MAX_ARRAY_SIZE > 0)
                newCapacity = hugeCapacity(minCapacity);
            // minCapacity is usually close to size, so this is a win:
            elementData = Arrays.copyOf(elementData, newCapacity);
        }


        private void ensureExplicitCapacity(int minCapacity) {
            // overflow-conscious code
            if (minCapacity - elementData.length > 0)
                grow(minCapacity);
        }

        private static int calculateCapacity(Object[] elementData, int minCapacity) {
            if (elementData == DEFAULTCAPACITY_EMPTY_ELEMENTDATA) {
                return Math.max(DEFAULT_CAPACITY, minCapacity);
            }
            return minCapacity;
        }

        private void ensureCapacityInternal(int minCapacity) {
            ensureExplicitCapacity(calculateCapacity(elementData, minCapacity));
        }




        public int size() {
            return size;
        }

        public E get(int index) {
            if (index >= 0 || index < size)
                //noinspection unchecked
                return (E) elementData[index];
            return null;
        }

        public void set(Object index, E element) {
            if (index instanceof Number) {
                this.set(((Number) index).intValue(), element);
            }
        }
        public void set(Number index, E element) {
            this.set(index.intValue(), element);
        }

        public void set(int index, E element) {
            if (index >= size) {
                int newSize = index + 1;
                ensureCapacityInternal(newSize);
                elementData[index] = element;
                size = newSize;
            } else {
                elementData[index] = element;
            }
        }

        public void setSize(int size) {
            if (elementData.length < size) {
                ensureCapacityInternal(size);
            }
            this.size = size;
        }

        public void trimToSize() {
            if (size < elementData.length) {
                elementData = (size == 0)
                        ? DEFAULTCAPACITY_EMPTY_ELEMENTDATA
                        : Arrays.copyOf(elementData, size);
            }
        }

        public void clear() {
            size = 0;
            elementData = DEFAULTCAPACITY_EMPTY_ELEMENTDATA;
        }

        public boolean add(E e) {
            ensureCapacityInternal(size + 1);  // Increments modCount!!
            elementData[size++] = e;
            return true;
        }

        public Object[] toArray() {
            return Arrays.copyOf(elementData, size);
        }
    }





    public static boolean toarrayable(Object object) {
        if (null == object) {
            return false;
        }
        if (object instanceof Re_IObject) {
            return true;
        }
        Class<?> aClass = object.getClass();
        if (aClass.isArray()) {
            return true;
        }

        //keyset
        if (object instanceof Iterable) {
            return true;
        }
        return false;
    }
    @SuppressWarnings("unchecked")
    public static Object[] toarray(Re_Executor executor, Object object) throws Throwable {
        if (null == object) {
            return null;
        }

        if (object instanceof Re_IObject) {
            Re_IObject iObject = (Re_IObject) object;
            Iterable keysProcess = iObject.getKeysProcess(executor);

            SimpleArray array = new SimpleArray();
            for (Object index : keysProcess) {
                Object  value = iObject.getVariableProcess(executor, index);
                if (executor.isReturn()) return null;

                array.set(index, value);
            }
            return array.toArray();
        }

        Class<?> aClass = object.getClass();
        if (aClass.isArray()) {
            Class<?> componentType = aClass.getComponentType();
            if (componentType.isPrimitive()) {
                return (Object[]) Arrayz.convert(object, Finals.OBJECT_ARRAY_CLASS);
            } else {
                if (componentType == Finals.OBJECT_CLASS) {
                    return (Object[]) object;
                } else {
                    return (Object[]) Arrayz.convert(object, Finals.OBJECT_ARRAY_CLASS);
                }
            }
        }

        //keyset
        if (object instanceof Iterable) {
            Iterable<?> o = (Iterable) object;

            Iterator<?> iterator = o.iterator();
            List cache = new ArrayList();
            while (iterator.hasNext())
                cache.add(iterator.next());

            return cache.toArray();
        }

        executor.setThrow("unsupport type: " + object.getClass());
        return null;
    }



    public static boolean tolistable(Object object) {
        if (null == object) {
            return false;
        }
        if (object instanceof Re_IObject) {
            return true;
        }
        Class<?> aClass = object.getClass();
        if (aClass.isArray()) {
            return true;
        }

        //keyset
        if (object instanceof Iterable) {
            return true;
        }
        return false;
    }
    public static Re_PrimitiveClass_list.Instance tolist(Re_Executor executor, Object object) throws Throwable {
        if (null == object) {
            return null;
        }

        Re_PrimitiveClass_list.Instance instance = Re_PrimitiveClass_list.reclass.createInstance();

        if (object instanceof Re_IObject) {
            Re_IObject iObject = (Re_IObject) object;
            Iterable keysProcess = iObject.getKeysProcess(executor);

            for (Object index : keysProcess) {
                Object  value = iObject.getVariableProcess(executor, index);
                if (executor.isReturn()) return null;

                instance.setElement(index, value);
            }
            return instance;
        }

        Class<?> aClass = object.getClass();
        if (aClass.isArray()) {
            if (aClass.getComponentType().isPrimitive()) {
                Object[] convert = Arrayz.convert(object, Finals.OBJECT_ARRAY_CLASS);
                instance.setElements(convert);
            } else {
                instance.setElements((Object[]) object);
            }
            return instance;
        }

        //keyset
        if (object instanceof Iterable) {
            Iterable<?> o = (Iterable) object;

            List cache = new ArrayList();
            Iterator<?> iterator = o.iterator();
            while (iterator.hasNext())
                cache.add(iterator.next());

            instance.setElements(cache.toArray());
            return instance;
        }

        executor.setThrow("unsupport type: " + object.getClass());
        return null;
    }




    public static boolean toinstanceable(Object object) {
        if (null == object) {
            return false;
        }
        if (object instanceof Re_IObject) {
            return true;
        }
        Class<?> aClass = object.getClass();
        if (aClass.isArray()) {
            return true;
        }

        //keyset
        if (object instanceof Iterable) {
            return true;
        }
        return false;
    }
    public static Re_Class.Instance toinstance(Re_Executor executor, Object object) throws Throwable {
        if (null == object) {
            return null;
        }

        Re_Class.Instance instance = Re_PrimitiveClass_object.reclass.createInstance();

        if (object instanceof Re_IObject) {
            Re_IObject reIReObject = (Re_IObject) object;
            Iterable keysProcess = reIReObject.getKeysProcess(executor);
            if (executor.isReturn()) return null;

            for (Object key : keysProcess) {
                Object val = reIReObject.getVariableProcess(executor, key);
                if (executor.isReturn()) return null;

                Re_Variable.accessSetValue(executor, key, val, instance);
                if (executor.isReturn()) return null;
            }
            return instance;
        }

        Class<?> aClass = object.getClass();
        if (aClass.isArray()) {
            for (int i = 0; i < Array.getLength(object); i++) {
                Object o = Array.get(object, i);

                Re_Variable.accessSetValue(executor, i, o, instance);
                if (executor.isReturn()) return null;
            }
            return instance;
        }

        //keyset
        if (object instanceof Iterable) {
            Iterable<?> o = (Iterable) object;

            int i = 0;
            for (Object value : o) {
                Re_Variable.accessSetValue(executor, i, value, instance);
                if (executor.isReturn()) return null;

                i++;
            }
            return instance;
        }

        executor.setThrow("unsupport type: " + object.getClass());
        return null;
    }








    public static Object getattr(Re_Executor executor, Object object, Object key) {
        if (null == object) {
            return null;
        }

        if (object instanceof Re_IObject) {
            Re_IObject reIReObject = (Re_IObject) object;
            try {
                return reIReObject.getVariableProcess(executor, key);
            } catch (Throwable e) {
                executor.setThrow(e);
                return null;
            }
        }

        Class<?> aClass = object.getClass();
        if (aClass.isArray()) {
            if (key instanceof Number) {
                int index = ((Number) key).intValue();
                return index >= 0 && index < Array.getLength(object) ? Array.get(object, index) : null;
            }
            return null;
        }
        executor.setThrow("unsupport type: " + object.getClass());
        return null;
    }


    public static boolean setattr(Re_Executor executor, Object object, Object key, Object value) {
        if (object instanceof Re_IObject) {
            Re_IObject reIReObject = (Re_IObject) object;
            try {
                reIReObject.setVariableProcess(executor, key, value);
                return true;
            } catch (Throwable e) {
                executor.setThrow(e);
                return false;
            }
        }

        Class<?> aClass = object.getClass();
        if (aClass.isArray()) {
            if (key instanceof Number) {
                int index = ((Number) key).intValue();
                if (index >= 0 && index < Array.getLength(object)) {
                    Array.set(object, index, value);
                    return true;
                }
            }
            return false;
        }
        executor.setThrow("unsupport type: " + object.getClass());
        return false;
    }
    public static boolean hasattr(Re_Executor executor, Object object, Object key) {
        if (null == object) {
            return false;
        }

        if (object instanceof Re_IObject) {
            Re_IObject reIReObject = (Re_IObject) object;
            try {
                return reIReObject.hasVariableProcess(executor, key);
            } catch (Throwable e) {
                executor.setThrow(e);
                return false;
            }
        }

        Class<?> aClass = object.getClass();
        if (aClass.isArray()) {
            if (key instanceof Number) {
                int index = ((Number) key).intValue();
                return index >= 0 && index < Array.getLength(object);
            }
            return false;
        }
        executor.setThrow("unsupport type: " + object.getClass());
        return false;
    }

    public static boolean delattr(Re_Executor executor, Object object, Object key) {
        if (null == object) {
            return false;
        }

        if (object instanceof Re_IObject) {
            Re_IObject reIReObject = (Re_IObject) object;
            try {
                return reIReObject.removeVariableProcess(executor, key);
            } catch (Throwable e) {
                executor.setThrow(e);
                return false;
            }
        }

        Class<?> aClass = object.getClass();
        if (aClass.isArray()) {
            executor.setThrow("unsupport type: " + object.getClass());
            return false;
        }
        executor.setThrow("unsupport type: " + object.getClass());
        return false;
    }
    public static int lenattr(Re_Executor executor, Object object) {
        if (null == object) {
            return 0;
        }

        if (object instanceof Re_IObject) {
            Re_IObject reIReObject = (Re_IObject) object;
            try {
                return reIReObject.getSizeProcess(executor);
            } catch (Throwable e) {
                executor.setThrow(e);
                return 0;
            }
        }

        Class<?> aClass = object.getClass();
        if (aClass.isArray()) {
            return Array.getLength(object);
        }
        executor.setThrow("unsupport type: " + object.getClass());
        return 0;
    }
    public static Iterable keyattr(Re_Executor executor, Object object) {
        if (null == object) {
            return null;
        }
        if (object instanceof Re_IObject) {
            Re_IObject reIReObject = (Re_IObject) object;
            try {
                return reIReObject.getKeysProcess(executor);
            } catch (Throwable e) {
                executor.setThrow(e);
                return null;
            }
        }

        Class<?> aClass = object.getClass();
        if (aClass.isArray()) {
            return Re_Iterables.Java.wrapRange(0, Array.getLength(object));
        }





        if (object instanceof Iterable) {
            return (Iterable<?>) object;
        }

        executor.setThrow("unsupport type: " + object.getClass());
        return null;
    }
}
