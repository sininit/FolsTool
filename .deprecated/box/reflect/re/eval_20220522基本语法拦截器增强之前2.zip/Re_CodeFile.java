package top.fols.box.reflect.re;

import top.fols.atri.lang.Objects;
import top.fols.box.reflect.re.variables.Re_ConstVariableMap;


@SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
public class Re_CodeFile implements Cloneable {

    public static final String INNER_EVAL__FILE_NAME    = Re_CodeLoader.intern("<eval>");
    public static final String JAVA_SOURCE__FILE_NAME = Re_CodeLoader.intern("<source>");

    public static final Re_CodeFile NULL_FILE = new Re_CodeFile() {{
        expressions = Re_CodeLoader.Expression.EMPTY_EXPRESSION;
        expressionsOffset = 0; //我们执行最后一个表达式即可
        filePath = JAVA_SOURCE__FILE_NAME;
        lineOffset = 1;   //没有意义的
        constManager = new Re_ConstVariableMap();
    }};


    String filePath;
    int lineOffset = 1; //代码在文件中的开始位置, 编译时是从这里算起的

    public String getFilePath() {
        return filePath;
    }
    public int getLineOffset()  {
        return lineOffset;
    }



    //↓以下全都是缓存↓
    //可以重复利用以下数据
    @Override
    public Re_CodeFile clone() {
        try {
            return (Re_CodeFile) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e); //不可能
        }
    }



    int expressionsOffset = 0;
    Re_CodeLoader.Expression[] expressions;
    Re_CodeLoader.Expression[] getExpressions() {
        return this.expressions;
    }
    void setExpressions(Re_CodeLoader.Expression[] re_lineCodes) {
        this.expressions = null==re_lineCodes? Re_CodeLoader.Expression.EMPTY_EXPRESSION :re_lineCodes;
    }

    /**
     * @return 表达式开始位置
     */
    int getExpressionsOffset() {
        return this.expressionsOffset;
    }
    /**
     * @return 获取表达式总长度，不是指需要执行的长度
     */
    int getExpressionsLength() {
        return this.expressions.length;
    }





    //自从Var自带variable后就弃用了
    Re_ConstVariableMap constManager = null;
    @Deprecated
    public Re_ConstVariableMap getConstManager() {
        return constManager;
    }



    public Re_CodeFile() {
        expressions = Re_CodeLoader.Expression.EMPTY_EXPRESSION;
    }





    /**
     * const.xxx
     * 将全部常量包装 包装每次get 的值都不会被修改
     */
    public Re_CodeLoader.Var createConst(Re_CodeLoader.Expression c, int line, long javavalue) {
        if (constManager == null) constManager = new Re_ConstVariableMap();

        String name = Re_CodeLoader.intern("l_" + javavalue);
        Re_Variable variable = constManager.get(name);
        if (null == variable) {
            variable = new Compile_Long_Variable(javavalue);
            Re_Variable.Unsafe.addVariable(name, variable, constManager);
        } else {
            if (!Objects.equals(javavalue, Re_Variable.Unsafe.fromDirectAccessorFindValue(name, constManager))) {
                throw new UnsupportedOperationException("repeat var: " + name);
            }
        }
        Re_CodeLoader.Var newTop = new Re_CodeLoader.Var();
        newTop.name = name;
        newTop.staticValue = variable;//将关键字值直接加入代码 以后将不在获取keyword
        newTop.line = line;

        return newTop;
    }

    public Re_CodeLoader.Var createConst(Re_CodeLoader.Expression c, int line, float javavalue) {
        if (constManager == null) constManager = new Re_ConstVariableMap();

        String name = Re_CodeLoader.intern("f_" + javavalue);
        Re_Variable variable = constManager.get(name);
        if (null == variable) {
            variable = new Compile_Float_Variable(javavalue);
            Re_Variable.Unsafe.addVariable(name, variable, constManager);
        } else {
            if (!Objects.equals(javavalue, Re_Variable.Unsafe.fromDirectAccessorFindValue(name, constManager))) {
                throw new UnsupportedOperationException("repeat var: " + name);
            }
        }
        Re_CodeLoader.Var newTop = new Re_CodeLoader.Var();
        newTop.name = name;
        newTop.staticValue = variable;//将关键字值直接加入代码 以后将不在获取keyword
        newTop.line = line;

        return newTop;
    }

    public Re_CodeLoader.Var createConst(Re_CodeLoader.Expression c, int line, double javavalue) {
        if (constManager == null) constManager = new Re_ConstVariableMap();

        String name = Re_CodeLoader.intern("d_" + javavalue);
        Re_Variable variable = constManager.get(name);
        if (null == variable) {
            variable = new Compile_Double_Variable(javavalue);
            Re_Variable.Unsafe.addVariable(name, variable, constManager);
        } else {
            if (!Objects.equals(javavalue, Re_Variable.Unsafe.fromDirectAccessorFindValue(name, constManager))) {
                throw new UnsupportedOperationException("repeat var: " + name);
            }
        }
        Re_CodeLoader.Var newTop = new Re_CodeLoader.Var();
        newTop.name = name;
        newTop.staticValue = variable;//将关键字值直接加入代码 以后将不在获取keyword
        newTop.line = line;

        return newTop;
    }

    public Re_CodeLoader.Var createConst(Re_CodeLoader.Expression c, int line, short javavalue) {
        if (constManager == null) constManager = new Re_ConstVariableMap();

        String name = Re_CodeLoader.intern("s_" + javavalue);
        Re_Variable variable = constManager.get(name);
        if (null == variable) {
            variable = new Compile_Short_Variable(javavalue);
            Re_Variable.Unsafe.addVariable(name, variable, constManager);
        } else {
            if (!Objects.equals(javavalue, Re_Variable.Unsafe.fromDirectAccessorFindValue(name, constManager))) {
                throw new UnsupportedOperationException("repeat var: " + name);
            }
        }
        Re_CodeLoader.Var newTop = new Re_CodeLoader.Var();
        newTop.name = name;
        newTop.staticValue = variable;//将关键字值直接加入代码 以后将不在获取keyword
        newTop.line = line;

        return newTop;
    }

    public Re_CodeLoader.Var createConst(Re_CodeLoader.Expression c, int line, byte javavalue) {
        if (constManager == null) constManager = new Re_ConstVariableMap();

        String name = Re_CodeLoader.intern("b_" + javavalue);
        Re_Variable variable = constManager.get(name);
        if (null == variable) {
            variable = new Compile_Byte_Variable(javavalue);
            Re_Variable.Unsafe.addVariable(name, variable, constManager);
        } else {
            if (!Objects.equals(javavalue, Re_Variable.Unsafe.fromDirectAccessorFindValue(name, constManager))) {
                throw new UnsupportedOperationException("repeat var: " + name);
            }
        }
        Re_CodeLoader.Var newTop = new Re_CodeLoader.Var();
        newTop.name = name;
        newTop.staticValue = variable;//将关键字值直接加入代码 以后将不在获取keyword
        newTop.line = line;

        return newTop;
    }

    public Re_CodeLoader.Var createConst(Re_CodeLoader.Expression c, int line, int javavalue) {
        if (constManager == null) constManager = new Re_ConstVariableMap();

        String name = Re_CodeLoader.intern("i_" + javavalue);
        Re_Variable variable = constManager.get(name);
        if (null == variable) {
            variable = new Compile_Int_Variable(javavalue);
            Re_Variable.Unsafe.addVariable(name, variable, constManager);
        } else {
            if (!Objects.equals(javavalue, Re_Variable.Unsafe.fromDirectAccessorFindValue(name, constManager))) {
                throw new UnsupportedOperationException("repeat var: " + name);
            }
        }
        Re_CodeLoader.Var newTop = new Re_CodeLoader.Var();
        newTop.name = name;
        newTop.staticValue = variable;//将关键字值直接加入代码 以后将不在获取keyword
        newTop.line = line;

        return newTop;
    }





    public Re_CodeLoader.Var createConst(Re_CodeLoader.Expression c, int line, char javavalue) {
        if (constManager == null) constManager = new Re_ConstVariableMap();

        String name = Re_CodeLoader.intern("c_" + javavalue);
        Re_Variable variable = constManager.get(name);
        if (null == variable) {
            variable = new Compile_Char_Variable(javavalue);
            Re_Variable.Unsafe.addVariable(name, variable, constManager);
        } else {
            if (!Objects.equals(javavalue, Re_Variable.Unsafe.fromDirectAccessorFindValue(name, constManager))) {
                throw new UnsupportedOperationException("repeat var: " + name);
            }
        }
        Re_CodeLoader.Var newTop = new Re_CodeLoader.Var();
        newTop.name = name;
        newTop.staticValue = variable;//将关键字值直接加入代码 以后将不在获取keyword
        newTop.line = line;

        return newTop;
    }


    private long id = 0;
    private long nextID() { return ++id; }
    /**
     * 下下策， string不能比较只能每个string做一个新的对象了
     */
    public Re_CodeLoader.Var createConst(Re_CodeLoader.Expression c, int line, String javavalue) {
        if (constManager == null) constManager = new Re_ConstVariableMap();

        String v = Re_CodeLoader.intern(javavalue); //破罐子破摔
        String name = Re_CodeLoader.intern("str_" + nextID());
        Re_Variable variable = constManager.get(name);
        if (null == variable) {
            variable = new Compile_String_Variable(v);
            Re_Variable.Unsafe.addVariable(name, variable, constManager);
        } else {
            if (!Objects.equals(javavalue, Re_Variable.Unsafe.fromDirectAccessorFindValue(name, constManager))) {
                throw new UnsupportedOperationException("repeat var: " + name);
            }
        }
        Re_CodeLoader.Var newTop = new Re_CodeLoader.Var();
        newTop.name = name;
        newTop.staticValue = variable;//将关键字值直接加入代码 以后将不在获取keyword
        newTop.line = line;

        return newTop;
    }











    //每次get(Re_Executor executor) 和缓存对比 如果不相同则返回新的对象，尽最大可能防止了傻逼操作

    public static class Compile_Int_Variable extends Re_Variable.FinalVariable<Integer> {
        final int value;

        public Compile_Int_Variable(int javavalue) {
            value = javavalue;
            __value__ = new Integer(javavalue);
        }

        @Override
        public Integer get(Re_Executor executor) {
            return (__value__.intValue() == value)?__value__:(__value__ = new Integer(value));
        }

        public Integer get() {
            return (__value__.intValue() == value)?__value__:(__value__ = new Integer(value));
        }
    }

    public static class Compile_Char_Variable extends Re_Variable.FinalVariable<Character> {
        final char value;

        public Compile_Char_Variable(char javavalue) {
            value = javavalue;
            __value__ = new Character(javavalue);
        }

        @Override
        public Character get(Re_Executor executor) {
            return (__value__.charValue() == value)?__value__:(__value__ = new Character(value));
        }

        public Character get() {
            return (__value__.charValue() == value)?__value__:(__value__ = new Character(value));
        }
    }

    public static class Compile_Byte_Variable extends Re_Variable.FinalVariable<Byte> {
        final byte value;
        public Compile_Byte_Variable(byte javavalue) {
            value = javavalue;
            __value__ = new Byte(javavalue);
        }

        @Override
        public Byte get(Re_Executor executor) {
            return (__value__.byteValue() == value)?__value__:(__value__ = new Byte(value));
        }

        public Byte get() {
            return (__value__.byteValue() == value)?__value__:(__value__ = new Byte(value));
        }
    }

    public static class Compile_Short_Variable extends Re_Variable.FinalVariable<Short> {
        final short value;

        public Compile_Short_Variable(short javavalue) {
            value = javavalue;
            __value__ = new Short(javavalue);
        }

        @Override
        public Short get(Re_Executor executor) {
            return (__value__.shortValue() == value)?__value__:(__value__ = new Short(value));
        }

        public Short get() {
            return (__value__.shortValue() == value)?__value__:(__value__ = new Short(value));
        }
    }

    public static class Compile_Double_Variable extends Re_Variable.FinalVariable<Double> {
        final double value;

        public Compile_Double_Variable(double javavalue) {
            value = javavalue;
            __value__ = new Double(javavalue);
        }

        @Override
        public Double get(Re_Executor executor) {
            return (__value__.doubleValue() == value)?__value__:(__value__ = new Double(value));
        }

        public Double get() {
            return (__value__.doubleValue() == value)?__value__:(__value__ = new Double(value));
        }
    }

    public static class Compile_Float_Variable extends Re_Variable.FinalVariable<Float> {
        final float value;

        public Compile_Float_Variable(float javavalue) {
            value = javavalue;
            __value__ = new Float(javavalue);
        }

        @Override
        public Float get(Re_Executor executor) {
            return (__value__.floatValue() == value)?__value__:(__value__ = new Float(value));
        }

        public Float get() {
            return (__value__.floatValue() == value)?__value__:(__value__ = new Float(value));
        }
    }

    public static class Compile_Long_Variable extends Re_Variable.FinalVariable<Long> {
        final long value;

        public Compile_Long_Variable(long javavalue) {
            value = javavalue;
            __value__ = new Long(javavalue);
        }

        @Override
        public Long get(Re_Executor executor) {
            return (__value__.longValue() == value)?__value__:(__value__ = new Long(value));
        }

        public Long get() {
            return (__value__.longValue() == value)?__value__:(__value__ = new Long(value));
        }
    }

    @SuppressWarnings("BooleanConstructorCall")
    public static class Compile_Boolean_Variable extends Re_Variable.FinalVariable<Boolean> {
        static final Boolean JAVA_CACHE_TRUE  = true;  //java auto boxing cache
        static final Boolean JAVA_CACHE_FALSE = false; //java auto boxing cache

        final boolean value;

        public Compile_Boolean_Variable(boolean javavalue) {
            value = javavalue;
            __value__ = javavalue? JAVA_CACHE_TRUE : JAVA_CACHE_FALSE;
        }

        @Override
        public Boolean get(Re_Executor executor) {
            return (__value__.booleanValue() == value)?__value__:(__value__ = new Boolean(value));
        }

        public Boolean get() {
            return (__value__.booleanValue() == value)?__value__:(__value__ = new Boolean(value));
        }
    }

    public static class Compile_Null_Variable extends Re_Variable.FinalVariable<Object> {
        public Compile_Null_Variable() {
            super(null);
        }

        @Override
        public Object get(Re_Executor executor) {
            return null;
        }

        public Object get() {
            return null;
        }
    }

    public static class Compile_String_Variable extends Re_Variable.FinalVariable<String> {
        public Compile_String_Variable(String string) {
            super(string);
        }

        @Override
        public String get(Re_Executor executor) {
            return __value__;
        }

        public String get() {
            return __value__;
        }
    }

}
