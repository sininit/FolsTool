package top.fols.box.reflect.re.interfaces;

import top.fols.box.reflect.re.Re_CodeLoader;
import top.fols.box.reflect.re.Re_Executor;
import top.fols.box.reflect.re.Re_Variable;

import java.util.Collection;


/**
 * 变量存储表
 * 该对象所有方法操作应该由Re_Variable进行
 * variable是用来存储object值的
 * 不用stack 因此不出现任何异常
 */
@SuppressWarnings("UnnecessaryModifier")
public interface Re_IVariableMap {

    /**
     * 直接删除
     * 理论上你必须使用 {@link Re_Variable} 而不是自己操作， 这些方法主要 {@link Re_Variable} 调用
     * 删除当前层的变量
     */
    public Re_Variable remove(Object key);


    /**
     * 只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
     *
     * print(a);
     * {@link Re_IVariableMap#find(Object)} 一般是在 Executor 执行过程中获取（局部变量 或者向上查找）的时候执行的	 *
     *
     * print(obj.x);
     * {@link Re_IObject} 它的实例是一个re对象，在Executor执行时需要获取这个实例的属性则会执行 {@link Re_IObject#getVariableProcess(Re_Executor, Object)} 这个方法
     */
    public Re_Variable find(Object key);

    /**
     * 获取当前层的变量， 一般用来判断如果不存在则put， 不要向上获取
     */
    public Re_Variable get(Object key);


    /**
     * 原始提交
     * 理论上你必须使用 {@link Re_Variable} 而不是自己操作， 这些方法主要 {@link Re_Variable} 调用
     *
     * 提交当前层的变量
     */
    public Re_Variable put(Object key, Re_Variable value);


    /**
     * 判断当前层是否存在变量
     */
    public boolean containsKey(Object key);

    /**
     * 当前层数量
     */
    public int size();


    /**
     * @return 变量名
     * 返回不可修改的集合， 或者克隆
     *
     * 当前层的变量名集合
     */
    public Collection<?> keySet();

}
