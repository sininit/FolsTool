package top.fols.box.reflect.re.interfaces;

import top.fols.box.reflect.re.*;

/**
 * interface 天下第一

 *  {@link Re_Variable}变量存储器，和 {@link Re_IObject}对象不是一个概念
 *  Re_Object 不是   Re_Variable
 *  Re_Object 可以被  Re_Variable 储存
 */
@SuppressWarnings("ALL")
public interface Re_IObject {
	public static final Re_CodeFile.Compile_Boolean_Variable True  = new Re_CodeFile.Compile_Boolean_Variable(true);
	public static final Re_CodeFile.Compile_Boolean_Variable False = new Re_CodeFile.Compile_Boolean_Variable(false);
	public static final Re_CodeFile.Compile_Null_Variable 	 Null  = new Re_CodeFile.Compile_Null_Variable();


	/**
	 * 底层实现的对象
	 */
	public boolean isPrimitive();


	/**
	 * 获取子变量，不是获取自己
	 * 只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
	 *
	 * print(a);
	 * {@link Re_IVariableMap#find(Object)} 一般是在 Executor 执行过程中获取（局部变量 或者向上查找）的时候执行的	 *
	 *
	 * print(obj.x);
	 * {@link Re_IObject} 它的实例是一个re对象，在Executor执行时需要获取这个实例的属性则会执行 {@link Re_IObject#getVariableProcess(Re_Executor, Object)} 这个方法
	 */
	public Object  getVariableProcess   (Re_Executor executor, Object key) throws Throwable;


	/**
	 * 设置子变量，不是设置自己
	 *  只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
	 *
	 *  xx.x = value;
	 */
	public void    setVariableProcess   (Re_Executor executor, Object key, Object value) throws Throwable;






	/**
	 *  只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
	 */
	public boolean hasVariableProcess   (Re_Executor executor, Object key) throws Throwable;

	/**
	 *  只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
	 */
	public boolean removeVariableProcess(Re_Executor executor, Object key) throws Throwable;

	/**
	 *  只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
	 */
	public int getSizeProcess(Re_Executor executor) throws Throwable;

	/**
	 *  只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
	 */
	public Iterable getKeysProcess(Re_Executor executor) throws Throwable;



















	/**
	 * 执行之前不可能已经return， 如果中间有执行了表达式应该判断表达式是否已经return 如果已经return 则返回return数据 而不是继续操作, 如果已经return返回的任何数据都是无效的
	 *
	 * 只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
	 *
	 * 如果你不想处理，建议使用 {@link Re_IObject#executePointMethodProcess(Re_Executor, String, Re_CodeLoader.Call)}
	 *
	 * 假定本对象名称x
	 * 那么执行的是 x.x()
	 * @param point_key          指子变量名称，假设这是个map里面有个a
	 *                            执行的就是map.a();
	 * @param call 如果是true 则callParam 为空 ，如果false则 callParam会经过计算后传入
	 */
	public Object executePointMethodProcess(Re_Executor executor, String point_key,
											Re_CodeLoader.Call call) throws Throwable;




	/**
	 * 执行之前不可能已经return， 如果中间有执行了表达式应该判断表达式是否已经return 如果已经return 则返回return数据 而不是继续操作, 如果已经return返回的任何数据都是无效的
	 * 只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
	 *
	 * 假定本对象名称x
	 * 那么执行的是 x()
	 * @param var_key                为当前名称，并非指子变量名称
	 *                              map();
	 *
	 * @param call 如果是true 则callParam 为空 ，如果false则 callParam会经过计算后传入
	 */
	public Object executeCallProcess(Re_Executor executor, String var_key,
									 Re_CodeLoader.Call call) throws Throwable;




















	public static abstract class IPrimitiveObject implements Re_IObject {
		@Override
		public boolean isPrimitive() {
			return true;
		}

		@Override
		public String toString() {
			boolean keyword = Re_Keywords.is_keyword(this);
			if (keyword)
				return "keyword:" + Re_Keywords.get_keyword_key(this).toString(); //java value
			return getClass().getName();
		}



		/**
		 * 执行之前不可能已经return， 如果中间有执行了表达式应该判断表达式是否已经return 如果已经return 则返回return数据 而不是继续操作, 如果已经return返回的任何数据都是无效的
		 * <p>
		 * 只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
		 * <p>
		 * 如果你不想处理，建议使用 {@link Re_IObject#executePointMethodProcess(Re_Executor, String, Re_CodeLoader.Call)}
		 * <p>
		 * 假定本对象名称x
		 * 那么执行的是 x.x()
		 * @param executor
		 * @param point_key          指子变量名称，假设这是个map里面有个a
		 *                            执行的就是map.a();
		 * @param call 如果是true 则callParam 为空 ，如果false则 callParam会经过计算后传入
		 */
		@Override
		public Object executePointMethodProcess(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
			Object instance = this.getVariableProcess(executor, point_key);
			if (executor.isReturn()) return executor.getReturn();

			return executor.executeCall(instance, point_key, call);
		}
	}


	/**
	 * 只执行 call()
	 *
	 * 其他任何操作无效
	 *
	 *  只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
	 */
	public static abstract class IPrimitiveCall extends IPrimitiveObject {
		@Override
		public final boolean hasVariableProcess(Re_Executor executor, Object key) throws Throwable {
			executor.setThrow("unsupported has var");
			return false;
		}
		@Override
		public final boolean removeVariableProcess(Re_Executor executor, Object key) throws Throwable {
			executor.setThrow("unsupported remove var");
			return false;
		}
		@Override
		public final Object getVariableProcess(Re_Executor executor, Object key) throws Throwable {
			executor.setThrow("unsupported get var");
			return null;
		}
		@Override
		public final void setVariableProcess(Re_Executor executor, Object key, Object value) throws Throwable {
			executor.setThrow("unsupported set var");
			return;
		}
		@Override
		public final int getSizeProcess(Re_Executor executor) throws Throwable {
			executor.setThrow("unsupported size var");
			return 0;
		}
		@Override
		public final Iterable getKeysProcess(Re_Executor executor) throws Throwable {
			executor.setThrow("unsupported key var");
			return null;
		}

		@Override
		public final Object executePointMethodProcess(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
			executor.setThrow(point_key + " undefined");
			return null;
		}
	}




	@SuppressWarnings("rawtypes")
	public static abstract class IPrimitiveObjectAndIVariableMap implements Re_IObject, Re_IVariableMap {

		@Override
		public String toString() {
			return Re_Variable.key(this).toString();
		}


		@Override
		public boolean isPrimitive() {
			return true;
		}



		@Override
		public Object getVariableProcess(Re_Executor executor, Object key) throws Throwable {
			return Re_Variable.accessFindValue(executor, key, this);
		}

		@Override
		public boolean hasVariableProcess(Re_Executor executor, Object key) throws Throwable {
			return Re_Variable.has(key, this);
		}

		@Override
		public boolean removeVariableProcess(Re_Executor executor, Object key) throws Throwable {
			return Re_Variable.accessRemove(executor, key, this);
		}

		@Override
		public void setVariableProcess(Re_Executor executor, Object key, Object value) throws Throwable {
			Re_Variable.accessSetValue(executor, key, value, this);
		}

		@Override
		public int getSizeProcess(Re_Executor executor) throws Throwable {
			return Re_Variable.size(this);
		}

		@Override
		public Iterable getKeysProcess(Re_Executor executor) throws Throwable {
			return Re_Variable.key(this);
		}

		@Override
		public Object executePointMethodProcess(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
			Object obj = getVariableProcess(executor, point_key);
			if (executor.isReturn()) return executor.getReturn();

			return executor.executeCall(obj, point_key, call);
		}

		@Override
		public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
			return Re_Executor.executeCallVariableMap(executor, this, call);
		}
	}




}
