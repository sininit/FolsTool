package top.fols.box.reflect.re.interfaces;

import top.fols.box.reflect.re.Re_Class;

public interface Re_IGetDeclaringClass {
    public Re_Class getReDeclaringClass();
}