package top.fols.box.reflect.re;

import java.nio.charset.Charset;
import java.util.LinkedHashMap;
import java.util.Map;

import top.fols.box.reflect.re.resource.Re_Resource;
import top.fols.box.reflect.re.resource.Re_ResourceFile;
import top.fols.atri.util.DoubleLinkedList;

/**
 * 类加载不是必须的 没有加载器 类也能炮
 */
@SuppressWarnings({"BooleanMethodIsAlwaysInverted"})
public abstract class Re_ClassLoader {
	protected final Object lock = new Object();
	protected final Re re;
	protected final Re_ClassLoader parent;


	final Map<String, Re_Class>         loaded = new LinkedHashMap<>();	//锁
	final DoubleLinkedList<Re_Resource> source = new DoubleLinkedList<>();//锁


	Re_ClassLoader(Re re, Re_ClassLoader parent) {
		this.re     = re;
		this.parent = parent;
	}



	public Re getHost() {
		return this.re;
	}







	public Re_ClassLoader getParent() {
		return parent;
	}

	/**
	 * @param name 完全限定名
	 */
	public Re_Class findLoadedClass(String name) {
		synchronized (lock) {
			return loaded.get(name);
		}
	}



	/**
	 * @param className 完全限定名
	 * 如果已经记载了将会返回已加载结果
	 * 会先向父类记载类 如果不存在再从 本加载器所有资源里找
	 */
	public Re_Class loadClass(String className)
			throws Re_Exceptions.CompileTimeGrammaticalException, Re_Exceptions.ReClassNotFoundException, Re_Exceptions.ReClassDefineException {
		synchronized (lock) {
			className = Re_CodeLoader.RuntimeUtils.formatClassName(className);

			//对原始名称判断
			Re_Class    re_class = loaded.get(className);
			if (null != re_class) {
				return  re_class;
			}

			if (null != parent) {
				try {
					re_class = parent.loadClass(className);
					if (null != re_class)
						return  re_class;
				} catch (Re_Exceptions.ReClassNotFoundException ignored) {
				}
			} else {
				//bootstrap loader...
				try {
					Re_ClassLoader bootstrapClassLoader = re.getBootstrapClassLoader();
					if (null !=    bootstrapClassLoader && this != bootstrapClassLoader) {
						re_class = bootstrapClassLoader.loadClass(className);
						if (null != re_class)
							return  re_class;
					}
				}  catch (Re_Exceptions.ReClassNotFoundException ignored) {
				}
			}
			
			//获取类
			Re_ResourceFile classSource = this.getClassSource(className);
			if (null == classSource) {
				throw new Re_Exceptions.ReClassNotFoundException(className);
			}

			//统一名称
			re_class = loaded.get(className = classSource.name());
			if (null != re_class) {
				return  re_class;
			}
			
			byte[]  bytes   = classSource.bytes();
			Charset charset = classSource.charset();

			//以类形式加载re文件
			Re_CodeFile classFile = this.compileReClass(classSource.path(), bytes, charset);

			Re_Class define;
			define = Re_Class.createClass(null, className, classFile, null);	//不可用出现错误
			define.setReClassLoader(this);	//不可用出现错误

			className = define.getReClassName();

			loaded.put(className, define);	//不可用出现错误

			initReClass(define);

			return define;
		}
	}

	/*
	 * 遍历寻类找源
	 * 越后面添加则等级越高
	 */
	protected Re_ResourceFile getClassSource(String className) {
		synchronized (lock) {
			for (DoubleLinkedList.Element<Re_Resource> element = this.source.getFirst(); null != element; element = (DoubleLinkedList.Element<Re_Resource>) element.getNext()) {
				Re_Resource resource = element.content();
				Re_ResourceFile data = resource.findClassResource(className);
				if (null != data) {
					return data;
				}
			}
			return null;
		}
	}







	protected Re_Resource[] getSources() {
		return this.source.toArray(new Re_Resource[]{});
	}



	protected boolean removeSourceManager(Re_Resource resource) {
		synchronized (lock) {
			DoubleLinkedList.Element<Re_Resource> find = source.indexOf(resource);
			if (null != find) {
				source.remove(find);
				return true;
			}
			return false;
		}
	}
	protected void addSourceManager(Re_Resource resource) {
		synchronized (lock) {
			DoubleLinkedList.Element<Re_Resource> find = source.indexOf(resource);
			if (null != find) {
				source.remove(find);
			}
			this.source.addFirst(new DoubleLinkedList.Element<>(resource));//将资源管理器推到第一个
		}
	}
	protected boolean hasSourceManager(Re_Resource resource) {
		synchronized (lock) {
			return null != source.indexOf(resource);
		}
	}



	@SuppressWarnings("StatementWithEmptyBody")
	public Re_ResourceFile getFileSource(String path) {
		if (null == path)
			return null;

		Re_ResourceFile c = null;
		if (null != parent) {
			c = parent.getFileSource(path);
		} else {
			//bootstrap
		}

		if (null == c) {
			for (DoubleLinkedList.Element<Re_Resource> element = this.source.getFirst(); null != element; element = (DoubleLinkedList.Element<Re_Resource>) element.getNext()) {
				Re_Resource resource = element.content();
				Re_ResourceFile data = resource.findFileResource(path);
				if (null != data) {
					return data;
				}
			}
		}

		return   c;
	}





	/**
	 * 定义一个顶级类
	 *
	 * @param filePath 文件路径
	 * @param data 代码字节
	 * @param charset 编码
	 */
	protected abstract Re_CodeFile compileReClass(String filePath, byte[] data, Charset charset)
			throws Re_Exceptions.CompileTimeGrammaticalException, Re_Exceptions.ReClassDefineException;

	protected abstract void initReClass(Re_Class define)
			throws Re_Exceptions.ReClassDefineException;















	/*
	 * @param callerClass 调用方
	 * @param 完全限定名
	 *
	 */
	public static Re_Class forName(Re_Class callerClass, String name)
			throws Re_Exceptions.CompileTimeGrammaticalException, Re_Exceptions.ReClassNotFoundException, Re_Exceptions.ReClassDefineException {

		Re_ClassLoader callerClassLoader = callerClass.getReClassLoader();
		if (null == callerClassLoader) {
			throw new Re_Exceptions.ReClassNotFoundException("reClass ["+callerClass.getReClassName()+"] no loader");
		}
		return callerClassLoader.loadClass(name);
	}
}

