package top.fols.box.reflect.re.variables;

import top.fols.box.reflect.re.Re_Variable;
import top.fols.box.reflect.re.interfaces.Re_IVariableMap;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * key 按 添加顺序排序
 */
public class Re_LinkedVariableMap implements Re_IVariableMap {
    protected final Map<Object, Re_Variable> map = Collections.synchronizedMap(new LinkedHashMap<Object, Re_Variable>());

    /**
     * 直接删除
     * 理论上你必须使用 {@link Re_Variable} 而不是自己操作， 这些方法主要 {@link Re_Variable} 调用
     *
     * @return 没有意义
     */
    @Override
    public Re_Variable remove(Object key) {
        return map.remove(key);
    }

    /**
     * 原始获取
     * 理论上你必须使用 {@link Re_Variable} 而不是自己操作， 这些方法主要 {@link Re_Variable} 调用
     *
     */
    @Override
    public Re_Variable find(Object key) {
        return map.get(key);
    }
    @Override
    public Re_Variable get(Object key) {
        return map.get(key);
    }

    /**
     * 原始提交
     * 理论上你必须使用 {@link Re_Variable} 而不是自己操作， 这些方法主要 {@link Re_Variable} 调用
     *
     * @return 没有意义
     */
    @Override
    public Re_Variable put(Object key, Re_Variable value) {
        return map.put(key, value);
    }

    @Override
    public boolean containsKey(Object key) {
        return map.containsKey(key);
    }





    /**
     * 数量
     */
    @Override
    public int size() {
        return map.size();
    }

    /**
     * @return 变量名
     * 返回不可修改的集合， 或者克隆
     */
    @Override
    public Collection<?> keySet() {
        return map.keySet();
    }





    @Override
    public int hashCode() {
        return map.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Re_LinkedVariableMap) {
            return map.equals(((Re_LinkedVariableMap) obj).map);
        }
        return map.equals(obj);
    }

    @Override
    public String toString() {
        return map.toString();
    }
}
