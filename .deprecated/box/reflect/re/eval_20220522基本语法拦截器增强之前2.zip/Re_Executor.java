package top.fols.box.reflect.re;

import top.fols.atri.lang.Finals;
import top.fols.atri.util.Throwables;
import top.fols.box.reflect.re.interfaces.Re_IObject;
import top.fols.box.reflect.re.interfaces.Re_IJavaReflector;
import top.fols.box.reflect.re.interfaces.Re_IVariableMap;
import top.fols.box.reflect.re.primitive.classes.Re_PrimitiveClass_list;
import top.fols.box.reflect.re.primitive.classes.Re_PrimitiveClass_object;
import top.fols.box.reflect.re.variables.Re_ConstVariableMap;
import top.fols.atri.util.DoubleLinked;
import top.fols.atri.util.annotation.NotNull;
import top.fols.atri.util.annotation.Nullable;
import top.fols.box.reflect.re.variables.Re_VariableMap;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collection;

import static top.fols.box.reflect.re.Re_CodeLoader.*;


/**
 * 一个 {@link Re_Executor}不能被多个线程同时执行 因为这是非常不安全的
 * 一个 {@link Re_Stack}   不能被多个线程同时使用 因为这是非常不安全的
 * 会变得很糟糕
 */
@SuppressWarnings({"rawtypes", "FieldCanBeLocal", "SameParameterValue", "UnusedReturnValue"})
public abstract class Re_Executor extends Re_IObject.IPrimitiveObjectAndIVariableMap {
    final Re                            host;
    final public Re_IJavaReflector reflector;
    final Re_CodeFile                   reCodes;
    final Re_Class                      reClass;
    final Re_Class.Instance             reClassInstance; // 对象实例, 不能为空, 也不能是static实例

    //需要新创建
    private final   Re_Stack reStack;
    private         DoubleLinked<Re_Stack.StackElement> current_stack;
    private         Re_Stack.StackElement               current_stack_element;





    /**
     *
     * @param host              主机
     * @param stack             栈
     * @param reCodes           代码
     * @param re_class             类        其实可以为空
     * @param reClassInstance      类实例     其实可以为空
     */
    private Re_Executor(@NotNull Re host, Re_Stack stack, @NotNull Re_CodeFile reCodes,
                        @Nullable Re_Class re_class,      @Nullable Re_Class.Instance reClassInstance) {
        this.host            = host;
        this.reflector       = host.reflector;
        this.reCodes         = reCodes;
        this.reClass         = re_class;
        this.reClassInstance = reClassInstance;

        //创建新对象...
        this.reStack = (null == stack ? Re_Stack.newThreadStack(null) : stack);
        if (this.reStack.isThrow())
            return;
    }



    protected Re                getHost() {
        return host;
    }

    protected Re_Stack          getStack() {
        return reStack;
    }
    protected Re_Stack.StackElement getStackElement(){
        return current_stack_element;
    }

    public Re_Class             getReClass() {
        return this.reClass;
    }
    public Re_Class.Instance    getReClassInstance() {
        return this.reClassInstance;
    }


















    /**
     * print(a);
     * {@link Re_IVariableMap#find(Object)} 一般是在 Executor 执行过程中获取（局部变量 或者向上查找）的时候执行的	 *
     *
     * print(obj.x);
     * {@link Re_IObject} 它的实例是一个re对象，在Executor执行时需要获取这个实例的属性则会执行 {@link Re_IObject#getVariableProcess(Re_Executor, Object)} 这个方法
     * @param key
     */
    public abstract Object find_var_value(String key) throws Re_Exceptions.ExecuteException;

    /**
     * x = value;
     * 如果异常请抛出java异常 而不是 setThrow
     */
    public abstract Object set_var_value(String key, Object value) throws Re_Exceptions.ExecuteException;


    public abstract Object[] arguments();




    /**
     * 禁止从外部访问本方法
     * 执行前不可以已经return状态, 如果执行时return 则会返回return结果
     * 本办法只会从{@link Re_Executor#executeExpressions0(Expression, int)} 访问
     *
     * xx.xx
     */
    protected Object getPointVariableValue(Object object, Base current, String currentName) throws Throwable {
        Object value;
        if (object instanceof Re_IObject) {
            Re_IObject clsInstance = (Re_IObject) object;
            value = clsInstance.getVariableProcess(this, currentName);
        } else if (null == object) {
            // from object can found currentName
            this.setThrow(Re_Exceptions.not_found_object_field(object, current));
            return null;
        } else {
            //java object reflect
            Class cls = object.getClass();
            Field field = reflector.field(cls, null, currentName);
            if (null == field) {
                this.setThrow(reflector.buildNoSuchField(cls, null, currentName));
                return null;
            }
            value = field.get(object);
        }
        if (isReturn || reStack.isThrow) return result;
        return value;
    }

    /**
     * 禁止从外部访问本方法
     * 执行前不可以已经return状态, 如果执行时return 则会返回return结果
     * 本办法只会从{@link Re_Executor#executeExpressions0(Expression, int)} 访问
     *
     * xx.xx = ?
     */
    protected Object setPointVariableValue(Object instance, Base current, String currentName, Object value) throws Throwable {
        if (instance instanceof Re_IObject) {
            Re_IObject clsInstance = (Re_IObject) instance;
            clsInstance.setVariableProcess(this, currentName, value);
        } else if (null == instance) {
            this.setThrow(Re_Exceptions.not_found_object_field(instance, current));
            return null;
        } else {
            //java object reflect
            Class cls = instance.getClass();
            Field field = reflector.field(cls, null, currentName);
            if (null == field) {
                this.setThrow(reflector.buildNoSuchField(cls, null, currentName));
                return null;
            }
            field.set(instance, value);
        }
        if (isReturn || reStack.isThrow) return result;
        return value;
    }



    /**
     * 执行后应该判断  {@link #isReturn()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getReturn()}
     *
     * 禁止从外部访问本方法
     * 执行前不可以已经return状态, 如果执行时return 则会返回return结果
     * 本办法只会从{@link Re_Executor#executeExpressions0(Expression, int)} 访问
     *
     * instance.point_var_name()
     * instance is instance-value
     * point_var_name is point_var_name
     */
    public Object executePointMethod(Object instance, String point_var_name, Call call) throws Throwable {
        if (instance instanceof Re_IObject) {
            //re reflect
            Re_IObject vp = ((Re_IObject) instance);
            Object o = vp.executePointMethodProcess(this, point_var_name, call);
            if (isReturn || reStack.isThrow) return result;//throw or return
            return o;
        } else if (instance == null) {
            this.setThrow(Re_Exceptions.not_found_object_method(instance, point_var_name, call.getParamExpressionCount()));
            return null;
        } else {
            //java object reflect
            Class<?> javaClass = instance.getClass();
            Object[] param = getExpressionValues(call, 0, call.getParamExpressionCount());
            if (isReturn || reStack.isThrow) return result;//throw or return

            Re_IJavaReflector reflector = this.reflector;
            Method method = reflector.method(javaClass, null, point_var_name, param);
            if (null == method) {
                this.setThrow(reflector.buildNoSuchMethod(javaClass, null, point_var_name, param));
                return null;
            }
            return method.invoke(instance, param);
        }
    }

    /**
     * 执行后应该判断  {@link #isReturn()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getReturn()}
     *
     * 禁止从外部访问本方法
     * 执行前不可以已经return状态, 如果执行时return 则会返回return结果
     * 本办法只会从{@link Re_Executor#executeExpressions0(Expression, int)} 访问
     *
     * var_name()
     *
     * instance is var_name-value
     */
    public Object executeCall(Object instance, String var_name, Call call) throws Throwable {
        if (instance instanceof Re_IObject) {
            //re reflect
            Re_IObject vp = ((Re_IObject) instance);
            Object o = vp.executeCallProcess(this, var_name, call);
            if (isReturn || reStack.isThrow) return result;//throw or return
            return o;
        } else if (instance == null) {
            this.setThrow(Re_Exceptions.not_a_method(instance, var_name));
            return null;
        } else if (instance.getClass().isArray()) {
            //操作java数组
            return executeCallJavaArray(instance, call);
        } else {
            this.setThrow(Re_Exceptions.not_a_method(instance, var_name));
            return null;
        }
    }








    /**
     * 禁止从外部访问本方法
     * 执行前不可以已经return状态, 如果执行时return 则会返回return结果
     * 本办法只会从{@link Re_Executor#executeExpressions0(Expression, int)} 访问
     */
    protected Object executeCallJavaArray(Object instance, Call call) {
        int paramExpressionCount = call.getParamExpressionCount();
        Object obj;
        switch (paramExpressionCount) {
            case 0:
                return Array.getLength(instance);
            case 1:
                obj = getExpressionValue(call,0);
                if (isReturn || reStack.isThrow) return result;//throw or return

                return Array.get(instance, Re_Util.toInt(obj));
            case 2:
                obj = getExpressionValue(call,0);
                if (isReturn || reStack.isThrow) return result;//throw or return

                Object value = getExpressionValue(call,1);
                if (isReturn || reStack.isThrow) return result;//throw or return

                Array.set(instance, Re_Util.toInt(obj), value);
                return value;
        }
        return null;
    }




    /**
     * variable_map()               获取长度 {@link Re_IVariableMap#size()} <br>
     * variable_map(key)            获取数据 {@link Re_IVariableMap#find(Object)} <br>
     * variable_map(key， value)     设置数据 {@link Re_IVariableMap#put(Object, Re_Variable)} <br>
     *
     * 本方法是用于外部扩展访问的 本执行器不会访问该方法 <br>
     * 执行后应该判断  {@link Re_Executor#isReturn()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link Re_Executor#getReturn()} <br>
     *
     * 区别是不用code参数, 可能会抛出Java异常 <br>
     */
    public static Object executeCallVariableMap(Re_Executor executor, Re_IVariableMap instance, Call call) {
        int paramExpressionCount = call.getParamExpressionCount();
        Object obj, value;
        switch (paramExpressionCount) {
            case 0: return Re_Variable.size(instance);
            case 1:
                obj = executor.getExpressionValue(call,0);
                if (executor.isReturn()) return executor.getReturn();//throw or return

                return Re_Variable.accessFindValue(executor, obj, instance);
            case 2:
                obj = executor.getExpressionValue(call,0);
                if (executor.isReturn()) return executor.getReturn();//throw or return

                value = executor.getExpressionValue(call,1);
                if (executor.isReturn()) return executor.getReturn();//throw or return

                Re_Variable.accessSetValue(executor, obj, value, instance); //强制提交 不 使用 intern
                return value;
        }
        return null;
    }





















    /**
     * 不安全的操作，必须严格使用本方法
     * 如果之前已经return 会抛出java异常, 如果执行时return 则会返回return结果
     * 执行后应该判断  {@link #isReturn()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getReturn()}
     *
     * @param call call
     * @param index no check
     */
    public Object getExpressionValue(Call call, int index) {
        if (isReturn || reStack.isThrow) throw new Re_Exceptions.InternalExecutorReturnedOrThrow(this.reStack.toString());//returned
        Expression expression = call.getBuildParamExpressionCache(index);
        return this.executeExpressions0(expression, 0);
    }

    /**
     * 不安全的操作，必须严格使用本方法
     * 获取参数转为java 对象， 如果之前已经return 会抛出java异常, 如果执行时return 则会中断获取并返回已经读取到的结果
     * 执行后应该判断  {@link #isReturn()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getReturn()}
     *
     * 本方法为内部方法
     *
     * @param call call         表达式的集合 (Expression, Expression, Expression...)
     * @param off, no check
     * @param len, no check
     */
    public Object[] getExpressionValues(Call call, int off, int len) {
        if (isReturn || reStack.isThrow) throw new Re_Exceptions.InternalExecutorReturnedOrThrow(this.reStack.toString());//returned
        Object[] paramList = new Object[len];
        Expression[] nowParam = call.getBuildParamExpressionCaches();
        for (int i = 0; i < len; i++) {
            Expression expression = nowParam[i+off];
            paramList[i] = this.executeExpressions0(expression, 0);
            if (isReturn || reStack.isThrow) break;
        }
        //returned?
        return paramList;
    }

    public Object[] getExpressionValues(Call call) {
        return getExpressionValues(call, 0, call.getParamExpressionCount());
    }


    /**
     * 不安全的操作，必须严格使用本方法
     * 如果之前已经return 会抛出java异常, 如果执行时return 则会返回return结果
     * 执行后应该判断  {@link #isReturn()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getReturn()}
     *
     * @param call call
     * @param off, no check
     * @param len, no check
     */
    public Object getExpressionLastValue(Call call, int off, int len) {
        if (isReturn || reStack.isThrow) throw new Re_Exceptions.InternalExecutorReturnedOrThrow(this.reStack.toString());//returned
        Object last = null;
        Expression[] nowParam = call.getBuildParamExpressionCaches();
        for (int i = 0; i < len; i++) {
            Expression code = nowParam[i+off];
            last = this.executeExpressions0(code, 0);
            if (isReturn || reStack.isThrow) return result;
        }
        return last;
    }











    /**
     * 不安全的操作，必须严格使用本方法
     * 如果之前已经return 会抛出java异常, 如果执行时return 则会返回return结果
     * 执行后应该判断  {@link #isReturn()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getReturn()}
     */
    public Object getExpressionValue(Expression expression) {
        if (isReturn || reStack.isThrow) throw new Re_Exceptions.InternalExecutorReturnedOrThrow(this.reStack.toString());//returned
        return this.executeExpressions0(expression, 0);
    }
    /**
     * 不安全的操作，必须严格使用本方法
     * 如果之前已经return 会抛出java异常, 如果执行时return 则会返回return结果
     * 执行后应该判断  {@link #isReturn()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getReturn()}
     *
     * @param expression expression
     * @param off, no check
     * @param len, no check
     */
    public Object getExpressionLastValue(Expression[] expression, int off, int len) {
        if (isReturn || reStack.isThrow) throw new Re_Exceptions.InternalExecutorReturnedOrThrow(this.reStack.toString());//returned
        Object last = null;
        for (int i = 0; i < len; i++) {
            Expression code = expression[i+off];
            last = this.executeExpressions0(code, 0);
            if (isReturn || reStack.isThrow) return result;
        }
        return last;
    }
















    protected void set_error_var(String name) {
        Re_Stack re_stack               = this.reStack.clone();
        Re_Variable<Re_Stack> variable  = new Re_Variable<>(re_stack);
        Re_Variable.Unsafe.putNewVariable(name, variable,this);
    }
    protected void set_error_var_null(String name) {
        Re_Variable.Unsafe.putNewVariable(name, Re_Variable.Null,this);
    }
    /**
     * 如果之前已经return 会抛出java异常
     * 执行后应该判断  {@link #isReturn()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getReturn()}
     */
    protected Object executeTry(@NotNull Expression[] executeExp, String catchName, @Nullable Expression[] catchExp, @Nullable Expression[] finallyExp) {
        //if (null == current) throw new RuntimeException("exited"); //exited  or re add stack
        if (isReturn || reStack.isThrow) throw new Re_Exceptions.InternalExecutorReturnedOrThrow(this.reStack.toString());//returned

        Object result = null;
        try {
            result = this.getExpressionLastValue (executeExp, 0, executeExp.length);
        } catch (Throwable e) {
            //inner error
            if (!this.isThrow())
                this.setThrow(e);
        }
        //可能(error|return)
        if (isReturn || reStack.isThrow) {
            if (this.isThrow()) {
                //执行失败 error
                //noinspection StatementWithEmptyBody
                if (null == catchExp) {
//                  this.clearReturnAndThrow();//清除代码块的异常
                } else {
                    this.set_error_var(catchName);
                    this.clearReturnAndThrow();//清除代码块的异常
                    result = this.getExpressionLastValue(catchExp, 0, catchExp.length);
                }

                boolean catchReturn = isReturn || reStack.isThrow;
                //catch (error||return)， 还要继续执行finally的话
                if (null != finallyExp) {
                    //有两种情况 catch未返回并且没有异常 或者 (error||return)
                    if (catchReturn) {
                        //catch (error||return)，现在执行finally
                        if (this.isThrow()) {
                            //catch异常了

                            //应该先执行finally后再重新抛出异常，
                            //如果finally 没有return或者error则抛出catch的 error
                            //如果finally return或者error了 则直接覆盖
                            String throwReason = reStack.getThrow();

                            this.clearReturnAndThrow();
                            result = this.getExpressionLastValue(finallyExp, 0, finallyExp.length);
                            if (!(isReturn || reStack.isThrow)) {
                                this.setThrow(throwReason);
                            }
                        } else {
                            //catch return了

                            //如果finally 没有return没有error 则设置结果为 cache
                            Object cache = this.result;
                            this.clearReturn();
                            result = this.getExpressionLastValue(finallyExp, 0, finallyExp.length);
                            if (!(isReturn || reStack.isThrow)) {
                                this.setReturn(cache);
                            }
                        }
                    } else {
                        //catch未返回也没有异常 直接执行finally
                        result = this.getExpressionLastValue(finallyExp, 0, finallyExp.length);
                    }
                } else {
                    //try{};
                    if (null == catchExp) {
                        this.clearReturnAndThrow();//清除代码块的异常
                    }
                }
            } else {
//                if (null == catchExp) {
//                } else {
//                    this.set_error_var_null(catchName);
//                }

                //code return了
                if (null != finallyExp) {
                    //如果finally 没有return没有error 则设置结果为 cache
                    Object cache = this.result;
                    this.clearReturn();
                    result = this.getExpressionLastValue(finallyExp, 0, finallyExp.length);
                    if (!(isReturn || reStack.isThrow)) {
                        this.setReturn(cache);
                    }
                }
            }
        } else {
//            if (null == catchExp) {
//            } else {
//                this.set_error_var_null(catchName);
//            }

            //正常执行 没有return 没有error
            //执行finally既可以
            //finally的return 可以覆盖整个try
            if (null != finallyExp) {
                this.getExpressionLastValue(finallyExp, 0, finallyExp.length);
            }
        }
        if ((isReturn || reStack.isThrow)) return result;
        return result;
    }







    private boolean isReturn;
    private Object result;


    public boolean isReturn() {
        return isReturn || reStack.isThrow;
    }
    /**
     * 如果已经return 会抛出java异常
     */
    public void setReturn(Object result) {
        if (isReturn || reStack.isThrow) throw new Re_Exceptions.InternalExecutorReturnedOrThrow(this.reStack.toString());//returned
        this.isReturn = true;
        this.result = result;
    }
    public Object getReturn() {
        return this.result;
    }
    protected void clearReturn() {
        this.isReturn = false;
        this.result   = null;
    }
    protected void cloneResult(Re_Executor sub) {
        this.isReturn = sub.isReturn;
        this.result   = sub.result;
    }




    public String getFilePath() {
        return this.reCodes.getFilePath();
    }


    public boolean isThrow() {
        return reStack.isThrow();
    }

    public void setThrow(Throwable e) {
        this.setThrow(Throwables.toString(e));
    }
    /**
     * 设置后
     * {@link #setReturn(Object)}
     * 也会一起设置
     */
    public void setThrow(String reason) {
        if (isReturn || reStack.isThrow) throw new Re_Exceptions.ExecuteException(this.reStack.toString());//returned
        this.reStack.setThrow(reason);
        this.isReturn = true;
        this.result   = null;
    }

    /**
     * 清除结果和 清除throw
     */
    protected void clearReturnAndThrow() {
        if (null == current_stack) throw new Re_Exceptions.ExecuteException("exited"); //exited  or re add stack
        this.reStack.clearThrow();
        this.reStack.disconBefore(this.current_stack);
        this.isReturn = false;
        this.result   = null;
    }

















    /**
     *    thread unsafe 线程不安全
     *    不能同时执行本（实例方法）否则 发生非常坑爹的事情
     *    每段代码都必须新建一个Executor
     *    本方法其实是一次性的， 重复执行 栈就没有了 请不要执行第二次
     */
    public Object run() {
        if (null == current_stack) {
            Re_Stack.StackElement current = new Re_Stack.StackElement(0);
            current.setFilePath(reCodes.getFilePath());
            this.current_stack = this.reStack.addStackElement(current_stack_element = current);//no start

            Re_CodeFile vars                        = this.reCodes;
            Expression[]  expressions = vars.getExpressions();
            this.run0(expressions, vars.getExpressionsOffset(), vars.getExpressionsLength());

            if (isThrow()) {
                return null;
            } else {
                reStack.removeStackElement(this.current_stack);
                return result;
            }
        } else {
            throw new Re_Exceptions.ExecuteException("exited"); //exited  or re add stack
        }
    }
    protected void run0(Expression[] vars, int start_index, int length) {
        while (!(isReturn || reStack.isThrow) && start_index < length) {
            Expression expression = vars[start_index];
            result = executeExpressions0(expression, 0);
            start_index++;// next line
        }
    }

    /**
     * 禁止外部包访问本方法
     */
    @SuppressWarnings("ConstantConditions")
    private Object executeExpressions0(Expression expression, int offset) {
        try {
            this.current_stack_element.line = expression.line;

            Base[] bases = expression.getBuildCodeCache();
            Object  stack        = null;
            boolean prevResult  = false;
            boolean joinPoint   = false;
            int size            = bases.length;
            Base current;

            for (int i = offset; i < size; i++) {
                if (isReturn || reStack.isThrow) return this.result;

                current = bases[i];
                if (codeIsVar(current)) {
                    // 栈底为空值
                    int next_index = i + 1;
                    if (null == stack) {
                        if (prevResult) {
                            if (joinPoint) {
                                // 无法从空结果获取字段
                                this.setThrow(Re_Exceptions.not_found_object_field(null, current));
                                return null;
                            } else {
                                this.setThrow(Re_Exceptions.grammatical_error(bases, current));
                                return null;
                            }
                        }
                        Base next = next_index < bases.length?bases[next_index]:null;
                        if (codeIsAssignment(next)) {
                            // x = ...
                            Object value = this.executeExpressions0(expression, i = next_index + 1);
                            if (isReturn || reStack.isThrow) return this.result;
                            stack = this.set_var_value(current.getName(), value); //可能会异常
                            return stack;
                        } else {
                            // x
                            if (null == current.staticValue)
                                stack = find_var_value(current.getName());
                            else
                                stack = current.staticValue.get(this);
                            prevResult = true;
                        }
                    } else if (joinPoint) {
                        // 上一个元素为点
                        // 当前元素为name
                        Base next = next_index < bases.length?bases[next_index]:null;//获取下一个元素
                        if (null == next) {
                            // 数据被读完 x.x
                            stack = this.getPointVariableValue(stack, current, current.getName());
                            return stack;
                        } else {
                            if (codeIsAssignment(next)) {
                                // x.x = ...
                                //这个i = next_index + 1 是不对 的！ 不应该是i=next_index+1 这样可能会重复执, 应该弄个代码读取器，或者I记录器, 又或者应该是直接return
                                Object value = this.executeExpressions0(expression, i = next_index + 1);
                                if (isReturn || reStack.isThrow) return this.result;

                                stack = this.setPointVariableValue(stack, current, current.getName(), value);
                                return stack;//测试
                            } else if (codeIsPoint(next)) {
                                // x.x.?
                                stack = this.getPointVariableValue(stack, current, current.getName());
                                prevResult = true;
                            } else {
                                this.setThrow(Re_Exceptions.grammatical_error(bases, current));
                                return null;
                            }
                            joinPoint = false;
                        }
                    } else {
                        this.setThrow(Re_Exceptions.grammatical_error(bases, current));
                        return null;
                    }
                } else if (codeIsCall(current)) {
                    if (null == stack) {// 栈底为空值
                        if (prevResult) {
                            // 无法从空结果获取方法
                            this.setThrow(Re_Exceptions.not_found_object_method(null, current, null));
                            return null;
                        }
                        // x();
                        String name = current.getName();
                        Call call = (Call) current;
                        Object instance;
                        if (null == current.staticValue)
                            instance = find_var_value(name);
                        else
                            instance = current.staticValue.get(this);
                        if (isReturn || reStack.isThrow) return this.result;

                        stack = this.executeCall(instance, name, call);
                        prevResult = true;
                    } else if (joinPoint) {
                        // ?.x()
                        Call call = (Call) current;
                        stack = this.executePointMethod(stack, current.getName(), call);
                        prevResult = true;
                        joinPoint = false;
                    } else {
                        //对上个结果执行 basemethod
                        //a()()     y
                        //a()b()    x grammatical_error
                        Call call = (Call) current;
                        if (call.isEmptyNameCall()) {
                            String name = current.getName();
                            stack = this.executeCall(stack, name, call);// 这里是对栈进行调用而不是变量//xxx()()
                            prevResult = true;
                        } else {
                            this.setThrow(Re_Exceptions.grammatical_error(bases, current));
                            return null;
                        }
                    }
                } else if (codeIsPoint(current)) {
                    joinPoint = true;
                } else {
                    this.setThrow(Re_Exceptions.grammatical_error(bases, current));
                    return null;
                }
            }
            return stack;
        } catch (Throwable e) {
            this.setThrow(e);
            return null;
        }
    }


























































    /**
     * 如果已经初始化过这个类 则返回null 结果
     * 一般用于class函数 和 re_classloader 编译加载类
     *
     */
    @SuppressWarnings("ConstantConditions")
    static Object runReClassInitialize0(@NotNull Re host, Re_Stack stack, @NotNull Re_CodeFile block,
                                        @NotNull Re_Class re_class) {
        if (stack.isThrow())
            return null;  //已经异常

        if (null == re_class) {
            stack.setThrow("re_class[" + (null == re_class ? null : re_class.getReClassName()) + "]" + " initialize failed");
            return null;
        }

        Object result = re_class.initializeStaticObject(host, stack, block, re_class);
        if (stack.isThrow()) {
            return null;
        }
        return result;
    }

    /**
     * @see Re_Class#initializeStaticObject(Re, Re_Stack, Re_CodeFile, Re_Class)
     * 创建类 static 实例初始化执行器，用于初始化类的无论是顶级类还是内部类 匿名类都可以使用
     * 如果已经 throw 必定返回null;
     *
     * @param block 类的代码
     */
    static Re_Executor buildReClassInitializeExecutor0(@NotNull Re host, Re_Stack stack, @NotNull Re_CodeFile block,
                                                       @NotNull final Re_Class re_class) {
        if (stack.isThrow())
            return null;  //已经异常

        if (null == re_class) {
            stack.setThrow("null reClass");
            return null;
        }

        final Object[]          arguments      = Finals.EMPTY_OBJECT_ARRAY;
        final Re_IVariableMap class_variable = re_class.variable;
        final Re_IVariableMap constManager   = block.getConstManager();

        return new Re_Executor(host, stack, block, re_class, null) {
            @Override
            public Object find_var_value(String key) {
                return Re_Variable.accessFindValueRequire(this, key, re_class);
            }
            @Override
            public Object set_var_value(String key, Object value) {
                Re_Variable.accessSetValue(this, key, value, class_variable);
                return value;
            }


            @Override
            public Re_Variable remove(Object key) {
                return class_variable.remove(key);
            }

            @Override
            public Re_Variable find(Object key) {
                return re_class.find(key);
            }

            @Override
            public Re_Variable get(Object key) {
                return class_variable.get(key);
            }

            @Override
            public Re_Variable put(Object key, Re_Variable value) {
                return class_variable.put(key, value);
            }

            @Override
            public boolean containsKey(Object key) {
                return class_variable.containsKey(key);
            }

            @Override
            public int size() {
                return class_variable.size();
            }

            @Override
            public Collection<?> keySet() {
                return class_variable.keySet();
            }


            @Override
            public Object[] arguments() {
                return arguments;
            }
        };
    }


    /**
     * 执行类方法 或者对象方法
     * @param host                  主机
     * @param stack                 stack
     * @param function              方法
     * @param reClass               类
     * @param instance              非静态的 类实例
     * @param local                 执行器的local变量
     */
    static Re_Executor buildReClassObjectOrStaticFunction0( @NotNull Re host,                @NotNull Re_Stack stack,                       @NotNull final Re_ClassFunction function,
                                                            @NotNull Re_Class reClass,       @Nullable final Re_Class.Instance instance,
                                                            @Nullable Re_IVariableMap local, @Nullable Object[] arguments) {
        if (stack.isThrow())
            return null;  //已经异常

        final Re_CodeFile block                            = function.reCodeBlock;
        final Re_IVariableMap constManager                 = block.getConstManager();

        Re_Class initializeStaticObject;
        if (null != reClass) {
            initializeStaticObject = reClass.getStatic();
            if (null == initializeStaticObject) {
                stack.setThrow("no initialize class: " + reClass.getReClassName());
                return null;
            }
        }

        if (null == arguments)
            arguments = Finals.EMPTY_OBJECT_ARRAY;
        if (null == local)
            local = new Re_VariableMap();

        final Object[] finalArguments       = arguments;
        final Re_IVariableMap finalLocal  = local;
        Re_Executor re_executor;
        if (null == instance) {
            if (null == function.parent) {
                //没有父变量的方法
                re_executor = new Re_Executor(host, stack, block, reClass, null) {
                    @Override
                    public Object find_var_value(String key) {
                        return Re_Variable.accessFindValueRequire(this, key, finalLocal);
                    }
                    @Override
                    public Object set_var_value(String key, Object value) {
                        Re_Variable.accessSetValue(this, key, value, finalLocal);
                        return value;
                    }


                    @Override
                    public Re_Variable remove(Object key) {
                        return finalLocal.remove(key);
                    }

                    @Override
                    public Re_Variable find(Object key) {
                        return finalLocal.find(key);
                    }
                    @Override
                    public Re_Variable get(Object key) {
                        return finalLocal.find(key);
                    }

                    @Override
                    public Re_Variable put(Object key, Re_Variable value) {
                        return finalLocal.put(key, value);
                    }
                    @Override
                    public boolean containsKey(Object key) {
                        return finalLocal.containsKey(key);
                    }
                    @Override
                    public int size() {
                        return finalLocal.size();
                    }
                    @Override
                    public Collection<?> keySet() {
                        return finalLocal.keySet();
                    }


                    @Override
                    public Object[] arguments() {
                        return finalArguments;
                    }

                };
            } else {
                //有变量的匿名方法 或者 类方法
                re_executor = new Re_Executor(host, stack, block, reClass, null) {
                    @Override
                    public Object find_var_value(String key) {
                        return Re_Variable.accessFindValueRequire(this, key, finalLocal, function.parent);
                    }
                    @Override
                    public Object set_var_value(String key, Object value) {
                        Re_Variable.accessSetValue(this, key, value, finalLocal);
                        return value;
                    }


                    @Override
                    public Re_Variable remove(Object key) {
                        return finalLocal.remove(key);
                    }

                    @Override
                    public Re_Variable find(Object key) {
                        Re_Variable re_variable = finalLocal.find(key);
                        if (null == re_variable)
                            re_variable = function.parent.find(key);
                        return re_variable;
                    }
                    @Override
                    public Re_Variable get(Object key) {
                        return finalLocal.find(key);
                    }

                    @Override
                    public Re_Variable put(Object key, Re_Variable value) {
                        return finalLocal.put(key, value);
                    }

                    @Override
                    public boolean containsKey(Object key) {
                        return finalLocal.containsKey(key);
                    }
                    @Override
                    public int size() {
                        return finalLocal.size();
                    }
                    @Override
                    public Collection<?> keySet() {
                        return finalLocal.keySet();
                    }



                    @Override
                    public Object[] arguments() {
                        return finalArguments;
                    }

                };
            }
        } else {
            if (null == function.parent) {
                //实例方法
                re_executor = new Re_Executor(host, stack, block, reClass, instance) {
                    @Override
                    public Object find_var_value(String key) {
                        return Re_Variable.accessFindValueRequire(this, key, finalLocal, instance);
                    }
                    @Override
                    public Object set_var_value(String key, Object value) {
                        Re_Variable.accessSetValue(this, key, value, finalLocal);
                        return value;
                    }


                    @Override
                    public Re_Variable remove(Object key) {
                        return finalLocal.remove(key);
                    }

                    @Override
                    public Re_Variable find(Object key) {
                        Re_Variable re_variable = finalLocal.find(key);
                        if (null == re_variable)
                            re_variable = instance.find(key);
                        return re_variable;
                    }
                    @Override
                    public Re_Variable get(Object key) {
                        return finalLocal.find(key);
                    }

                    @Override
                    public Re_Variable put(Object key, Re_Variable value) {
                        return finalLocal.put(key, value);
                    }

                    @Override
                    public boolean containsKey(Object key) {
                        return finalLocal.containsKey(key);
                    }

                    @Override
                    public int size() {
                        return finalLocal.size();
                    }
                    @Override
                    public Collection<?> keySet() {
                        return finalLocal.keySet();
                    }


                    @Override
                    public Object[] arguments() {
                        return finalArguments;
                    }
                };
            } else {
                re_executor = new Re_Executor(host, stack, block, reClass, instance) {
                    @Override
                    public Object find_var_value(String key) {
                        return Re_Variable.accessFindValueRequire(this, key, finalLocal, function.parent);
                    }
                    @Override
                    public Object set_var_value(String key, Object value) {
                        Re_Variable.accessSetValue(this, key, value, finalLocal);
                        return value;
                    }


                    @Override
                    public Re_Variable remove(Object key) {
                        return finalLocal.remove(key);
                    }
                    @Override
                    public Re_Variable find(Object key) {
                        Re_Variable re_variable = finalLocal.find(key);
                        if (null == re_variable)
                            re_variable = function.parent.find(key);
                        return re_variable;
                    }
                    @Override
                    public Re_Variable get(Object key) {
                        return finalLocal.find(key);
                    }

                    @Override
                    public Re_Variable put(Object key, Re_Variable value) {
                        return finalLocal.put(key, value);
                    }

                    @Override
                    public boolean containsKey(Object key) {
                        return finalLocal.containsKey(key);
                    }

                    @Override
                    public int size() {
                        return finalLocal.size();
                    }
                    @Override
                    public Collection<?> keySet() {
                        return finalLocal.keySet();
                    }




                    @Override
                    public Object[] arguments() {
                        return finalArguments;
                    }
                };
            }
        }
        return re_executor;
    }





    /**
     * { }
     *
     * @param current_executor              current_executor
     * @return {@link Re_Class.Instance}
     */
    static Object runReClassDict0(@NotNull final Re_Executor current_executor, @NotNull Call callParamController) {
        if (current_executor.isReturn()) return current_executor.isReturn();

        final Re_Class reClass           = Re_PrimitiveClass_object.reclass.getReClass();
        final Re_Class.Instance instance = Re_PrimitiveClass_object.reclass.createInstance();

        Re_CodeFile block        = new Re_CodeFile();
        block.expressions        = callParamController.getBuildParamExpressionCaches();
        block.expressionsOffset  = 0; //我们执行最后一个表达式即可
        block.filePath           = current_executor.getFilePath();
        block.lineOffset         = callParamController.getLine();   //没有意义的
        block.constManager       = current_executor.reCodes.getConstManager();

        final Re_ConstVariableMap constManager = block.constManager;

        Re_Executor re_executor = new Re_Executor(current_executor.host, current_executor.getStack(), block, reClass, instance) {
            @Override
            public Object find_var_value(String key) {
                return Re_Variable.accessFindValueRequire(this, key, instance, current_executor);
            }
            @Override
            public Object set_var_value(String key, Object value) {
                Re_Variable.accessSetValue(this, key, value, instance);
                return value;
            }


            @Override
            public Re_Variable remove(Object key) {
                return instance.remove(key);
            }

            @Override
            public Re_Variable find(Object key) {
                Re_Variable re_variable = instance.find(key);
                if (null == re_variable)
                    re_variable = current_executor.find(key);
                return re_variable;
            }
            @Override
            public Re_Variable get(Object key) {
                return instance.find(key);
            }


            @Override
            public Re_Variable put(Object key, Re_Variable value) {
                return instance.put(key, value);
            }


            @Override
            public boolean containsKey(Object key) {
                return instance.containsKey(key);
            }

            @Override
            public int size() {
                return instance.size();
            }

            @Override
            public Collection<?> keySet() {
                return instance.keySet();
            }

            @Override
            public Object[] arguments() {
                return current_executor.arguments();
            }
        };

        Object run = re_executor.run();
        return instance;
    }

    /**
     * [ ]
     *
     * @param current_executor current_executor
     * @return {@link Re_Class.Instance}
     */
    static Object runReClassList0(@NotNull final Re_Executor current_executor, Re_PrimitiveClass_list.Instance instance, @NotNull Call callParamController) {
        if (null == instance) {
            return null;
        }
        instance.setElements(current_executor, callParamController);
        return instance;
    }




    /**
     * 继承父 executor 执行 代码块
     * 一般用于eval
     *
     * @param host                  主机
     * @param stack                 current_executor 的stack
     * @param block                 代码块
     * @param current_executor      继承当前变量
     */
    static Re_Executor buildReInheritVariableExecutor0(@NotNull Re host, Re_Stack stack, @NotNull Re_CodeFile block,
                                                       @NotNull final Re_Executor current_executor) {
        if (stack.isThrow())
            return null;  //已经异常

        final Re_IVariableMap constManager          = block.getConstManager();
        final Re_Class reClass                      = current_executor.getReClass();
        final Re_Class.Instance classInstanceObject = current_executor.getReClassInstance();

        return new Re_Executor(host, stack, block, reClass, classInstanceObject) {
            @Override
            public Object find_var_value(String key) {
                return Re_Variable.accessFindValueRequire(this, key, current_executor);
            }
            @Override
            public Object set_var_value(String key, Object value) {
                Re_Variable.accessSetValue(this, key, value, current_executor);
                return value;
            }

            @Override
            public Re_Variable remove(Object key) {
                return current_executor.remove(key);
            }

            @Override
            public Re_Variable find(Object key) {
                return current_executor.find(key);
            }
            @Override
            public Re_Variable get(Object key) {
                return current_executor.find(key);
            }

            @Override
            public Re_Variable put(Object key, Re_Variable value) {
                return current_executor.put(key, value);
            }

            @Override
            public boolean containsKey(Object key) {
                return current_executor.containsKey(key);
            }


            @Override
            public int size() {
                return current_executor.size();
            }
            @Override
            public Collection<?> keySet() {
                return current_executor.keySet();
            }


            @Override
            public Object[] arguments() {
                return current_executor.arguments();
            }
        };
    }







    /**
     * 创建一个没有绑定任何类的执行器 {@link Re#execute(String, Object...)}
     */
    public static Re_Executor buildReHostExecutor(@NotNull Re host, @Nullable Re_Stack stack, @NotNull Re_CodeFile block,
                                                  @NotNull Re_IVariableMap local, @Nullable Object[] arguments) {
        final Re_IVariableMap constManager = block.getConstManager();

        if (null == arguments)
            arguments = Finals.EMPTY_OBJECT_ARRAY;

        if (null == local)
            local = new Re_VariableMap();

        final Object[] finalArguments = arguments;
        final Re_IVariableMap finalLocal = local;
        @SuppressWarnings("UnnecessaryLocalVariable")
        Re_Executor re_executor = new Re_Executor(host, stack, block, null, null) {
            @Override
            public Object find_var_value(String key) {
                return Re_Variable.accessFindValueRequire(this, key, finalLocal);
            }
            @Override
            public Object set_var_value(String key, Object value) {
                Re_Variable.accessSetValue(this, key, value, finalLocal);
                return value;
            }

            @Override
            public Re_Variable remove(Object key) {
                return finalLocal.remove(key);
            }

            @Override
            public Re_Variable find(Object key) {
                return finalLocal.find(key);
            }
            @Override
            public Re_Variable get(Object key) {
                return finalLocal.find(key);
            }

            @Override
            public Re_Variable put(Object key, Re_Variable value) {
                return finalLocal.put(key, value);
            }

            @Override
            public boolean containsKey(Object key) {
                return finalLocal.containsKey(key);
            }

            public int size() {
                return finalLocal.size();
            }

            @Override
            public Collection<?> keySet() {
                return finalLocal.keySet();
            }

            @Override
            public Object[] arguments() {
                return finalArguments;
            }
        };
        return re_executor;
    }







    static class Arguments extends Re_Variable.FinalVariable {
        @Override
        protected DirectAccessor getDirectAccessor() {
            return null;
        }

        public Arguments() {
        }

        @Override public Object get(Re_Executor executor) {
            return executor.arguments();
        }
    }

    static class Space extends Re_Variable.FinalVariable {
        @Override
        protected DirectAccessor getDirectAccessor() {
            return null;
        }

        public Space() {
        }

        @Override public Object get(Re_Executor executor) {
            return executor;
        }
    }


    static class Global extends Re_Variable.FinalVariable {
        public Global() {
            super();
        }

        /**
         * @param executor 默认无意义
         */
        @Override
        public Object get(Re_Executor executor) {
            return executor.host.global;
        }
    }

}
