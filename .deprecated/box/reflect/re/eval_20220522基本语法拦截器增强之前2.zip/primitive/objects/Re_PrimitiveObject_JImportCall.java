package top.fols.box.reflect.re.primitive.objects;

import top.fols.box.reflect.re.Re_CodeLoader;
import top.fols.box.reflect.re.Re_Executor;

public class Re_PrimitiveObject_JImportCall extends Re_PrimitiveObject_JImport {
    public Re_PrimitiveObject_JImportCall(Class<?> type) {
        super(type);
    }

    @Override
    public final boolean hasVariableProcess(Re_Executor executor, Object key) throws Throwable {
        executor.setThrow("unsupported has var");
        return false;
    }

    @Override
    public final boolean removeVariableProcess(Re_Executor executor, Object key) throws Throwable {
        executor.setThrow("unsupported remove var");
        return false;
    }

    @Override
    public final Object getVariableProcess(Re_Executor executor, Object key) throws Throwable {
        executor.setThrow("unsupported get var");
        return null;
    }

    @Override
    public final void setVariableProcess(Re_Executor executor, Object key, Object value) throws Throwable {
        executor.setThrow("unsupported set var");
    }

    @Override
    public final int getSizeProcess(Re_Executor executor) throws Throwable {
        executor.setThrow("unsupported size var");
        return 0;
    }

    @Override
    public final Iterable getKeysProcess(Re_Executor executor) throws Throwable {
        executor.setThrow("unsupported key var");
        return null;
    }

    @Override
    public final Object executePointMethodProcess(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
        executor.setThrow(point_key + " undefined");
        return null;
    }
}
