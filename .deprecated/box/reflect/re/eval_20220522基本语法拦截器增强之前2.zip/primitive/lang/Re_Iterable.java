package top.fols.box.reflect.re.primitive.lang;


public interface Re_Iterable {
    /**
     * 每次执行都可以获取一个元素遍历器
     */
    public abstract Re_Iterator iterator();
}
