package top.fols.box.reflect.re;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import top.fols.atri.lang.Finals;
import top.fols.atri.lang.Objects;
import top.fols.atri.reflect.ReflectCache;
import top.fols.atri.reflect.ReflectMatcher;
import top.fols.atri.reflect.ReflectPeakMatcher;
import top.fols.atri.reflect.Reflects;
import top.fols.box.reflect.re.interfaces.Re_IJavaReflector;


/**
 * Java反射器
 * 作用是可以防止直接反射私有字段
 * 这玩意一般是在re里面用的，需要防止在re里面反射 re
 * 其实没啥用 但是起码得弄一个吧
 */
@SuppressWarnings("rawtypes")
public class Re_Reflector extends ReflectMatcher<Re_Reflector.Cache> implements Re_IJavaReflector {

    @SuppressWarnings("SameParameterValue")
    protected static class Cache extends ReflectCache {
        protected ClassesList 	    getClassesList(Class cls) 			 			{ return super.getClassesList(cls);      }
        protected Class             getClassesList(Class cls, String simpleName) 	{ return super.getClassesList(cls, simpleName); }
        protected ConstructorList   getConstructorList(Class cls)  				    { return super.getConstructorList(cls); }
        protected FieldList         getFieldList(Class cls)						    { return super.getFieldList(cls);       }
        protected FieldList         getFieldList(Class cls, String name)  		    { return super.getFieldList(cls, name); }
        protected MethodList        getMethodList(Class p1)   					    { return super.getMethodList(p1);   }
        protected MethodList        getMethodList(Class p1, String p2)    		    { return super.getMethodList(p1, p2);   }

        @Override
        protected String getSimpleName0(Class<?> name) {
            return Re_CodeLoader.intern(name.getSimpleName());
        }

        @Override
        protected String getMemberName0(Member member) {
            return Re_CodeLoader.intern(member.getName());
        }

        /**
         * safe reflect
         * 禁止访问私有字段
         */
        private final HashMap<Filter, Object> filterPackage  = new HashMap<Filter, Object>() {{//不会增量
            for (Filter aClass: getDefaultInterceptor()) {
                put(aClass, null);
            }
        }};

        private  Filter findInterceptor(Map<Filter, Object> map, Class<?> reflectClass) {
            for (Filter k: map.keySet()) {
                 Filter enable = k.enable(reflectClass);
                if (null != enable)
                    return  enable;
            }
            return null;
        }

        static abstract class Filter {
            public abstract Filter enable(Class clasz);

            public abstract Class[]       createClasses(Class cls);
            public abstract Constructor[] createConstructors(Class cls);
            public abstract Field[]       createFields(Class cls);
            public abstract Method[]      createMethods(Class cls);
        }
        static abstract class HidePrivateFilter extends Filter {
            @Override
            public Class[] createClasses(Class cls) {
                return null == cls ? Finals.EMPTY_CLASS_ARRAY : cls.getClasses();
            }
            @Override
            public Constructor[] createConstructors(Class cls) {
                return null == cls ? Finals.EMPTY_CONSTRUCTOR_ARRAY : cls.getConstructors();
            }
            @Override
            public Field[] createFields(Class cls) {
                return null == cls ? Finals.EMPTY_FIELD_ARRAY : cls.getFields();
            }
            @Override
            public Method[] createMethods(Class cls) {
                return null == cls ? Finals.EMPTY_METHOD_ARRAY : cls.getMethods();
            }
        }
        static class HideClassPrivateFilter extends HidePrivateFilter {
            String className;
            public HideClassPrivateFilter(String className) {
                this.className = className;
            }

            @Override
            public Filter enable(Class clasz) {
                boolean equals = Objects.equals(clasz.getName(), className);
                return  equals ? this: null;
            }
        }
        static class HidePackagePrefixPrivateFilter extends HidePrivateFilter {
            String  packagePrefix;
            Pattern pattern;
            public HidePackagePrefixPrivateFilter(String pack) {
                this.pattern = Pattern.compile(pack + "\\..+");
                this.packagePrefix = pack;
            }

            @Override
            public Filter enable(Class clasz) {
                String name = clasz.getName();
                boolean equals = pattern.matcher(name).matches();
                return  equals ? this: null;
            }
        }

        @SuppressWarnings("unused")
        static Filter[] getDefaultInterceptor() {
            return new Filter[] {
                    new HidePackagePrefixPrivateFilter(    Reflects.class.getPackage().getName()   ),

                    new HidePackagePrefixPrivateFilter(    Re.class.getPackage().getName()         ),

                    new HideClassPrivateFilter(    Class.class.getName()       ),
                    new HideClassPrivateFilter(    String.class.getName()      ),
                    new HideClassPrivateFilter(    Integer.class.getName()     ),
                    new HideClassPrivateFilter(    Character.class.getName()   ),
                    new HideClassPrivateFilter(    Byte.class.getName()        ),
                    new HideClassPrivateFilter(    Long.class.getName()        ),
                    new HideClassPrivateFilter(    Float.class.getName()       ),
                    new HideClassPrivateFilter(    Double.class.getName()      ),
                    new HideClassPrivateFilter(    Short.class.getName()       ),
                    new HideClassPrivateFilter(    Boolean.class.getName()     ),
                    new HideClassPrivateFilter(    Object.class.getName()      ),
            };
        }




        public Cache() {}

        @Override
        protected Class[] createClasses(Class cls) {
            Filter interceptor = findInterceptor(filterPackage, cls);
            if (null != interceptor)
                return  interceptor.createClasses(cls);
            else
                return super.createClasses(cls);
        }
        @Override
        protected Constructor[] createConstructors(Class cls) {
            Filter interceptor = findInterceptor(filterPackage, cls);
            if (null != interceptor)
                return  interceptor.createConstructors(cls);
            else
                return super.createConstructors(cls);
        }
        @Override
        protected Field[] createFields(Class cls) {
            Filter interceptor = findInterceptor(filterPackage, cls);
            if (null != interceptor)
                return  interceptor.createFields(cls);
            else
                return super.createFields(cls);
        }
        @Override
        protected Method[] createMethods(Class cls) {
            Filter interceptor = findInterceptor(filterPackage, cls);
            if (null != interceptor)
                return  interceptor.createMethods(cls);
            else
                return super.createMethods(cls);
        }
    }







    public Re_Reflector() {
        super(new Cache());
    }

    public static class Peak extends ReflectPeakMatcher<Cache> implements Re_IJavaReflector {
        public Peak() {
            super(new Cache());
        }
    }



}

