package top.fols.box.reflect.re.resource;

import top.fols.atri.io.file.Filez;
import top.fols.atri.lang.Finals;
import top.fols.box.reflect.re.Re_CodeLoader;
import top.fols.atri.util.annotation.Nullable;

import java.io.File;
import java.net.URI;
import java.nio.charset.Charset;

public class Re_DirectoryResource implements Re_Resource {
    File directory;
    Charset charset;


    /**
     * @param directory default value UTF_8
     */
    public Re_DirectoryResource(File directory) {
        this(directory, null);
    }
    public Re_DirectoryResource(File directory, Charset charset) {
        this.directory = directory;
        this.charset   = null==charset?Finals.Charsets.UTF_8:charset;
    }




    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof Re_DirectoryResource))
            return false;

        Re_DirectoryResource other = (Re_DirectoryResource) obj;
        return Filez.wrap(directory).equals(Filez.wrap(other.directory));
    }

    @Override
    public URI toURI() {
        if (null == this.directory)
            return null;
        return this.directory.toURI();
    }


    @Override
    public Charset defaultCharset() {
        return this.charset;
    }


    @Nullable
    @Override
    public Re_ResourceFile findFileResource(final String path) {
        if (null == this.directory)
            return null;
        final File file = new File(this.directory, path);
        if (file.exists()) {
//            try {
//                //当您使用Windows(保留大小写(FAT32/NTFS/..))时,可以使用 file.getCanonicalFile().getName(); 来获取所选文件的规范名称.
//                System.out.println(file.getCanonicalPath());
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
            return new Re_DirectoryResourceFile(path, file, defaultCharset());
        }
        return null;
    }


    @Nullable
    @Override
    public Re_ResourceFile findClassResource(String className) {
        if (null == this.directory)
            return null;
        String path = Re_CodeLoader.RuntimeUtils.classNameToPath(className);
        final File file = new File(this.directory, path);
        if (file.exists()) {
            return new Re_DirectoryResourceFile(className, file, defaultCharset());
        }
        return null;
    }
}
