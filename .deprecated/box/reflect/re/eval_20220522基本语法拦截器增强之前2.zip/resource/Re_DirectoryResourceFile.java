package top.fols.box.reflect.re.resource;

import top.fols.atri.io.file.Filez;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URI;
import java.nio.charset.Charset;

public class Re_DirectoryResourceFile implements Re_ResourceFile {

    String name;
    File file;
    Charset charset;
    Re_DirectoryResourceFile(String name, File file, Charset charset) {
        this.name = name;
        this.file = file;
        this.charset = charset;
    }

    @Override
    public URI toURI() {
        return file.toURI();
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public String path() {
        return file.getPath();
    }

    @Override
    public Charset charset() {
        return charset;
    }

    Filez filez;
    public Filez file(){
        if (null == filez)
            filez = Filez.wrap(file);
        return filez;
    }

    @Override
    public byte[] bytes() {
        return file().readBytes();
    }
    @Override
    public InputStream stream() {
        try {
            return new FileInputStream(file);
        } catch (Throwable e) {
            return null;
        }
    }

    @Override
    public String toString() {
        return this.name;
    }
}
