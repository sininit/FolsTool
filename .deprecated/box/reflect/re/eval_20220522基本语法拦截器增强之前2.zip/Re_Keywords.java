package top.fols.box.reflect.re;

import top.fols.atri.lang.Classz;
import top.fols.atri.util.annotation.NotNull;
import top.fols.atri.util.annotation.Nullable;
import top.fols.box.reflect.re.interfaces.Re_IObject;
import top.fols.box.reflect.re.interfaces.Re_IJavaReflector;
import top.fols.box.reflect.re.interfaces.Re_IGetDeclaringClass;
import top.fols.box.reflect.re.interfaces.Re_IVariableMap;
import top.fols.box.reflect.re.primitive.classes.Re_PrimitiveClass_json;
import top.fols.box.reflect.re.primitive.classes.Re_PrimitiveClass_list;
import top.fols.box.reflect.re.primitive.classes.Re_PrimitiveClass_object;
import top.fols.box.reflect.re.primitive.lang.Re_Iterable;
import top.fols.box.reflect.re.primitive.lang.Re_Iterables;
import top.fols.box.reflect.re.primitive.lang.Re_Iterator;
import top.fols.box.reflect.re.primitive.objects.Re_PrimitiveObject_JImport;
import top.fols.box.reflect.re.primitive.objects.Re_PrimitiveObject_JImportCall;
import top.fols.box.reflect.re.primitive.util.*;
import top.fols.box.reflect.re.variables.Re_KeywordVariableMap;
import top.fols.box.reflect.re.variables.Re_VariableMap;

import java.lang.reflect.*;
import java.util.*;

import static top.fols.box.reflect.re.Re_CodeLoader.*;

@SuppressWarnings({"DanglingJavadoc", "UnnecessaryBoxing", "BooleanConstructorCall", "rawtypes"})
public class Re_Keywords {
    Re_Keywords(){}

    public static Object getKeywordValue(String name) {
        return Re_Variable.Unsafe.fromDirectAccessorFindValue(name, keyword);
    }
    public static void setKeywordValue(String name, Object value) {
        Re_Variable.Unsafe.addFinalValueIntern(name, value, keyword);
    }
    public static void removeKeywordValue(String name) {
        Re_Variable.Unsafe.removeVariable(name, keyword);
    }
    public static boolean hasKeywordValue(String name) {
        return Re_Variable.has(name, keyword);
    }

    public static Re_KeywordVariableMap getKeyword() {
        return keyword;
    }


    /**
     * 判断是否为 Re_IObject
     * 所有实现都以 Re_IObject 为基础
     */
    static public final String INNER_FUNCTION__IS_RE_OBJECT         = "is_re";
    static public final String INNER_FUNCTION__IS_JAVA_OBJECT       = "is_java";

    static public final String INNER_FUNCTION__                     = ""; // (true, false) --> false 空名字方法 全部执行 返回最后一个值（如果return 将会中断）

    static public final String INNER_FUNCTION__EVAL                 = "eval";

    static public final String INNER_FUNCTION__IMPORT               = "import";







//    @Deprecated
//    static public final String INNER_FUNCTION__CLASS0               = "class0";              //MAP EXPRESSION
//    @Deprecated
//    static public final String INNER_FUNCTION__SET_INIT_FUNCTION0   = "init0";               //MAP EXPRESSION
//    @Deprecated
//    static public final String INNER_FUNCTION__FUNCTION0            = "function0";           //MAP EXPRESSION
//    @Deprecated
//    static public final String INNER_FUNCTION__ISOLATE0             = "isolate0";            //MAP EXPRESSION
//
//    @Deprecated
//    static public final String INNER_FUNCTION__WHILE0   = "while0";
//    @Deprecated
//    static public final String INNER_FUNCTION__FOR0     = "for0";
//    @Deprecated
//    static public final String INNER_FUNCTION__FOREACH0 = "foreach0";
//
//    @Deprecated
//    static public final String INNER_FUNCTION__IF0      = "if0";
//    @Deprecated
//    static public final String INNER_FUNCTION__ELSE0    = "else0";
//
//    @Deprecated
//    static public final String INNER_FUNCTION__TRY0     = "try0";
//    @Deprecated
//    static public final String INNER_DYNAMIC_VAR__ERROR0= "error0";            //try catch 的 变量， 运行时动态添加的
//    @Deprecated
//    static public final String INNER_FUNCTION__CATCH0   = "catch0";
//    @Deprecated
//    static public final String INNER_FUNCTION__FINALLY0 = "finally0";


//    static public final String INNER_FUNCTION__JCLASSES                 = "jclasses";
//    static public final String INNER_FUNCTION__JFIELD                   = "jfield";
//    static public final String INNER_FUNCTION__JCONSTRUCTOR             = "jconstructor";
//    static public final String INNER_FUNCTION__JMETHOD                  = "jmethod";
//    public static final String INNER_FUNCTION__JIMPORT_CLASS_METHOD     = "jimport_class_method";
//    public static final String INNER_FUNCTION__JIMPORT_OBJECT_METHOD    = "jimport_object_method";




    static public final String INNER_EXPRESSION_CALL__CLASS             = "class";
    static public final String INNER_EXPRESSION_CALL__SET_INIT_FUNCTION = "init";
    static public final String INNER_EXPRESSION_CALL__FUNCTION          = "function";
    static public final String INNER_EXPRESSION_CALL__ISOLATE           = "isolate";

    static public final String INNER_EXPRESSION_CALL__WHILE             = "while";
    static public final String INNER_EXPRESSION_CALL__FOR               = "for";
    static public final String INNER_EXPRESSION_CALL__FOREACH           = "foreach";

    static public final String INNER_EXPRESSION_CALL__TRY               = "try";
    static public final String INNER_EXPRESSION_CALL__CATCH             = "catch";
    static public final String INNER_EXPRESSION_CALL__FINALLY           = "finally";

    static public final String INNER_EXPRESSION_CALL__IF                = "if";
    static public final String INNER_EXPRESSION_CALL__ELSE              = "else";










    static public final String INNER_FUNCTION__ARRAY        = "array";
    static public final String INNER_FUNCTION__NEW_ARRAY    = "new_array";
    static public final String INNER_FUNCTION__IS_ARRAY     = "is_array";
    static public final String INNER_FUNCTION__TO_ARRAY     = "to_array";

    static public final String INNER_CONVERT_FUNCTION__CREATE_OBJECT    = "_instance";          //{"key": value}; 语法自动转换为方法 创建一个对象实例
    static public final String INNER_FUNCTION__IS_CLASS_INSTANCE        = "is_instance";      //判断是否为re class 实例
    static public final String INNER_FUNCTION__TO_CLASS_INSTANCE        = "to_instance";

    static public final String INNER_CONVERT_FUNCTION__CREATE_LIST      = "_list";              //["key"]; 语法自动转换为方法 创建一个列表
    static public final String INNER_FUNCTION__IS_LIST_INSTANCE         = "is_list";          //判断是否为re class 实例
    static public final String INNER_FUNCTION__TO_LIST_INSTANCE         = "to_list";

    static public final String INNER_FUNCTION__IS_CLASS             = "is_class";       //判断是否为re class
    static public final String INNER_FUNCTION__IS_FUNCTION          = "is_function";    //判断是否为re function

    static public final String INNER_FUNCTION__GET_CLASS            = "get_class";      //如果是实例则获取类
    static public final String INNER_FUNCTION__GET_DECLARE_CLASS    = "get_declare_class";      //如果是实例则获取类


    static public final String INNER_VAR__SPACE             = "space";
    static public final String INNER_FUNCTION__IS_SPACE     = "is_space";       //判断是否为space

    static public final String INNER_VAR__ARGUMENTS = "arguments";      //参数
    static public final String INNER_VAR__$         = "$";              //参数


    static public final String INNER_VAR__THIS      = "this";
    static public final String INNER_VAR__STATIC    = "static";

    static public final String INNER_VAR__TRUE      = "true";
    static public final String INNER_VAR__FALSE     = "false";
    static public final String INNER_VAR__NULL      = "null";


    static public final String INNER_FUNCTION__IS_TRUE   = "is_true";
    static public final String INNER_FUNCTION__IS_FALSE  = "is_false";





    
    static public final String INNER_FUNCTION__FINAL    = "final";






    static public final String INNER_FUNCTION__THROW    = "throw";
    static public final String INNER_FUNCTION__RETURN   = "return";

    static public final String INNER_VAR__GLOBAL        = "global";


    static public final String INNER_FUNCTION__RANGE    = "range";


    public static final String INNER_FUNCTION__BREAK    = "break";
    public static final String INNER_FUNCTION__CONTINUE = "continue";


    static public final String INNER_FUNCTION__NOT          = "not";


    static public final String INNER_FUNCTION__LIST_KEYWORD      = "list_keyword";
    static public final String INNER_FUNCTION__IS_KEYWORD_KEY    = "is_keyword_key";
    static public final String INNER_FUNCTION__IS_KEYWORD        = "is_keyword";
    static public final String INNER_FUNCTION__GET_KEYWORD_KEY   = "get_keyword_key";
    static public final String INNER_FUNCTION__GET_KEYWORD       = "get_keyword";


    static public final String INNER_FUNCTION__IS_RUNTIME_KEYWORD_KEY   = "is_runtime_keyword_key";
    static public final String INNER_FUNCTION__GET_RUNTIME_KEYWORD      = "get_runtime_keyword";





    static public final String INNER_FUNCTION__IS_PRIMITIVE   = "is_primitive";//判断变量是否为primitive

    public static final String INNER_FUNCTION__PRINT       = "print";
    public static final String INNER_FUNCTION__PRINTLN     = "println";
    public static final String INNER_FUNCTION__INPUT       = "input";
    public static final String INNER_FUNCTION__TIME        = "time";
    public static final String INNER_FUNCTION__SLEEP       = "sleep";



    static public final String INNER_FUNCTION__JINVOKE                  = "jinvoke";
    static public final String INNER_FUNCTION__JSET                     = "jset";
    static public final String INNER_FUNCTION__JGET                     = "jget";


    public static final String INNER_FUNCTION__JFORNAME                 = "jforname";
    public static final String INNER_FUNCTION__JINTERFACE               = "jinterface";
    public static final String INNER_FUNCTION__JCLASS                   = "jclass";
    public static final String INNER_FUNCTION__JINSTANCEOF              = "jinstanceof";

    public static final String INNER_FUNCTION__JIMPORT                  = "jimport";
    public static final String INNER_FUNCTION__JOBJECT                  = "jobject";


    //变量操作
    public static final String INNER_FUNCTION__GETATTR = "getattr";
    public static final String INNER_FUNCTION__SETATTR = "setattr";
    public static final String INNER_FUNCTION__HASATTR = "hasattr";
    public static final String INNER_FUNCTION__DELATTR = "delattr";
    public static final String INNER_FUNCTION__LENATTR = "lenattr";
    public static final String INNER_FUNCTION__KEYATTR = "keyattr";



    //内置数据转换
    public static final String INNER_FUNCTION__STR      = "str";
    public static final String INNER_FUNCTION__INT      = "int";
    public static final String INNER_FUNCTION__LONG     = "long";
    public static final String INNER_FUNCTION__CHAR     = "char";
    public static final String INNER_FUNCTION__FLOAT    = "float";
    public static final String INNER_FUNCTION__DOUBLE   = "double";
    public static final String INNER_FUNCTION__SHORT    = "short";
    public static final String INNER_FUNCTION__BYTE     = "byte";
    public static final String INNER_FUNCTION__BOOLEAN  = "boolean";


    public static final String INNER_FUNCTION__ISSTR      = "is_str";
    public static final String INNER_FUNCTION__ISINT      = "is_int";
    public static final String INNER_FUNCTION__ISLONG     = "is_long";
    public static final String INNER_FUNCTION__ISCHAR     = "is_char";
    public static final String INNER_FUNCTION__ISFLOAT    = "is_float";
    public static final String INNER_FUNCTION__ISDOUBLE   = "is_double";
    public static final String INNER_FUNCTION__ISSHORT    = "is_short";
    public static final String INNER_FUNCTION__ISBYTE     = "is_byte";
    public static final String INNER_FUNCTION__ISBOOLEAN  = "is_boolean";






    //-----------------------------------------------内置类
    public static final String INNER_CLASS__OBJECT      = "object";
    public static final String INNER_CLASS__LIST        = "list";
    public static final String INNER_CLASS__JSON        = "json";
    //-----------------------------------------------




    //-----------------------------------------------计算和自动转换
    public static final String INNER_FUNCTION__TILDE        = "~";      //不会自动转换



    /**
     * 内置自动符号转换计算方法  {@link Re_Primitive_Util_Math#getAutomaticConversionOperator()}
     */
    public static final String INNER_MATH_FUNCTION__AAND            = "&&";
    public static final String INNER_MATH_FUNCTION__AND             = "&";

    public static final String INNER_MATH_FUNCTION__OR              = "|";
    public static final String INNER_MATH_FUNCTION__OOR             = "||";

    public static final String INNER_MATH_FUNCTION__XOR             = "^";

    public static final String INNER_MATH_FUNCTION__SHIFT_RIGHT             = ">>";
    public static final String INNER_MATH_FUNCTION__SHIFT_LEFT              = "<<";
    public static final String INNER_MATH_FUNCTION__UNSIGNED_SHIFT_RIGHT    = ">>>";

    public static final String INNER_MATH_FUNCTION__ADD             = "+";
    public static final String INNER_MATH_FUNCTION__SUBTRACT        = "-";
    public static final String INNER_MATH_FUNCTION__MULTIPLY        = "*";
    public static final String INNER_MATH_FUNCTION__DIVICE          = "/";
    public static final String INNER_MATH_FUNCTION__MOD             = "%";

    public static final String INNER_MATH_FUNCTION__NE              = "!=";
    public static final String INNER_MATH_FUNCTION__EQ              = "==";

    public static final String INNER_MATH_FUNCTION__EQO             = "===";
    public static final String INNER_MATH_FUNCTION__NEQO            = "!==";

    public static final String INNER_MATH_FUNCTION__GREATER         = ">";
    public static final String INNER_MATH_FUNCTION__LESS            = "<";
    public static final String INNER_MATH_FUNCTION__LESS_EQ         = "<=";
    public static final String INNER_MATH_FUNCTION__EQ_LESS         = "=<";
    public static final String INNER_MATH_FUNCTION__EQ_GREATER      = "=>";
    public static final String INNER_MATH_FUNCTION__GREATER_EQ      = ">=";






    public static final String INNER_MATH_FUNCTION__COLON_SET_INSTANCE_VALUE = ":";
    public static final String INNER_MATH_FUNCTION__FAST_FUNCTION_STATEMENT  = "->";
    //-----------------------------------------------



    public static final String INNER_VAR__INT_MAX       = "int_max";
    public static final String INNER_VAR__INT_MIN       = "int_min";
    public static final String INNER_VAR__CHAR_MAX      = "char_max";
    public static final String INNER_VAR__CHAR_MIN      = "char_min";
    public static final String INNER_VAR__FLOAT_MAX     = "float_max";
    public static final String INNER_VAR__FLOAT_MIN     = "float_min";
    public static final String INNER_VAR__DOUBLE_MAX    = "double_max";
    public static final String INNER_VAR__DOUBLE_MIN    = "double_min";
    public static final String INNER_VAR__SHORT_MAX     = "short_max";
    public static final String INNER_VAR__SHORT_MIN     = "short_min";
    public static final String INNER_VAR__LONG_MAX      = "long_max";
    public static final String INNER_VAR__LONG_MIN      = "long_min";
    public static final String INNER_VAR__BOOLEAN_MAX   = "boolean_max";
    public static final String INNER_VAR__BOOLEAN_MIN   = "boolean_min";
    public static final String INNER_VAR__BYTE_MAX      = "byte_max";
    public static final String INNER_VAR__BYTE_MIN      = "byte_min";





    /**
     * 最基础的对象
     */
    public static boolean isIReObject(Object o) {
        return o instanceof  Re_IObject;
    }

    /**
     * 底层实现的keyword 方法
     */
    public static boolean isRePrimitive(Object o) {
        return o instanceof  Re_IObject && ((Re_IObject) o).isPrimitive();
    }




    /**
     * 静态对象或者类都可以判断为类
     */
    public static boolean isReClass(Object o) {
        return o instanceof Re_Class && !(o instanceof Re_Class.Instance);
    }
    public static boolean isReFunction(Object o) {
        return o instanceof Re_ClassFunction;
    }


    public static boolean isReClassInstance(Object o) {
        return o instanceof Re_Class.Instance;
    }
    public static Re_Class.Instance asReClassInstance(Object o) {
        return o instanceof Re_Class.Instance? (Re_Class.Instance) o: null;
    }

    public static Re_ClassFunction asReClassFunction(Object o) {
        return o instanceof Re_ClassFunction? (Re_ClassFunction) o: null;
    }

    public static boolean isReListInstance(Object o) {
        return isReClassInstance(o)
                && ((Re_Class)o).getReClass() instanceof Re_PrimitiveClass_list;
    }
    public static Re_PrimitiveClass_list.Instance asReListInstance(Object o) {
        return o instanceof Re_PrimitiveClass_list.Instance? (Re_PrimitiveClass_list.Instance) o: null;
    }


    public static Re_Class getReClass(Object o) {
        return o instanceof Re_Class?((Re_Class)o).getReClass():null;
    }
    public static Re_Class getDeclareClass(Object o) {
        return o instanceof Re_IGetDeclaringClass ?((Re_IGetDeclaringClass)o).getReDeclaringClass():null;
    }









    public static class Break extends Re_IObject.IPrimitiveCall {
        public Break() {}

        public static boolean isBreak(Object result) {
            return result instanceof Break;
        }
        public static Break asBreak(Object result) {
            return result instanceof Break ? (Break)result: null;
        }
        @Override
        public Object executeCallProcess(Re_Executor p1, String p2, Call p3) throws Throwable {
            // TODO: Implement this method
            int paramCount = p3.getParamExpressionCount();
            if (paramCount == 0) {
                return null;
            }
            p1.setThrow(Re_Exceptions.unable_to_process_parameters(p2, paramCount));
            return null;
        }
    }
    public static class Continue extends Re_IObject.IPrimitiveCall {
        public Continue() {}

        public static boolean isContinue(Object result) {
            return result instanceof Continue;
        }
        public static Continue asContinue(Object result) {
            return result instanceof Continue ? (Continue)result: null;
        }
        @Override
        public Object executeCallProcess(Re_Executor p1, String p2, Call p3) throws Throwable {
            // TODO: Implement this method
            int paramCount = p3.getParamExpressionCount();
            if (paramCount == 0) {
                return null;
            }
            p1.setThrow(Re_Exceptions.unable_to_process_parameters(p2, paramCount));
            return null;
        }
    }

    // (true, false) --> false 空名字方法 全部执行 返回最后一个值（如果return 将会中断）
    public static class __ extends Re_IObject.IPrimitiveCall {
        @Override
        public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
            Object o = executor.getExpressionLastValue(call, 0, call.getParamExpressionCount());
            if (executor.isReturn()) return executor.getReturn();
            return o;
        }
    }


    public static class ReClassUtils {
        static String text_class =
                "create a class:     \n" +
                "class(name, { expression...; });  \n"+
                "name can be a local variable name";
        public static Object dynamicCreateInnerReClassAndInitialize(final Re_Executor executor, final Call callParamController) {
            int paramExpressionCount = callParamController.getParamExpressionCount();
            if (paramExpressionCount >= 1 && paramExpressionCount <= 2) {
                //获取所有表达式, 这是个非常非常危险的方法
                //将表达式创建为一个代码块
                Expression[] createObjectExpressions = RuntimeUtils.Expressions.getCreateObjectExpressions(callParamController.getBuildParamExpressionCache(paramExpressionCount - 1));
                if (null == createObjectExpressions) {
                    executor.setThrow(text_class);
                    return null;
                }

                String cname = null;
                if (paramExpressionCount > 1) {
                    cname = RuntimeUtils.Expressions.getExpressionAsLocalName(callParamController.getBuildParamExpressionCache(0));

                    if (null == cname) {
                        executor.setThrow(text_class);
                        return null;
                    }
                }
                return dynamicCreateInnerReClassAndInitialize(executor, cname, createObjectExpressions, callParamController);
            }
            executor.setThrow(text_class);
            return null;
        }
        public static Object dynamicCreateInnerReClassAndInitialize(final Re_Executor executor,
                                                                    @Nullable String className, @NotNull Expression[] expressions,
                                                                    @NotNull Call from) {
            Re_CodeFile block        = new Re_CodeFile();
            block.expressions        = expressions;
            block.expressionsOffset  = 0;
            block.filePath           = executor.getFilePath();
            block.lineOffset         = from.getLine();
            block.constManager       = executor.reCodes.getConstManager();

            //内部类
            Re_Class reDeclaringClass = executor.getReClass();
            Re_Class reClass = null == className ?
                    Re_Class.createAnonymousClass(executor, block, reDeclaringClass):
                    Re_Class.createClass(executor, className,   block, reDeclaringClass);

            if (null != reDeclaringClass)
                reClass.setReClassLoader(reDeclaringClass.getReClassLoader());

            if (null != className && null != reDeclaringClass) {
                Re_Variable.accessAddFinalValueIntern(executor, className, reClass, executor);
                if (executor.isReturn()) return executor.isReturn();
            }

            Re_Executor.runReClassInitialize0(executor.host, executor.getStack(), block, reClass);
            if (executor.isReturn()) return executor.isReturn();

            return reClass;
        }





        static String text_function = "create a function:     \n" +
                "function(name(param1, param2, param3), {\n" +
                "    println(param1);\n" +
                "});  \n" +

                "\n" +

                "create a function:     \n" +
                "function((param1, param2, param3), {\n" +
                "    println(param1);\n" +
                "});  \n" +
                "\n"+

                "create a function:     \n" +
                "function({\n" +
                "    println(param1);\n" +
                "}); ";
        public static Object dynamicCreateInnerReFunction(final Re_Executor executor, final Call callParamController) {
            int paramExpressionCount = callParamController.getParamExpressionCount();
            if (paramExpressionCount > 0 && paramExpressionCount <= 2) {
                String      fname = null;
                String[]    fparam_names = null;

                if (paramExpressionCount == 2) {
                    Expression firstExpression = callParamController.getBuildParamExpressionCache(0);
                    Call expressionAsCall = RuntimeUtils.Expressions.getExpressionAsCall(firstExpression);
                    if (null != expressionAsCall) {
                        fname = expressionAsCall.getName();
                        String[]    callAsParamName = RuntimeUtils.Expressions.getCallParamNameArray(expressionAsCall);
                        if (null == callAsParamName) {
                            executor.setThrow(text_function);
                            return null;
                        } else {
                            fparam_names = callAsParamName;
                        }
                    } else {
                        executor.setThrow(text_function);
                        return null;
                    }
                }

                Expression[] createObjectExpressions = RuntimeUtils.Expressions.getCreateObjectExpressions(callParamController.getBuildParamExpressionCache(paramExpressionCount - 1));
                if (null == createObjectExpressions) {
                    executor.setThrow(text_function);
                    return null;
                }

                return dynamicCreateInnerReFunction(executor, fname, fparam_names, createObjectExpressions, callParamController);
            }
            executor.setThrow(text_function);
            return null;
        }
        public static Object dynamicCreateInnerReFunction(final Re_Executor executor,
                                                          @Nullable String functionName, @Nullable String[] functionParamNameArray, @NotNull Expression[] expressions,
                                                          @NotNull Call from) {
            Re_CodeFile block        = new Re_CodeFile();
            block.expressions        = expressions;
            block.expressionsOffset  = 0;
            block.filePath           = executor.getFilePath();
            block.lineOffset         = from.getLine();
            block.constManager       = executor.reCodes.getConstManager();

            if (null == functionName || functionName.length() == 0)
                functionName = null;

            Re_Class reDeclaringClass = executor.getReClass();
            Re_ClassFunction function = null == functionName?
                    Re_ClassFunction.createAnonymousFunction(executor, block, reDeclaringClass, functionParamNameArray):
                    Re_ClassFunction.createFunction(executor, functionName, block, reDeclaringClass, functionParamNameArray);

            if (null != functionName) {
                Re_Variable.accessAddFinalValueIntern(executor, functionName, function, executor);
                if (executor.isReturn()) return executor.isReturn();
            }
            return function;
        }
    }








    public static boolean is_runtime_keyword_key(Object key) {
        return keyword.isRuntimeKeyword(key);
    }
    public static Object  get_runtime_keyword(Re_Executor executor, Object key) {
        return keyword.findRuntimeKeyword(executor, key);
    }


    public static boolean is_keyword_key(Object key) {
        return keyword.isKeywordKey(key);
    }
    public static boolean is_keyword(Object value) {
        return keyword.isKeywordValue(value);
    }
    public static Object get_keyword_key(Object value) {
        return keyword.getKeywordKey(value);
    }
    public static Object get_keyword(Object key) {
        return keyword.findKeyword(key);
    }
    public static String[] get_keyword_keys() {
        return keyword.getKeywordNames();
    }








    //导入最基础的 ***

    static final Re_KeywordVariableMap keyword = new Re_KeywordVariableMap();
    static {
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__,                  new __(), keyword);

        Re_Variable.Unsafe.addVariableIntern(INNER_VAR__NULL,                     new Re_CodeFile.Compile_Null_Variable(), keyword);
        Re_Variable.Unsafe.addVariableIntern(INNER_VAR__TRUE,                     new Re_CodeFile.Compile_Boolean_Variable(true), keyword);
        Re_Variable.Unsafe.addVariableIntern(INNER_VAR__FALSE,                    new Re_CodeFile.Compile_Boolean_Variable(false), keyword);
        Re_Variable.Unsafe.addVariableIntern(INNER_VAR__GLOBAL,                   new Re_Executor.Global(),       keyword);
        Re_Variable.Unsafe.addVariableIntern(INNER_VAR__SPACE,                    new Re_Executor.Space(),        keyword);
        Re_Variable.Unsafe.addVariableIntern(INNER_VAR__ARGUMENTS,                new Re_Executor.Arguments(),    keyword);
        Re_Variable.Unsafe.addVariableIntern(INNER_VAR__$,                        new Re_Executor.Arguments(),    keyword);

        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__TILDE,             new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object x0 = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Primitive_Util_Math.hash1(INNER_FUNCTION__TILDE, x0);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__NOT,    new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object expressionValue = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Primitive_Util_Math.hash11("-", expressionValue);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);






        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__THROW,   new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                Object[] callParam = executor.getExpressionValues(call);
                if (executor.isReturn()) return executor.getReturn();

                if (callParam.length == 0) {
//                    executor.currentLine(call);
                    executor.setThrow("");
                    return null;
                }
                if (callParam.length == 1) {
//                    executor.currentLine(call);
                    executor.setThrow(Re_Util.toString(callParam[0]));
                    return null;
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, callParam));
                return null;
            }
        }, keyword);


        //返回最后一个参数值
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__RETURN,  new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                Object result = executor.getExpressionLastValue(call, 0, call.getParamExpressionCount());
                if (executor.isReturn()) return executor.getReturn(); // throw or return();

                executor.setReturn(result);
                return result;
            }
        }, keyword);






        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__IS_TRUE,   new Re_IObject.IPrimitiveCall() {

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.ifTrue(temp)?True.get():False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__IS_FALSE,   new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.ifFalse(temp)?True.get():False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__RANGE, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                // TODO: Implement this method
                int paramCount = call.getParamExpressionCount();
                if (paramCount == 1) {
                    Object end = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.isReturn();
                    if (end instanceof Integer) {
                        return Re_Iterables.Re.wrapRange(executor, 0, (Integer) end);
                    }
                    executor.setThrow("unsupported data type: " + (null == end ? null : end.getClass().getName()));
                    return null;
                }
                if (paramCount == 2) {
                    Object start = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.isReturn();

                    Object end = executor.getExpressionValue(call, 1);
                    if (executor.isReturn()) return executor.isReturn();

                    if (start instanceof Integer && end instanceof Integer) {
                        return Re_Iterables.Re.wrapRange(executor, (Integer) start, (Integer) end);
                    }
                    executor.setThrow("unsupported data type: " + (null == start ? null : start.getClass().getName()));
                    return null;
                }
                if (paramCount == 3) {
                    Object start = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.isReturn();

                    Object end = executor.getExpressionValue(call, 1);
                    if (executor.isReturn()) return executor.isReturn();

                    Object step = executor.getExpressionValue(call, 2);
                    if (executor.isReturn()) return executor.isReturn();

                    if (start instanceof Integer && end instanceof Integer && step instanceof Integer) {
                        return Re_Iterables.Re.wrapRange(executor, (Integer) start, (Integer) end, (Integer) step);
                    }
                    executor.setThrow("unsupported data type: " + (null == start ? null : start.getClass().getName()));
                    return null;
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramCount));
                return null;
            }
        }, keyword);



        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__BREAK, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                // TODO: Implement this method

                int paramCount = call.getParamExpressionCount();
                if (paramCount == 0) {
                    Object v = new Break();
                    executor.setReturn(v);
                    return v;
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__CONTINUE, new Re_IObject.IPrimitiveCall(){
            String text = "(tag) or ()";

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                // TODO: Implement this method

                int paramCount = call.getParamExpressionCount();
                if (paramCount == 0) {
                    Object v = new Continue();
                    executor.setReturn(v);
                    return v;
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramCount));
                return null;
            }
        }, keyword);







        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__EVAL, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                if (call.getParamExpressionCount() == 1) {
                    if (executor.isReturn()) return executor.getReturn();//returned

                    String code = Re_Util.toString(executor.getExpressionValue(call, 0));
                    if (executor.isReturn()) return executor.getReturn();

                    int line = 1;

                    //这里这么算的原因是因为 一旦代码执行了 currentLine 就会 + 假设代码是从第四行开始，开始执行了就会变成第五行
                    Re host = executor.getHost();
                    Re_CodeFile block = host.compileCode(code, Re_CodeFile.INNER_EVAL__FILE_NAME, line);
                    Re_Executor     inheritVariableExecutor = Re_Executor.buildReInheritVariableExecutor0(host, executor.getStack(), block, executor);
                    Object result = inheritVariableExecutor.run();
                    executor.cloneResult(inheritVariableExecutor);
                    return result;
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, call.getParamExpressionCount()));
                return null;
            }
        }, keyword);


        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__FINAL, new Re_IObject.IPrimitiveCall() {
            final String text =
                    "use final(variable_manager, name, value);\n"+
                    "use final(name, value);"+
                    "name can be a local variable name";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 2) {
                    String name   = RuntimeUtils.Expressions.getExpressionAsLocalName(call.getBuildParamExpressionCache(0));
                    if (null == name) {
                        executor.setThrow(text);
                        return null;
                    }

                    Object value = executor.getExpressionValue(call, 1);
                    if (executor.isReturn()) return executor.getReturn();

                    Re_Variable.accessAddFinalValueIntern(executor, name, value, executor);
                    return value;
                }
                if (paramExpressionCount == 3) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();
                    if (!(temp instanceof Re_IVariableMap)) {
                        executor.setThrow(text);
                        return null;
                    }
                    Re_IVariableMap iVariableMap = (Re_IVariableMap) temp;

                    String name   = RuntimeUtils.Expressions.getExpressionAsLocalName(call.getBuildParamExpressionCache(1));
                    if (null == name) {
                        name = Re_Util.toString(executor.getExpressionValue(call,1));
                        if (executor.isReturn()) return executor.isReturn();
                        if (null == name) {
                            executor.setThrow(text);
                            return null;
                        }
                    }

                    Object value = executor.getExpressionValue(call, 2);
                    if (executor.isReturn()) return executor.getReturn();

                    Re_Variable.accessAddFinalValueIntern(executor, name, value, iVariableMap);
                    return value;
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);








        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__GETATTR, new Re_IObject.IPrimitiveCall() {
            String text = "(object, key)";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 2) {
                    Object object = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    Object key = executor.getExpressionValue(call, 1);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.getattr(executor, object, key);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__SETATTR, new Re_IObject.IPrimitiveCall() {
            String text = "(object, key, value)";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 3) {
                    Object object = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    Object key = executor.getExpressionValue(call, 1);
                    if (executor.isReturn()) return executor.getReturn();

                    Object value = executor.getExpressionValue(call, 2);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.setattr(executor, object, key, value)?True.get():False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__HASATTR, new Re_IObject.IPrimitiveCall() {
            String text = "(object, key)";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 2) {
                    Object object = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    Object key = executor.getExpressionValue(call, 1);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.hasattr(executor, object, key)? True.get():False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__DELATTR, new Re_IObject.IPrimitiveCall() {
            String text = "(object)";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 2) {
                    Object object = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    Object key = executor.getExpressionValue(call, 1);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.delattr(executor, object, key)?True.get():False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__LENATTR, new Re_IObject.IPrimitiveCall() {
            String text = "(object)";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object object = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.lenattr(executor, object);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__KEYATTR, new Re_IObject.IPrimitiveCall() {
            String text = "(object)";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object object = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.keyattr(executor, object);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);


    }









    static {
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__IS_PRIMITIVE,    new Re_IObject.IPrimitiveCall() {
            String text = "use "+ INNER_FUNCTION__IS_PRIMITIVE +"()";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Keywords.isRePrimitive(temp)?True.get():False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);



        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__IS_SPACE,        new Re_IObject.IPrimitiveCall() {
            String text = "use "+ INNER_FUNCTION__IS_SPACE +"()";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.isSpace(temp)?True.get():False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);


        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__IS_RE_OBJECT,        new Re_IObject.IPrimitiveCall() {
            String text = "use "+ INNER_FUNCTION__IS_RE_OBJECT +"()";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Keywords.isIReObject(temp)?True.get():False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__IS_JAVA_OBJECT,        new Re_IObject.IPrimitiveCall() {
            String text = "use "+ INNER_FUNCTION__IS_JAVA_OBJECT +"()";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return !Re_Keywords.isIReObject(temp) ?True.get():False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
    }






    //类和方法 this static eval import final
    static {

        Re_Variable.Unsafe.addFinalValueIntern(INNER_CONVERT_FUNCTION__CREATE_OBJECT, new Re_IObject.IPrimitiveCall() {
            String text = "m = { \"key\": value }; ";

            /**
             * 控制参数 代码由自己执行
             */@Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                Object o = Re_Executor.runReClassDict0(executor, call);
                return o;
            }
        }, keyword);

        Re_Variable.Unsafe.addFinalValueIntern(INNER_CONVERT_FUNCTION__CREATE_LIST, new Re_IObject.IPrimitiveCall() {
            String text = "m = [1, 2, 3]; ";

            /**
             * 控制参数 代码由自己执行
             */@Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                Re_PrimitiveClass_list.Instance instance = Re_PrimitiveClass_list.reclass.createInstance();
                return Re_Executor.runReClassList0(executor, instance, call);
            }
        }, keyword);







        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__IS_CLASS_INSTANCE, new Re_IObject.IPrimitiveCall() {
            String text = "use "+ INNER_FUNCTION__IS_CLASS_INSTANCE +"()";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Keywords.isReClassInstance(temp)?True.get():False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__TO_CLASS_INSTANCE, new Re_IObject.IPrimitiveCall() {
            String text = "use "+ INNER_FUNCTION__TO_CLASS_INSTANCE +"()";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.toinstance(executor, temp);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);



        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__IS_LIST_INSTANCE, new Re_IObject.IPrimitiveCall() {
            String text = "use "+ INNER_FUNCTION__IS_LIST_INSTANCE +"()";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Keywords.isReListInstance(temp)?True.get():False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__TO_LIST_INSTANCE, new Re_IObject.IPrimitiveCall() {
            final String text = "use "+ INNER_FUNCTION__TO_LIST_INSTANCE +"()";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.tolist(executor, temp);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);


        Re_Variable.Unsafe.addVariableIntern(INNER_VAR__THIS,     new Re_Class.This(),        keyword);
        Re_Variable.Unsafe.addVariableIntern(INNER_VAR__STATIC,   new Re_Class.Static(),      keyword);


        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__IMPORT, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                if (call.getParamExpressionCount() == 1) {
                    if (executor.isReturn()) return executor.getReturn();//returned

                    String name = Re_Util.toString(executor.getExpressionValue(call, 0));
                    if (executor.isReturn()) return executor.getReturn();

                    if (null == name) {
                        executor.setThrow("null class name");
                        return null;
                    }

                    Re_Class reClass = executor.getReClass();
                    if (null == reClass) {
                        executor.setThrow("executor no bind class");
                        return null;
                    }

                    if (name.startsWith(PACKAGE_SEPARATOR_STRING)) {
                        name = name.substring(PACKAGE_SEPARATOR_STRING.length(), name.length());

                        String reClassPackageName = reClass.getReClassPackageName();
                        if (null != reClassPackageName && reClassPackageName.length() != 0) {
                            name  = reClassPackageName + PACKAGE_SEPARATOR_STRING + name;
                        } else {
                            name  = name.substring(PACKAGE_SEPARATOR_STRING.length(), name.length());
                        }
                    }

                    Re_Class re_class = Re_ClassLoader.forName(reClass, name);
                    if (executor.isReturn()) return executor.getReturn();

                    String simpleName = re_class.getReClassSimpleName();
                    executor.set_var_value(simpleName, re_class);
                    return   re_class;
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, call.getParamExpressionCount()));
                return null;
            }

        }, keyword);



        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__GET_CLASS,       new Re_IObject.IPrimitiveCall() {
            String text = "use "+ INNER_FUNCTION__GET_CLASS +"()";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Keywords.getReClass(temp);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__GET_DECLARE_CLASS,       new Re_IObject.IPrimitiveCall() {
            String text = "use "+ INNER_FUNCTION__GET_DECLARE_CLASS +"()";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Keywords.getDeclareClass(temp);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);



        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__IS_CLASS,        new Re_IObject.IPrimitiveCall() {
            String text = "use "+ INNER_FUNCTION__IS_CLASS +"()";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Keywords.isReClass(temp)?True.get():False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__IS_FUNCTION,     new Re_IObject.IPrimitiveCall() {
            String text = "use "+ INNER_FUNCTION__IS_FUNCTION +"()";
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object temp = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Keywords.isReFunction(temp)?True.get():False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
    };


    //核心-数据转换方法 ***
    static {
        //str(), int(), char(), float(), double)(, short(), boolean(), long(), byte()
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__STR,       new Re_PrimitiveObject_JImportCall(String.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.toString(obj);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__INT,       new Re_PrimitiveObject_JImportCall(int.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.toInt(obj);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__LONG,      new Re_PrimitiveObject_JImportCall(long.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.toLong(obj);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__CHAR,      new Re_PrimitiveObject_JImportCall(char.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.toChar(obj);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__FLOAT,     new Re_PrimitiveObject_JImportCall(float.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.toFloat(obj);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__DOUBLE,    new Re_PrimitiveObject_JImportCall(double.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.toDouble(obj);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__SHORT,     new Re_PrimitiveObject_JImportCall(short.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.toShort(obj);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__BYTE,      new Re_PrimitiveObject_JImportCall(byte.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.toByte(obj);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__BOOLEAN,   new Re_PrimitiveObject_JImportCall(boolean.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.toBoolean(obj);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
    }


    static {
        //is_str(), is_int(), is_char(), is_float(), is_double)(, is_short(), is_boolean(), is_long(), is_byte()
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__ISSTR,       new Re_PrimitiveObject_JImportCall(String.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.isString(obj) ? True.get(): False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__ISINT,       new Re_PrimitiveObject_JImportCall(int.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.isInt(obj) ? True.get(): False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__ISLONG,      new Re_PrimitiveObject_JImportCall(long.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.isLong(obj) ? True.get(): False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__ISCHAR,      new Re_PrimitiveObject_JImportCall(char.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.isChar(obj) ? True.get(): False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__ISFLOAT,     new Re_PrimitiveObject_JImportCall(float.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.isFloat(obj) ? True.get(): False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__ISDOUBLE,    new Re_PrimitiveObject_JImportCall(double.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.isDouble(obj) ? True.get(): False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__ISSHORT,     new Re_PrimitiveObject_JImportCall(short.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.isShort(obj) ? True.get(): False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__ISBYTE,      new Re_PrimitiveObject_JImportCall(byte.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.isByte(obj) ? True.get(): False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__ISBOOLEAN,   new Re_PrimitiveObject_JImportCall(boolean.class) {
            @Override
            public boolean isPrimitive() {
                return true;
            }

            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.isBoolean(obj) ? True.get(): False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
    }
















    //核心-数据结构 ***
    static {
        Re_Variable.Unsafe.addFinalValueIntern(INNER_CLASS__OBJECT, Re_PrimitiveClass_object.reclass, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_CLASS__LIST,   Re_PrimitiveClass_list.reclass,   keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_CLASS__JSON,   Re_PrimitiveClass_json.reclass,   keyword);
    }




    //核心-符号方法 ***
    static {
        //symbol method + - * / ...
        Re_Primitive_Util_Math.addMethodToKeyword(keyword);
    }

    //核心- ***
    static {
        //创建 Object数组
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__ARRAY, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                return Re_Primitive_Util_Array._array(executor, call);
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__NEW_ARRAY, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                return Re_Primitive_Util_Array._newarray(executor, call);
            }
        }, keyword);

        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__IS_ARRAY, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.isArray(obj);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);


        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__TO_ARRAY, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.toarray(executor, obj);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__LIST_KEYWORD, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                Object[] callParam = executor.getExpressionValues(call);
                if (executor.isReturn()) return executor.getReturn();

                return get_keyword_keys();
            }
        }, keyword);


        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__IS_KEYWORD_KEY, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Keywords.is_keyword_key(obj) ? True.get() : False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__IS_KEYWORD, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Keywords.is_keyword(obj) ? True.get() : False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__GET_KEYWORD_KEY, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Keywords.get_keyword_key(obj);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__GET_KEYWORD, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Keywords.get_keyword(obj);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);


        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__GET_RUNTIME_KEYWORD, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Keywords.get_runtime_keyword(executor, obj);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__IS_RUNTIME_KEYWORD_KEY, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Keywords.is_runtime_keyword_key(obj) ? True.get() : False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);
    }




    static {
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__PRINT, new Re_IObject.IPrimitiveCall() {
            /**
             * @see Re_IObject#executeCallProcess(Re_Executor, String, Call)
             * @see Re_IObject#executePointMethodProcess(Re_Executor, String, Call)
             * <p>
             * 如果返回 true  则需要自己获取参数 执行器不会获取参数	所以传入参数 (Object[] callParam) 为null
             * 如果返回 false 执行器会自动执行获取参数并传入(Object[] callParam)
             * <p>
             * 千万要注意执行后判断是否已经return了，如果return应该立即返回return数据而不是继续执行
             * <p>
             * 只要用了{@link Re_Executor#getExpressionValue(Call, int)} 后都要手动检测是否return
             */@Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 0) return null;

                for (int i = 0, count = call.getParamExpressionCount(); i < count; i++) {
                    Object value = executor.getExpressionValue(call, i);
                    if (executor.isReturn()) return executor.getReturn();

                    System.out.print(Re_Util.toString(value));
                }
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__PRINTLN, new Re_IObject.IPrimitiveCall() {
            /**
             * @see Re_IObject#executeCallProcess(Re_Executor, String, Call)
             * @see Re_IObject#executePointMethodProcess(Re_Executor, String, Call)
             * <p>
             * 如果返回 true  则需要自己获取参数 执行器不会获取参数	所以传入参数 (Object[] callParam) 为null
             * 如果返回 false 执行器会自动执行获取参数并传入(Object[] callParam)
             * <p>
             * 千万要注意执行后判断是否已经return了，如果return应该立即返回return数据而不是继续执行
             * <p>
             * 只要用了{@link Re_Executor#getExpressionValue(Call, int)} 后都要手动检测是否return
             */@Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 0) return null;

                for (int i = 0, count = call.getParamExpressionCount(); i < count; i++) {
                    Object value = executor.getExpressionValue(call, i);
                    if (executor.isReturn()) return executor.getReturn();

                    String x = Re_Util.toString(value);
                    System.out.println(x);
                }
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__INPUT, new Re_IObject.IPrimitiveCall() {
            /**
             * @see Re_IObject#executeCallProcess(Re_Executor, String, Call)
             * @see Re_IObject#executePointMethodProcess(Re_Executor, String, Call)
             * <p>
             * 如果返回 true  则需要自己获取参数 执行器不会获取参数	所以传入参数 (Object[] callParam) 为null
             * 如果返回 false 执行器会自动执行获取参数并传入(Object[] callParam)
             * <p>
             * 千万要注意执行后判断是否已经return了，如果return应该立即返回return数据而不是继续执行
             * <p>
             * 只要用了{@link Re_Executor#getExpressionValue(Call, int)} 后都要手动检测是否return
             */@Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount <= 1) {
                    if (paramExpressionCount == 1) {
                        Object expressionValue = executor.getExpressionValue(call, 0);
                        if (executor.isReturn()) return executor.getReturn();//returned

                        System.out.println(Re_Util.toString(expressionValue));
                    }
                    Scanner scanner = new Scanner(System.in);
                    String s = scanner.nextLine();
                    scanner.reset();
                    return s;
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, call.getParamExpressionCount()));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__TIME, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                if (call.getParamExpressionCount() == 0) {
                    return System.currentTimeMillis();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, call.getParamExpressionCount()));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__SLEEP, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                if (call.getParamExpressionCount() == 1) {
                    Object obj = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();
                    Thread.sleep(Re_Util.toLong(obj));

                    return True.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, call.getParamExpressionCount()));
                return null;
            }
        }, keyword);
    }


    /**
     * 导入java反射
     */
    static {
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__JINVOKE, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramCount = call.getParamExpressionCount();
                if (paramCount == 3) {
                    Object variableValue = executor.getExpressionValue(call,0);
                    if (executor.isReturn()) return executor.getReturn();

                    Object nameValue = executor.getExpressionValue(call,1);
                    if (executor.isReturn()) return executor.getReturn();

                    Object argsValue = executor.getExpressionValue(call,2);
                    if (executor.isReturn()) return executor.getReturn();

                    Object toarray = Re_Util.toarray(executor, argsValue);


                    Re_IJavaReflector reflects = executor.reflector;
                    Method method = reflects.method(variableValue.getClass(), null, Re_Util.toString(nameValue), (Object[]) toarray);
                    if (null == method) {
                        executor.setThrow(reflects.buildNoSuchMethod(variableValue.getClass(), null, Re_Util.toString(nameValue), (Object[]) toarray));
                        return null;
                    }
                    return method.invoke(variableValue, (Object[]) toarray);
                }
                if (paramCount == 4) {
                    Object classValue = executor.getExpressionValue(call,0);
                    if (executor.isReturn()) return executor.getReturn();

                    Object variableValue = executor.getExpressionValue(call,1);
                    if (executor.isReturn()) return executor.getReturn();

                    Object nameValue = executor.getExpressionValue(call,2);
                    if (executor.isReturn()) return executor.getReturn();

                    Object argsValue = executor.getExpressionValue(call,3);
                    if (executor.isReturn()) return executor.getReturn();

                    Object toarray = Re_Util.toarray(executor, argsValue);

                    Re_IJavaReflector reflects = executor.reflector;
                    Method method = reflects.method(Re_Util.jObjectToJClass(classValue), null, Re_Util.toString(nameValue), (Object[]) toarray);
                    if (null == method) {
                        executor.setThrow(reflects.buildNoSuchMethod(Re_Util.jObjectToJClass(classValue), null, Re_Util.toString(nameValue), (Object[]) toarray));
                        return null;
                    }
                    if (executor.isReturn()) return executor.getReturn();
                    return method.invoke(variableValue, (Object[]) toarray);
                }
                if (paramCount == 5) {
                    Object classValue = executor.getExpressionValue(call,0);
                    if (executor.isReturn()) return executor.getReturn();

                    Object variableValue = executor.getExpressionValue(call,1);
                    if (executor.isReturn()) return executor.getReturn();

                    Object returnClass = executor.getExpressionValue(call,2);
                    if (executor.isReturn()) return executor.getReturn();

                    Object nameValue = executor.getExpressionValue(call,3);
                    if (executor.isReturn()) return executor.getReturn();

                    Object argsValue = executor.getExpressionValue(call,4);
                    if (executor.isReturn()) return executor.getReturn();

                    Object toarray = Re_Util.toarray(executor, argsValue);

                    Re_IJavaReflector reflects = executor.reflector;
                    Method method = reflects.method(Re_Util.jObjectToJClass(classValue), Re_Util.jObjectToJClass(returnClass), Re_Util.toString(nameValue), (Object[]) toarray);
                    if (null == method) {
                        executor.setThrow(reflects.buildNoSuchMethod(Re_Util.jObjectToJClass(classValue), Re_Util.jObjectToJClass(returnClass), Re_Util.toString(nameValue), (Object[]) toarray));
                        return null;
                    }
                    return method.invoke(variableValue, (Object[]) toarray);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramCount));
                return null;
            }
        }, keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__JSET, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramCount = call.getParamExpressionCount();
                if (paramCount == 3) {
                    Object variableValue = executor.getExpressionValue(call,0);
                    if (executor.isReturn()) return executor.getReturn();

                    Object nameValue = executor.getExpressionValue(call,1);
                    if (executor.isReturn()) return executor.getReturn();

                    Object argsValue = executor.getExpressionValue(call,2);
                    if (executor.isReturn()) return executor.getReturn();

                    Re_IJavaReflector reflects = executor.reflector;
                    Field method = reflects.field(variableValue.getClass(), null, Re_Util.toString(nameValue));
                    if (null == method) {
                        executor.setThrow(reflects.buildNoSuchField(variableValue.getClass(), null, Re_Util.toString(nameValue)));
                        return null;
                    }

                    method.set(variableValue, argsValue);
                    return argsValue;
                }
                if (paramCount == 4) {
                    Object classValue = executor.getExpressionValue(call,0);
                    if (executor.isReturn()) return executor.getReturn();

                    Object variableValue = executor.getExpressionValue(call,1);
                    if (executor.isReturn()) return executor.getReturn();

                    Object nameValue = executor.getExpressionValue(call,2);
                    if (executor.isReturn()) return executor.getReturn();

                    Object argsValue = executor.getExpressionValue(call,3);
                    if (executor.isReturn()) return executor.getReturn();

                    Re_IJavaReflector reflects = executor.reflector;
                    Field method = reflects.field(Re_Util.jObjectToJClass(classValue), null, Re_Util.toString(nameValue));
                    if (null == method) {
                        executor.setThrow(reflects.buildNoSuchField(Re_Util.jObjectToJClass(classValue), null, Re_Util.toString(nameValue)));
                        return null;
                    }

                    method.set(variableValue, argsValue);
                    return argsValue;
                }
                if (paramCount == 5) {
                    Object classValue = executor.getExpressionValue(call,0);
                    if (executor.isReturn()) return executor.getReturn();

                    Object variableValue = executor.getExpressionValue(call,1);
                    if (executor.isReturn()) return executor.getReturn();

                    Object returnClass = executor.getExpressionValue(call,2);
                    if (executor.isReturn()) return executor.getReturn();

                    Object nameValue = executor.getExpressionValue(call,2);
                    if (executor.isReturn()) return executor.getReturn();

                    Object argsValue = executor.getExpressionValue(call,3);
                    if (executor.isReturn()) return executor.getReturn();

                    Re_IJavaReflector reflects = executor.reflector;
                    Field method = reflects.field(Re_Util.jObjectToJClass(classValue), Re_Util.jObjectToJClass(returnClass), Re_Util.toString(nameValue));
                    if (null == method) {
                        executor.setThrow(reflects.buildNoSuchField(Re_Util.jObjectToJClass(classValue), Re_Util.jObjectToJClass(returnClass), Re_Util.toString(nameValue)));
                        return null;
                    }

                    method.set(variableValue, argsValue);
                    return argsValue;
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__JGET, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramCount = call.getParamExpressionCount();
                if (paramCount == 3) {
                    Object variableValue = executor.getExpressionValue(call,0);
                    if (executor.isReturn()) return executor.getReturn();

                    Object nameValue = executor.getExpressionValue(call,1);
                    if (executor.isReturn()) return executor.getReturn();

                    Re_IJavaReflector reflects = executor.reflector;
                    Field method = reflects.field(variableValue.getClass(), null, Re_Util.toString(nameValue));
                    if (null == method) {
                        executor.setThrow(reflects.buildNoSuchField(variableValue.getClass(), null, Re_Util.toString(nameValue)));
                        return null;
                    }

                    return method.get(variableValue);
                }
                if (paramCount == 4) {
                    Object classValue = executor.getExpressionValue(call,0);
                    if (executor.isReturn()) return executor.getReturn();

                    Object variableValue = executor.getExpressionValue(call,1);
                    if (executor.isReturn()) return executor.getReturn();

                    Object nameValue = executor.getExpressionValue(call,2);
                    if (executor.isReturn()) return executor.getReturn();

                    Re_IJavaReflector reflects = executor.reflector;
                    Field method = reflects.field(Re_Util.jObjectToJClass(classValue), null, Re_Util.toString(nameValue));
                    if (null == method) {
                        executor.setThrow(reflects.buildNoSuchField(Re_Util.jObjectToJClass(classValue), null, Re_Util.toString(nameValue)));
                        return null;
                    }

                    return method.get(variableValue);
                }
                if (paramCount == 5) {
                    Object classValue = executor.getExpressionValue(call,0);
                    if (executor.isReturn()) return executor.getReturn();

                    Object variableValue = executor.getExpressionValue(call,1);
                    if (executor.isReturn()) return executor.getReturn();

                    Object returnClass = executor.getExpressionValue(call,2);
                    if (executor.isReturn()) return executor.getReturn();

                    Object nameValue = executor.getExpressionValue(call,2);
                    if (executor.isReturn()) return executor.getReturn();

                    Re_IJavaReflector reflects = executor.reflector;
                    Field method = reflects.field(Re_Util.jObjectToJClass(classValue), Re_Util.jObjectToJClass(returnClass), Re_Util.toString(nameValue));
                    if (null == method) {
                        executor.setThrow(reflects.buildNoSuchField(Re_Util.jObjectToJClass(classValue), Re_Util.jObjectToJClass(returnClass), Re_Util.toString(nameValue)));
                        return null;
                    }
                    return method.get(variableValue);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramCount));
                return null;
            }
        }, keyword);







        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__JFORNAME, new Re_IObject.IPrimitiveCall() {
            String text =   "use @Deprecated jforname(java.lang.String:ClassName);\n"+
                            "use jforname(java.lang.Class:AClassInALoader, java.lang.String:ClassName);\n"+
                            "use jforname(java.lang.ClassLoader:ClassLoader, java.lang.String:ClassName);\n";

            /**
             * @param var_key  jimport
             * @param call
             *
             */
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                Object[] callParam = executor.getExpressionValues(call);
                if (executor.isReturn()) return executor.getReturn();

                if (callParam.length == 1) {
                    return Re_Util.jforNameFindClass(callParam[0]);
                }
                if (callParam.length == 2) {
                    String name = Re_Util.toString(callParam[1]);

                    if (callParam[0] instanceof ClassLoader) {
                        return Re_Util.jforNameFindClass(name, true, (ClassLoader) callParam[0]);
                    } else  {
                        Class callClass  = Re_Util.jforNameFindClass(callParam[0]);//解包，最好不要用
                        ClassLoader loader = callClass.getClassLoader();
                        return Re_Util.jforNameFindClass(name, true, loader);
                    }
                }
                executor.setThrow(text);
                return null;
            }
        }, keyword);


        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__JINTERFACE, new Re_IObject.IPrimitiveCall() {
            final String text =
                    "(  [java.lang.Class: class, ...], re_object_instance  ); //the first parameter must be a list";
            @Override
            public Object executeCallProcess(final Re_Executor executor, String var_key, Call call) throws Throwable {
                Object[] callParam = executor.getExpressionValues(call);
                if (executor.isReturn()) return executor.getReturn();

                if (callParam.length == 2) {
                    Object interfaceList0 = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();
                    if (!Re_Keywords.isReListInstance(interfaceList0)) {
                        executor.setThrow(text);
                        return null;
                    }
                    Object[] interfaceList1 = ((Re_PrimitiveClass_list.Instance) interfaceList0).toArray(executor, new Object[]{});
                    if (executor.isReturn()) return executor.getReturn();

                    Object instance0 = executor.getExpressionValue(call, 1);
                    if (executor.isReturn()) return executor.getReturn();
                    if (!Re_Keywords.isReClassInstance(instance0)) {
                        executor.setThrow(text);
                        return null;
                    }
                    final Re_Class.Instance instance = (Re_Class.Instance) instance0;

                    final Re_Stack re_stack = executor.getStack().clone();

                    InvocationHandler invocationHandler = new InvocationHandler() {
                        @Override
                        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                            String name = method.getName();

                            Re_Executor temp = Re_Executor.buildReHostExecutor(executor.host, re_stack, Re_CodeFile.NULL_FILE, new Re_VariableMap(), null);
                            Object instance_value = Re_Variable.accessGetInstanceValue(temp, name, instance);
                            if (temp.isThrow()) {
                                Re.throwStackException(temp);
                                return null;
                            }

                            if (isReFunction(instance_value)) {
                                Re_ClassFunction function = (Re_ClassFunction) instance_value;

                                Object o = function.invoke(temp, instance.getReClass(), instance, args,
                                        Re_ClassFunction.getArgumentsArrayAsVariableMap(args, function));

                                Re.throwStackException(re_stack);
                                return o;
                            } else {
                                re_stack.setThrow("no a function: " + name);
                                Re.throwStackException(re_stack);
                                return null;
                            }
                        }
                    };

                    Class[] interfaceList = Re_Util.jforNameFindClasss(interfaceList1);
                    Object proxy = null;
                    Throwable ex = null;
                    for (Class anInterface : interfaceList) {
                        try {
                            ClassLoader classLoader = anInterface.getClassLoader();
                            proxy = Proxy.newProxyInstance(
                                    classLoader,
                                    interfaceList,
                                    invocationHandler);
                            if (null != proxy) {
                                break;
                            }
                        } catch (Throwable e) {
                            ex = e;
                        }
                    }
                    if (null == proxy) {
                        executor.setThrow(null == ex?"new proxy error":ex.getMessage());
                        return null;
                    }
                    return proxy;
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, callParam));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__JCLASS, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 1) {
                    Object value = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.jObjectToJClass(value);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__JINSTANCEOF, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                int paramExpressionCount = call.getParamExpressionCount();
                if (paramExpressionCount == 2) {
                    Object value = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    Object cls = executor.getExpressionValue(call, 1);
                    if (executor.isReturn()) return executor.getReturn();

                    Class<?> aClass = Re_Util.jforNameFindClass(cls);
                    return Classz.isInstance(value, aClass, false)?True.get():False.get();
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
                return null;
            }
        }, keyword);

        //          jimport("java.lang.System")
        //System =  jimport("java.lang.System")
        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__JIMPORT, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                Object[] callParam = executor.getExpressionValues(call);
                if (executor.isReturn()) return executor.getReturn();

                if (callParam.length == 1) {
                    Re_PrimitiveObject_JImport re_import = Re_Util.jimport(callParam[0]);
                    String simpleName = re_import.getJavaClass().getSimpleName();
                    executor.set_var_value(simpleName, re_import);
                    return    re_import;
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, callParam));
                return null;
            }
        }, keyword);




        Re_Variable.Unsafe.addFinalValueIntern(INNER_FUNCTION__JOBJECT, new Re_IObject.IPrimitiveCall() {
            @Override
            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                Object[] callParam = executor.getExpressionValues(call);
                if (executor.isReturn()) return executor.getReturn();

                if (callParam.length == 1) {
                    Object value = executor.getExpressionValue(call, 0);
                    if (executor.isReturn()) return executor.getReturn();

                    return Re_Util.jobject(value);
                }
                executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, callParam));
                return null;
            }
        }, keyword);
    };


    //辅助变量
    //导入最大值，和基础类 ***
    static {
        Re_Variable.Unsafe.addFinalValueIntern(INNER_VAR__INT_MAX,      new Integer(Integer.MAX_VALUE),     keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_VAR__INT_MIN,      new Integer(Integer.MIN_VALUE),     keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_VAR__CHAR_MAX,     new Character(Character.MAX_VALUE), keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_VAR__CHAR_MIN,     new Character(Character.MIN_VALUE), keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_VAR__FLOAT_MAX,    new Float(Float.MAX_VALUE),         keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_VAR__FLOAT_MIN,    new Float(Float.MIN_VALUE),         keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_VAR__DOUBLE_MAX,   new Double(Double.MAX_VALUE),       keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_VAR__DOUBLE_MIN,   new Double(Double.MIN_VALUE),       keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_VAR__SHORT_MAX,    new Short(Short.MAX_VALUE),         keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_VAR__SHORT_MIN,    new Short(Short.MIN_VALUE),         keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_VAR__LONG_MAX,     new Long(Long.MAX_VALUE),           keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_VAR__LONG_MIN,     new Long(Long.MIN_VALUE),           keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_VAR__BOOLEAN_MAX,  new Boolean(true),            keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_VAR__BOOLEAN_MIN,  new Boolean(false),           keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_VAR__BYTE_MAX,     new Byte(Byte.MAX_VALUE),           keyword);
        Re_Variable.Unsafe.addFinalValueIntern(INNER_VAR__BYTE_MIN,     new Byte(Byte.MIN_VALUE),           keyword);
    }


}
