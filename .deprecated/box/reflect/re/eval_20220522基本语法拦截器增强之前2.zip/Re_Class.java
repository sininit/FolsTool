package top.fols.box.reflect.re;

import top.fols.atri.lang.Value;
import top.fols.box.reflect.re.interfaces.Re_IObject;
import top.fols.box.reflect.re.interfaces.Re_IGetDeclaringClass;
import top.fols.box.reflect.re.interfaces.Re_IVariableMap;
import top.fols.atri.util.annotation.NotNull;
import top.fols.box.reflect.re.variables.Re_VariableMap;

import java.util.Collection;

import static top.fols.box.reflect.re.Re_CodeLoader.SUB_CLASS_SEPARATOR;
import static top.fols.box.reflect.re.Re_CodeLoader.PACKAGE_SEPARATOR_STRING;

/**
 * 理论上来讲这不是一个类 它就像是
 * import java.lang.String;
 * 里的 String, 直接操作String 的功能 比如 String.trim();
 *
 * 你可以称这个{@link Re_Class}为 {类属性}
 */
@SuppressWarnings({"SynchronizeOnNonFinalField", "rawtypes"})
public class Re_Class implements Re_IVariableMap, Re_IObject, Re_IGetDeclaringClass {


    Re_Class() {}


    /**
     * thisClass         类所有实例都是这个类            创建时复制 不可修改
     */
    //
    Re_Class reClass;

    /**
     * 为空则代表是一个顶级类
     * 本类来自哪个类 一个文件里的第二个类? 也就是说 这是值上一水平的类    创建时复制 不可修改
     */
    //
    Re_Class reClassDeclaringClass;

    /**
     * 类名, 不可改
     */
    //
    String reClassName;
    Re_CodeFile reCodeBlock;
    Re_ClassLoader reClassLoader;

    //在什么地方声明的这个类
    Re_Executor parent = null;


    //类变量
    Re_IVariableMap variable;




    /**
     * 创建匿名类
     *
     * @param reCodeBlock      代码
     * @param reDeclaringClass 所属的类，也就是说是谁的子类
     */
    static Re_Class createAnonymousClass(Re_Executor parent,
                                         Re_CodeFile reCodeBlock,
                                         Re_Class reDeclaringClass) {
        return createAnonymousClassAfter(new Re_Class(), parent, reCodeBlock, reDeclaringClass);
    }
    static Re_Class createAnonymousClassAfter(Re_Class instance,

                                              Re_Executor parent,
                                              Re_CodeFile reCodeBlock,
                                              Re_Class reDeclaringClass) {
        instance.reClass = instance;
        instance.reClassDeclaringClass = reDeclaringClass;
        instance.reClassName = Re_CodeLoader.intern(
                (null == reDeclaringClass ? "" : reDeclaringClass.getReClassName()) + (SUB_CLASS_SEPARATOR + Re_Keywords.INNER_EXPRESSION_CALL__CLASS +"_"+reCodeBlock.getLineOffset()+"_" + Integer.toHexString(instance.hashCode())) );    //匿名类
        instance.reCodeBlock = reCodeBlock;
        instance.parent = parent;
        instance.variable = new Re_VariableMap();

        instance.initializeIsRun = false;
        instance.initializedLock = new Object();
        instance.initializeStaticObject = null;
        return instance;
    }

    /**
     * 创建顶级类或者子类
     *
     * @param name             确定的类名
     * @param reCodeBlock      代码
     * @param reDeclaringClass 所属的类，也就是说是谁的子类
     */
    static Re_Class createClass(Re_Executor parent,
                                String name, Re_CodeFile reCodeBlock,
                                Re_Class reDeclaringClass) {
        return createClassAfter(new Re_Class(), parent, name, reCodeBlock, reDeclaringClass);
    }
    static Re_Class createClassAfter(Re_Class instance,

                                     Re_Executor parent,
                                     String name, Re_CodeFile reCodeBlock,
                                     Re_Class reDeclaringClass) {
        if (null == name)
            name = String.valueOf((Object) null);

        instance.reClass = instance;
        instance.reClassDeclaringClass = reDeclaringClass;
        instance.reClassName = Re_CodeLoader.intern(
                null == reDeclaringClass ? (name) : (reDeclaringClass.getReClassName() + SUB_CLASS_SEPARATOR + name));  // 主类 or 子类
        instance.reCodeBlock = reCodeBlock;
        instance.parent = parent;
        instance.variable = new Re_VariableMap();

        instance.initializeIsRun = false;
        instance.initializedLock = new Object();
        instance.initializeStaticObject = null;
        return instance;
    }

















    public final Re_Class getReClass() {
        return reClass;
    }
    @Override
    public final Re_Class getReDeclaringClass() {
        return reClassDeclaringClass;
    }


    private String simple_name0;
    public final String getReClassSimpleName() {
        if (null == simple_name0) {
            String name = reClass.reClassName;
            int index = name.lastIndexOf(PACKAGE_SEPARATOR_STRING);
            if (index > -1) {
                name = name.substring(index + PACKAGE_SEPARATOR_STRING.length(), name.length());
            }
            int i = name.lastIndexOf(SUB_CLASS_SEPARATOR);
            if (i > -1) {
                name = name.substring(i + SUB_CLASS_SEPARATOR.length(), name.length());
            }
            simple_name0 = Re_CodeLoader.intern(name);
        }
        return simple_name0;
    }

    private Value<String> package_name0;
    public final String getReClassPackageName() {
        if (null == package_name0) {
            String name = reClass.reClassName;
            int index = name.lastIndexOf(PACKAGE_SEPARATOR_STRING);
            if (index > -1) {
                name = Re_CodeLoader.intern(name.substring(0, index));
            } else {
                name = null;
            }
            package_name0 = new Value<>(Re_CodeLoader.intern(name));
        }
        return package_name0.get();
    }


    public final String getReClassName() {
        return reClass.reClassName;
    }

    public final Re_ClassLoader getReClassLoader() {
        return reClass.reClassLoader;
    }
    /**
     * 只是设置 并没有实际意义
     * 类加载器将不会有任何变动
     * 不可用重复执行
     *
     * @param classLoader 类加载器
     */
    protected final void        setReClassLoader(Re_ClassLoader classLoader) {
        if (null != reClass.reClassLoader) {
            throw new Re_Exceptions.ExecuteException("already resolve loader");
        }
        reClass.reClassLoader = classLoader;
    }

    /**
     * 断开类加载器
     */
    protected final void disconReClassLoader() {
        reClass.reClassLoader = null;
    }

    /**
     * 获取代码块
     */
    protected final Re_CodeFile getCodeBlock() {
        return reClass.reCodeBlock;
    }










    private boolean initialize;
    public boolean isInitialize() {
        return reClass.initialize;
    }







    private Re_ClassFunction initFunction = null;
    /**
     * 在类被初始化时设置
     */
    public final Re_ClassFunction getInitFunction() {
        return  reClass.initFunction;
    }
    protected void setInitFunction(Re_ClassFunction initFunction) {
        if (null == this.reClass.initFunction) {
            this.reClass.initFunction = initFunction;
        }
    }





    //primitive class是在Java里 的 理论上不需要初始化
    static void setPrimitiveClassInitialized(Re_PrimitiveClass classInitialized, Re_Class staticInstance) {
        synchronized (classInitialized.reClass.initializedLock) {
            classInitialized.reClass.initializeStaticObject = staticInstance;
            classInitialized.reClass.initializeIsRun = true;
        }
    }







    /**
     * 不要修改
     */
    private Object              initializedLock;
    private Re_Class            initializeStaticObject;
    private boolean             initializeIsRun;                //只是执行过不是代表已经初始化成功了
    final Object initializeStaticObject(@NotNull Re host, Re_Stack stack, @NotNull Re_CodeFile block,
                                        @NotNull Re_Class re_class) {
        if (stack.isThrow())        //一个栈只能一个线程用
            return null;

        //该类的 唯一锁
        synchronized (reClass.initializedLock) {
            Object result = null;
            if (reClass.initializeIsRun) {
                if (null == reClass.initializeStaticObject) {
                    return null;//类初始化失败
                }
            } else {
                reClass.initializeStaticObject = re_class;
                reClass.initializeIsRun = true;

                boolean run = false;
                try {
                    Re_Executor re_executor = Re_Executor.buildReClassInitializeExecutor0(host, stack, block, re_class);
                    if (null != re_executor) {  //获取执行器成功
                        if (!re_executor.isThrow()) {   //没有出错
                            result = re_executor.run(); //执行所有代码
                            if (!re_executor.isThrow()) {   //执行所有代码没有出错
                                run = true;
                            }
                        }
                    }
                } finally {
                    if (run) {
                        reClass.initialize = true;
                    } else {
                        reClass.initializeStaticObject = null;
                        // noinspection ConstantConditions
                        reClass.initializeIsRun = reClass.initializeIsRun;
                    }
                }
            }
            return result;
        }
    }





    public final Re_Class getStatic() {
        return reClass.initializeStaticObject;
    }







    @Override
    public Re_Variable remove(Object key) {
        return variable.remove(key);
    }

    @Override
    public Re_Variable find(Object key) {
        Re_Variable re_variable = variable.find(key);
        if (null == re_variable)
            if (null != reClass.parent)
                re_variable = reClass.parent.find(key);
        return re_variable;
    }

    @Override
    public Re_Variable get(Object key) {
        return variable.find(key);
    }

    @Override
    public Re_Variable put(Object key, Re_Variable value) {
        return variable.put(key, value);
    }


    @Override
    public boolean containsKey(Object key) {
        return variable.containsKey(key);
    }

    @Override
    public int size() {
        return variable.size();
    }

    @Override
    public Collection<?> keySet() {
        return variable.keySet();
    }







    /**
     * @see #createInstanceAfter(Re_Class, Instance, Re_IVariableMap)
     */
    public Instance createInstance() {
        return new Instance(this);
    }

    /**
     * @see #createInstance()
     */
    protected static <T extends Instance> T createInstanceAfter(Re_Class reClass, T instance, Re_IVariableMap variableMap) {
        instance.reClass                    = reClass.reClass;
        instance.reClassDeclaringClass      = reClass.reClassDeclaringClass;
        instance.variable                   = variableMap;
        return instance;
    }

    public static class Instance extends Re_Class implements Re_IVariableMap, Re_IObject {
        protected Instance(Re_Class reClass) {
            Re_Class.createInstanceAfter(reClass, Instance.this, new Re_VariableMap());
        }
        protected Instance(Re_Class reClass, Re_IVariableMap variableMap) {
            Re_Class.createInstanceAfter(reClass, Instance.this, variableMap);
        }

        
        private String name0;
        public String getName() {
            if (null == name0)
                name0 = getReClassName() + "@" + System.identityHashCode(this);
            return name0;
        }


        @Override
        public String toString() {
            return getName();
        }


        @Override
        public boolean isPrimitive() {
            return false;
        }


        @Override
        public Instance createInstance() {
            return reClass.createInstance();
        }


        /**
         * 原始获取
         * 理论上你必须使用 {@link Re_Variable} 而不是自己操作， 这些方法主要 {@link Re_Variable} 调用
         *
         *            递归获取
         */
        @Override
        public Re_Variable find(Object key) {
            Re_Variable re_variable = variable.find(key);
            if (null == re_variable)
                re_variable = reClass.initializeStaticObject.find(key);
            return re_variable;
        }

        @Override
        public Re_Variable get(Object key) {
            return variable.find(key);
        }


        /**
         * 直接删除
         * 理论上你必须使用 {@link Re_Variable} 而不是自己操作， 这些方法主要 {@link Re_Variable} 调用
         *
         */
        @Override
        public Re_Variable remove(Object key) {
            return variable.remove(key);
        }

        /**
         * 原始提交
         * 理论上你必须使用 {@link Re_Variable} 而不是自己操作， 这些方法主要 {@link Re_Variable} 调用
         *·
         * @param value
         */
        @Override
        public Re_Variable put(Object key, Re_Variable value) {
            return variable.put(key, value);
        }

        @Override
        public boolean containsKey(Object key) {
            return variable.containsKey(key);
        }

        /**
         * 数量
         */
        @Override
        public int size() {
            return variable.size();
        }

        /**
         * @return 变量名
         * 返回不可修改的集合， 或者克隆
         */
        @Override
        public Collection<?> keySet() {
            return variable.keySet();
        }




        /**
         * 获取子变量，不是获取自己
         * 只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
         *  @param executor
         * @param key
         */
        @Override
        public Object getVariableProcess(Re_Executor executor, Object key) throws Throwable {
            return Re_Variable.accessFindValue(executor, key, variable, reClass.initializeStaticObject.variable);
        }


        @Override
        public boolean hasVariableProcess(Re_Executor executor, Object key) throws Throwable {
            return Re_Variable.has(key, variable);
        }

        /**
         * 只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
         *  @param executor
         * @param key
         */
        @Override
        public boolean removeVariableProcess(Re_Executor executor, Object key) throws Throwable {
            return Re_Variable.accessRemove(executor, key, variable);
        }


        /**
         * 设置子变量，不是设置自己
         * 只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
         *  @param executor
         * @param key
         * @param value
         */
        @Override
        public void setVariableProcess(Re_Executor executor, Object key, Object value) throws Throwable {
            Re_Variable.accessSetValue(executor, key, value, variable);
        }

        @Override
        public int getSizeProcess(Re_Executor executor) throws Throwable {
            return Re_Variable.size(variable);
        }

        @Override
        public Iterable getKeysProcess(Re_Executor executor) throws Throwable {
            return Re_Variable.key(variable);
        }

        //方法如果设置名称 的话则设置为final


        /**
         * 执行之前不可能已经return， 如果中间有执行了表达式应该判断表达式是否已经return 如果已经return 则返回return数据 而不是继续操作, 如果已经return返回的任何数据都是无效的
         * <p>
         * 只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
         * <p>
         * 如果你不想处理，建议使用 {@link Re_IObject#executePointMethodProcess(Re_Executor, String, Re_CodeLoader.Call)}
         * <p>
         * 假定本对象名称x
         * 那么执行的是 x.x()
         * @param executor
         * @param point_key          指子变量名称，假设这是个map里面有个a
         *                            执行的就是map.a();
         * @param call 如果是true 则callParam 为空 ，如果false则 callParam会经过计算后传入
         */
        @Override
        public Object executePointMethodProcess(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
            Object findValue = Re_Variable.accessFindValue(executor, point_key, variable, this.reClass.initializeStaticObject.variable);
            if (executor.isReturn()) return executor.getReturn();

            boolean is_re_function = Re_Keywords.isReFunction(findValue);
            if (is_re_function) {
                Re_ClassFunction reFunction = (Re_ClassFunction) findValue;

                Object[] arguments = executor.getExpressionValues(call);
                if (executor.isReturn()) return executor.getReturn();

                Re_IVariableMap re_iReVariableMap = Re_ClassFunction.getArgumentsArrayAsVariableMap(arguments, reFunction);
                if (executor.isReturn()) return executor.getReturn();

                //最后一行 不需要判断return
                return reFunction.invoke(executor, reClass, this, arguments, re_iReVariableMap);
            }
            return executor.executeCall(findValue, point_key, call);
        }

        /**
         * 已经是实例了 你还要执行？
         */
        @Override
        public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
            return Re_Executor.executeCallVariableMap(executor, this, call);
        }
    }







    @Override
    public String toString() {
        return "re-" + Re_Keywords.INNER_EXPRESSION_CALL__CLASS + ": " + getReClassName();
    }

    @Override
    public boolean isPrimitive() {
        return false;
    }












    //------------------------------------------

    @Override public Object getVariableProcess(Re_Executor executor, Object key) throws Throwable {
        if (null == initializeStaticObject) {
            executor.setThrow("no initialize class: " + getReClassName());
            return null;
        }
        return Re_Variable.accessFindValue(executor, key, variable);
    }
    @Override public boolean hasVariableProcess(Re_Executor executor, Object key) throws Throwable {
        if (null == initializeStaticObject) {
            executor.setThrow("no initialize class: " + getReClassName());
            return false;
        }
        return Re_Variable.has(key, variable);
    }
    @Override public boolean removeVariableProcess(Re_Executor executor, Object key) throws Throwable {
        if (null == initializeStaticObject) {
            executor.setThrow("no initialize class: " + getReClassName());
            return false;
        }
        return Re_Variable.accessRemove(executor, key, variable);
    }
    @Override public void setVariableProcess(Re_Executor executor, Object key, Object value) throws Throwable {
        if (null == initializeStaticObject) {
            executor.setThrow("no initialize class: " + getReClassName());
            return;
        }
        Re_Variable.accessSetValue(executor, key, value, variable);
    }

    @Override
    public int getSizeProcess(Re_Executor executor) throws Throwable {
        if (null == initializeStaticObject) {
            executor.setThrow("no initialize class: " + getReClassName());
            return 0;
        }
        return Re_Variable.size(variable);
    }

    @Override
    public Iterable getKeysProcess(Re_Executor executor) throws Throwable {
        if (null == initializeStaticObject) {
            executor.setThrow("no initialize class: " + getReClassName());
            return null;
        }
        return Re_Variable.key(variable);
    }

    @Override public Object executePointMethodProcess(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
        if (null == initializeStaticObject) {
            executor.setThrow("no initialize class: " + getReClassName());
            return null;
        }

        Object static_value     = Re_Variable.accessFindValue(executor, point_key, variable);
        if (executor.isReturn()) return executor.getReturn();

        boolean is_re_function  = Re_Keywords.isReFunction(static_value);
        if (is_re_function) {
            Re_ClassFunction reFunction = (Re_ClassFunction) static_value;


            Object[] arguments = executor.getExpressionValues(call);
            if (executor.isReturn()) return executor.getReturn();

            Re_IVariableMap re_iReVariableMap = Re_ClassFunction.getArgumentsArrayAsVariableMap(arguments, reFunction);
            if (executor.isReturn()) return executor.getReturn();

            //最后一行 不需要判断return
            return reFunction.invoke(executor, reClass, executor.reClassInstance,  arguments, re_iReVariableMap);
        }
        return executor.executeCall(static_value, point_key, call);
    }
    @Override public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
        if (null == initializeStaticObject) {
            executor.setThrow("no initialize class: " + getReClassName());
            return null;
        }
        Instance newInstance = createInstance(); //创建实例
        Re_ClassFunction reFunction = getInitFunction();//获取初始化方法
        if (null != reFunction) {
            Object[] arguments = executor.getExpressionValues(call);
            if (executor.isReturn()) return executor.getReturn();

            //执行初始化方法
            //将参数转换为 re_iReVariableMap 如果function有参数的话 如果没有返回null
            Re_IVariableMap re_iReVariableMap = Re_ClassFunction.getArgumentsArrayAsVariableMap(arguments, reFunction);
            if (executor.isReturn()) return executor.getReturn();

            reFunction.invoke(executor, reClass, newInstance, arguments, re_iReVariableMap);
            //最后一行 不需要判断return
            return newInstance;
        }
        return newInstance;
    }
    //------------------------------------------




    protected Re_IVariableMap getVariableMap() { return variable; }

    protected void addFunctionToStaticFinal(String name, Re_ClassFunction function) {
        Re_Variable.Unsafe.addFinalValueIntern(name, function, variable);
    }



    //------------------------------------------

    static class This   extends Re_Variable.FinalVariable {
        @Override
        protected DirectAccessor getDirectAccessor() {
            return null;
        }

        public This() {
            super();
        }

        /**
         * @param executor 默认无意义
         */
        @Override
        public Object get(Re_Executor executor) {
            Re_Class.Instance reClassInstance = executor.getReClassInstance();
            if (null == reClassInstance) {
                executor.setThrow("the executor is not running on the instance");
                return null;
            }
            return reClassInstance;
        }
    }
    static class Static extends Re_Variable.FinalVariable {
        @Override
        protected DirectAccessor getDirectAccessor() {
            return null;
        }

        public Static() {
            super();
        }

        /**
         * @param executor 默认无意义
         */
        @Override
        public Object get(Re_Executor executor) {
            Re_Class reClass = executor.getReClass();
            if (null == reClass) {
                executor.setThrow("executor no bind class");
                return null;
            }
            Re_Class initializeStaticObject = reClass.getStatic();
            if (null == initializeStaticObject) {
                executor.setThrow("no initialize class: " + reClass.getReClassName());
                return null;
            }
            return initializeStaticObject;
        }
    }







    public static class Unsafe {
        /**
         * 非法访问
         */
        public static Object directExecuteFunction(Re re, Re_Class reClass, Re_Class.Instance instance, String functionName, Object[] params) {
            Object v;
            if (null == instance) {
                if (null == reClass) {
                    throw new NullPointerException("reClass is null");
                }
                v = Re_Variable.Unsafe.fromDirectAccessorGetClassValue(functionName, reClass);
            } else {
                v = Re_Variable.Unsafe.fromDirectAccessorGetInstanceValue(functionName, instance);
            }

            if (v instanceof Re_ClassFunction) {
                return directExecuteFunction(re, reClass, instance, (Re_ClassFunction) v, params);
            }
            throw new IllegalArgumentException("[" + (null == v?null:v.getClass()) + "] is not a function: " + functionName);
        }
        /**
         * 非法访问
         */
        public static Object directExecuteFunction(Re re, Re_Class reClass, Re_Class.Instance instance, Re_ClassFunction function, Object[] params) {
            Re_Stack stack = Re_Stack.newStack();
            Re_IVariableMap variableMap = Re_ClassFunction.getArgumentsArrayAsVariableMap(params, function);
            //temp executor
            Re_Executor beforeExecutor = Re_Executor.buildReClassObjectOrStaticFunction0(re, stack, function, reClass, instance, variableMap, params);
            if (stack.isThrow()) {
                Re.throwStackException(stack);
            }
            if (null == beforeExecutor) {
                throw new NullPointerException("build executor fail");
            }

            Object o = function.invoke(beforeExecutor,  reClass, instance, params, variableMap);
            if (stack.isThrow()) {
                Re.throwStackException(stack);
            }
            return o;
        }
        /**
         * 非法访问
         */
        public static Object directCreateInstance(Re re, Re_Class reClass, Object... params) {
            if (null == reClass) {
                throw new NullPointerException("reClass is null");
            }
            Instance instance = reClass.createInstance();

            Re_ClassFunction initFunction = reClass.getInitFunction();
            if (null == initFunction) {
                return instance;
            }

            return directExecuteFunction(re, reClass, instance, initFunction, params);
        }

        public static Object directGetInstanceValue(Re_Class.Instance instance, String name) {
            if (null == instance) {
                return null;
            }
            return Re_Variable.Unsafe.fromDirectAccessorGetInstanceValue(name, instance);
        }

        public static void directSetInstanceValue(Re_Class.Instance instance, String name, Object value) {
            if (null == instance) {
                return;
            }
            Re_Variable.Unsafe.fromDirectAccessorSetValueIntern(name, value, instance);
        }


        public static Object directGetClassValue(Re_Class instance, String name) {
            if (null == instance) {
                return null;
            }
            return Re_Variable.Unsafe.fromDirectAccessorGetClassValue(name, instance);
        }

        public static void directSetClassValue(Re_Class.Instance instance, String name, Object value) {
            if (null == instance) {
                return;
            }
            Re_Variable.Unsafe.fromDirectAccessorSetValueIntern(name, value, instance);
        }
    }
}
