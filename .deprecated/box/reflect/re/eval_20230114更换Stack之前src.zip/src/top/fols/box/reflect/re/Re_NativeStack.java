
package top.fols.box.reflect.re;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import top.fols.atri.lang.Strings;
import top.fols.atri.util.DoubleLinked;

@SuppressWarnings("RedundantCast")
public class Re_NativeStack {

	public static String toLineAddressString(String fileName, int line) {
		return '(' + fileName + ":" + line + ')';
	}
	public static String toLineAddressString(String funName, String fileName, int line) {
		return funName + '(' + fileName + ":" + line + ')';
	}
	public static ReTraceElement createTraceElement(String filePath, int line) {
		return new ReTraceElement(filePath, line);
	}
	public static ReTraceElement parseLineAddressString(String toLineAddressString) {
		String fun;
		String path;
		int line;
		if (null == toLineAddressString) {
			fun  = "";
			path = "";
			line = 0;
		} else {
			int offsetPath = toLineAddressString.indexOf('(') + 1;
			int offsetLine = toLineAddressString.lastIndexOf(":");
			int offset = offsetPath;
			while ((offset > 0) && !(toLineAddressString.charAt(offset - 1) <= ' ')) {
				offset--;
			}
			fun  = toLineAddressString.substring(offset, offsetPath - 1);

			if (offsetPath == offsetLine) {
				path = "";
			} else {
				path = toLineAddressString.substring(offsetPath, offsetLine);
			}

			line = Integer.parseInt(toLineAddressString.substring(offsetLine + 1, toLineAddressString.lastIndexOf(')')));
		}
		return new ReTraceElement(path, line);
	}



	@SuppressWarnings("SpellCheckingInspection")
	public static final ITraceElement[] 	  	  EMPTY_ITRACE_ELEMENTS = {};

	@SuppressWarnings("SpellCheckingInspection")
	public static final NativeTraceElement[]  	  EMPTY_NATIVETRACES = {};
	@SuppressWarnings("SpellCheckingInspection")
	public static final ReTraceElement[] 		  EMPTY_TRACEELEMENTS = {};



	@SuppressWarnings({"UnnecessaryModifier", "UnnecessaryInterfaceModifier"})
	public static interface ITraceElement extends Cloneable {
		public String getFilePath();
		public int getLine();

		public ITraceElement clone();
	}

	public static final class ReTraceElement implements Cloneable, ITraceElement {
		protected final String filePath;
		protected final int    line;

		public ReTraceElement(Re_NativeStack.ITraceElement iTrace) {
			this.filePath = iTrace.getFilePath();
			this.line     = iTrace.getLine();
		}
		public ReTraceElement(String filePath, int line) {
			this.filePath = filePath;
			this.line     = line;
		}

		public String getFilePath() {
			return filePath;
		}

		public int getLine() {
			return line;
		}


		@Override
		public String toString() {
			// TODO: Implement this method
			return toLineAddressString(this.filePath, this.line);
		}

		@Override
		public ReTraceElement clone() {
			// TODO: Implement this method
			try {
				return (ReTraceElement) super.clone();
			} catch (CloneNotSupportedException e) {
				throw new RuntimeException(e);//不可能
			}
		}
	}
	protected static final class NativeTraceElement implements Cloneable, ITraceElement {
		protected final Re_Executor executor;
		protected final String filePath;
		protected int line;

		protected NativeTraceElement(Re_Executor executor,
									 String filePath) {
			this.executor = executor;
			this.filePath = filePath;
		}

		@Override
		public String getFilePath() {
			return filePath;
		}
		@Override
		public int getLine() {
			return line;
		}


		@Override
		public String toString() {
			// TODO: Implement this method
			return toLineAddressString(this.filePath, this.line);
		}

		@Override
		public NativeTraceElement clone() {
			// TODO: Implement this method
			try {
				return (NativeTraceElement) super.clone();
			} catch (CloneNotSupportedException e) {
				throw new RuntimeException(e);//不可能
			}
		}
	}




	Re re;

	DoubleLinked<NativeTraceElement> top, bottom;

	int max_size = 8 * 1024 * 1024;// 8M
	int now_size;

	boolean 							  isThrow;
	Re_ZPrimitiveClass_exception.Instance exception;


	public boolean isEmpty() {
		return null == top;
	}





	private Re_NativeStack(Re_NativeStack beCloneStack) {
		this.re = beCloneStack.re;

		if (null != beCloneStack.top) {
			this.top = this.bottom = new DoubleLinked<> (beCloneStack.top.content().clone());//克隆第一个元素

			for (DoubleLinked<NativeTraceElement> next = beCloneStack.top.getNext(); null != next; next = next.getNext()) {
				NativeTraceElement current = next.content();
				if (null != current) {
					DoubleLinked<NativeTraceElement> clone_next = new DoubleLinked<>(current.clone());
					this.bottom.addNext(clone_next);
					this.bottom = clone_next;
				}
			}
		}

		this.max_size    = beCloneStack.max_size;
		this.now_size    = beCloneStack.now_size;
		this.isThrow     = beCloneStack.isThrow;
		this.exception   = null == beCloneStack.exception ? null : beCloneStack.exception.superClone();
	}
	private Re_NativeStack(Re re, NativeTraceElement startNativeTrace) {
		this.re = re;

		if (null != startNativeTrace) {
			this.top = this.bottom = new DoubleLinked<>(startNativeTrace.clone());
		}
	}

	@SuppressWarnings("MethodDoesntCallSuperMethod")
	@Override
	public Re_NativeStack clone() {
		// TODO: Implement this method
		return cloneStack(this);
	}







	public Re_ZPrimitiveClass_exception.Instance createExceptionInstance(
			String throwReason, Re_NativeStack stack) {
		return Rez.Safes.createInstance_exception(re,
				throwReason, stack);
	}

	static void fillExceptionInstanceTraceElements(Re_ZPrimitiveClass_exception.Instance instance, Re_NativeStack stack) {
		instance.setStackElements(stack.getReTraceElements());
	}
	static void fillExceptionInstanceTraceElements(Re_ZPrimitiveClass_exception.Instance instance, ReTraceElement[] reTraceElements) {
		instance.setStackElements(reTraceElements);
	}



	protected ReTraceElement[] getReTraceElements() {
		List<ReTraceElement> cs = new ArrayList<>();
		for (DoubleLinked<NativeTraceElement> now = this.top; null != now; now = now.getNext()) {
			NativeTraceElement current = now.content();
			if (null !=  current) {
				cs.add(new ReTraceElement(current));
			}
		}
		return cs.toArray(EMPTY_TRACEELEMENTS);
	}

	protected NativeTraceElement[] getNativeTraceElements() {
		List<NativeTraceElement> cs = new ArrayList<>();
		for (DoubleLinked<NativeTraceElement> now = this.top; null != now; now = now.getNext()) {
			NativeTraceElement current = now.content();
			if (null !=  current) {
				cs.add(current);
			}
		}
		return cs.toArray(EMPTY_NATIVETRACES);
	}





	public boolean isThrow() {
		return this.isThrow;
	}
	public Re_ZPrimitiveClass_exception.Instance getThrow() {
		return this.exception;
	}


	public void setThrow(String reason) {
		if (isThrow) return;//returned

		this.isThrow = true;
		this.exception = createExceptionInstance(reason, this);
	}
	public void setThrow(Re_ZPrimitiveClass_exception.Instance reason) {
		if (isThrow) return;//returned

		this.isThrow = true;
		this.exception = reason;
	}


	public void clearThrow() {
		this.isThrow = false;
		this.exception = null;
	}




	static Re_NativeStack cloneStack(Re_NativeStack stack) {
		return new Re_NativeStack(stack);
	}


	static Re_NativeStack newStack(Re re) {
		return new Re_NativeStack(re, (NativeTraceElement) null);
	}
	static Re_NativeStack newThreadStack(Re re, NativeTraceElement threadStartNativeTrace) {
		return new Re_NativeStack(re, (NativeTraceElement) threadStartNativeTrace);
	}




	protected DoubleLinked<NativeTraceElement> addStackElement(NativeTraceElement current) {
		DoubleLinked<NativeTraceElement> c = new DoubleLinked<>(current);
		if (null == this.bottom) {
			this.top = this.bottom = c;
		} else {
			this.top.addPrev(c);
			this.top = c;
		}
		this.now_size++;
		if (this.now_size >= this.max_size) {
			this.setThrow(Re_Accidents.stack_overflow(this.now_size, this.max_size));
		}
		return c;
	}
	//无法保证栈元素是当前栈的 所以请不要执行
	protected void removeStackElement(DoubleLinked<NativeTraceElement> current) {
		if (current == this.bottom) {
			if (this.top == this.bottom) {
				this.now_size = 0;
				this.top = this.bottom = null;
				current.remove();
			} else {
				DoubleLinked<NativeTraceElement> prev = this.bottom.getNext();
				this.now_size -= 1;
				current.remove();
				this.bottom = prev;
			}
		} else if (current == this.top) {
			DoubleLinked<NativeTraceElement> next = current.getNext();
			this.now_size--;
			current.remove();
			this.top = next;
		} else {
			current.remove();
		}
	}

	/**
	 * 删除某个栈之前的所有栈
	 */
	@SuppressWarnings({"UnnecessaryReturnStatement", "SpellCheckingInspection"})
	protected void disconBefore(DoubleLinked<NativeTraceElement> current) {
		if (current == this.top) {
			return;
		} else if (current == this.bottom) {
			this.top = current;
			current.disconAfter();
			this.now_size = 1;
		} else {
			DoubleLinked<NativeTraceElement> stackElementDoubleLinked = current.disconBefore();
			if (null != stackElementDoubleLinked) {
				int size = 0;
				for (DoubleLinked<NativeTraceElement> c = stackElementDoubleLinked; null != c; c= c.getPrev()) {
					size++;
				}
				this.top = current;
				this.now_size -= size;
			}
		}
	}




	static public String buildExceptionString(String reason, ITraceElement[] top) {
		return buildExceptionString0(reason, getStackElementIterator(top));
	}
	static String buildExceptionString0(String reason, Iterable<ITraceElement> top) {
		StringBuilder sb = new StringBuilder();
		sb.append("Reason: ") .append(Strings.tabs(Re_CodeLoader.CODE_LINE_SEPARATOR_CHAR + reason)).append(Re_CodeLoader.CODE_LINE_SEPARATOR_CHAR);
		sb.append("Traces: ") .append(Re_CodeLoader.CODE_LINE_SEPARATOR_CHAR);
		for (ITraceElement trace : top) {
			if (null != trace) {
				sb.append("\tin ").append(trace).append(Re_CodeLoader.CODE_LINE_SEPARATOR_CHAR);
			}
		}
		if (sb.length() > String.valueOf(Re_CodeLoader.CODE_LINE_SEPARATOR_CHAR).length()) {
			sb.setLength(sb.length() - String.valueOf(Re_CodeLoader.CODE_LINE_SEPARATOR_CHAR).length());
		}
		return sb.toString();
	}


	@SuppressWarnings("SameParameterValue")
	public String asString() {
		return buildExceptionString0(null, getStackElementIterator(this.top));
	}

	@Override
	public String toString() {
		return asString();
	}














	protected static class ArrayElementIterator implements Iterator<ITraceElement> {
		ITraceElement[] top;
		int index = -1;
		public ArrayElementIterator(ITraceElement[] top) {
			this.top = top;
		}

		@Override
		public boolean hasNext() {
			return index + 1 < top.length;
		}

		@Override
		public ITraceElement next() {
			if (hasNext())
				return top[++index];
			return null;
		}

		@Override
		public void remove() {
			throw new UnsupportedOperationException();
		}
	}
	protected static Iterable<ITraceElement> getStackElementIterator(final ITraceElement[] top) {
		return new Iterable<ITraceElement>() {
			@Override
			public Iterator<ITraceElement> iterator() {
				return new ArrayElementIterator(null == top? EMPTY_ITRACE_ELEMENTS :top);
			}
		};
	}


	protected static class LinkedElementIterator implements Iterator<ITraceElement> {
		DoubleLinked<? extends ITraceElement> top;
		DoubleLinked<? extends ITraceElement> current;
		boolean start;
		public LinkedElementIterator(DoubleLinked<? extends ITraceElement> top) {
			this.top = top;
		}

		@Override
		public boolean hasNext() {
			if (null == top)
				return false;
			if (start)
				return current.hasNext();
			return true;
		}

		@Override
		public ITraceElement next() {
			if (start) {
				current = current.getNext();
			} else {
				current = top;
				start = true;
			}
			return null == current?null:current.content();
		}

		@Override
		public void remove() {
			throw new UnsupportedOperationException();
		}
	}
	protected static Iterable<ITraceElement> getStackElementIterator(final DoubleLinked<? extends ITraceElement> top) {
		return new Iterable<ITraceElement>() {
			@Override
			public Iterator<ITraceElement> iterator() {
				return new LinkedElementIterator(top);
			}
		};
	}
}
