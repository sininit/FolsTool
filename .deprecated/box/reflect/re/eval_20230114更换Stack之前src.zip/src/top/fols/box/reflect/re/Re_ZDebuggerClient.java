package top.fols.box.reflect.re;

import top.fols.atri.lang.Classz;
import top.fols.box.net.interconnect.InterconnectSocketClient;

import java.io.Closeable;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Serializable;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.Map;

import top.fols.box.net.interconnect.InterconnectSocketSerializeReceiver;
import top.fols.box.net.interconnect.InterconnectSocketSerializeReceiver.AServerReply;
import top.fols.box.net.interconnect.InterconnectSocketSerializeReceiver.InterconnectSocketClientImpl;
import top.fols.box.net.interconnect.InterconnectSocketSerializeReceiver.RemoteThrowException;
import top.fols.box.net.interconnect.InterconnectSocketServer;

@SuppressWarnings({"rawtypes", "unchecked"})
public class Re_ZDebuggerClient implements Closeable {
    static protected final Map<String, AServerReply> STRING_SERVER_REPLY_HASH_MAP = new HashMap<>();
    static {
        Class<?>[] classes = Re_ZDebuggerClient.class.getClasses();
        for (Class c: classes){
            if (Classz.isInstanceNullable(c, AServerReply.class)) {
                try {
                    //noinspection unchecked
                    addServerReply((AServerReply) c.getDeclaredConstructor().newInstance());
                } catch (Throwable e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
    protected static <DATA extends Serializable, RET extends Serializable> void addServerReply(AServerReply<DATA, RET> reply) {
        addServerReply(reply.name(), reply);
    }
    protected static <DATA extends Serializable, RET extends Serializable> void addServerReply(String type, AServerReply<DATA, RET> reply) {
        STRING_SERVER_REPLY_HASH_MAP.put(type, reply);
    }
    protected static void removeServerReply(AServerReply reply) {
        removeServerReply(reply.name());
    }
    protected static void removeServerReply(String name) {
        STRING_SERVER_REPLY_HASH_MAP.remove(name);
    }
    protected static <DATA extends Serializable, RET extends Serializable> AServerReply<DATA, RET> findServerReply(String name) {
        return STRING_SERVER_REPLY_HASH_MAP.get(name);
    }

    static class AInterconnectSocketSerializeReceiver extends InterconnectSocketSerializeReceiver {
        Re_ZDebuggerClient client;
        public AInterconnectSocketSerializeReceiver(Re_ZDebuggerClient client) {
            this.client = client;
        }

        @Override
        public byte[] sendOriginalData(String target, String type, byte[] data) {
            return client.client.send(type, data);
        }

        @Override protected <DATA extends Serializable, RET extends Serializable> void addServerReply(AServerReply<DATA, RET> reply) {
            Re_ZDebuggerServer.addServerReply(reply);
        }
        @Override
        protected <DATA extends Serializable, RET extends Serializable> void addServerReply(String type, AServerReply<DATA, RET> reply) {
            Re_ZDebuggerServer.addServerReply(type, reply);
        }
        @Override
        protected void removeServerReply(AServerReply reply) {
            Re_ZDebuggerServer.removeServerReply(reply);
        }
        @Override
        protected void removeServerReply(String name) {
            Re_ZDebuggerServer.removeServerReply(name);
        }
        @Override
        protected <DATA extends Serializable, RET extends Serializable> AServerReply<DATA, RET> findServerReply(String name) {
            return Re_ZDebuggerServer.findServerReply(name);
        }

        <DATA extends Serializable, RET extends Serializable> RET send(AServerReply<DATA, RET> data) throws IOException, ClassNotFoundException, RemoteThrowException {
            return super.send(null, data);
        }
    };


    AInterconnectSocketSerializeReceiver  receiver = new AInterconnectSocketSerializeReceiver(this);
    InterconnectSocketClientImpl client = receiver.createClient();


    public Re_ZDebuggerClient(InetAddress inetAddress, int port) {
        client.connect(inetAddress, port);
    }







    public static Re_ZDebuggerClient link(int port) throws IOException, InterruptedException {
        return link(InetAddress.getLocalHost(), port);
    }

    public static Re_ZDebuggerClient link(Re re) throws IOException, InterruptedException {
        Re_ZDebuggerServer debuggerServer = re.open_debugger();
        InetAddress address = debuggerServer.getAddress();
        Integer p = debuggerServer.getPort();
        return link(address, p);
    }
    public static Re_ZDebuggerClient link(InetAddress ip, int port) throws IOException {
        return new Re_ZDebuggerClient(ip, port);
    }


    public boolean isConnect() {
        return client.isConnect();
    }
    @Override
    public void close() {
        client.close();
    }




    public Re_ZDebuggerServer.FindDebuggerStack.NativeStack findDebuggerStack() throws RemoteThrowException, IOException, ClassNotFoundException {
        return receiver.send(new Re_ZDebuggerServer.FindDebuggerStack());
    }
    public Boolean recoveryDebuggerStack() throws RemoteThrowException, IOException, ClassNotFoundException {
        return receiver.send(new Re_ZDebuggerServer.RecoveryDebugger());
    }

    public Re_ZDebuggerServer.GetObjectVariableList.VarElementList getObjectVariableList(Re_ZDebuggerServer.IGetObjectID element) throws RemoteThrowException, IOException, ClassNotFoundException {
        return receiver.send(new Re_ZDebuggerServer.GetObjectVariableList(element));
    }


    public Re_ZDebuggerServer.GetObjectData.ObjectData     getObjectData(Re_ZDebuggerServer.IGetObjectID element) throws RemoteThrowException, IOException, ClassNotFoundException {
        return receiver.send(new Re_ZDebuggerServer.GetObjectData(new Re_ZDebuggerServer.IGetObjectID[]{element})).first();
    }
    public Re_ZDebuggerServer.GetObjectData.ObjectDataList getObjectData(Re_ZDebuggerServer.IGetObjectID[] element) throws RemoteThrowException, IOException, ClassNotFoundException {
        return receiver.send(new Re_ZDebuggerServer.GetObjectData(element));
    }


    public Integer getObjectVariableCount(Re_ZDebuggerServer.IGetObjectID objectID) throws RemoteThrowException, IOException, ClassNotFoundException {
        return receiver.send(new Re_ZDebuggerServer.GetObjectVariableCount(objectID));
    }

    public Re_ZDebuggerServer.GetObjectData.ObjectData getObjectVariableValue(Re_ZDebuggerServer.IGetObjectID objectID, Re_ZDebuggerServer.IGetObjectID keyID) throws RemoteThrowException, IOException, ClassNotFoundException {
        return receiver.send(new Re_ZDebuggerServer.GetObjectVariableValue(objectID, null, keyID));
    }
    public Re_ZDebuggerServer.GetObjectData.ObjectData getObjectVariableValue(Re_ZDebuggerServer.IGetObjectID objectID, Object key) throws RemoteThrowException, IOException, ClassNotFoundException {
        return receiver.send(new Re_ZDebuggerServer.GetObjectVariableValue(objectID, key, null));
    }

    public Re_ZDebuggerServer.GetObjectData.ObjectData setObjectVariableValueFromCodeResult(Re_ZDebuggerServer.IGetObjectID objectID, Re_ZDebuggerServer.IGetObjectID keyID, String code) throws RemoteThrowException, IOException, ClassNotFoundException {
        return receiver.send(new Re_ZDebuggerServer.SetObjectVariableValueFromCodeResult(objectID, null, keyID, code));
    }
    public Re_ZDebuggerServer.GetObjectData.ObjectData setObjectVariableValueFromCodeResult(Re_ZDebuggerServer.IGetObjectID objectID, Object key, String code) throws RemoteThrowException, IOException, ClassNotFoundException {
        return receiver.send(new Re_ZDebuggerServer.SetObjectVariableValueFromCodeResult(objectID, key, null, code));
    }







    public static class PrintByte extends AServerReply<PrintByte, Boolean> implements Serializable {
        private static final long serialVersionUID = -3042686055658047285L;
        PrintByte() {}

        byte[] content;
        public PrintByte(byte[] content) {
            this.content = content;
        }



        @Override
        public Boolean callback(InterconnectSocketSerializeReceiver server, InterconnectSocketClient.TakeoverData<InterconnectSocketServer> takeoverData,
                                PrintByte data) {
            Re_ZDebuggerClient nrs = ((AInterconnectSocketSerializeReceiver) server).client;
            nrs.receive_print(data.content);
            return null;
        }
    }
    public void send_print(byte[] data, int off, int len) {
        byte[] buf;
        if (off == 0 && len == data.length) {
            buf = data;
        } else {
            buf = new byte[len];
            System.arraycopy(data, off, buf, 0, len);
        }
        try {
            receiver.send(new Re_ZDebuggerServer.PrintByte(buf));
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }
    public void receive_print(byte[] content) {
        try {
            PrintStream out = System.out;
            out.write(content);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
