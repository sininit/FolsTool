package top.fols.box.util;

import java.util.ArrayList;
import java.util.List;

public class Tests {
    public static void outOfMemory() {
        List<Object> data;
        try {
            data  = new ArrayList<>();
            for (;;) {
                data.add(new int[Integer.MAX_VALUE]);
            }
        } catch (OutOfMemoryError ignored) {}
        data = null;
    }
}
