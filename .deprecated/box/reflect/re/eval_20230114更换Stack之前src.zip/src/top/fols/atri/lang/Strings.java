package top.fols.atri.lang;

import top.fols.atri.io.*;
import top.fols.box.array.ArrayObject;
import top.fols.atri.regex.Regexs;
import top.fols.box.lang.Arrayx;
import top.fols.atri.util.Randoms;

import java.util.*;
import java.util.regex.Matcher;


@SuppressWarnings("SpellCheckingInspection")
public class Strings {

	public static String cast(Object object) {
		return null == object?null:object.toString();
	}
	public static String nonNull(Object object, String def) {
		return null == object?def:object.toString();
	}


	static final char[][] LINE_SEPARATOR_ALL = Finals.Separator.getAllSystemLineSeparatorCharsSortedMaxToMin();


	public static String tabs(String lines) {
		return tabs(lines, "\t");
	}
	public static String tabs(String lines, String tabs) {
		if (null == lines) {
			return tabs + null;
		}
		StringBuilder result = new StringBuilder();
		StringReaders reader = new StringReaders(lines);

		char[] chars;
		while (null != (chars = reader.readLine(LINE_SEPARATOR_ALL, true))) {
			result.append(tabs).append(chars);
		}
		Streams.close(reader);
		return result.toString();
	}
	public static String line(String... lines) {
		if (null == lines) { return null; }

		StringBuilder result = new StringBuilder();
		for (String line: lines) {
			result.append(line).append(Finals.Separator.LINE_SEPARATOR_CHAR_N);
		}
		if (result.length() > 1) {
			result.setLength(result.length() - 1);
		}
		return result.toString();
	}




	public static int indexOfChar(String str, char chars) {
		return (null == str)?-1:str.indexOf(chars);
	}
	public static int indexOfChar(String str, char[] chars, int offset) {
		if (!(null == str || null == chars)) {
			for (int i = offset; i < str.length(); i++) {
				char ch = str.charAt(i);
				for (char s: chars) {
					if (ch == s) {
						return i;
					}
				}
			}
		}
		return -1;
	}

	public static int lastIndexOfChar(String str, char chars) {
		return (null == str)?-1:str.lastIndexOf(chars);
	}
	public static int lastIndexOfChar(String str, char[] chars) {
		return lastIndexOfChar(str, chars, str.length()-1);
	}
	public static int lastIndexOfChar(String str, char[] chars, int offset) {
		if (!(null == str || null == chars) && str.length() > 0) {
			for (int i = offset; i >= 0; i--) {
				char ch = str.charAt(i);
				for (char s: chars) {
					if (ch == s) {
						return i;
					}
				}
			}
		}
		return -1;
	}





	public static Matcher matches(String regex, String content) {
		return Regexs.matches(regex, content);
	}

	public static String[][] subpatterns_all(String content, String regex) {
		return Regexs.subpatterns_all(content, regex);
	}
	public static String[] subpatterns(String content, String regex) {
		return Regexs.subpatterns(content, regex);
	}

	public static String[] subpattern_all(String content, String regex, int subpattern) {
		return Regexs.subpattern_all(content, regex, subpattern);
	}
	public static String subpattern(String content, String regex, int subpattern) {
		return Regexs.subpattern(content, regex, subpattern);
	}

	public static String[] group_all(String content, String regex) {
		return Regexs.group_all(content, regex);
	}
	public static String group(String content, String regex) {
		return Regexs.group(content, regex);
	}



	public static List<String> splitSpace(String firstLine) {
		List<String> list = new ArrayList<>();
		if (null == firstLine) {
			return list;
		}
		int last = 0, length = firstLine.length();
		for (int i = 0; i < length; i++) {
			if (Character.isSpaceChar(firstLine.charAt(i))) {
				if (i - last > 0) {
					String element = firstLine.substring(last, i);
					list.add(element);
				}
				while (i + 1 < length && Character.isSpaceChar(firstLine.charAt(i + 1))) {
					i++;
				}
				last = i + 1;
			}
		}
		if (last < length) {
			String element = firstLine.substring(last, length);
			list.add(element);
		}
		return list;
	}







	public static String join(Object[] array, String joinString) {
		return Strings.join(array, null, joinString, null);
	}
	@SuppressWarnings({"ImplicitArrayToString", "ConstantConditions"})
	public static String join(Object[] array, String head, String joinString, String end) {
		StringBuilder sb = new StringBuilder();
		if (null != head) { sb.append(head); }
		if (null == array) {
			sb.append(array);
		} else {
			if (array.length > 0) {
				for (Object o : array) {
					sb.append(o).append(joinString);
				}
				if (sb.length() > joinString.length()) {
					sb.setLength(sb.length() - joinString.length());
				}
			}
		}
		if (null != end) { sb.append(end); }
		return sb.toString();
	}



	public static String join(Collection<?> array, String joinString) {
		return Strings.join(array, null, joinString, null);
	}

	public static String join(Collection<?> array, String head, String joinString, String end) {
		StringBuilder sb = new StringBuilder();
		if (null != head) { sb.append(head); }
		if (null == array) {
			sb.append(array);
		} else {
			if (array.size() > 0) {
				for (Object o : array) {
					sb.append(o).append(joinString);
				}
				if (sb.length() > joinString.length()) {
					sb.setLength(sb.length() - joinString.length());
				}
			}
		}
		if (null != end) { sb.append(end); }
		return sb.toString();
	}


	/**
	 * StringJoiner
	 * 
	 * @param array
	 * @param joinString
	 * @return
	 */
	public static String join(Object array, String joinString) {
		return Strings.join(array, null, joinString, null);
	}

	public static String join(Object array, String head, String joinString, String end) {
		StringBuilder sb = new StringBuilder();
		if (null != head) { sb.append(head); }
		if (!ArrayObject.wrapable(array)) {
			sb.append(array);
		} else {
			ArrayObject<?> xifs = ArrayObject.wrap(array);
			int len = xifs.length();
			if (len > 0) {
				for (int i = 0; i < len; i++) {
					sb.append(xifs.objectValue(i)).append(joinString);
				}
				if (sb.length() > joinString.length()) {
					sb.setLength(sb.length() - joinString.length());
				}
			}
		}
		if (null != end) { sb.append(end); }
		return sb.toString();
	}



	public static String join(Map<?, ?> map, String joinString) {
		return Strings.join(map, null, "=", joinString, null);
	}
	public static String join(Map<?, ?> map, String valSeparator, String joinString) {
		return Strings.join(map, null, valSeparator, joinString, null);
	}
	public static String join(Map<?, ?> map, String head, String valSeparator, String joinString, String end) {
		StringBuilder sb = new StringBuilder();
		if (null != head) { sb.append(head); }
		if (null == map) {
			sb.append(map);
		} else {
			int len = map.size();
			Set<?> set = map.keySet();
			int i = 0;
			for (Object k : set) {
				sb.append(k).append(valSeparator).append(map.get(k)).append((i >= len - 1) ? "" : joinString);
				i++;
			}
		}
		if (null != end) { sb.append(end); }
		return sb.toString();
	}




	public static String marge(Object... values) {
		StringBuilder concat = new StringBuilder();
		if (null == values || values.length == 0) {
		} else {
			for (Object value: values) {
				concat.append(Objects.throwOrObjectToString(value));
			}
		}
		return concat.toString();
	}





	public static String random(char[] str, int length) {
		if (null == str) { return  null; }
		if (length == 0) { return Finals.STRING_EMPTY_VALUE; }

		Randoms random = new Randoms();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < length; i++) {
			sb.append(str[random.randomInt(0, str.length - 1)]);
		}
		return sb.toString();
	}

	public static String random(CharSequence str, int length) {
		if (null == str) { return  null; }
		if (length == 0) { return Finals.STRING_EMPTY_VALUE; }

		Randoms random = new Randoms();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < length; i++) {
			sb.append(str.charAt(random.randomInt(0, str.length() - 1)));
		}
		return sb.toString();
	}

	/**
	 * 替换字符串 i代表替换次数
	 */
	public static String replace(String str, CharSequence target, CharSequence replacement) {
		return replace(str, target, replacement, -1);
	}

	public static String replace(String str, CharSequence target, CharSequence replacement, int limiter) {
		if (null == str || null == target || target.length() == 0) { return  str; }
		if (null == replacement) { replacement = Finals.STRING_EMPTY_VALUE; }

		String tgtStr = target.toString();
		String replStr = replacement.toString();
		int j = str.indexOf(tgtStr);
		int tgtLen = tgtStr.length();
		if (j < 0 || limiter == 0 || tgtLen == 0) {
			return str;
		}
		int tgtLen1 = Math.max(tgtLen, 1);
		int length = str.length();
		int newLenHint = length - tgtLen + replStr.length();
		if (newLenHint < 0) {
			throw new OutOfMemoryError();
		}
		StringBuilder sb = new StringBuilder(newLenHint);
		int i = 0;
		if (limiter < 0)
			do {
				sb.append(str, i, j).append(replStr);
				i = j + tgtLen;
			} while (j < length && (j = str.indexOf(tgtStr, j + tgtLen1)) > 0);
		else
			do {
				sb.append(str, i, j).append(replStr);
				i = j + tgtLen;
			} while (--limiter > 0 && j < length && (j = str.indexOf(tgtStr, j + tgtLen1)) > 0);
		return sb.append(str, i, length).toString();
	}

	/**
	 * 获取str 出现的位置集合
	 */
	public static List<Integer> search(String str, String element) {
		List<Integer> list = new ArrayList<Integer>();
		if (Objects.empty(str) || Objects.empty(element)) {
			return list;
		}
		int elementlen = element.length();
		int indexOf = str.indexOf(element);
		if (indexOf <= -1) {
			return list;
		}
		do {
			list.add(indexOf);
		} while ((indexOf = str.indexOf(element, indexOf + elementlen)) > -1);
		return list;
	}

	/**
	 * 获取str重复出现的次数
	 */
	public static int 			searchRepeatCount(String str, String find) {
		if (Objects.empty(str) || Objects.empty(find)) { return 0; }

		int i = 0;
		int elementlen = find.length();
		int indexOf = str.indexOf(find);
		if (indexOf <= -1) { return 0; }
		do {
			i++;
		} while ((indexOf = str.indexOf(find, indexOf + elementlen)) > -1);
		return i;
	}



	/**
	 * 取文本长度
	 */
	public static int length(String str) { return null == str ? 0 : str.length(); }



//	public static String submiddle(String str, String left, String right) {
//		return submiddle(str, left, right, 0);
//	}
//	public static String submiddle(String str, String left, String right, int off) {
//		if (Objects.empty(str) || Objects.empty(left) || Objects.empty(right)) { return ""; }
//		if (off < 0) { off = 0; }
//		int start = str.indexOf(left, off);
//		int end = str.indexOf(right, start + left.length());
//		if (start > -1 && end > -1) {
//			return str.substring(start + left.length(), end);
//		}
//		return "";
//	}
//
//	public static String subleft(String str, String text, int off) {
//		int index = str.indexOf(text, off);
//		if (index > -1) {
//			return subleft(str, index);
//		} else {
//			return "";
//		}
//	}
//
//	public static String subright(String str, String text, int off) {
//		int index = str.indexOf(text, off);
//		if (index > -1) {
//			return subright(str, index + text.length());
//		} else {
//			return "";
//		}
//	}
//
//	/**
//	 * 取文本左边
//	 */
//	public static String subleft(String str, int endIndex) {
//		return null == str ? null : str.substring(0, endIndex);
//	}
//
//	/**
//	 * 取文本右边
//	 */
//	public static String subright(String str, int startIndex) {
//		return null == str ? null : str.substring(startIndex, str.length());
//	}




	/**
	 * 取文本中间
	 */
	public static String substring(String str, int startIndex, int endIndex) {
		if (null == str || (startIndex < 0 || endIndex < 0)) { return null; }

		return str.substring(startIndex, endIndex);
	}
	public static String subtrim(String spec, int start, int limit) {
		if (null == spec || (start < 0 || limit < 0)) { return null; }

		while ((limit > 0) && (spec.charAt(limit - 1) <= ' ')) limit--;
		while ((start < limit) && (spec.charAt(start) <= ' ')) start++;
		return spec.substring(start, limit);
	}




	/**
	 * 寻找文本
	 */
	public static int indexOf(String str, String find, int off) {
		return (null == str || null == find) ? -1 : str.indexOf(find, off);
	}
	public static int indexOfChar(String str, char find, int off) {
		return (null == str) ? -1 : str.indexOf(find, off);
	}
	public static int indexOfChar(String str, int find, int off) {
		return (null == str) ? -1 : str.indexOf(find, off);
	}



	public static int lastIndexOf(String str, String find, int off) {
		return (null == str || null == find) ? -1 : str.lastIndexOf(find, off);
	}
	public static int lastIndexOfChar(String str, char find, int off) {
		return (null == str) ? -1 : str.lastIndexOf(find, off);
	}
	public static int lastIndexOfChar(String str, int find, int off) {
		return (null == str) ? -1 : str.lastIndexOf(find, off);
	}





	/**
	 * split String
	 * <p>
	 * 分割文本
	 * 
	 * split("ab+cd+ef","+"); >> {"ab","cd",ef"}
	 */
	public static List<String> split(String str, String separator) {
		List<String> list = new ArrayList<>();
		Strings.split(str, separator, list);
		return list;
	}

	public static void split(String str, String separator, Collection<String> splits) {
		if (Objects.empty(str) || Objects.empty(separator) || str.equals(separator) || null == splits) { return; }

		int end = 0;
		int off = -separator.length();

		boolean startWith;
		if (startWith = str.startsWith(separator)) {
			end += separator.length();
			off += separator.length();
		}

		if ((end = str.indexOf(separator, end)) > -1) {
			while (end > -1) {
				splits.add(str.substring(off + separator.length(), end));
				off = end;
				end = str.indexOf(separator, end + separator.length());
			}
			if (str.endsWith(separator)) {
				return;
			}
			splits.add(str.substring(off + separator.length(), str.length()));
		} else {
			if (startWith) {
				splits.add(str.substring(off + separator.length(), str.length()));
			}
		}
	}

	/**
	 * repeat String
	 * <p>
	 * 取重复字符串
	 */
	public static String repeat(String str, int repeatLength) {
		if (null == str) { return null; }
		if (str.length() == 0 || repeatLength == 0) { return Finals.STRING_EMPTY_VALUE; }

		char[] newChar = Arrayx.repeat(str.toCharArray(), repeatLength);
		return new String(newChar);
	}

	/**
	 * fill String left
	 * <p>
	 * 在左边填充文本
	 * 
	 * fillLeft("123456",'0',2)); >> "56"
	 * <p>
	 * fillLeft("123456",'0',8)); >> "00123456"
	 */
	public static String fillLeft(String str, char fillstr, int newLength) {
		if (null == str)    { str = Finals.STRING_EMPTY_VALUE;  }
		if (newLength <= 0) { return Finals.STRING_EMPTY_VALUE; }

		char[] newChar = new char[newLength];
		fillLeft(str.toCharArray(), fillstr, newChar);
		return new String(newChar);
	}

	public static void fillLeft(char[] str, char fillstr, char[] newChar) {
		if (null == newChar) { return; }
		if (null == str)     { str = Finals.EMPTY_CHAR_ARRAY; }

		if (newChar.length == str.length) {
			if (str == newChar) {
				return;
			}
			System.arraycopy(str, 0, newChar, 0, str.length);
			return;
		} else if (newChar.length == 0) {
			return;
		}
		if (newChar.length < str.length) {
			int strart = str.length - newChar.length;
			int end = newChar.length;
			System.arraycopy(str, strart, newChar, 0, end);
		} else {
			int strart = newChar.length - str.length;
			System.arraycopy(str, 0, newChar, strart, str.length);
			Arrays.fill(newChar, 0, strart, fillstr);
		}
	}









	/**
	 * fill String Last
	 * <p>
	 * 在末尾填充文本
	 * 
	 * fillRight("123456",'0',2)); >> "12"
	 * <p>
	 * fillRight("123456",'0',8)); >> "12345600"
	 */
	public static String fillRight(String str, char fillstr, int newLength) {
		if (null == str)    { str =  Finals.STRING_EMPTY_VALUE; }
		if (newLength <= 0) { return Finals.STRING_EMPTY_VALUE; }

		char[] newChar = new char[newLength];
		fillRight(str.toCharArray(), fillstr, newChar);
		return new String(newChar);
	}

	public static void fillRight(char[] str, char fillstr, char[] newChar) {
		if (null == newChar) { return; }
		if (null == str)     { str = Finals.EMPTY_CHAR_ARRAY; }

		if (newChar.length == str.length) {
			if (str == newChar) {
				return;
			}
			System.arraycopy(str, 0, newChar, 0, str.length);
			return;
		} else if (newChar.length == 0) {
			return;
		}
		if (newChar.length < str.length) {
			System.arraycopy(str, 0, newChar, 0, newChar.length);
		} else {
			System.arraycopy(str, 0, newChar, 0, str.length);
			Arrays.fill(newChar, str.length, newChar.length, fillstr);
		}
	}

	/**
	 * reverse string
	 * <p>
	 * 字符串反转
	 * 
	 */
	public static String reverse(String str, int off, int end) throws NullPointerException {
		if (null == str)     		{ return null; }
		if (off < 0 || end < 0)     { return null; }

		if (end > off) {
			char[] chars = new char[str.length()];
			for (int i = end - 1, chi = 0; i >= off; i--) {
				chars[chi++] = (str.charAt(i));
			}
			return new String(chars);
		} else {
			return str.substring(off, end);
		}
	}

	/**
	 * retain chars
	 * <p>
	 * 保留char字符
	 * <p>
	 * 
	 * @return if @param str exist @param @retain element will return these exist
	 * @example retain("123123123321", 0, 12, new char[]{'1','2'}) >> 12121221
	 */
	public static String retain(CharSequence str, int off, int len, char[] retain) {
		if (null == str)     								  { return null; }
		if (null == retain)     							  { return null; }
		if (off < 0 || len < 0)     						  { return null; }

		CharsWriters retains = new CharsWriters();
		for (int i = off; i < off + len; i++) {
			char ch = str.charAt(i);
			for (char c : retain) {
				if (c == ch) {
					retains.write(c);
					break;
				}
			}
		}
		return retains.toString();
	}




	/**
	 * 替换文本
	 * replace string
	 * @param str string
	 * @param target need replace substrings
	 * @param replacement replacement
	 */
	public static CharSequence replace(CharSequence str, CharSequence[] target, CharSequence replacement) {
		if (null == str) 			{ return null; }
		if (str.length() == 0) 		{ return Finals.STRING_EMPTY_VALUE; }
		if (null == target || target.length == 0) { return str; }

		StringBuilder sb = new StringBuilder();

		int len = str.length();
		int lastIndex = 0;
		for (int strIndex = 0; strIndex < len; strIndex++) {
			char strchar = str.charAt(strIndex);

			for (int targetIndex = 0; targetIndex < target.length; targetIndex++) {
				if (target[targetIndex].charAt(0) == strchar && (strIndex + target[targetIndex].length()) <= len) {
					int c = 1;
					for (int targetElementIndex = 1; targetElementIndex < target[targetIndex].length(); targetElementIndex++) {
						if (target[targetIndex].charAt(targetElementIndex) == str.charAt(strIndex + targetElementIndex)) {
							c++;
						}
					}
					if (c == target[targetIndex].length()) {
						int st = lastIndex;
						int et = strIndex + target[targetIndex].length();

						sb.append(str, st, strIndex).append(replacement);

						lastIndex = et;
						strIndex += target[targetIndex].length();

						strIndex -= 1;// for (offset for self-increment)
					}
				}
			}
		}
		if (lastIndex != len) {
			sb.append(str, lastIndex, len);
		}
		return sb.toString();
	}

	/**
	 * 替换文本
	 * replace string
	 * @param str string
	 * @param target need replace substrings
	 * @param replacement correspond@param target
	 */
	public static CharSequence replace(CharSequence str, CharSequence[] target, CharSequence[] replacement) {
		if (null == str) 							{ return null; }
		if (str.length() == 0) 						{ return Finals.STRING_EMPTY_VALUE; }
		if (null == target || target.length == 0) 	{ return str; }

		StringBuilder sb = new StringBuilder();

		int len = str.length();
		int lastIndex = 0;
		for (int strIndex = 0; strIndex < len; strIndex++) {
			char strchar = str.charAt(strIndex);

			for (int targetIndex = 0; targetIndex < target.length; targetIndex++) {
				if (target[targetIndex].charAt(0) == strchar && (strIndex + target[targetIndex].length()) <= len) {
					int c = 1;
					for (int targetElementIndex = 1; targetElementIndex < target[targetIndex].length(); targetElementIndex++) {
						if (target[targetIndex].charAt(targetElementIndex) == str.charAt(strIndex + targetElementIndex)) {
							c++;
						}
					}
					if (c == target[targetIndex].length()) {
						int st = lastIndex;
						int et = strIndex + target[targetIndex].length();

						sb.append(str, st, strIndex).append(replacement[targetIndex]);

						lastIndex = et;
						strIndex += target[targetIndex].length();

						strIndex -= 1;// for (offset for self-increment)
					}
				}
			}
		}
		if (lastIndex != len) {
			sb.append(str, lastIndex, len);
		}
		return sb.toString();
	}
}
