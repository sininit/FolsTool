package top.fols.atri.util;

public class Runtimes {


    public static long getJVMUseMemory() {
        Runtime runtime = Runtime.getRuntime();
        return runtime.totalMemory() - runtime.freeMemory();
    }


    /**
     * @return use memory / max apply memory
     */
    public static double getJVMUseMemoryPercentage() {
        Runtime runtime = Runtime.getRuntime();
        double use = (runtime.totalMemory() - runtime.freeMemory());
        return(use / (double) runtime.maxMemory()) * 100;
    }


    /**
     * @return use memory / already apply memory
     */
    public static double getJVMUseApplyMemoryPercentage() {
        Runtime runtime = Runtime.getRuntime();
        long totalMemory = runtime.totalMemory();
        double  use = (totalMemory - runtime.freeMemory());
        return (use / (double) totalMemory) * 100;
    }
}
