package top.fols.box.io.cache;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import top.fols.atri.io.BytesInputStreams;
import top.fols.atri.io.Streams;
import top.fols.atri.io.file.Filex;
import top.fols.atri.lang.Objects;
import top.fols.atri.util.DoubleLinkedList;
import top.fols.atri.util.SizeUnit;
import top.fols.atri.util.annotation.Nullable;
import java.io.OutputStream;
import java.io.FileOutputStream;

public class FileCache {
//	public static void test() throws IOException	{
//		FileCache fc = new FileCache(createDirectoryIFileCache(new File("/")));
//		fc.getCacheInputStream("/storage/emulated/0/360安全云盘下载的文件/我的文件/Programming/JAVA/fols/folsTool/src/top/fols/atri/util/DoubleLinkedList.java");
//		fc.getCacheInputStream("/storage/emulated/0/360安全云盘下载的文件/我的文件/Programming/JAVA/fols/folsTool/src/top/fols/atri/io/BytesCodeInputStreams.java");
//		fc.getCacheInputStream("/storage/emulated/0/360安全云盘下载的文件/我的文件/Programming/JAVA/fols/folsTool/src/top/fols/atri/io/StringWriters.java");
//
//		System.out.println(Arrays.toString(fc.getCaches()));
//		fc.cleanExpiredCacheFromSize(10000000);
//		System.out.println(Arrays.toString(fc.getCaches()));
//
//		Times.sleep(1000);
//
//		fc.cleanExpiredCacheFromSize(1);
//		System.out.println(Arrays.toString(fc.getCaches()));
//
//		fc.cleanExpiredCacheFromSize(1);
//		System.out.println(Arrays.toString(fc.getCaches()));
//
//		fc.cleanExpiredCacheFromSize(1);
//		System.out.println(Arrays.toString(fc.getCaches()));
//	}


    public static DirectoryIFileCache createDirectoryIFileCache(File dir) {
        return new DirectoryIFileCache(dir);
    }
    public static class DirectoryIFileCache implements IFileCache {
        File directory;
        public DirectoryIFileCache(final File dir) {
            this.directory = Filex.newFileInstance(dir);
        }

        public File getDirectory() {
            return directory;
        }

        @Override
        public Long getFileLastModified(String path) {
            // TODO: Implement this method
            File f = new File(directory, path);
            if (f.canRead())
                return f.lastModified();
            return null;
        }
        @Override
        public Long getFileSize(String path) {
            // TODO: Implement this method
            File f = new File(directory, path);
            if (f.canRead())
                return f.length();
            return null;
        }



        @Override
        public InputStream getFileInputStream(String path) throws FileNotFoundException {
            // TODO: Implement this method
            File f = new File(directory, path);
            return new FileInputStream(f);
        }

        @Override
        public OutputStream getFileOutputStream(String path, boolean append) throws IOException {
            // TODO: Implement this method
            File f = new File(directory, path);
            return new FileOutputStream(f, append);
        }
    }
    public interface IFileCache {
        /**
         * If null is returned, it means failure or the file does not exist
         */
        public @Nullable Long         getFileLastModified(String path);
        public @Nullable Long         getFileSize(String path);

        public InputStream  getFileInputStream(String path) throws IOException;
        public OutputStream getFileOutputStream(String path, boolean append) throws IOException;
    }




    //	public static final long DEFAULT_AUTO_CLEAN_EXPIRED_CACHE_TIME = DEFAULT_CACHE_MAX_TIME * 10L;


    public static final long DEFAULT_CACHE_MAX_TIME = 100L;
    public static final long DEFAULT_CACHE_MAX_SIZE = SizeUnit.FILE_SIZE_1024_SIZE_UNIT.parseValue("32MB").longValue();

    public static final long UNLIMIT_SIZE = -1;


    public class Cache {
        public final String path;
        public final byte[] data;

        public volatile long lastModified;
        public volatile long lastReadTime;

        DoubleLinkedList.Element<Cache> linkedElement;

        //
        public Cache(String path, byte[] bytes) {
            this.path = path;
            this.data = bytes;
        }
    }
    protected Cache[] getCaches()	{ return this.currentCacheLinked.toArray(new Cache[]{}); }



    private IFileCache ifc;
    private long cacheMaxTime;
    private long cacheMaxSize;
//	private long cacheAutoCleanExpiredTime  = DEFAULT_AUTO_CLEAN_EXPIRED_CACHE_TIME;

    private long                          currentCacheSize   = 0;
    private final Map<String, Cache>      currentCache       = new HashMap<>();
    private final DoubleLinkedList<Cache> currentCacheLinked = new DoubleLinkedList<>();







    public FileCache(IFileCache ifc) {
        this.ifc = Objects.requireNonNull(ifc, "interface");
        this.setCacheMaxTimeFromMillis(DEFAULT_CACHE_MAX_TIME);
        this.setCacheMaxSize(DEFAULT_CACHE_MAX_SIZE);
    }





    long time() {
        return System.nanoTime();//no sync
    }
    long millisToTime(long millis) {
        return millis * 1000000L;
    }
    long timeToMillis(long time) {
        return time / 1000000L;
    }

    public long getCacheMaxTimeToMillis() {
        return timeToMillis(cacheMaxTime);
    }
    public void setCacheMaxTimeFromMillis(long millis) {
        if (millis >= 0) {
            long newTime =  millisToTime(millis);
            if  (newTime < 0) {
                throw new IllegalArgumentException("overflow, newTime=" + newTime);
            }
            this.cacheMaxTime = newTime;
        } else {
            throw new IllegalArgumentException("millis=" + millis);
        }
    }

//  he is not suitable for high-frequency interview
//	public long getAutoCleanExpiredCacheTime() {
//		return timeToMillis(cacheAutoCleanExpiredTime);
//	}
//	public void setAutoCleanExpiredCacheTime(long millis){
//		if (millis >= 0) {
//			this.cacheAutoCleanExpiredTime = millisToTime(millis);
//		} else {
//			throw new IllegalArgumentException("millis=" + millis);
//		}
//	}
//


    public long getCacheMaxSize() {
        return cacheMaxSize;
    }
    public void setCacheMaxSize(long size) {
        if (size >= 0) {
            this.cacheMaxSize = size;
        } else if (size == UNLIMIT_SIZE) {
        } else {
            throw new IllegalArgumentException("size=" + size);
        }
    }






    public int  getUseCacheCount() { return currentCache.size(); }
    public long getUseCacheSize()  { return currentCacheSize;    }
    public void clearCache() {
        synchronized (this.currentCache) {
            this.currentCacheSize = 0;
            this.currentCache.clear();
            this.currentCacheLinked.clear();
        }
    }
    public void removeCache(String path) {
        synchronized (this.currentCache) {
            removeCache(getCache(path));
        }
    }




    public static BytesInputStreams createBytesStream(byte[] data) {
        return new BytesInputStreams(data);
    }
    public static byte[] fromByteStreamGetBuffer(InputStream stream) {
        return stream instanceof BytesInputStreams ? ((BytesInputStreams)stream).buffer(): null;
    }
    public static boolean isBytesStream(Object stream) {
        return stream instanceof BytesInputStreams;
    }




    /**
     * the returned stream is not necessarily a cache stream
     * if you keep getting new files, it will slow down
     * @return BytesInputStreams or InputStream
     */
    public InputStream getCacheStreamOrGetStream(String path) throws IOException {
        Object ci = openCacheOrInputStream(path);
        if (ci instanceof Cache)
            return createBytesStream(((Cache)ci).data);
        else if (ci instanceof InputStream)
            return (InputStream) ci;
        else
            return null;
    }
    public byte[]     getCacheBytesOrReadBytes(String path) throws IOException {
        Object ci = openCacheOrInputStream(path);
        if (ci instanceof Cache)
            return ((Cache)ci).data;
        else if (ci instanceof InputStream)
            return Streams.toBytes((InputStream) ci);
        else
            return null;
    }





//		DoubleLinkedList.Element<Cache> last = this.currentCacheLinked.getLast();
//		if (null != last) {
//			Cache  c = last.content();
//			if  (time - c.lastReadTime >= cacheAutoCleanExpiredTime) {
//				this.__linkedCleanExpiredCacheFromSize(UNLIMIT_SIZE);
//			}
//		}

    protected Object openCacheOrInputStream(String path) throws IOException {
        Cache cache;
        if (null != (cache = getCache(path))) {
            long time = time();
            if  (time - cache.lastReadTime >= cacheMaxTime) {
                Long newLastModified = ifc.getFileLastModified(cache.path);
                if (null == newLastModified) {
                    removeCache(cache);
                    return null;// not found file
                }
                //version equals
                if (newLastModified == cache.lastModified) {
                    accessCache(cache, time);
                    return cache;
                }
            } else {
                //within cache validity
                //cache.lastReadTime = time;
                return cache;
            }
        }
        return openCacheOrInputStream0(path);
    }
    protected Object openCacheOrInputStream0(String path) throws IOException {
        synchronized (this.currentCache) {
            Cache cache;
            if (null != (cache = getCache(path))) {
                long time = time();
                if  (time - cache.lastReadTime >= cacheMaxTime) {
                    Long newLastModified = ifc.getFileLastModified(cache.path);
                    if (null == newLastModified) {
                        removeCache(cache);
                        return null;// not found file
                    }
                    //version equals
                    if (newLastModified == cache.lastModified) {
                        accessCache(cache, time);
                        return cache;
                    }
                } else {
                    //within cache validity
                    //cache.lastReadTime = time;
                    return cache;
                }
            }
            removeCache(cache);

            Long size = ifc.getFileSize(path);
            if (null == size) {
                return null;// not found file
            }

            InputStream stream = ifc.getFileInputStream(path);

            //unlimit size
            if (cacheMaxSize != UNLIMIT_SIZE) {
                //cannot cache even if the cache is empty
                if (size > cacheMaxSize) {
                    return stream;
                }
                //cache full, clear cache
                if (currentCacheSize + size > cacheMaxSize) {
                    if (!cleanExpiredCacheFromSize(size)) {//no extra space
                        return stream;
                    }
                }
            }

            Cache newCache;
            try {
                newCache = new Cache(path, Streams.toBytes(stream));
                newCache.lastReadTime = time();
                newCache.lastModified = ifc.getFileLastModified(path);
            } finally {
                Streams.close(stream);
            }

            addCache(newCache);
            return newCache;
        }
    }

    public void save(String path, byte[] bytes) throws IOException {
        synchronized (this.currentCache) {
            try {
                OutputStream os = null;
                try {
                    os = ifc.getFileOutputStream(path, false);
                    os.write(bytes);
                    os.flush();
                } finally {
                    Streams.close(os);
                }
            } finally {
                removeCache(path);
            }
        }
    }



    protected void addCacheAfter(Cache cache) {}
    protected void accessCacheAfter(Cache cache) {}
    protected void removeCacheAfter(Cache cache) {}


    public boolean cleanExpiredCacheFromSize(long size) {
        synchronized (this.currentCache) {
            long time = time();
            //sort by time
            if (size == UNLIMIT_SIZE) {
                for (DoubleLinkedList.Element<Cache> current = this.currentCacheLinked.getLast(); null != current;) {
                    DoubleLinkedList.Element<Cache> prev = (DoubleLinkedList.Element<FileCache.Cache>) current.getPrev();
                    Cache c = current.content();
                    //it is unnecessary to empty the cache without expiration
                    if (time - c.lastReadTime < cacheMaxTime)
                        break;

                    removeCache(c);

                    current = prev;
                }
                return true;
            } else {
                for (DoubleLinkedList.Element<Cache> current = this.currentCacheLinked.getLast(); null != current;) {
                    DoubleLinkedList.Element<Cache> prev = (DoubleLinkedList.Element<FileCache.Cache>) current.getPrev();
                    Cache c = current.content();
                    //it is unnecessary to empty the cache without expiration
                    if (time - c.lastReadTime < cacheMaxTime)
                        break;

                    removeCache(c);

                    //there is already enough space
                    if ((size -= c.data.length) <= 0)
                        return true;

                    current = prev;
                }
                return false;
            }
        }
    }







    private Cache getCache(String path) {
        return currentCache.get(path);
    }
    private void addCache(Cache newCache) {
        synchronized (this.currentCache) {
            _mapAddCache(newCache);
            __linkedAccessCache(newCache);
        }
        addCacheAfter(newCache);
    }
    private void accessCache(Cache cache, long accessTime) {
        synchronized (this.currentCache) {
            cache.lastReadTime = accessTime;
            __linkedAccessCache(cache);
        }
        accessCacheAfter(cache);
    }
    private void removeCache(Cache cache) {
        if (null == cache) return;
        synchronized (this.currentCache) {
            _mapRemoveCache(cache);
            __linkedRemoveCache(cache);
        }
        removeCacheAfter(cache);
    }





    private void _mapAddCache(Cache cache) {
        currentCache.put(cache.path, cache);
        currentCacheSize += cache.data.length;
    }
    private void _mapRemoveCache(Cache cache) {
        currentCache.remove(cache.path);
        currentCacheSize -= cache.data.length;
    }

    private void __linkedAccessCache(Cache cache) {
        synchronized (this.currentCache) {
            DoubleLinkedList.Element<Cache> le = cache.linkedElement;
            if (null == le) {
                cache.linkedElement = le = new DoubleLinkedList.Element<Cache>(cache);
            }
            this.currentCacheLinked.addFirst(le);
        }
    }
    private void __linkedRemoveCache(Cache cache) {
        synchronized (this.currentCache) {
            this.currentCacheLinked.remove(cache.linkedElement);
            cache.linkedElement = null;
        }
    }

}
