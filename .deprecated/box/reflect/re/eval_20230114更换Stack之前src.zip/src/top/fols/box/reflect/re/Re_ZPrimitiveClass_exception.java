package top.fols.box.reflect.re;

import top.fols.box.reflect.re.interfaces.Re_IReInnerVariableMap;

import static top.fols.box.reflect.re.Re_NativeStack.ReTraceElement;

public class Re_ZPrimitiveClass_exception extends Re_PrimitiveClass {

    @SuppressWarnings("SpellCheckingInspection")
    public static final Re_ZPrimitiveClass_exception reclass = new Re_ZPrimitiveClass_exception(Re_Keywords.INNER_CLASS__EXCEPTION);

    public static Object[] buildNewInstanceParameters(String throwReason, boolean isFillExecutorTrace) {
        return new Object[] { throwReason, isFillExecutorTrace };
    }

    protected Re_ZPrimitiveClass_exception(String className) {
        super(className, new InitBefore() {
            @Override
            public void init(Re_PrimitiveClass thatClass) {
                thatClass.setInitFunction(new Re_PrimitiveClassFunction(null, thatClass, null) {
                    @Override
                    public Object unauthenticationExecuteOnNative(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) throws Throwable {
                        int length = arguments.length;
                        Instance eInstance = (Instance) runInInstance;

                        String throwReason = null;
                        if (length > 0) {
                            throwReason = Re_Utilities.toJString(arguments[0]);
                        }
                        eInstance.setThrowReason(throwReason);

                        boolean fillExecutorTrace = true;
                        if (length > 1) {
                            fillExecutorTrace = Re_Utilities.toJBoolean(arguments[1]);
                        }
                        if (fillExecutorTrace) {
                            Re_NativeStack.fillExceptionInstanceTraceElements(eInstance, executor.getStack());
                        }
                        return null;
                    }
                });
            }
        });


        {
            final String name = "message";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object unauthenticationExecuteOnNative(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) {
                    int length = arguments.length;
                    if (length == 0) {
                        Instance e = (Instance) runInInstance;
                        return e.getReason();
                    }
                    executor.setThrow(Re_Accidents.unable_to_process_parameters(name, length));
                    return null;
                }
            });
        }
        {
            final String name = "stack";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object unauthenticationExecuteOnNative(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) {
                    int length = arguments.length;
                    if (length == 0) {
                        Instance e = (Instance) runInInstance;
                        return e.getStackElements();
                    }
                    executor.setThrow(Re_Accidents.unable_to_process_parameters(name, length));
                    return null;
                }
            });
        }

    }








    @Override
    protected Instance newUndefinedInstance(Re_Class reClass) {
        return new Instance(reClass);
    }




    public static final class Instance extends Re_PrimitiveClassInstance {
        protected Instance(Re_Class reClass) {
            super(reClass);
        }

        @Override
        Instance superClone() {
            Instance instance = (Instance) super.superClone();
            instance.throwReason = this.throwReason;
            instance.traces      = new ReTraceElement[this.traces.length];
            for (int i = 0; i < this.traces.length; i++) {
                instance.traces[i] = this.traces[i].clone();
            }
            return instance;
        }

        //reason
        String throwReason;

        //safe
        ReTraceElement[] traces;

        public void setThrowReason(String throwReason) {
            this.throwReason = throwReason;
        }
        public void setStackElements(ReTraceElement[] traces) {
            this.traces = traces;
        }

        public String getReason() {
            return throwReason;
        }
        public ReTraceElement[] getStackElements() {
            return traces;
        }

        public String asString() {
            return Re_NativeStack.buildExceptionString(this.throwReason, traces);
        }



        @Override
        public String toString() {
            return asString();
        }
    }
}
