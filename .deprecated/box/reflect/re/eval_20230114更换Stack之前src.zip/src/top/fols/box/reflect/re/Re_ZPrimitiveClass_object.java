package top.fols.box.reflect.re;

import java.util.Map;

/**
 * {对象} 和 它的抽象 {类}
 */

public class Re_ZPrimitiveClass_object extends Re_PrimitiveClass {
    @SuppressWarnings("SpellCheckingInspection")
    public static final Re_ZPrimitiveClass_object reclass = new Re_ZPrimitiveClass_object(Re_Keywords.INNER_CLASS__OBJECT);


    protected Re_ZPrimitiveClass_object(String className) {
        super(className);
    }




    @Override
    protected Re_PrimitiveClassInstance newUndefinedInstance(Re_Class reClass) {
        return new Re_PrimitiveClassInstance(reClass);
    }
}
