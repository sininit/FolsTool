package top.fols.box.reflect.re.resource;

import top.fols.atri.util.annotation.Nullable;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.nio.charset.Charset;

@SuppressWarnings({"UnnecessaryModifier", "UnnecessaryInterfaceModifier"})
public interface Re_IResourceFile {

    //统一名称
    public String name();

    public String absolutePath();
    public String path();

    public Charset charset();

    public InputStream  asStream();
    public byte[]       asBytes();
    public String       asString();
}
