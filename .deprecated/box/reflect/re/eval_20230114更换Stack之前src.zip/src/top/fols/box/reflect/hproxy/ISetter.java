package top.fols.box.reflect.hproxy;

import top.fols.atri.lang.Finals;
import top.fols.atri.reflect.ReflectMatcher;
import top.fols.atri.reflect.Reflects;

import java.lang.annotation.*;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;

@SuppressWarnings({"rawtypes", "UnnecessaryModifier", "unused"})
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface ISetter {
    String value() default "";
    Class type()   default void.class;

	int order() default 0;
	
    public static final Class<ISetter> TYPE = ISetter.class;
    public static final HProxy.AnnotationExecutor<ISetter> EXECUTOR = new HProxy.AnnotationExecutor<ISetter>() {
        Integer orderCache = null;
        @Override
        public Integer order(ISetter annotation) {
            // TODO: Implement this method
            if (null != orderCache && orderCache == annotation.order())
                return  orderCache;
            return orderCache = annotation.order();
        }

        @Override
        public ISetter cloneAnnotation(ISetter annotation) {
            Class type0 = null;
            try { type0 = annotation.type(); type0 = type0 == Finals.VOID_CLASS?null:type0; } catch (Throwable ignored) {}
            String value0 = null;
            try {  value0 = annotation.value();} catch (Throwable ignored) {}

			final Integer order = annotation.order();
            final int hashCode = annotation.hashCode();
            final Class type = type0;
            final String value = value0;
            return new ISetter() {
				@Override
				public int order() {
					// TODO: Implement this method
					return order;
				}
				
                @Override
                public String value() {
                    return value;
                }

                @Override
                public Class type() {
                    return type;
                }

                @Override
                public Class<? extends Annotation> annotationType() {
                    return TYPE;
                }



                @Override
                public int hashCode() {
                    return hashCode;
                }
                @Override
                public boolean equals(Object obj) {
                    if (obj == this)
                        return true;
                    if (!(obj instanceof ISetter))
                        return false;
                    ISetter other = (ISetter) obj;
                    return Objects.equals(type, other.type()) && Objects.equals(value, other.value());
                }
                @Override
                public String toString() {
                    return "@" + TYPE.getName() + "(tip=" + value + ", type=" + type + ", order=" + order() + ")";
                }
            };
        }

        @Override
        public void execute(ISetter annotation,
                            Class beProxyObjectClass, Object beProxyObject, Method runMethod, Method originalMethod, Object[] args, HProxy.ObjectProxy proxy, HProxy.Return result) throws Throwable {
            // TODO: Implement this method

            String fieldName = annotation.value();
            Class type = null;
            try { type = annotation.type(); type = type == Finals.VOID_CLASS?null:type; } catch (Throwable ignored) {}

            Field find = Reflects.accessible(Reflects.field(beProxyObjectClass, type, fieldName));
            if (null == find) {
                throw new RuntimeException(ReflectMatcher.buildNoSuchMatch(beProxyObjectClass, Reflects.fields(beProxyObjectClass), type, fieldName, (Object[]) null));
            }
            Object data = null == args || args.length == 0 ?null: args[0];
            find.set(beProxyObject, data);

            result.setReturn(data);
        }
    };
}
