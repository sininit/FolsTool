package top.fols.atri.io;

import top.fols.atri.lang.Finals;
import top.fols.atri.util.annotation.Tips;
import top.fols.atri.util.interfaces.IReleasable;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import top.fols.box.io.interfaces.IPrivateBuffOperat;
import top.fols.box.io.interfaces.IPrivateStreamIndexOperat;


public class BytesCodeInputStreams extends InputStream implements IPrivateBuffOperat<byte[]>,
        IPrivateStreamIndexOperat, IReleasable {

    // 保存字节输入流数据的字节数组
    private byte[] buf;
    // 下一个会被读取的字节的索引
    private int pos;
    // 标记的索引
    private int mark = 0;
    // 字节流的长度
    private int count;

    public BytesCodeInputStreams() {
        this(Finals.EMPTY_BYTE_ARRAY);
    }

    // 构造函数：创建一个内容为buf的字节流
    public BytesCodeInputStreams(byte[] buf) {
        // 初始化“字节流对应的字节数组为buf”
        this.buf = buf;
        // 初始化“下一个要被读取的字节索引号为0”
        this.pos = 0;
        // 初始化“字节流的长度为buf的长度”
        this.count = buf.length;
    }

    // 构造函数：创建一个内容为buf的字节流，并且是从offset开始读取数据，读取的长度为length
    public BytesCodeInputStreams(byte[] buf, int offset, int length) {
        // 初始化“字节流对应的字节数组为buf”
        this.buf = buf;
        // 初始化“下一个要被读取的字节索引号为offset”
        this.pos = offset;
        // 初始化“字节流的长度”
        this.count = Math.min(offset + length, buf.length);
        // 初始化“标记的字节流读取位置”
        this.mark = offset;
    }

    // 读取下一个字节
    @Override
    public int read() {
        return (pos < count) ? (buf[pos++] & 0xff) : -1;
    }

    @Override
    public int read(byte[] b) {
        return this.read(b, 0, b.length);
    }

    // 将“字节流的数据写入到字节数组b中”
    // off是“字节数组b的偏移地址”，表示从数组b的off开始写入数据
    // len是“写入的字节长度”
    @Override
    public int read(byte b[], int off, int len) {
        if (null == b) {
            throw new NullPointerException();
        } else if (off < 0 || len < 0 || len > b.length - off) {
            throw new IndexOutOfBoundsException();
        }
        if (pos >= count) {
            return -1;
        }
        int avail = count - pos;
        if (len > avail) {
            len = avail;
        }
        if (len <= 0) {
            return 0;
        }
        System.arraycopy(buf, pos, b, off, len);
        pos += len;
        return len;
    }

    // 跳过“字节流”中的n个字节。
    @Override
    public long skip(long n) {
        long k = count - pos;
        if (n < k) {
            k = n < 0 ? 0 : n;
        }
        pos += k;
        return k;
    }

    // “能否读取字节流的下一个字节”
    @Override
    public int available() {
        return count - pos;
    }

    // 是否支持“标签”
    @Override
    public boolean markSupported() {
        return true;
    }

    // 保存当前位置。readAheadLimit在此处没有任何实际意义
    @Override
    public void mark(int readAheadLimit) {
        mark = pos;
    }

    // 重置“字节流的读取索引”为“mark所标记的位置”
    @Override
    public void reset() {
        pos = mark;
    }

    @Override
    public void close() {
        release();
    }







    @Override
    public byte[] buffer() {
        return buf;
    }

    @Override
    public int buffer_length() {
        // TODO: Implement this method
        return buf.length;
    }

    @Override
    public void buffer(byte[] newBuff, int size) {
        // TODO: Implement this method
        this.buf = null == newBuff ? Finals.EMPTY_BYTE_ARRAY : newBuff;
        this.buffer_length(size);
    }

    @Override
    public void buffer_length(int size) throws ArrayIndexOutOfBoundsException {
        if (size > buf.length) {
            throw new ArrayIndexOutOfBoundsException("arrayLen=" + buf.length + ", setLen=" + size);
        }
        count = size;
    }



    @Override
    public void seekIndex(int index) {
        if (!(index > -1 && index <= count)) {
            throw new ArrayIndexOutOfBoundsException("can't set pos index=" + index + " length=" + count);
        }
        pos = index;
    }

    @Override
    public int getIndex() {
        return pos;
    }


    public int size() {
        return count;
    }



    @Override
    public boolean release() {
        this.buffer(null, 0);
        this.separatorIndex = SEPARATOR_INDEX_UNSET;
        this.separators = null;
        return true;
    }
    @Override
    public boolean released() {
        return  (null == buf || buf.length == 0) &&
                (null == separators && separatorIndex == SEPARATOR_INDEX_UNSET);
    }









    public boolean hasNext() {
        return (count - pos) > 0;
    }
    public boolean hasNext(int pos) {
        return (count - pos) > 0;
    }

    public static final int SEPARATOR_INDEX_UNSET = -1;

    private byte[][] separators;
    private int separatorIndex = SEPARATOR_INDEX_UNSET;




    public void sortSeparators() {
        sortSeparators(this.separators);
    }
    public static void sortSeparators(byte[][] separators) {
        if (null == separators)
            return;
        Arrays.sort(separators, new Comparator<byte[]>() {
            @Override
            public int compare(byte[] o1, byte[] o2) {
                return Integer.compare(o2.length, o1.length);
            }
        });
    }

    /**
     * you need to sort manually, and it is [max length,..., min length]
     */
    @Tips("you need to sort manually, and it is [max length,..., min length]")
    public void setSeparators(byte[][] separators) {
        this.separators = separators;
    }

    public int getSeparatorsCount() {
        return this.separators.length;
    }
    public byte[][] getSeparators() {
        return this.separators;
    }


    public void setSeparatorsAndSort(String... separators) {
        List<byte[]> buff = new ArrayList<>();
        for (String s: separators) {
            if (null == s)
                continue;
            byte[] chars = s.getBytes();
            if (chars.length == 0)
                continue;
            buff.add(chars);
        }
        this.separators = buff.toArray(new byte[][]{});
        this.sortSeparators();
    }
    public void setSeparatorsAndSort(byte[]... separators) {
        List<byte[]> buff = new ArrayList<>();
        for (byte[] s: separators) {
            if (null == s)
                continue;
            byte[] chars = s.clone();
            if (chars.length == 0)
                continue;
            buff.add(chars);
        }
        this.separators = buff.toArray(new byte[][]{});
        this.sortSeparators();
    }
    public void addSeparatorsAndSort(byte[]... separators) {
        List<byte[]> buff = new ArrayList<>();
        if (null != this.separators)
            buff.addAll(Arrays.asList(this.separators));
        for (byte[] s: separators) {
            if (null == s)
                continue;
            byte[] chars = s.clone();
            if (chars.length == 0)
                continue;
            buff.add(chars);
        }
        this.separators = buff.toArray(new byte[][]{});
        this.sortSeparators();
    }





    /**
     * 如果最后一次next返回的是分隔符 则return >= 0
     */
    public boolean lastIsReadReadSeparator(){
        return SEPARATOR_INDEX_UNSET != this.separatorIndex;
    }
    public int lastReadSeparatorIndex() {
        return this.separatorIndex;
    }
    public void lastReadSeparatorIndexReset() {
        this.separatorIndex = SEPARATOR_INDEX_UNSET;
    }
    public byte[] lastReadSeparator() {
        return separatorIndex == SEPARATOR_INDEX_UNSET ? null: separators[separatorIndex];
    }

    /**
     * 返回分隔符 或者分隔符之前的内容
     */
    public byte[] readNext() {
        this.separatorIndex = SEPARATOR_INDEX_UNSET;

        if (this.pos >= this.count) {
            return null;
        }

        int endIndex = this.count;
        int offIndex = this.pos;
        byte[] data = this.buf;

        int len = endIndex - offIndex;
        int lastIndex = this.pos;
        for (int ii = 0; ii < len; ii++) {
            byte b1 = data[offIndex + ii];

            for (int ii2 = 0; ii2 < separators.length; ii2++) {
                if (separators[ii2][0] == b1 && (offIndex + ii + separators[ii2].length) <= endIndex) {
                    int j = 1;
                    for (int ii3 = 1; ii3 < separators[ii2].length; ii3++) {
                        if (separators[ii2][ii3] == data[offIndex + ii + ii3]) {
                            j++;
                        } else break;
                    }
                    if (j == separators[ii2].length) {
                        if (ii == 0) { // is separator
                            this.separatorIndex = ii2;

                            int et = offIndex + separators[ii2].length;
                            byte[] array = separators[ii2].clone();

                            lastIndex = et;
                            this.pos = lastIndex;
                            return array;
                        } else {
                            int st = lastIndex;
                            int et = offIndex + ii;
                            int l = et - st;
                            byte[] array = new byte[l];
                            System.arraycopy(data, st, array, 0, array.length);

                            lastIndex = et;
                            ii -= 1;// for (offset for self-increment)

                            this.pos = lastIndex;
                            return array;
                        }
                    }
                }
            }
        }

        if (lastIndex != endIndex) {
            int st = lastIndex;
            int et = endIndex;
            // System.out.println(st + "," + et);
            int l = et - st;
            byte[] array = new byte[l];
            System.arraycopy(data, st, array, 0, array.length);
            this.pos = endIndex;
            return array;
        } else {
            return null;
        }
    }


    public byte[] getBuffer(int index, int len) {
        if (len <= 0)
            return Finals.EMPTY_BYTE_ARRAY;

        byte[] arr = new byte[len];
        System.arraycopy(this.buf, index, arr, 0, len);
        return arr;
    }
    public byte[] getBuffer(int len) {
        return getBuffer(this.pos, len);
    }

    public byte[] subBuffer(int startIndex, int end) {
        int len = end - startIndex;
        if (len <= 0)
            return Finals.EMPTY_BYTE_ARRAY;

        return getBuffer(startIndex, len);
    }

    public void getBuffer(int startIndex, byte[] to, int toIndex, int len) {
        System.arraycopy(this.buf, startIndex, to, toIndex, len);
    }
}

