package top.fols.box.reflect.re;

import top.fols.atri.lang.Classz;
import top.fols.atri.lang.Finals;
import top.fols.atri.util.annotation.NotException;

import static top.fols.box.reflect.re.Re_Class.Safes.*;
import static top.fols.box.reflect.re.Re_Class.SafesRe.createInstance;

/**
 * 快速的匿名访问
 * 应该直接
 */
public class Rez {
    static final Re_Class CLASS_EXCEPTION = Re_ZPrimitiveClass_exception.reclass;
    static final Re_Class CLASS_OBJECT    = Re_ZPrimitiveClass_object.reclass;
    static final Re_Class CLASS_LIST      = Re_ZPrimitiveClass_list.reclass;
    static final Re_Class CLASS_JSON      = Re_ZPrimitiveClass_json.reclass;

    public static class SafesRe {
        public static Re_ClassInstance createInstance_object(Re_Executor executor) throws Throwable {
            return Re_Class.SafesRe.createInstance(executor,
                    CLASS_OBJECT,
                    null, null);
        }
        public static Re_ZPrimitiveClass_list.Instance createInstance_list(Re_Executor executor) throws Throwable {
            Re_ClassInstance instance = createInstance(executor,
                    CLASS_LIST,
                    null, null);
            if (Re_Utilities.isReClassInstance_list(instance)) {
                return (Re_ZPrimitiveClass_list.Instance) instance;
            } else {
                executor.setThrow("new instance type is not supported: " + Classz.getName(instance));
                return null;
            }
        }
        public static Re_ClassInstance createInstance_json(Re_Executor executor) throws Throwable {
            return createInstance(executor,
                    CLASS_JSON,
                    null, null);
        }

    }

    /**
     * 每次访问都会创建一个匿名执行器
     */
    public static class Safes {
        public Re_ClassInstance createInstanceOrThrowEx_object() {
            return newInstanceOrThrowEx(CLASS_OBJECT, Finals.EMPTY_OBJECT_ARRAY);
        }
        @NotException
        public static Re_ZPrimitiveClass_exception.Instance createInstance_exception(Re re,
                String throwReason, Re_NativeStack stack) {
            return Re_Class.Safes.createInstance_exception(re,
                    CLASS_EXCEPTION,
                    throwReason, stack);
        }





        final Re re;

        public Safes(Re temp) {
            this.re = temp;
        }





        public Re_ClassInstance newInstanceOrThrowEx(Re_Class reClass, Object[] arguments) {
            Re_NativeStack stack = re.newStack();
            try {
                return anonymousCreateInstanceOrThrowEx(
                        re, stack,
                        reClass, arguments,
                        null
                );
            } catch (RuntimeException e) {
                throw e;
            } catch (Throwable e) {
                throw new RuntimeException(e);
            }
        }

        public void setClassValueOrThrowEx(Re_Class reClass,
                                           Object key, Object value) {
            Re_NativeStack stack = re.newStack();
            anonymousSetClassValueOrThrowEx(
                    re, stack,
                    reClass,
                    key, value);
        }

        public Object getClassValueOrThrowEx(Re_Class reClass,
                                             Object key) {
            Re_NativeStack stack = re.newStack();
            return anonymousGetInstanceOrClassValueOrThrowEx(
                    re, stack,
                    reClass, null,
                    key);
        }

        public void setInstanceValueOrThrowEx(Re_ClassInstance instance,
                                              Object key, Object value) {
            Re_NativeStack stack = re.newStack();
            anonymousSetInstanceValueOrThrowEx(re, stack,
                    instance,
                    key, value);
        }

        public Object getInstanceValueOrThrowEx(Re_ClassInstance instance,
                                                Object key) {
            Re_NativeStack stack = re.newStack();
            return anonymousGetInstanceOrClassValueOrThrowEx(
                    re, stack,
                    null, instance,
                    key);
        }


        public Re_ClassFunction getFunctionOrThrowEx(Re_Class reClass, Re_ClassInstance instance,
                                            Object key) {
            Re_NativeStack stack = re.newStack();
            return anonymousGetFunctionValueOrThrowEx(re, stack,
                    reClass, instance,
                    key);
        }


        public Object invokeOrThrowEx(Re_Class fromReClassGet, Re_ClassInstance fromReClassInstanceGet,
                                      Object key,
                                      Object[] args) {
            Re_NativeStack stack = re.newStack();
            try {
                return anonymousExecutePointFunctionOrThrowEx(re, stack,
                        fromReClassGet, fromReClassInstanceGet,
                        key, args,
                        null);
            } catch (RuntimeException e) {
                throw e;
            } catch (Throwable e) {
                throw new RuntimeException(e);
            }
        }
        public Object invokeOrThrowEx(Re_ClassFunction function, Object[] args) {
            Re_NativeStack stack = re.newStack();
            try {
                return anonymousExecuteFunctionOrThrowEx(re, stack,
                        function,
                        args, null);
            } catch (RuntimeException e) {
                throw e;
            } catch (Throwable e) {
                throw new RuntimeException(e);
            }
        }

    }





}
