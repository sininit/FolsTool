package top.fols.box.io.cache;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.IdentityHashMap;
import java.util.Map;
import top.fols.atri.io.Streams;
import top.fols.atri.io.file.Filex;
import top.fols.atri.lang.Finals;

public class FileCacheDirectoryAsString extends FileCache {
	private final File directory;
	private final Charset charset;

	public FileCacheDirectoryAsString(String dir, Charset charset) {
		this(Filex.newFileInstance(dir), charset);
	}
	public FileCacheDirectoryAsString(File dir, Charset charset) {
		super(createDirectoryIFileCache(dir));
		
		this.directory = dir;
		this.charset = null == charset ? Finals.Charsets.UTF_8 : charset;
	}
	
	public File getDirectory() {
		return directory;
	}


	static class LastString {
		byte[]  lastBytes;
		
		volatile String  lastContent;
	}
	final Map<FileCache.Cache, LastString> cacheMap = new IdentityHashMap<>();



	public String getCacheStringOrNewString(String path) throws IOException {
		Object  ci = super.openCacheOrInputStream(path);
		if (ci instanceof Cache) {
			Cache cache = (FileCache.Cache) ci;
			LastString  ls = cacheMap.get(cache);
			if (null == ls) {
				return new String(cache.data, charset);
			} else {
				if (ls.lastBytes == cache.data) {
					return ls.lastContent;
				}
				return new String(cache.data, charset);
			}
		} else if (ci instanceof InputStream) {
			byte[] bytes = Streams.toBytes((InputStream)ci);
			return new String(bytes, charset);
		} else {
			return null;
		}
	}


	@Override
	protected void addCacheAfter(FileCache.Cache cache) {
		// TODO: Implement this method
		synchronized (this.cacheMap) {
			LastString newLastString = new LastString();
			newLastString.lastBytes   = cache.data;
			newLastString.lastContent = new String(cache.data, charset);

			cacheMap.put(cache, newLastString);
		}
	}


	@Override
	protected void removeCacheAfter(FileCache.Cache cache) {
		// TODO: Implement this method
		synchronized (this.cacheMap) {
			this.cacheMap.remove(cache);
		}
	}






}
