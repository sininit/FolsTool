package top.fols.atri.util;

import java.io.Serializable;
import java.util.Arrays;
import top.fols.atri.lang.Finals;
import top.fols.atri.util.abstracts.ABitsOptions;

import static top.fols.atri.lang.Arrayz.leftMove;
import static top.fols.atri.lang.Arrayz.rightMove;

//	public static class DigitalRecords extends CycleDigitalRecorder {
//
//		public DigitalRecords(long cycle, int recordCount) {
//			super(cycle, recordCount);
//		}
//
//		long current;
//		@Override
//		public long current() {
//			return current;
//		}
//
//	}
//	public static void test() {
//		 {
//            DigitalRecords recorder = new DigitalRecords(TimeUnit.DAYS.toMillis(1), 7);
//            recorder.addCurrentRecordValue(1);
//            System.out.println(recorder);
//
//
//            recorder.current -= TimeUnit.DAYS.toMillis(1) * 3;
//            recorder.addCurrentRecordValue(2);
//            System.out.println(recorder);
//
//            recorder.current -= TimeUnit.DAYS.toMillis(1) * 2;
//            recorder.addCurrentRecordValue(3);
//            System.out.println(recorder);
//
//
//            recorder.current += TimeUnit.DAYS.toMillis(1) * 1;
//            recorder.addCurrentRecordValue(4);
//            System.out.println(recorder);
//
//
//            recorder.current += TimeUnit.DAYS.toMillis(1) * 5;
//            recorder.addCurrentRecordValue(5);
//            System.out.println(recorder);
//
//
//            recorder.current += TimeUnit.DAYS.toMillis(1) * 1;
//            recorder.addCurrentRecordValue(6);
//            System.out.println(recorder);
//
//            recorder.current -= TimeUnit.DAYS.toMillis(1) * 7;
//            recorder.addCurrentRecordValue(7);
//            System.out.println(recorder);
//
//            recorder.current += TimeUnit.DAYS.toMillis(1) * 7;
//            recorder.addCurrentRecordValue(8);
//            System.out.println(recorder);
//
//            recorder.current += TimeUnit.DAYS.toMillis(1) * 1;
//            recorder.addCurrentRecordValue(9);
//            System.out.println(recorder);
//
//
//            recorder.current -= TimeUnit.DAYS.toMillis(1) * 1;
//            recorder.addCurrentRecordValue(10);
//            System.out.println(recorder);
//        }
//	}



@SuppressWarnings({"AccessStaticViaInstance", "SameParameterValue", "UnnecessaryLocalVariable"})
public class CycleDigitalRecorder implements Serializable {
	private static final long serialVersionUID = 1L;


	static final int unitSize = ABitsOptions.BIG_ENDIAN.long_byte_length;
	static final int presetCount = 2; //startTime cycle

	public static int calcDataBytesLength(int recordCount) {
		return (presetCount + recordCount) * unitSize;
	}
	public static long[] bytesToLongs(byte[] datas) {
		if (null == datas) {
			return Finals.EMPTY_LONG_ARRAY;
		} else {
			long[] data = new long[datas.length / unitSize];
			for (int i=0;i < data.length;i++) {
				data[i] = ABitsOptions.BIG_ENDIAN.getLong(datas, i * unitSize);
			}
			return data;
		}
	}
	public static byte[] longsToBytes(long[] datas) {
		byte[] data = new byte[datas.length * unitSize];
		for (int i=0;i < datas.length;i++) {
			ABitsOptions.BIG_ENDIAN.putBytes(data, i * unitSize, datas[i]);
		}
		return data;
	}



	static long _getStartTime(long[] data) {
		return data[0];
	}
	static void _setStartTime(long[] data, long v) {
		data[0] = v;
	}
	static long _getCycle(long[] data) {
		return data[1];
	}
	static void _setCycle(long[] data, long v) {
		data[1] = v;
	}
	static long _getRecordValue(long[] data, int RecordIndex) {
		return data[presetCount + RecordIndex];
	}
	static void _setRecordValue(long[] data, int RecordIndex, long record) {
		data[presetCount + RecordIndex] = record;
	}
	static int _getRecordLength(long[] data) {
		return data.length - presetCount;
	}
	static long[] _create(long startTime, long cycle,
						  int recordCount) {

		long[] newData = new long[presetCount + recordCount];
		_setStartTime(newData, startTime);
		_setCycle(newData, cycle);
		return newData;
	}
	static void _reset(long[] data,
					   long startTime, long cycle) {
		_setStartTime(data, startTime);
		_setCycle(data, cycle);

		int length = data.length;
		for (int i = presetCount; i < length; i++) {
			data[i] = 0;
		}
	}
	static long[] _getRecords(long[] loaded) {
		long[] records = new long[_getRecordLength(loaded)];
		for (int i =0; i < records.length; i++) {
			long record = _getRecordValue(loaded, i);
			records[i] = record;
		}
		return records;
	}



	long[] dataCache;
	long   cycle;
	int    recordCount;
	public CycleDigitalRecorder(long cycle, int recordCount) throws IllegalArgumentException {
		this(cycle, recordCount, null);
	}
	public CycleDigitalRecorder(long cycle, int recordCount, long[] dataCache) throws IllegalArgumentException {
		if (recordCount <= 0) {
			throw new IllegalArgumentException("recordCount = 0");
		}

		this.cycle       = cycle;
		this.recordCount = recordCount;
		this.dataCache   = isMatch(dataCache) ? dataCache: _create(this.current(), this.cycle, this.recordCount) ;
	}



	public void   save(long[] serializ) {}


	protected long current() {
		return System.currentTimeMillis();
	}
	protected long[]  getCache()			{ return dataCache;  }
	protected void    setCache(long[] data) throws IllegalArgumentException { 
	    if (isMatch(data)) {
			this.dataCache = data;
		} else {
			throw new IllegalArgumentException("data=" + Arrays.toString(data));
		}
	}
	protected boolean isMatch(long[] data)  {
		return (null != data && data.length > 0 &&
			_getCycle(data) == cycle && 
			_getRecordLength(data) == recordCount);
	}

	public long getCycle()  { return cycle; }
	public int getRecordCount() {
		return recordCount;
	}



	public long getCurrentRecordValue() {
		int recordIndex = this.updateGetIndex();
		long[] data = dataCache;
		return data[presetCount + recordIndex];
	}
	public long getRecordSum() {
		this.updateGetIndex();
		long[] data = dataCache;
		long sum = 0;
		for (int i = 0; i < _getRecordLength(data); i++) {
			sum +=          _getRecordValue(data, i);
		}
		return sum;
	}



	@Deprecated
	public int getCurrentCycleIndex() {
		int    recordIndex  = this.updateGetIndex();
		return recordIndex;
	}
	@Deprecated
	public long getRecordValue(int recordIndex) {
		this.updateGetIndex();
		long[] data = dataCache;
		return data[presetCount + Math.max(0, recordIndex)];
	}


	int updateGetIndex() {
		long[] data = dataCache;
		long startTime   = _getStartTime(data);
		long currentTime = current();
		int recordIndex;
		long cedCount = (currentTime - startTime) / cycle;
		if  (cedCount    >= recordCount) {
			if (cedCount >= recordCount * 2L - 1) {
				_reset(data,
					   currentTime, cycle);
				recordIndex = 0;
			} else {
				int left = (int) (cedCount + 1 - recordCount);
				leftMove(data, presetCount, data.length, left);
				startTime += (left * cycle);
				_setStartTime(data, startTime);
				recordIndex = cedCount > recordCount ? recordCount - 1: (recordCount - left);
			}
			save(this.dataCache = data);
		} else {
			if (cedCount >= 0) {
				recordIndex = (int) cedCount;
			} else {
				int abeCedCount = (int) Math.abs(cedCount);
				if (abeCedCount >= recordCount) {
					_reset(data,
						   currentTime, cycle);
					recordIndex = 0;
				} else {
					int right = (abeCedCount);
					rightMove(data, presetCount, data.length, right);
					startTime -= (right * cycle);
					_setStartTime(data, startTime);
					recordIndex = 0;  //left no data
				}
				save(this.dataCache = data);
			}
		}
		return recordIndex;
	}
	public void setCurrentRecordValue(long v) {
		int recordIndex = this.updateGetIndex();
		long[] data   = dataCache;
		data[presetCount + recordIndex] = v;
		save(this.dataCache = data);
	}
	public void addCurrentRecordValue(long v) {
		int recordIndex = this.updateGetIndex();
		long[] data   = dataCache;
		data[presetCount + recordIndex] += v;
		save(this.dataCache = data);
	}
	public <T> T modifierRecord(Modifier<T> modifier) {
		int recordIndex = this.updateGetIndex();
		long[] data = dataCache;
		T result  = modifier.modifiy(new Records(data), recordIndex);
		save(this.dataCache = data);
		return result;
	}



	public long getStartTime() {
		this.updateGetIndex();
		long[] loaded = dataCache;
		return _getStartTime(loaded);
	}

	public long[] getRecords() {
		this.updateGetIndex();
		long[] loaded = dataCache;
		return _getRecords(loaded);
	}

	@Override
	public String toString() {
		// TODO: Implement this method
		int index = this.updateGetIndex();
		long[] loaded = dataCache;
		return "start=" + _getStartTime(loaded) + ", cycle=" + cycle  + ", data=" + Arrays.toString(_getRecords(loaded)) + ", currentCycleIndex=" + index;
	}




	public static class Records {
		long[] records;
		Records(long[] records) {
			this.records = records;
		}
		public int  length()				    {return _getRecordLength(records);}
		public long get(int index)				{return _getRecordValue(records, index);}
		public void set(int index, long value)  { _setRecordValue(records, index, value);}
	}
	public static interface Modifier<T> {
		public T modifiy(Records record, int recordIndex);
	}
}

