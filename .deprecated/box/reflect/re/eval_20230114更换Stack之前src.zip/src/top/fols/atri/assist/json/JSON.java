/*
 * Copyright (C) 2010 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * origin module @org.json
 */

package top.fols.atri.assist.json;
import top.fols.atri.lang.Arrayz;
import top.fols.atri.lang.Objects;

import java.lang.reflect.Array;
import java.util.*;

@SuppressWarnings({"rawtypes", "unchecked", "ForLoopReplaceableByForEach", "UnusedReturnValue"})
public class JSON {
    /**
     * Returns the input if it is a JSON-permissible tip; throws otherwise.
     */
    static double checkDouble(double d) throws JSONException {
        if (Double.isInfinite(d) || Double.isNaN(d)) {
            throw new JSONException("Forbidden numeric tip: " + d);
        }
        return d;
    }

    static Boolean toBoolean(Object value) throws JSONException {
        if (value instanceof Boolean) {
            return (Boolean) value;
        } else if (value instanceof String) {
            String stringValue = (String) value;
            if ("true".equalsIgnoreCase(stringValue)) {
                return true;
            } else if ("false".equalsIgnoreCase(stringValue)) {
                return false;
            }
        }
        return null;
    }

    static Double toDouble(Object value) throws JSONException {
        if (value instanceof Double) {
            return (Double) value;
        } else if (value instanceof Number) {
            return ((Number) value).doubleValue();
        } else if (value instanceof String) {
            try {
                return Double.valueOf((String) value);
            } catch (NumberFormatException ignored) {}
        }
        return null;
    }

    static Integer toInteger(Object value) throws JSONException {
        if (value instanceof Integer) {
            return (Integer) value;
        } else if (value instanceof Number) {
            return ((Number) value).intValue();
        } else if (value instanceof String) {
            try {
                return (int) Double.parseDouble((String) value);
            } catch (NumberFormatException ignored) {}
        }
        return null;
    }

    static Long toLong(Object value) throws JSONException {
        if (value instanceof Long) {
            return (Long) value;
        } else if (value instanceof Number) {
            return ((Number) value).longValue();
        } else if (value instanceof String) {
            try {
                return (long) Double.parseDouble((String) value);
            } catch (NumberFormatException ignored) {}
        }
        return null;
    }

    static String toString(Object value) throws JSONException {
        if (value instanceof String) {
            return (String) value;
        } else if (value != null) {
            return String.valueOf(value);
        }
        return null;
    }




	












    public static JSONException typeMismatch(Object indexOrName, Object actual,
											 String requiredType) throws JSONException {
        if (actual == null) {
            throw new JSONException("Value at " + indexOrName + " is null.");
        } else {
            throw new JSONException("Value " + actual + " at " + indexOrName
									+ " of type " + actual.getClass().getName()
									+ " cannot be converted to " + requiredType);
        }
    }

    public static JSONException typeMismatch(Object actual, String requiredType)
	throws JSONException {
        if (actual == null) {
            throw new JSONException("Value is null.");
        } else {
            throw new JSONException("Value " + actual
									+ " of type " + actual.getClass().getName()
									+ " cannot be converted to " + requiredType);
        }
    }








    public static JSONObject parseJSONObject(String str) throws JSONException {
        Object object = parseJSON(str);
        if (object instanceof JSONObject) {
            return ((JSONObject) object);
        } else {
            throw JSON.typeMismatch(object, "JSONObject");
        }
    }
    public static JSONArray parseJSONArray(String str) throws JSONException {
        Object object = parseJSON(str);
        if (object instanceof JSONArray) {
            return ((JSONArray) object);
        } else {
            throw JSON.typeMismatch(object, "JSONArray");
        }
    }
    public static Object parseJSON(String str) throws JSONException {
        /*
         * Getting the parser to populate this could get tricky. Instead, just
         * parse to temporary JSONObject and then steal the data from that.
         */
        JSONTokener readFrom = new JSONTokener(str);
        Object object = readFrom.readFirstJSONObject();
        if (object instanceof JSONObject || object instanceof JSONArray) {
            return object;
        } else {
            throw JSON.typeMismatch(object, "JSON");
        }
    }




    public static boolean isJSON(String str) {
        return isJSONObject(str) || isJSONArray(str);
    }
    public static boolean isJSONObject(String str) {
        if (!Objects.empty(str) && (str = str.trim()).length() > 0 && (str.charAt(0) == '{' && str.charAt(str.length() - 1) == '}')) {
            try {
                parseJSONObject(str);
                return true;
            } catch (Throwable ignored) {
            }
        }
        return false;
    }
    public static boolean isJSONArray(String str) {
        if (!Objects.empty(str) && (str = str.trim()).length() > 0 && (str.charAt(0) == '[' && str.charAt(str.length() - 1) == ']')) {
            try {
                parseJSONArray(str);
                return true;
            } catch (Throwable ignored) {
            }
        }
        return false;
    }



    public static JSONObject toJSONObject(Map<String, Object> map) {
        if (null == map) {
            return null;
        }
        JSONObject json = new JSONObject();
        for (Object k: map.keySet()) {
            String  ks = null == k ?null: k.toString();
            Object  v = map.get(k);
            Object  vs = javaObjectToJSON(v);
            json.put(ks, vs);
        }
        return json;
    }
    public static JSONArray toJSONArrayFromArray(Object map) {
        if (null == map) {
            return null;
        }
        JSONArray json = new JSONArray();
        int length = Array.getLength(map);
        for (int i = 0; i < length;i++) {
            Object v = Array.get(map, i);
            Object vs = javaObjectToJSON(v);
            json.put(vs);
        }
        return json;
    }
    public static JSONArray toJSONArray(List map) {
        if (null == map) {
            return null;
        }
        JSONArray json = new JSONArray();
        for (int i = 0; i < map.size();i++) {
            Object   v = map.get(i);
            Object   vs = javaObjectToJSON(v);
            json.put(vs);
        }
        return json;
    }
    public static JSONArray toJSONArray(Iterable map) {
        if (null == map) {
            return null;
        }
        JSONArray json = new JSONArray();
        for (Object v : map) {
            Object vs = javaObjectToJSON(v);
            json.put(vs);
        }
        return json;
    }

    static Object javaObjectToJSON(Object object) {
        if (object instanceof Map) {
            return toJSONObject((Map) object);
        }
        if (object instanceof List) {
            return toJSONArray((List) object);
        }

        if (Arrayz.isArray(object)) {
            return toJSONArrayFromArray(object);
        }
        if (object instanceof Iterable) {
            return toJSONArray((Iterable) object);
        }
        return object;
    }




    static Object JSONToJavaObject(Object object) {
        if (object instanceof JSONObject) {
            return toMap((JSONObject)object);
        } else if (object instanceof JSONArray) {
            return toList((JSONArray)object);
        }
        return object;
    }
    public static Map<String, Object> toMap(JSONObject json) {
        if (null == json) {
            return null;
        }
        Map cloneMap = new LinkedHashMap<>();
        Map<String, Object> inner = json.getInnerMap();
        for (String k:  inner.keySet()) {
            Object  v  = inner.get(k);
            Object  vs = JSONToJavaObject(v);
            cloneMap.put(k, vs);
        }
        return cloneMap;
    }
    public static List<Object> toList(JSONArray json) {
        if (null == json) {
            return null;
        }
        List<Object> cloneMap = new ArrayList<>();
        List<Object> inner = json.getInnerList();
        for (int i = 0; i < inner.size();i++) {
            Object v  = inner.get(i);
            Object vs = JSONToJavaObject(v);
            cloneMap.add(vs);
        }
        return cloneMap;
    }

}
