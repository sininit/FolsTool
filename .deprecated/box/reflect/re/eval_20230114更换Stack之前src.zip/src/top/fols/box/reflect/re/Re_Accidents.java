package top.fols.box.reflect.re;

import top.fols.atri.util.Throwables;
import top.fols.box.reflect.re.interfaces.Re_IReObject;

import java.util.Arrays;

public class Re_Accidents {

	public static String runtime_grammatical_error(Re_CodeLoader.Base[] bases, Re_CodeLoader.Base index) {
		return "runtime grammatical errors [" + index + "], in [" + Re_CodeLoader.Expression.getExpressionAsString(Arrays.asList(bases)) + "]"
				   + ", indexLine["+index.getLine()+"]";
	}


	public static String stack_overflow(long now, long max) {
		return "stack overflow, now==" + now + ", max=" + max;
	}



	public static String reclass_initialized(Re_Class re_class) {
		return "re-class[" + (null == re_class ? null : re_class.getName()) + "]" + " initialized";
	}
	public static String reclass_initialize_failed(Re_Class re_class) {
		return "re-class[" + (null == re_class ? null : re_class.getName()) + "]" + " initialize failed";
	}


	public static String not_found_reclass(String name) {
		return "not found re-class: " + name;
	}




	public static String executor_no_bind_class() {
		return "executor no bind class";
	}
	public static String executor_no_bind_class_instance() {
		return "executor no bind class instance";
	}
	public static String executor_no_bind_class_loader() {
		return "executor no bind class loader";
	}

	public static String cannot_execute(String vName) {
		return vName + " is not a function";
	}

	public static String unable_to_process_parameters(String vName, int count) {
		return vName + " unable to process parameters"
				+ ", paramCount=" + count;
	}



	public static String unsupported_type(String type) {
		return "unsupported type: " + type;
	}


	public static String undefined_object_var(String instanceName, Re_CodeLoader.Base name) {
		return "properties: " + (instanceName + '.' + name)  + " is not defined" +
				", indexLine=" + name.getLine();
	}
	public static String undefined_object_call(String instanceName, Re_CodeLoader.Base name, int paramCount) {
		return "properties: " + (instanceName + '.' + name)  + " is not defined" +
				", paramCount=" + paramCount + ", indexLine="+name.getLine();
	}


	public static String undefined(Re_IReObject reObject, String name) {
		return "properties: " + ((null == reObject ? null : reObject.getName()) + "." + name) + " is not defined";
	}
	public static String undefined(String name) {
		return "properties: " + (name) + " is not defined";
	}


	public static String assignment_to_final_variable(){
		return "assignment to final variable";
	}




	static String typeReOrJava(Object v) {
		return "[" + (Re_Utilities.isIReObject(v) ? "re" : "java") + "]";
	}



	public static class CompileTimeGrammaticalException extends RuntimeException {
		String filePath;
		int line;

		public CompileTimeGrammaticalException(String message, String filePath, int line)  {
			super(message);

			this.filePath = filePath;
			this.line = line;
		}
		public CompileTimeGrammaticalException(String message, String filePath, int line, Throwable cause)  {
			super(message, cause);

			this.filePath = filePath;
			this.line = line;
		}

		public String getFilePath() {
			return filePath;
		}

		public int getLine() {
			return line;
		}
	}

	public static class ExecuteException extends RuntimeException {
		public ExecuteException(String message)  { super(message); }
		public ExecuteException(String message, Throwable cause) {
			super(message, cause);
		}
		public ExecuteException(Throwable cause) {
			super(cause);
		}
	}







	public static class InternalExpressionProcessingException extends RuntimeException {
		public InternalExpressionProcessingException(String message)  { super(message); }
	}
	/**
	 * 没有栈的异常
	 */
	static class RuntimeInternalMathError extends Throwables.EmptyStackException {
		public RuntimeInternalMathError(String message)  { super(message); }
	}















}

