package top.fols.box.reflect.re;

import top.fols.atri.util.annotation.NotNull;

@SuppressWarnings("rawtypes")
public class Re_ZPrimitiveObject_jimportCall extends Re_ZPrimitiveObject_jimport {
    public Re_ZPrimitiveObject_jimportCall(Class<?> type) {
        super(type);
    }


    @Override
    public final boolean containsVariable(Re_Executor executor, Object key) throws Throwable {
        return false;
    }

    @Override
    public final boolean removeVariable(Re_Executor executor, Object key) throws Throwable {
        return false;
    }

    @Override
    public final Object getVariableValue(Re_Executor executor, Object key) throws Throwable {
        return null;
    }

    @Override
    public final void putVariableValue(Re_Executor executor, Object key, Object value) throws Throwable {
    }

    @Override
    public final int getVariableCount(Re_Executor executor) throws Throwable {
        return 0;
    }

    @Override
    public @NotNull final Iterable getVariableKeys(Re_Executor executor) throws Throwable {
        return null;
    }

    @Override
    public final Object executePoint(Re_Executor executor, Object point_key, Re_CodeLoader.Call call) throws Throwable {
        String s = Re_Utilities.toJString(point_key);
        executor.setThrow(Re_Accidents.undefined(this, s));
        return null;
    }


}
