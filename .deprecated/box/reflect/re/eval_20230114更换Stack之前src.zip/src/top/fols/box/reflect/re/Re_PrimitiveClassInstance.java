package top.fols.box.reflect.re;

import top.fols.box.reflect.re.interfaces.Re_IReInnerVariableMap;

public class Re_PrimitiveClassInstance extends Re_ClassInstance {
    protected Re_PrimitiveClassInstance(Re_Class reClass) {
        super(reClass, Re.newPrimitiveObjectVariableMap());
    }
    protected Re_PrimitiveClassInstance(Re_Class reClass, Re_IReInnerVariableMap variableMap) {
        super(reClass, variableMap);
    }


    @Override
    public boolean isPrimitive() {
        return true;
    }
}
