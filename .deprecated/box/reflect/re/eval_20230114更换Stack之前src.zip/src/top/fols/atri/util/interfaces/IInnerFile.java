package top.fols.atri.util.interfaces;

import java.io.File;

public interface IInnerFile {
	public File innerFile();
}
