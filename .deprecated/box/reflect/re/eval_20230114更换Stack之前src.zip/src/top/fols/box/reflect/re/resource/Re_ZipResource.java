package top.fols.box.reflect.re.resource;

import java.io.*;
import java.nio.charset.Charset;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import top.fols.atri.io.Streams;
import top.fols.atri.io.file.Filex;
import top.fols.atri.lang.Finals;
import top.fols.atri.lang.Objects;
import top.fols.box.reflect.re.Re_ClassLoader;

/**
 * .
 * .. 
 */
@SuppressWarnings({"UnnecessaryLocalVariable", "SpellCheckingInspection"})
public class Re_ZipResource implements Closeable, Re_IResource {
	static final char   SEPARATOR  = '/';
	static final String SEPARATORS = "" + SEPARATOR;

	static final String ROOT_DIRECTORY = "";


	File    file;
	String  base;
	Charset zfilecharset;
	ZipFile zfile;



	public Re_ZipResource(File zip) {
		this(zip, null);
	}
	public Re_ZipResource(File zip,
						  String innerBaseDirectory) {
		this(zip, null, innerBaseDirectory);
	}
	public Re_ZipResource(File zip, Charset zipCharset,
						  String innerBaseDirectory) {
		try {
			this.file    = zip;
			this.base    = Objects.empty(innerBaseDirectory) ? ROOT_DIRECTORY : formatPath(innerBaseDirectory, false);
			this.zfilecharset = null == zipCharset ? Finals.Charsets.UTF_8: zipCharset;

			this.zfile  = new ZipFile(this.file, ZipFile.OPEN_READ, this.zfilecharset);
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}



	public static boolean pathIsFile(String path) {
		return !pathIsDirectory(path);
	}
	public static boolean pathIsDirectory(String path) {
		return  path.endsWith(SEPARATORS);
	}

	public static String formatPath(String path, Boolean isFile) {
		path = Filex.toFileSystemSeparator(path, SEPARATOR);
		path = Filex.normalizePath(path, SEPARATOR);

		if (path.startsWith(SEPARATORS)) {
			path = path.substring(SEPARATORS.length(), path.length());
		}

		if (path.length() == 0)
			throw new UnsupportedOperationException("empty file name");

		if (pathIsFile(path)) {
			if (isFile == null) return path;
			if (isFile)
				return path;
			else
				return path + SEPARATORS;
		} else {
			if (isFile == null) return path;
			if (isFile)
				return path.substring(0, path.length() - SEPARATORS.length());
			else
				return path;
		}
	}
	protected static String formatPath(String subpath) {
		subpath = Filex.toFileSystemSeparator(subpath, SEPARATOR);
		subpath = Filex.normalizePath(subpath, SEPARATOR);

		if (subpath.startsWith(SEPARATORS)) {
			subpath = subpath.substring(SEPARATORS.length(), subpath.length());
		}

//		if (subpath.length() == 0)
//			throw new UnsupportedOperationException("empty file name");

		return subpath;
	}
	protected String formatSubPath(String subpath) {
		String f = base + formatPath(subpath);
		return f;
	}





	public String getAbsolutePath(String subpath) {
		String p = formatSubPath(subpath);
		return p;
	}

	public String getBaseDirectory() {
		return base;
	}

	public Charset getCharset() {
	    return this.zfilecharset;
	}

	@Override
	public void close() {
		// TODO: Implement this method
		Streams.close(this.zfile);
	}

	public ZipEntry getEntry(String subpath) {
		String s       = getAbsolutePath(subpath);
		return zfile.getEntry(s);
	}
	public boolean exists(String subpath) {
		return null  != getEntry(subpath);
	}
	public InputStream getInputStream(ZipEntry entry) {
		if (null == entry) {
			return null;
		}
		try {
			return zfile.getInputStream(entry);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public Enumeration<? extends ZipEntry> entries() {
		return zfile.entries();
	}

	Map<String, Set<String>> files;
	@SuppressWarnings("unchecked")
	Map<String, Set<String>> loadFiles() {
		if (null == files) {
			Map<String, Set<String>> loads = new HashMap<>();
			Enumeration<ZipEntry> enums = (Enumeration<ZipEntry>) entries();
			while (enums.hasMoreElements()) {
				ZipEntry entry    = enums.nextElement();
				String originPath = entry.getName();
				String subPath = formatPath(originPath);
				if (subPath.startsWith(base)) {
					subPath = subPath.substring(base.length(), subPath.length());
					String parent = Filex.getParent(subPath);
					if (null == parent) {
						parent = ROOT_DIRECTORY;
					}

					Set<String> sf = loads.get(parent);
					if (null == sf) {
						loads.put(parent, sf = new HashSet<>());
					}

					if (!Objects.empty(subPath)) {
						sf.add(subPath);
					}

				}
			}

			this.files = loads;
		}
		return this.files;
	}

	public String[] listFilePaths(String dir) {
		String d = formatPath(dir);
		Set<String>    s = loadFiles().get(d);
		return null == s ? 
			Finals.EMPTY_STRING_ARRAY:
			s.toArray(Finals.EMPTY_STRING_ARRAY);
	}
	public String[] listRootPaths() {
		return listFilePaths(ROOT_DIRECTORY);
	}



	
	Charset contentCharset = DEFAULT_CONTENT_CHARSET;
	public void contentCharset(Charset charset) {
		this.contentCharset   = null == charset ?DEFAULT_CONTENT_CHARSET: charset;
	}
	@Override
	public Charset contentCharset() {
		// TODO: Implement this method
		return contentCharset;
	}

	@Override
	public Re_IResourceFile getFileResource(String relativePath) {
		// TODO: Implement this method
		String absolutePath = getAbsolutePath(relativePath);
		ZipEntry entry = zfile.getEntry(absolutePath);
		if (null == entry) {
			return null;
		}
		return new Re_ZipResourceFile(this,
				relativePath,
				absolutePath, relativePath,
				contentCharset);
	}
	@Override
	public Long getFileSize(String relativePath) {
		String absolutePath = getAbsolutePath(relativePath);
		ZipEntry entry = zfile.getEntry(absolutePath);
		if (null == entry) {
			return null;
		}
		return entry.getSize();
	}
	@Override
	public Long getFileLastModified(String relativePath) {
		String absolutePath = getAbsolutePath(relativePath);
		ZipEntry entry = zfile.getEntry(absolutePath);
		if (null == entry) {
			return null;
		}
		return entry.getTime();
	}
	@Override
	public InputStream getFileInputStream(String relativePath) {
		String absolutePath = getAbsolutePath(relativePath);
		ZipEntry entry = zfile.getEntry(absolutePath);
		if (null == entry) {
			return null;
		}
		return getInputStream(entry);
	}



	@Override
	public Re_IResourceFile findClassResource(String className) {
		// TODO: Implement this method
		String relativePath = Re_ClassLoader.classNameToPath(className);
		String absolutePath = getAbsolutePath(relativePath);
		ZipEntry entry = zfile.getEntry(absolutePath);
		if (null == entry) {
			return null;
		}
		return new Re_ZipResourceFile(this,
				className,
				absolutePath, relativePath,
				contentCharset);
	}

	
	
	public static class Re_ZipResourceFile implements Re_IResourceFile {
		Re_ZipResource resource;

		String name;
		String absolutePath;
		String relativePath;
		Charset charset;

		Re_ZipResourceFile(
			Re_ZipResource resource,
			String name, 
			String absolutePath,  String path,
			Charset charset) {

			this.resource = resource;

			this.name = name;
			this.absolutePath = absolutePath;
			this.relativePath = path;
			this.charset = charset;
		}

		@Override
		public String name() {
			return name;
		}


		@Override
		public String  absolutePath() {
			return absolutePath;
		}
		@Override
		public String  path() {
			return relativePath;
		}

		@Override
		public Charset charset() {
			return charset;
		}



		ZipEntry getEntry(){ return resource.zfile.getEntry(absolutePath); }
		@Override
		public InputStream asStream() {
			ZipEntry entry = getEntry();
			return null == entry ? null : resource.getInputStream(entry);
		}

		@Override
		public byte[] asBytes() {
			InputStream s = asStream();
			try {
				return Streams.toBytes(s);
			} catch (Throwable e) {
				throw new RuntimeException(e);
			} finally {
				Streams.close(s);
			}
		}
		@Override
		public String asString() {
			return new String(asBytes(), charset());
		}


		@Override
		public String toString() {
			return this.name;
		}
	}
	
}
