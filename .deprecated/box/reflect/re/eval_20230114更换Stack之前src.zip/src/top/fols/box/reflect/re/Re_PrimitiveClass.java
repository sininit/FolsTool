package top.fols.box.reflect.re;

public class Re_PrimitiveClass extends Re_Class {
    protected Re_PrimitiveClass(String className) {
        this(className, null, null);
    }
    protected Re_PrimitiveClass(String className, InitBefore initBefore) {
        this(className, initBefore, null);
    }
    protected Re_PrimitiveClass(String className, InitBefore initBefore,
                                Re_Class reDeclaringClass) {
        Re_CodeFile block = new Re_CodeFile();
        block.lineOffset         = Re_CodeFile.LINE_OFFSET;
        block.filePath           = getClass().getName();
        block.expressions        = Re_CodeLoader.Base.EMPTY_EXPRESSION;

        Re_Class.createAfter(this, null, className, block, reDeclaringClass);
        if (null != initBefore) {
            initBefore.init(this);
        }
        Re_Class.setPrimitiveClassInitialized(this);
    }



    @SuppressWarnings({"UnnecessaryModifier", "UnnecessaryInterfaceModifier"})
    public static interface InitBefore {
        public void init(Re_PrimitiveClass thatClass);
    }


    @Override
    public boolean isPrimitive() {
        return true;
    }




    @Override
    protected Re_PrimitiveClassInstance newUndefinedInstance(Re_Class reClass) {
        return new Re_PrimitiveClassInstance(reClass);
    }



}
