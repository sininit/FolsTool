package top.fols.box.reflect.re;


public class Re_PrimitiveClassFunction extends Re_ClassFunction {
    public Re_PrimitiveClassFunction(String name,
                                     Re_Class declaringReClass, Re_ClassInstance declaringReClassInstance) {
        this(name,null,
                declaringReClass, declaringReClassInstance);
    }
    public Re_PrimitiveClassFunction(String name, String[] param,
                                     Re_Class declaringReClass, Re_ClassInstance declaringReClassInstance) {
        Re_CodeFile block = new Re_CodeFile();
        block.lineOffset         = Re_CodeFile.LINE_OFFSET;
        block.filePath           = getClass().getName();
        block.expressions        = Re_CodeLoader.Base.EMPTY_EXPRESSION;

        Re_ClassFunction.createReCassFunctionNoModifierAfter(this, block,
                name, param, null,
                declaringReClass, declaringReClassInstance);
    }


    @Override
    public final boolean isPrimitive() {
        return true;
    }

}
