package top.fols.atri.io.file;

import java.io.*;
import java.nio.charset.Charset;
import java.text.Collator;
import java.util.*;

import top.fols.box.io.buffer.ByteBufferLinesInputStream;
import top.fols.box.io.buffer.CharBufferLinesReader;
import top.fols.atri.io.Streams;
import top.fols.atri.lang.Finals;
import top.fols.atri.lang.Mathz;
import top.fols.atri.lang.Objects;
import top.fols.box.util.TabPrint;
import top.fols.atri.util.interfaces.IInnerFile;
import top.fols.box.util.encode.ByteEncoders;

@SuppressWarnings({"SpellCheckingInspection", "StatementWithEmptyBody"})
public class Filez implements IInnerFile {
	public static final File[] EMPTY_FILE_ARRAY = {};


	public static Filez RUN  = new Filez(Filex.NAME_CURRENT_DIRECTORY_STRING);
	public static Filez RUN_CANONICAL  = RUN.getCanonical();

	public static Filez TEMP = new Filez(System.getProperty(Finals.Property.JAVA_IO_TEMPDIR, ""));
	public static Filez TEMP_CANONICAL = TEMP.getCanonical();



	public static Filez absolute(Object path) {
		return new Filez(Filex.getCanonicalRelativePath(Filex.toPath(path)));
	}
	public static Filez wrap(Object path) {
		return new Filez(path);
	}



	private final File fileOrDirectory;


	/**
	 * no check
	 */
	public Filez(Object path) {
		this.fileOrDirectory = Objects.requireNonNull(Filex.toFile(path), "path");
	}
	public Filez(Filez path) {
		this.fileOrDirectory = Objects.requireNonNull(path, "path").fileOrDirectory;
		this.canonical     = path.canonical;
	}



	@Override
	public File innerFile() {
		return this.fileOrDirectory;
	}
	public String getPath() {
		return this.fileOrDirectory.getPath();
	}




	private transient String  canonicalPath;
	private transient boolean canonical;

	public String getCanonicalPath() {
		String path = this.canonicalPath;
		if (null ==      path) {
			if (isCanonical()) {
				//路径经过了格式化又创建为了File 实际上它获取到的路径可能已经改变了
				path = this.fileOrDirectory.getPath();
				if (!path.startsWith(Filex.system_separators)) {
					 path = Filex.system_separators + path;
				}
			} else {
				path = getCanonicalPath(this.fileOrDirectory);
			}
			this.canonicalPath = path;
		}
		return path;
	}



	/**
	 * absolutely path
	 */
	public static String getCanonicalPath(Object path) {
		File file = Filex.toFile(path);
		if (null == file) {
			return null;
		} else if (path instanceof Filez) {
			return ((Filez)path).getCanonicalPath();
		} else {
			String paths = new File(Filex.getCanonicalRelativePath(
					Filex.toLocalCanonicalPath(file), true, Filex.system_separator)).getPath();
			if (!paths.startsWith(Filex.system_separators)) {
				 paths = Filex.system_separators + paths;
			}
			return paths;
		}
	}
	public String getCanonicalPath(char separator) {
		String path = this.getCanonicalPath();
		if (separator == Filex.system_separator) {
			return path;
		} else {
			return path.replace(Filex.system_separator, separator);
		}
	}
	public Filez getCanonical() {
		if (this.canonical) {
			return this;
		} else {
			String path = this.getCanonicalPath();
			Filez  instance;
			instance = new Filez(path);
			instance.canonical = true;
			return instance;
		}
	}
	//localCanonical
	public boolean isCanonical() {
		return this.canonical;
	}



	public Filez getParent() {
		String filePath = this.getParentPath();
		File p = null == filePath ?null: new File(filePath);
		if (null == p) {
			return null;
		} else {
			Filez  instance;
			instance = new Filez(p);
			instance.canonical = this.canonical;
			return instance;
		}
	}

	public String getParentPath() {
		return Filex.getParent(this.getPath());
	}

	public String getName() {
		return Filex.getName(this.getPath());
	}

	public String getExtensionName() {
		return Filex.getExtensionName(this.getPath());
	}

	public String getNameNoExtension() {
		return Filex.getNameNoExtension(this.getPath());
	}











	@Override
	public Filez clone() {
		// TODO: Implement this method
		try {
			Filez  instance = (Filez) super.clone();
			return instance;
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException(e);
		}
	}



	@Override
	public int hashCode() {
		// TODO: Implement this method
		return this.getCanonicalPath().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		// TODO: Implement this method
		if (null == obj) { return false; }
		if (obj instanceof Filez) {
			Filez fz = (Filez) obj;
			return Objects.equals(getPath(), fz.getPath()) || Objects.equals(getCanonicalPath(), fz.getCanonicalPath());
		}
		return false;
	}






	@Override
	public String toString() {
		// TODO: Implement this method
		return this.getPath();
	}


	/**
	 * @return 判断是否是本地文件
	 */
	public boolean isFile() {
		return Filex.isFile(this);
	}
	/**
	 * @return 判断是否是本地目录
	 */
	public boolean isDirectory() {
		return Filex.isDir(this);
	}




	/**
	 * @return 判断是否是本地存在
	 */
	public boolean exists() {
		return Filex.exists(this);
	}
	/**
	 * 会检测名称的规范性 不能出现指向 父目录等， 有什么用我也不知道，但是我觉得有用
	 * @see Filex#pathCheck
	 */
	public boolean exists(String name) {
		return Filex.exists(new File(innerFile(), name));
	}

	public boolean createsFile() {
		return Filex.createsFile(this);
	}
	/**
	 * 会检测名称的规范性 不能出现指向 父目录等， 有什么用我也不知道，但是我觉得有用
	 * @see Filex#pathCheck
	 */
	public Filez   createsFile(String name) {
		File file = new File(this.innerFile(), name);
		Filex.createsFile(file);
		Filez  files;
		files = new Filez(file);
		files.canonical = Filex.pathChecked(name) && this.canonical;
		return files;
	}

	public boolean createsDir() {
		return Filex.createsDir(this);
	}
	/**
	 * 会检测名称的规范性 不能出现指向 父目录等， 有什么用我也不知道，但是我觉得有用
	 * @see Filex#pathCheck
	 */
	public Filez   createsDir(String name) {
		File file = new File(this.innerFile(), name);
		Filex.createsDir(file);
		Filez  files;
		files = new Filez(file);
		files.canonical = Filex.pathChecked(name) && this.canonical;
		return files;
	}


	public File file(String name) {
		File   file = new File(this.innerFile(), name);
		return file;
	}
	/**
	 * 会检测名称的规范性 不能出现指向 父目录等， 有什么用我也不知道，但是我觉得有用
	 * @see Filex#pathCheck
	 */
	public Filez files(String name) {
		File   file = this.file(name);
		Filez  filez;
		filez = new Filez(file);
		filez.canonical = this.canonical;
		return filez;
	}


	/**
	 * @param name 将格式化子路径， 格式化后不会再出现 .. .等
	 */
	public File subfile(String name) {
		return new File(this.innerFile(), Filex.getCanonicalRelativePath(name, Filex.system_separator));
	}
	/**
	 * @param name 将格式化子路径， 格式化后不会再出现 .. .等
	 */
	public Filez subfiles(String name) {
		File   file = this.subfile(name);
		Filez  filez;
		filez = new Filez(file);
		filez.canonical = this.canonical;
		return filez;
	}





	public String[] listNames() {
		String[] names = this.fileOrDirectory.list();
		return   names;
	}
	public Filez[]  listFiles() {
		String[] names = this.fileOrDirectory.list();
		if (null == names) {
			return null;
		}
		Filez[] list = new Filez[names.length];
		for (int i = 0; i < names.length; i++) {
			// On some file systems,
			// the file separator of another system can be used as the file name. . . so.  no  use {new File}
			list[i] = new Filez(new File(getPath(), names[i]));
			list[i].canonical = this.canonical;
		}
		return list;
	}






	/**
	 * 会检测名称的规范性 不能出现指向 父目录等，也不能出现分隔符 有什么用我也不知道，但是我觉得有用
	 * @see Filex#pathCheck
	 */
	public boolean refilename(String name) {
		Filex.nameCheck(name);
		String parent = getParentPath();
		File   file = null == parent?new File(name):new File(parent, name);
		return innerFile().renameTo(file);
	}
	public boolean reparent(String directory) {
		String name = getName();
		File   file = null == directory?new File(name):new File(directory, name);
		return innerFile().renameTo(file);
	}
	public boolean renameTo(String path) {
		return innerFile().renameTo(new File(path));
	}



	public Snapshot snapshot() {
		return snapshot(innerFile());
	}
	public static Snapshot snapshot(Object path) {
		File file = Filex.toFile(path);
		return Snapshot.parse(file);
	}


	public boolean delete() {
		return Filex.deletes(this);
	}
	public boolean deleteIfFile() {
		if (this.isFile()) {
			return innerFile().delete();
		}
		return false;
	}
	public boolean deleteIfDirectory() {
		if (this.isDirectory()) {
			return delete();
		}
		return false;
	}




	public int len() {
		return Mathz.toIntExact(length());
	}
	public long length() {
		return this.innerFile().length();
	}


	public FileInputStream  input() throws FileNotFoundException {
		return Filex.forInput(this);
	}
	public FileOutputStream output() throws FileNotFoundException {
		return Filex.forOutput(this);
	}



	public RandomAccessFile randomAccess(String mode) throws FileNotFoundException {
		return new RandomAccessFile(innerFile(), mode);
	}




	public byte[] readBytes() {
		InputStream stream = null;
		try {
			stream = input();
			return Streams.toBytes(stream);
		} catch (IOException e) {
			return null;
		} finally {
			Streams.close(stream);
		}
	}
	public char[] readChars(Charset charset) {
		if (null == charset) {
			throw new NullPointerException("charset");
		}
		byte[] bytes = this.readBytes();
		if (null == bytes) {
			return null;
		} else {
			return ByteEncoders.bytesToChars(bytes, 0, bytes.length, charset);
		}
	}
	public char[] readUTF8() {
		return readChars(Finals.Charsets.UTF_8);
	}
	public String readUTF8Chars() {
		char[] str = readChars(Finals.Charsets.UTF_8);
		return null == str ?null: new String(str);
	}


	public boolean writeUTF8(String data) {
		return writeChars(data, Finals.Charsets.UTF_8);
	}
	public boolean writeUTF8(char[] data) {
		return writeChars(data, Finals.Charsets.UTF_8);
	}
	public boolean writeChars(CharSequence data, Charset charset) {
		if (null == data) {
			throw new NullPointerException("data");
		}
		return writeChars(data, 0, data.length(), charset);
	}
	public boolean writeChars(char[] data, Charset charset) {
		if (null == data) {
			throw new NullPointerException("data");
		}
		return writeChars(data, 0, data.length, charset);
	}
	public boolean writeChars(CharSequence data, int off, int len, Charset charset) {
		if (null == data) {
			throw new NullPointerException("data");
		}
		byte[] bytes = ByteEncoders.charsToBytes(data, 0, data.length(), charset);
		return writeBytes(bytes, 0, bytes.length);
	}
	public boolean writeChars(char[] data, int off, int len, Charset charset) {
		if (null == data) {
			throw new NullPointerException("data");
		}
		byte[] bytes = ByteEncoders.charsToBytes(data, 0, data.length, charset);
		return writeBytes(bytes, 0, bytes.length);
	}



	public boolean writeBytes(byte[] data) {
		if (null == data) {
			throw new NullPointerException("bytes");
		}
		return writeBytes(data, 0, data.length);
	}
	public boolean writeBytes(byte[] data, int off, int len) {
		if (null == data) {
			throw new NullPointerException("data");
		}
		OutputStream stream = null;
		try {
			stream = output();
			stream.write(data, off, len);
			stream.flush();

			return true;
		} catch (IOException e) {
			return false;
		} finally {
			Streams.close(stream);
		}
	}


	public CharBufferLinesReader<Reader> lineChars(Charset charset) throws FileNotFoundException {
		Reader reader = new InputStreamReader(input(), charset);
		return new CharBufferLinesReader<>(reader);
	}
	public ByteBufferLinesInputStream<FileInputStream> lineBytes() throws FileNotFoundException {
		return new ByteBufferLinesInputStream<>(input());
	}


	/**
	 * Copy this file to the specified directory
	 *
	 * @param to to
	 */
	public boolean copyTo(Filez to) {
		try {
			return copySubFilesTo(null, to, true);
		} catch (IOException ignored) {
			return false;
		}
	}



	/**
	 * Copy sub files to the specified directory
	 * A snapshot of the list is saved before copying
	 *
	 * @param to to
	 */
	public boolean copySubFilesTo(Filez to) {
		try {
			return copySubFilesTo(Snapshot.parse(this.innerFile()), to, true);
		} catch (IOException ignored) {
			return false;
		}
	}

	/**
	 * Copy sub files to the specified directory
	 * A snapshot of the list is saved before copying
	 *
	 * @param thisList file filter   if this file is Directory
	 * @param to to
	 */
	public boolean copySubFilesTo(Snapshot thisList, Filez to, boolean ignoredIoError) throws IOException {
		return clone0(thisList, to, ignoredIoError);
	}



	private boolean clone0(Snapshot thisList, Filez to, boolean ignoredIoError) throws IOException  {
		if (null == to) {
			throw new NullPointerException("to file");
		}
		if (to.exists()) {
			//throw new IOException("existed: " + file);
		}
		boolean result = true;
		if (this.isFile()) {
			to.createsFile();
			try {
				copyAfterClose(input(), output());
			} catch (IOException e) {
				if (ignoredIoError) {
					result = false;
				} else {
					throw e;
				}
			}
		} else if (this.isDirectory()) {
			to.createsDir();

			if (null != thisList) {
				for (String s : thisList.keySet()) {
					final Filez fromFiles = this.files(s);
					if (thisList.isFile(s)) {
						Filez toFiles;
						toFiles = to.files(s);
						toFiles.createsFile();

						try {
							copyAfterClose(fromFiles.input(), toFiles.output());
						} catch (IOException e) {
							if (ignoredIoError) {
								result = false;
							} else {
								throw e;
							}
						}
					} else {
						result = result & fromFiles.clone0(thisList.getFileList(s), to.files(s), ignoredIoError);
					}
				}
			}
		}
		return result;
	}







	@SuppressWarnings("UnusedReturnValue")
	public static long copyAfterClose(InputStream input, OutputStream output) throws IOException {
		long   copy = Streams.copyFixedLength(input, output, Streams.DEFAULT_BYTE_BUFF_SIZE, Streams.COPY_UNLIMIT_COPYLENGTH, true);
		output.flush();

		Streams.close(input);
		Streams.close(output);

		return copy;
	}

	/**
	 * deep file list
	 */
	@SuppressWarnings({"UnnecessaryLocalVariable"})
	public static class Snapshot implements Serializable {
		static final long serialVersionUID = 42L;

		String name;
		LinkedHashMap<String, Object> fileLinkedHashMap = new LinkedHashMap<>();//thread unsafe

		private Snapshot(String name) {
			this.name = name;
		}


		private void put(String name, File file) {
			if (null == file) { return; }
			fileLinkedHashMap.put(name, file);
		}
		private void put(String name, Snapshot fileList) {
			if (null ==   fileList) { return; }
			fileLinkedHashMap.put(name, fileList);
		}


		public boolean contains(String name) {
			return fileLinkedHashMap.containsKey(name);
		}
		public boolean remove(String name) {
			return null == fileLinkedHashMap.remove(name);
		}


		public static Snapshot parse(File file) {
			if (null == file) {
				throw new NullPointerException("to file");
			}
			return parse0(new Snapshot(file.getName()),  file);
		}
		//递归搜索文件，假设子文件的子文件中存在一个子文件的链接，是否会造成无限死循环？
		private static Snapshot parse0(Snapshot fileList, File file) {
			if (null == file) {
				throw new NullPointerException("to file");
			}
			File[] fs = file.listFiles();
			for (File f: null == fs ?EMPTY_FILE_ARRAY: fs) {
				String name = f.getName();
				if (f.isFile()) {
					fileList.put(name, f);
				} else {
					Snapshot fileL = new Snapshot(name);
					fileList.put(name, fileL);
					parse0(fileL, f);
				}
			}
			return fileList;
		}



		public String   getName() {
			return name;
		}
		public String[] listName() {
			return fileLinkedHashMap.keySet().toArray(Finals.EMPTY_STRING_ARRAY);
		}


		public Set<String> keySet() {
			return fileLinkedHashMap.keySet();
		}

		public Object get(String name) {
			Object object = fileLinkedHashMap.get(name);
			return object;
		}

		public boolean isDirectory(String name) {
			return get(name) instanceof Snapshot;
		}
		public boolean isFile(String name) {
			return get(name) instanceof File;
		}

		public Snapshot getFileList(String name) {
			Object object = get(name);
			if (object instanceof Snapshot) { return (Snapshot) object; }
			return null;
		}
		public File 	getFile(String name) {
			Object object = get(name);
			if (object instanceof File)     { return (File) object;     }
			return null;
		}


		@Override
		public boolean equals(Object o) {
			if (this == o) return true;
			if (!(o instanceof Snapshot)) return false;
			Snapshot snapshot = (Snapshot) o;
			return java.util.Objects.equals(name, snapshot.name) &&
				java.util.Objects.equals(fileLinkedHashMap, snapshot.fileLinkedHashMap);
		}

		@Override
		public int hashCode() {
			return java.util.Objects.hash(name, fileLinkedHashMap);
		}

		@Override
		public String toString() {
			TabPrint tp = new TabPrint();
			tp.tag = name;
			for (Object value: fileLinkedHashMap.values()) {
				if (value instanceof File) {
					value = ((File)value).getName();
				}
				tp.add(value);
			}
			return tp.toString();
		}
	}



	//递归搜索文件，假设子文件的子文件中存在一个子文件的链接，是否会造成无限死循环？
	public static List<String> listRelativeFilePath(String filePath, boolean recursion, boolean addDirectory) {
		List<String> List = new ArrayList<>();
		return listRelativeFilePath0(List, new File(filePath), recursion, addDirectory, new StringBuilder());
	}
	private static List<String> listRelativeFilePath0(List<String> list, File filePath, boolean recursion, boolean adddir,
													  StringBuilder baseDir) {
		File[] files = filePath.listFiles();
		if (null != files) {
			for (File file : files) {
				if (null == file)
					continue;
				String name = file.getName();
				if (file.isDirectory()) {
					if (recursion) {
						listRelativeFilePath0(list, file, true, adddir,
								new StringBuilder(baseDir).append(name).append(File.separator));
					}
					if (adddir) {
						list.add(baseDir + name + File.separator);
					}
				} else {
					list.add(baseDir + name);
				}
			}
		}
		return list;
	}






	public static List<String> listFilesSort(File filePath, boolean adddir) {
		return listFilesSort(filePath.listFiles(), adddir, Locale.getDefault());
	}
	public static List<String> listFilesSort(File[] files, boolean adddir, Locale locale) {
		List<String> d = new ArrayList<>();
		List<String> f = new ArrayList<>();
		if (null != files) {
			for (File file : files) {
				if (null == file) {
					continue;
				}
				String name = file.getName();
				if (file.isDirectory()) {
					if (adddir) {
						d.add(name + File.separator);
					}
				} else {
					f.add(name);
				}
			}
		}
		Collections.sort(d, Collator.getInstance(locale));
		Collections.sort(f, Collator.getInstance(locale));
		if (adddir) {
			d.addAll(f);
			return d;
		} else {
			return f;
		}
	}


}
