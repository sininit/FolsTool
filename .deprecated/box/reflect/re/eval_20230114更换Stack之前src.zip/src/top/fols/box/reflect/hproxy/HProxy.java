package top.fols.box.reflect.hproxy;

import java.io.Serializable;
import java.lang.annotation.Annotation;
import java.lang.reflect.*;
import java.util.*;
import java.util.regex.Pattern;
import top.fols.atri.lang.Classz;
import top.fols.atri.lang.Objects;
import top.fols.atri.reflect.ReflectMatcher;
import top.fols.atri.reflect.Reflects;
import top.fols.atri.reflect.Proxys;
import top.fols.box.util.TabPrint;
import top.fols.box.reflect.re.Re_PrimitiveClassInstance;
import top.fols.box.reflect.re.Re_ZPrimitiveClass_object;


@SuppressWarnings({"rawtypes", "unchecked", "SpellCheckingInspection"})
public class HProxy implements Serializable {
	private static final long serialVersionUID = 1L;

	protected HProxy() {}

	@SuppressWarnings("UnnecessaryModifier")
	public static interface AnnotationExecutor<T extends Annotation> {
		public T cloneAnnotation(T annotation);

		public Integer order(T annotation);

		/**
		 * @param annotation         annotation
		 * @param beProxyObjectClass original object class
		 * @param beProxyObject      original object
		 * @param runMethod          run method
		 * @param originalMethod     original method
		 * @param args               args
		 * @param proxy              proxy
		 * @param result             result
		 */
		public void  execute(T annotation,
							 Class beProxyObjectClass, Object beProxyObject,
							 Method runMethod, Method originalMethod,
							 Object[] args,
							 ObjectProxy proxy,
							 Return result) throws Throwable;
	}







	public static class Return {
		Object value;
		boolean isReturn;
		Throwable ex;

		public Return(Object value) {
			this.value = value;
		}
		public Return() {}


		public void setReturn(Object value) throws IllegalAccessException {
			this.value    = value;
			this.isReturn = true;
			this.ex       = null;
		}
		public Object getReturn() {
			return value;
		}

		public boolean isReturn() {
			return this.isReturn;
		}

		public void setThrowable(Throwable e) {
			this.value = null;
			this.isReturn = false;
			this.ex = e;
		}
		public Throwable getThrowable() {
			return this.ex;
		}
		public boolean isThrow() {
			return null != this.ex;
		}


		@Override
		public String toString() {
			// TODO: Implement this method
			return String.valueOf(value);
		}

		@Override
		public int hashCode() {
			// TODO: Implement this method
			return null == value ?0: value.hashCode();
		}

		@Override
		public boolean equals(Object obj) {
			// TODO: Implement this method
			if (null == obj) return false;
			if (obj == this) return true;
			if (obj instanceof Return) {
				Return r = (Return) obj;
				return Objects.equals(value, r.value);
			}
			return false;
		}
	}






	public <T> T proxyObject(Object proxyObject, Class<T> annotationInterfaceOne) {
		return proxy(null, proxyObject.getClass(), proxyObject, annotationInterfaceOne);
	}
	public <T> T proxyObject(ClassLoader classLoader, Object proxyObject, Class<T> annotationInterfaceOne) {
		return proxy(classLoader, proxyObject.getClass(), proxyObject, annotationInterfaceOne);
	}

	public <O, T> T proxyClass(Class<O> proxyClass, Class<T> annotationInterfaceOne) {
		return proxy(null, proxyClass, null, annotationInterfaceOne);
	}
	public <O, T> T proxyClass(ClassLoader classLoader, Class<O> proxyClass, Class<T> annotationInterfaceOne) {
		return proxy(classLoader, proxyClass, null, annotationInterfaceOne);
	}

	/**
	 *
	 * @param classLoader   in classloader
	 * @param proxyClass    nonnull
	 * @param proxyObject	nullable
	 * @param annotationInterfaceOne	@interface
	 */
	public <O, T> T proxy(ClassLoader classLoader, Class<O> proxyClass, Object proxyObject, Class<T> annotationInterfaceOne) {
		if (null == annotationInterfaceOne)
			throw new NullPointerException("interface");
		if (null == classLoader)
			classLoader = annotationInterfaceOne.getClassLoader();
		if (null == proxyClass)
			throw new NullPointerException("proxy class");
		InvocationHandler invocationHandler  = new ObjectProxy(proxyClass, proxyObject, annotationInterfaceOne);
		Class[] interfaces = {annotationInterfaceOne};
		Object o = Proxys.createProxyClassInstance(classLoader, interfaces, invocationHandler);
		return (T) o;
	}




	public <T> T proxiesObject(Object proxyObject, Class<T> annotationInterfaceOne, Class... interfaces) {
		return proxies(null, proxyObject.getClass(), proxyObject, annotationInterfaceOne, interfaces);
	}
	public <T> T proxiesObject(ClassLoader classLoader, Object proxyObject, Class<T> annotationInterfaceOne, Class... interfaces) {
		return proxies(classLoader, proxyObject.getClass(), proxyObject, annotationInterfaceOne, interfaces);
	}

	public <O, T> T proxiesClass(Class<O> proxyClass, Class<T> annotationInterfaceOne, Class... interfaces) {
		return proxies(null, proxyClass, null, annotationInterfaceOne, interfaces);
	}

	public <O, T> T proxiesClass(ClassLoader classLoader, Class<O> proxyClass, Class<T> annotationInterfaceOne, Class... interfaces) {
		return proxies(classLoader, proxyClass, null, annotationInterfaceOne, interfaces);
	}


	/**
	 *
	 * @param classLoader   in classloader
	 * @param proxyClass    nonnull
	 * @param proxyObject	nullable
	 * @param annotationInterfaceOne	@interface
	 * @param interfaces must contain   annotationInterfaceOne
	 */
	public <O, T> T proxies(ClassLoader classLoader, Class<O> proxyClass, Object proxyObject, Class<T> annotationInterfaceOne, Class... interfaces) {
		if (null == proxyClass)
			throw new NullPointerException("proxy class");
		if (null == annotationInterfaceOne)
			throw new NullPointerException("interface");
		if (null == classLoader)
			classLoader = annotationInterfaceOne.getClassLoader();

		InvocationHandler invocationHandler = new ObjectProxy(proxyClass, proxyObject, annotationInterfaceOne);
		Object o = Proxys.createProxyClassInstance(classLoader, interfaces, invocationHandler);
		if (!annotationInterfaceOne.isAssignableFrom(o.getClass()))
			throw new IllegalArgumentException("interfaces[" + Arrays.toString(interfaces) + "] not assignable: " + annotationInterfaceOne);
		return (T) o;
	}








	protected AnnotationExecutor parseAnnotationExecutorValue(Class<? extends Annotation> annotationClass) {
		Field[] fields = annotationClass.getFields();
		for (Field field : fields) {
			if (field.getType() == AnnotationExecutor.class && Modifier.isStatic(field.getModifiers())) {
				try {
					return (AnnotationExecutor) field.get(null);
				} catch (IllegalAccessException e) {
					throw new RuntimeException(e);
				}
			}
		}
		return null;
	}

	//<Class, One-AnnotationExecutor>
	Map<Class, AnnotationExecutor[]> annotationExecutorHashMap = new HashMap<>();
	protected AnnotationExecutor findAnnotationExecutor(Class<? extends Annotation> annotationClass) {
		AnnotationExecutor[] annotationExecutor = annotationExecutorHashMap.get(annotationClass);
		if (null == annotationExecutor) {
			AnnotationExecutor executor = parseAnnotationExecutorValue(annotationClass);
			if (null == executor) {
				annotationExecutorHashMap.put(annotationClass, annotationExecutor = new AnnotationExecutor[]{});//put null
			} else {
				annotationExecutorHashMap.put(annotationClass, annotationExecutor = new AnnotationExecutor[]{executor});
			}
		}
		return Objects.first(annotationExecutor);
	}
	protected void addAnnotationExecutor(Class<Annotation> annotationClass, AnnotationExecutor executor) {
		annotationExecutorHashMap.put(annotationClass, new AnnotationExecutor[]{executor});
	}
	protected void removeAnnotationExecutor(Class<Annotation> annotationClass, AnnotationExecutor executor) {
		annotationExecutorHashMap.remove(annotationClass);
	}
	protected boolean hasAnnotationExecutor(Class<Annotation> annotationClass) {
		return annotationExecutorHashMap.containsKey(annotationClass);
	}






	protected Return newResult() {
		return new Return();
	}



	public static class InterfaceMapping {
		Class interfaceOne;
		InterfaceMapping(Class interfaceOne) {
			this.interfaceOne = interfaceOne;
		}

		public Class getInterface() {
			return interfaceOne;
		}


        //<method name Pattern, method>
		private final Map<Pattern, Method> methodInterceptorRegexCacheMap = new LinkedHashMap<>();

		//<method name, one-Interceptor-method>
		private final Map<String,  InterceptorMessage[]> methodInterceptorMap = new HashMap<>();
		private static class InterceptorMessage {
			Method target;
			Annotation[] targetAnnotations;
			public InterceptorMessage(Method target, Annotation[] targetAnnotations) {
				this.target = target;
				this.targetAnnotations = targetAnnotations;
			}
			public InterceptorMessage(InterceptorMessage clone) {
				this.target = clone.target;
				this.targetAnnotations = clone.targetAnnotations;
			}

			@Override
			public String toString() {
				// TODO: Implement this method
				return new TabPrint()
					.add("target", target)
					.add("targetAnnotations", Arrays.toString(targetAnnotations))
					.toString();
			}

		}

		public InterceptorMessage findInterceptor(HProxy proxyx, Method originalMethod) {
			String methodName = originalMethod.getName();
			InterceptorMessage[] find = methodInterceptorMap.get(methodName);
			if (null == find) {
				Set<Pattern> set = methodInterceptorRegexCacheMap.keySet();
				synchronized (methodInterceptorMap) {
					for (Pattern s: set) {
						if (s.matcher(methodName).find()) {
							Method pattern = methodInterceptorRegexCacheMap.get(s);
							InterceptorMessage interceptorMessage =
								new InterceptorMessage(pattern, MethodMapping.create(proxyx, this.getInterface(), pattern).targetAnnotations);
							methodInterceptorMap.put(methodName, find = new InterceptorMessage[]{interceptorMessage});
							return Objects.first(find);
						}
					}
					methodInterceptorMap.put(methodName, new InterceptorMessage[]{});//not this method
				}
			}
			return Objects.first(find);
		}




		public static InterfaceMapping create(HProxy proxyx, Class clazz) {
			//interface all method is public
			InterfaceMapping mapping = new InterfaceMapping(clazz);
			if (clazz.isInterface()) {
				Method[] methods = getCurrentInterfaceMethod(clazz);
				if (null != methods && methods.length > 0) {
					TreeMap<Integer, List<RegisterInterceptor>> treeMap = new TreeMap<Integer, List<RegisterInterceptor>>(new Comparator<Integer>() {
							@Override
							public int compare(Integer x, Integer y) {
								return (x < y) ? -1 : ((x.intValue() == y.intValue()) ? 0 : 1);
							}
						});
					Map<RegisterInterceptor, Method> methodMap = new HashMap<>();
					for (Method method : methods) {
						RegisterInterceptor annotation = method.getAnnotation(RegisterInterceptor.class);
						if (null != annotation) {
							String name = annotation.name();
							if (null == name || name.length() == 0) {
								throw new RuntimeException("null interceptor name: " + name + ", " + method);
							}
							Object cacheMethod = mapping.methodInterceptorMap.get(name);
							if (null != cacheMethod) {
								throw new RuntimeException("repeat interceptor: " + name + ", " + cacheMethod);
							}
							int order = annotation.interceptOrder();

							List<RegisterInterceptor> value = treeMap.get(order);
							if (null == value) {
								treeMap.put(order, value = new ArrayList<>());
							}
							value.add(annotation);

							treeMap.put(order, value);
							methodMap.put(annotation, method);
						}
					}
					for (Map.Entry<Integer, List<RegisterInterceptor>> entry : treeMap.entrySet()) {
						List<RegisterInterceptor> value = entry.getValue();
						for (RegisterInterceptor annotation : value) {
							String name = annotation.name();
							Method method = methodMap.get(annotation);
							mapping.methodInterceptorRegexCacheMap.put(Pattern.compile(name), method);
						}
					}
//					System.out.println(TabPrint.wrap(Strings.join(mapping.methodInterceptorMap, "\n")));
				}
				return mapping;
			}
			throw new RuntimeException("not a interface class: " + clazz);
		}

		@Override
		public String toString() {
			TabPrint toString = new TabPrint()
				.add("interface",                this.interfaceOne)
				.add("interceptorRegexCacheMap", this.methodInterceptorRegexCacheMap)
				.add("methodMapping",            this.methodMappingMap);

			TabPrint interceptors = new TabPrint();
			for (String key: this.methodInterceptorMap.keySet()) {
				interceptors.add(key, Objects.first(this.methodInterceptorMap.get(key)));
			}

			toString.add("interceptors", interceptors);

			return toString.toString();
		}




		public static Method[] getCurrentInterfaceMethod(Class myInterface) {
			return myInterface.getDeclaredMethods();
		}

		public static class MethodMapping {
			Method target;
			Annotation[] targetAnnotations;
			InterfaceMapping.InterceptorMessage interceptor;

			boolean isMyInterfaceMethod = false;
			public boolean isMyInterfaceMethod() {
				return this.isMyInterfaceMethod;
			}


			/**
			 * The run method is not necessarily related to my interface
			 */
			public static Method fromInterfaceFindEqualsMethod(Class<?> myInterface, Method runMethod) {
				if (runMethod.getDeclaringClass() == myInterface) {
					return runMethod;
				} else {
					//only current interface method
					Method[] methods = getCurrentInterfaceMethod(myInterface);

					String  runName             = runMethod.getName();
					Class   runReturnType       = runMethod.getReturnType();
					Class[] runMethodParamTypes = runMethod.getParameterTypes();
					for (Method m: methods) {
						if (m.getName().equals(runName)) {
							if (m.getReturnType() == runReturnType) {
								if (Objects.classesEquals(m.getParameterTypes(), runMethodParamTypes)) {
									return m;
								}
							}
						}
					}
					return null;
				}
			}

			/**
			 * The run method is not necessarily related to my interface
			 */
			public static MethodMapping create(HProxy proxyx, Class<?> myInterface, Method runMethod) {
				MethodMapping mapping = new MethodMapping();

				//my interface rewrite method, or  extends other interface method
				Method      myInterfaceMethod = fromInterfaceFindEqualsMethod(myInterface, runMethod);
				if (null == myInterfaceMethod) {
					//other interface method
					mapping.targetAnnotations   = new Annotation[]{};
					mapping.target        = runMethod;
					mapping.isMyInterfaceMethod = false;
					return mapping;
				} else {
					//my interface rewrite method
					Map<Integer, List<Annotation>> treeAnnotations = new TreeMap<Integer, List<Annotation>>(new Comparator<Integer>() {
							@Override
							public int compare(Integer x, Integer y) {
								return (x < y) ? -1 : ((x.intValue() == y.intValue()) ? 0 : 1);
							}
						});
					for (Annotation a: myInterface.getAnnotations()) {
						AnnotationExecutor annotationExecutor = proxyx.findAnnotationExecutor(a.annotationType());
						if (null != annotationExecutor) {
							a = annotationExecutor.cloneAnnotation(a); //cloneExecutor

							Integer order = annotationExecutor.order(a);
							List<Annotation> list = treeAnnotations.get(order);
							if (null == list) {
								treeAnnotations.put(order, list = new ArrayList<>());
							}
							list.add(a);
						}
					}
					for (Annotation a: myInterfaceMethod.getAnnotations()) {
						AnnotationExecutor annotationExecutor = proxyx.findAnnotationExecutor(a.annotationType());
						if (null != annotationExecutor) {
							a = annotationExecutor.cloneAnnotation(a); //cloneExecutor

							Integer order = annotationExecutor.order(a);
							List<Annotation> list = treeAnnotations.get(order);
							if (null == list) {
								treeAnnotations.put(order, list = new ArrayList<>());
							}
							list.add(a);
						}
					}

					List<Annotation> annotations = new ArrayList<>();
					for (List<Annotation> as: treeAnnotations.values()) {
						for (Annotation an: as) {
							annotations.add(an);
						}
					}

					mapping.targetAnnotations   = annotations.toArray(new Annotation[]{});
					mapping.target              = myInterfaceMethod;
					mapping.isMyInterfaceMethod = true;
					return mapping;
				}
			}




			@Override
			public String toString() {
				return new TabPrint()
					.add("targetAnnotations", TabPrint.wrap(targetAnnotations))
					.add("target", target)
					.add("interceptor", interceptor)
					.add("isMyInterface", isMyInterfaceMethod)
					.toString();
			}
		}

		final Map<Method, MethodMapping> methodMappingMap = new HashMap<>();

		/**
		 * @param originalMethod RunMethod is not necessarily in myinterface
		 */
		MethodMapping getMethodMapping(HProxy proxyx, Method originalMethod) {
			MethodMapping mapping = methodMappingMap.get(originalMethod);
			if (null == mapping) {
				synchronized (methodMappingMap) {
					methodMappingMap.put(originalMethod, mapping = MethodMapping.create(proxyx, this.getInterface(), originalMethod));
				}
			}
			return mapping; // no sort
		}
	}

	final Map<Class, InterfaceMapping> interfaceMappingMap = new IdentityHashMap<>();
	InterfaceMapping getInterfaceMapping(Class clazz) {
		if (clazz.isInterface()) {
			InterfaceMapping mapping = interfaceMappingMap.get(clazz);
			if (null == mapping) {
				synchronized (interfaceMappingMap) {
					interfaceMappingMap.put(clazz, mapping = InterfaceMapping.create(this, clazz));
				}
			}
			return mapping;
		}
		throw new RuntimeException("not a interface class: " + clazz);
	}

	@SuppressWarnings("SpellCheckingInspection")
	public class ObjectProxy extends Re_PrimitiveClassInstance implements InvocationHandler, Serializable {
		private static final long serialVersionUID = 1L;

		@Override
		public Object invoke(Object thisObject, Method originalMethod, Object[] params) throws Throwable {
			// TODO: Implement this method
			InterfaceMapping interfaceMapping = getInterfaceMapping(this.getInterface()); //find interface runMethod... weakmap
			InterfaceMapping.MethodMapping methodMapping = interfaceMapping.getMethodMapping(HProxy.this, originalMethod);//map
//			System.out.println("source: " + originalMethod);
//			System.out.println("mapping: " + methodMapping);
//			System.out.println(interfaceMapping);
			Annotation[] runMethodAnnotations = methodMapping.targetAnnotations;
			Method runMethod = methodMapping.target;
			//Query the table at most two
			if (!methodMapping.isMyInterfaceMethod()) {
				if (null == methodMapping.interceptor) {
//					System.out.println("from: " + declaringClass + " " + originalMethod);
					//Methods of the interface are not intercepted
					InterfaceMapping.InterceptorMessage interceptor = interfaceMapping.findInterceptor(HProxy.this, originalMethod);//weakmap
//						System.out.println("interceptor" + interceptor);
					if (null == interceptor) {
						methodMapping.interceptor = new InterfaceMapping.InterceptorMessage(runMethod, runMethodAnnotations); //cache
					} else {
						runMethodAnnotations = interceptor.targetAnnotations;
						runMethod            = interceptor.target;//has interceptor, run interceptor

						//Make weakmap work
						methodMapping.interceptor = new InterfaceMapping.InterceptorMessage(interceptor); //cache
					}
//			        System.out.println("to: " + runMethod);
				} else {
					runMethodAnnotations = methodMapping.interceptor.targetAnnotations;
					runMethod   		 = methodMapping.interceptor.target;//has interceptor, run interceptor
				}
			}
//			System.out.println(originalMethod + " ---> " + runMethod);
			return invoke0(thisObject, runMethodAnnotations, runMethod, originalMethod, params);
		}

		/**
		 * @param runMethodAnnotations		runMethod Annotations
		 */
		public Object invoke0(Object proxyInstance, Annotation[] runMethodAnnotations, Method runMethod, Method originalMethod, Object[] params) throws Throwable {
			if (runMethodAnnotations.length == 0) {
				return invokeObjectEqualsMethod(proxyObjectClass, proxyObject, runMethod, params);
			} else {
				Return ret = newResult();
				for (Annotation annotation : runMethodAnnotations) {
					AnnotationExecutor executor;

					executor = findAnnotationExecutor(annotation.annotationType());//non null
					executor.execute(annotation, proxyObjectClass, proxyObject, runMethod, originalMethod,
									 params, this, ret);
				}
				if (ret.isThrow()) {
					throw ret.getThrowable();
				}
				if (ret.isReturn) {
					//auto transfer
					Class<?> returnType = runMethod.getReturnType();
					Object result = ret.value;
					if (returnType.isInterface()) {
						if (Classz.isInstanceNullable(result, returnType)) {
							return result;
						} else {
							return proxyObject(result, returnType);
						}
					}
					return result;
				} else {
					return invokeObjectEqualsMethod(proxyObjectClass, proxyObject, runMethod, params);
				}
			}
		}







		Class  proxyObjectClass;
		Object proxyObject;
		Class<?> interfaceOne;

		public Class<?> getInterface() {
			return this.interfaceOne;
		}

		public HProxy getProxyz() {
			return HProxy.this;
		}

		public ObjectProxy(Class<?> proxyObjectClass, Object proxyObject, Class<?> interfaceOne) {
			super(Re_ZPrimitiveClass_object.reclass);

			if (null == interfaceOne)
				throw new NullPointerException("interface");

			this.proxyObjectClass = proxyObjectClass;
			this.proxyObject 	  = proxyObject;
			this.interfaceOne     = interfaceOne;
		}
	}




	/**
	 * execute the method with the same object name and parameter name and the same return tip
	 */
	public static Object invokeObjectEqualsMethod(Class proxyObjectClass, Object proxyObject, Method method, Object... params) throws IllegalAccessException, InvocationTargetException, IllegalArgumentException {
		Method find = getObjectEqualsMethod(proxyObjectClass, method);
		return find.invoke(proxyObject, params);
	}
	public static Method getObjectEqualsMethod(Class proxyObjectClass, Method method) {
		String name 		= method.getName();
		Class returnType 	= method.getReturnType();
		Class[] paramTypes  = method.getParameterTypes();
		Method find = Reflects.accessible(Reflects.method(proxyObjectClass, returnType, name, paramTypes));
		if (null == find) {
			throw new RuntimeException(ReflectMatcher.buildNoSuchMatch(proxyObjectClass, Reflects.methods(proxyObjectClass), returnType, name, paramTypes));
		}
		return find;
	}











}


