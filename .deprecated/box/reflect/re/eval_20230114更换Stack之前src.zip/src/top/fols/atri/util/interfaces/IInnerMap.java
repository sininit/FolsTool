package top.fols.atri.util.interfaces;


import java.util.Map;

public interface IInnerMap<K, V> {
    public Map<K, V> getInnerMap();
}
