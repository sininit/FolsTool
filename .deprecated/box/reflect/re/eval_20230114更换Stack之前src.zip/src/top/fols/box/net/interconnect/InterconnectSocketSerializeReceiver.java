package top.fols.box.net.interconnect;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import top.fols.atri.io.Streams;
import top.fols.atri.lang.Objects;

@SuppressWarnings({"rawtypes", "unchecked"})
public abstract class InterconnectSocketSerializeReceiver {
	static byte[] toSerialBytes(Object o) throws IOException {
        return Streams.ObjectTool.toBytes(o);
    }
    static Object toSerialObject(byte[] o) throws IOException, ClassNotFoundException {
        return Streams.ObjectTool.toObject(o);
    }

	@SuppressWarnings("rawtypes")
    static Objects.Call<byte[], InterconnectSocketClient.TakeoverData> NOT_FOUND_TYPE_CALL = new Objects.Call<byte[], InterconnectSocketClient.TakeoverData>() {
        @Override
		public byte[] call(InterconnectSocketClient.TakeoverData param) {
			try {
				return toSerialBytes(new RemoteThrowExceptionWrap(new RuntimeException("not found type receiver: " + param.getType())));
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
	};


	


	public InterconnectSocketClientImpl createClient() {
		return new InterconnectSocketClientImpl(this);
	}
	public static class InterconnectSocketClientImpl extends InterconnectSocketClient {
		InterconnectSocketSerializeReceiver sb;
		public InterconnectSocketClientImpl(InterconnectSocketSerializeReceiver sb) {
			this.sb = sb;
		}


        @Override
        public void onTypeReceiver(String type, final Objects.Call<byte[], InterconnectSocketClient.TakeoverData<InterconnectSocketClient>> call) {
            throw new UnsupportedOperationException("use: " + AServerReply.class);
        }


        Objects.Call<byte[], InterconnectSocketClient.TakeoverData<InterconnectSocketClient>> toCall(final AServerReply serverReply) {
            return new Objects.Call<byte[], InterconnectSocketClient.TakeoverData<InterconnectSocketClient>>() {
                @SuppressWarnings({"unchecked"})
                @Override
                public byte[] call(InterconnectSocketClient.TakeoverData<InterconnectSocketClient> param) {
                    try {
                        Object p = toSerialObject(param.getData());
                        Object r = serverReply.callback(sb, param, p);
                        return toSerialBytes(r);
                    } catch (Throwable e) {
                        try {
                            return toSerialBytes(new RemoteThrowExceptionWrap(e));
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                    }
                }
            };
        }
		
        @Override
        protected Objects.Call<byte[], InterconnectSocketClient.TakeoverData<InterconnectSocketClient>> getTypeReceiver(final String type) {
            AServerReply   serverReply = sb.findServerReply(type);
            return null == serverReply ? (Objects.Call) NOT_FOUND_TYPE_CALL: toCall(serverReply);
        }
    }

	public InterconnectSocketServerImpl createServer() {
		return new InterconnectSocketServerImpl(this);
	}
    public static class InterconnectSocketServerImpl extends InterconnectSocketServer {
        InterconnectSocketSerializeReceiver sb;
		public InterconnectSocketServerImpl(InterconnectSocketSerializeReceiver sb) {
			this.sb = sb;
		}

		@Override
        public void onTypeReceiver(String type, final Objects.Call<byte[], InterconnectSocketClient.TakeoverData<InterconnectSocketServer>> call) {
            throw new UnsupportedOperationException("use: " + AServerReply.class);
        }


        Objects.Call<byte[], InterconnectSocketClient.TakeoverData<InterconnectSocketServer>> toCall(final AServerReply serverReply) {
            return new Objects.Call<byte[], InterconnectSocketClient.TakeoverData<InterconnectSocketServer>>() {
                @SuppressWarnings({"unchecked"})
                @Override
                public byte[] call(InterconnectSocketClient.TakeoverData<InterconnectSocketServer> param) {
                    try {
                        Object p = toSerialObject(param.getData());
                        Object r = serverReply.callback(sb, param, p);
                        return toSerialBytes(r);
                    } catch (Throwable e) {
                        try {
                            return toSerialBytes(new RemoteThrowExceptionWrap(e));
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                    }
                }
            };
        }
		


        @Override
        protected Objects.Call<byte[], InterconnectSocketClient.TakeoverData<InterconnectSocketServer>> getTypeReceiver(final String type) {
            AServerReply   serverReply = sb.findServerReply(type);
            return null == serverReply ? (Objects.Call) NOT_FOUND_TYPE_CALL: toCall(serverReply);
        }
    }


	interface IServerReply<DATA, RET> {
        RET callback(InterconnectSocketSerializeReceiver reply,
                     InterconnectSocketClient.TakeoverData<InterconnectSocketServer> takeoverData, DATA dataObject) throws Throwable;
    }

    public static abstract class AServerReply<DATA extends Serializable, RET extends Serializable>implements Serializable, IServerReply<DATA, RET> {
        private static final long serialVersionUID = -3042686055658047285L;

        public String name() {
            return getClass().getSimpleName();
        }
    }


	protected final Map<String, AServerReply> STRING_SERVER_REPLY_HASH_MAP = new HashMap<>();



    protected <DATA extends Serializable, RET extends Serializable> void addServerReply(AServerReply<DATA, RET> reply) {
        addServerReply(reply.name(), reply);
    }
    protected <DATA extends Serializable, RET extends Serializable> void addServerReply(String type, AServerReply<DATA, RET> reply) {
        STRING_SERVER_REPLY_HASH_MAP.put(type, reply);
    }
	protected void removeServerReply(AServerReply reply) {
        removeServerReply(reply.name());
	}
	protected void removeServerReply(String name) {
		STRING_SERVER_REPLY_HASH_MAP.remove(name);
	}

    protected <DATA extends Serializable, RET extends Serializable> AServerReply<DATA, RET> findServerReply(String name) {
        return STRING_SERVER_REPLY_HASH_MAP.get(name);
    }



	public static class RemoteThrowException extends Exception {
        public RemoteThrowException(Throwable cause) {
            super(cause);
        }
    }
    static class RemoteThrowExceptionWrap implements Serializable {
        private static final long serialVersionUID = -3042686055658047285L;

        Throwable throwable;
        public RemoteThrowExceptionWrap(Throwable throwable) {
            this.throwable = throwable;
        }
    }


	public abstract byte[] sendOriginalData(String target,
											String type, byte[] data);


	public <DATA extends Serializable, RET extends Serializable> RET send(String target, 
																		  AServerReply<DATA, RET> data) throws IOException, ClassNotFoundException, RemoteThrowException {
        if (data.getClass().isAnonymousClass()) {
            throw new RuntimeException("anonymous type");
        }
		Object send = send(target,  data.name(), data);
        return (RET)  send;
    }
	public Object send(String target, 
					   String type, Object data) throws IOException, ClassNotFoundException, RemoteThrowException {
        byte[] dataBytes    = toSerialBytes(data);
        byte[] resultBytes  = sendOriginalData(target, type, dataBytes);
        Object resultObject = toSerialObject(resultBytes);
        if (resultObject instanceof RemoteThrowExceptionWrap) {
            throw new RemoteThrowException(((RemoteThrowExceptionWrap)resultObject).throwable);
        }
        return resultObject;
    }
}
