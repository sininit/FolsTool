package top.fols.box.reflect.re.resource;

import top.fols.atri.io.file.Filez;
import top.fols.atri.util.annotation.Nullable;
import top.fols.box.reflect.re.Re_ClassLoader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.nio.charset.Charset;

public class Re_DirectoryResource implements Re_IResource {
    File directory;
    Charset contentCharset;


    /**
     * @param directory default tip UTF_8
     */
    public Re_DirectoryResource(File directory) {
        this(directory, null);
    }
    public Re_DirectoryResource(File directory, Charset contentCharset) {
        this.directory = directory;
        this.contentCharset = null==contentCharset?DEFAULT_CONTENT_CHARSET:contentCharset;
    }




    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof Re_DirectoryResource))
            return false;

        Re_DirectoryResource other = (Re_DirectoryResource) obj;
        return Filez.wrap(directory).equals(Filez.wrap(other.directory));
    }

    public void contentCharset(Charset charset) {
        this.contentCharset = null == charset ?DEFAULT_CONTENT_CHARSET: charset;
    }
    @Override
    public Charset contentCharset() {
        return this.contentCharset;
    }


    @Nullable
    @Override
    public Re_IResourceFile getFileResource(final String relativePath) {
        if (null == this.directory)
            return null;
        final File absolute = new File(this.directory, relativePath);
        if (absolute.exists()) {
//            try {
//                //当您使用Windows(保留大小写(FAT32/NTFS/..))时,可以使用 absolute.getCanonicalFile().getInstanceName(); 来获取所选文件的规范名称.
//                System.out.println(absolute.getCanonicalPath());
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
            return new TargetFile(relativePath,
                    absolute, relativePath,
                    contentCharset());
        }
        return null;
    }
    @Override
    public Long getFileSize(String relativePath) {
        if (null == this.directory)
            return null;
        final File absolute = new File(this.directory, relativePath);
        if (absolute.exists()) {
            return absolute.length();
        }
        return null;
    }
    @Override
    public Long getFileLastModified(String relativePath) {
        if (null == this.directory)
            return null;
        final File absolute = new File(this.directory, relativePath);
        if (absolute.exists()) {
            return absolute.lastModified();
        }
        return null;
    }
    @Override
    public InputStream getFileInputStream(String relativePath) {
        if (null == this.directory)
            return null;
        final File absolute = new File(this.directory, relativePath);
        try {
            return new FileInputStream(absolute);
        } catch (Throwable e) {
            return null;
        }
    }



    @Nullable
    @Override
    public Re_IResourceFile findClassResource(String className) {
        if (null == this.directory)
            return null;
        String relativePath = Re_ClassLoader.classNameToPath(className);
        final File absolute = new File(this.directory, relativePath);
        if (absolute.exists()) {
            return new TargetFile(className,
                    absolute, relativePath,
                    contentCharset());
        }
        return null;
    }




    public static class TargetFile implements Re_IResourceFile {
        String name;
        File absoluteFile; String relativePth;
        Charset charset;

        TargetFile(String name,
                   File absoluteFile, String relativePath,
                   Charset charset) {
            this.name = name;
            this.absoluteFile = absoluteFile;
            this.relativePth = relativePath;
            this.charset = charset;
        }

        @Override
        public String name() {
            return name;
        }

        @Override
        public String absolutePath() {
            return absoluteFile.getPath();
        }
        @Override
        public String path() {
            return relativePth;
        }

        @Override
        public Charset charset() {
            return charset;
        }

        Filez filez;
        public Filez file(){
            if (null == filez)
                filez = Filez.wrap(absoluteFile);
            return filez;
        }

        @Override
        public InputStream asStream() {
            try {
                return new FileInputStream(absoluteFile);
            } catch (Throwable e) {
                return null;
            }
        }
        @Override
        public byte[] asBytes() {
            return file().readBytes();
        }
        @Override
        public String asString() {
            return new String(asBytes(), charset());
        }


        @Override
        public String toString() {
            return this.name;
        }
    }
}
