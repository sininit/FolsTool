package top.fols.atri.cache;

import top.fols.atri.lang.Value;

import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public abstract class WeakCache<V> {
//    static List<int[]> caches = new ArrayList<>();
//    static final WeakCache<Map<?, ?>> cache = new WeakCache<Map<?, ?>>() {
//        @Override
//        public Map<?, ?> createCache() {
//            caches.clear();
//            return new ConcurrentHashMap<>();
//        }
//    };
//    public static void test() {
//        synchronized (cache) {
//            for (int c = 0; c < 1000 * 10000; c++) {
//                Map<?, ?> orCreateCache = cache.getOrCreateCache();
//                caches.add(new int[100*10000]);
//                System.out.println(c + ":" + orCreateCache);
//
//            }
//            System.out.println(cache.getOrCreateCache());
//
//            cache.release();
//            caches.clear();
//            caches = null;
//        }
//    }



    Reference<Value<V>> createReference(Value<V> value) {
        return new WeakReference<>(value);
    }
    Reference<Value<V>> reference = createReference(null);


    public abstract V createCache();

    public final Value<V> getOrCreateCacheValue() {
        Value<V> vw;
        if (null == (vw = reference.get())) {
            reference = createReference(vw = new Value<>(createCache()));
        }
        return vw;
    }

    public final V getOrCreateCache() {
        return getOrCreateCacheValue().get();
    }
    public final void release() {
        reference.clear();
    }
}
