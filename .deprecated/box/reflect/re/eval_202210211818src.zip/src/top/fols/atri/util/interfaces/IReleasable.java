package top.fols.atri.util.interfaces;

public interface IReleasable extends IReleasableIO {
	@Override 
	public boolean release();

	@Override
	public boolean released();
}
