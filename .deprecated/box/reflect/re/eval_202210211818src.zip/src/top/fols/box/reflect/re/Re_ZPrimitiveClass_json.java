package top.fols.box.reflect.re;

import top.fols.atri.assist.json.*;
import top.fols.box.reflect.re.interfaces.Re_IReObject;
import top.fols.box.reflect.re.interfaces.Re_IReInnerVariableMap;

import java.lang.reflect.Array;
import java.util.Iterator;

/**
 * {对象} 和 它的抽象 {类}
 */
@SuppressWarnings({"rawtypes"})
public class Re_ZPrimitiveClass_json extends Re_PrimitiveClass {
    @SuppressWarnings("SpellCheckingInspection")
    public static final Re_ZPrimitiveClass_json reclass = new Re_ZPrimitiveClass_json(Re_Keywords.INNER_CLASS__JSON);


    protected Re_ZPrimitiveClass_json(String className) {
        super(className);

        {
            final String name = "loads";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) {
                    int length = arguments.length;
                    if (length == 1) {
                        String str = Re_Utilities.toJString(arguments[0]);
                        return Re_ZPrimitiveClass_json.this.loads(executor, str);
                    }
                    executor.setThrow(Re_Accidents.unable_to_process_parameters(name, length));
                    return null;
                }
            });
        }

        {
            final String name = "dumps";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) throws Throwable {
                    int length = arguments.length;
                    if (length == 1) {
                        Object json = arguments[0];
                        return Re_ZPrimitiveClass_json.this.dumps(executor, json);
                    }
                    executor.setThrow(Re_Accidents.unable_to_process_parameters(name ,arguments.length));
                    return null;
                }
            });
        }
    }


    @Override
    public Re_PrimitiveClassInstance createInstance() {
        return createInstance(this);
    }
    @Override
    public Re_PrimitiveClassInstance createInstance(Re_Class reClass) {
        return new Re_PrimitiveClassInstance(reClass, new Re_ZVariableMap_Linked());
    }






    public Re_ZPrimitiveClass_list.Instance loadToReList(Re_Executor executor, JSONArray object) {
        if (null == object) return null;
        Object[] array = new Object[object.length()];
        for (int i = 0; i < object.length(); i++) {
            Object value = object.get(i);
            if (value instanceof JSONObject) {
                value = loadToReInstance(executor, (JSONObject) value);
            } else if (value instanceof JSONArray) {
                value = loadToReList(executor, (JSONArray) value);
            }
            array[i] = value;
        }
        Re_ZPrimitiveClass_list.Instance instance = Re_ZPrimitiveClass_list.reclass.createInstance();
        instance.setElements(array);
        if (executor.isReturnOrThrow()) return null;
        return instance;
    }

    public Re_PrimitiveClassInstance loadToReInstance(Re_Executor executor, JSONObject object) {
        if (null == object) return null;
        Re_PrimitiveClassInstance instance =  this.createInstance();
        for (String s : object.keySet()) {
            Object value = object.get(s);
            if (value instanceof JSONObject) {
                value = loadToReInstance(executor, (JSONObject) value);
            } else if (value instanceof JSONArray) {
                value = loadToReList(executor, (JSONArray) value);
            }
            Re_Utilities.setattr(executor, instance, s, value);
            if (executor.isReturnOrThrow()) return null;
        }
        return instance;
    }

    public Object loads(Re_Executor executor, String str) {
        if (null == str || str.length() == 0) return null;

        Object object = JSON.parseJSON(str);
        if (object instanceof JSONObject) {
            return loadToReInstance(executor, (JSONObject) object);
        } else if (object instanceof JSONArray) {
            return loadToReList(executor, (JSONArray) object);
        }

        return object;
    }





    public void dumpIterable(JSONStringer stringer, Re_Executor executor, Iterable array) throws Throwable {
        if (null == array)
            return;

        Iterator iterator = array.iterator();
        stringer.array();
        while (iterator.hasNext()) {
            Object value  = iterator.next();

            if (null == value) {
                stringer.value(null);
                continue;
            }

            if (value instanceof Re_IReObject) {
                if (Re_Utilities.isReClassInstance_list(value)) {
                    dumpReList(stringer, executor, (Re_ClassInstance) value);
                } else {
                    dumpReIObject(stringer, executor, (Re_IReObject) value);
                }
                if (executor.isReturnOrThrow()) return;
            } else if (value.getClass().isArray()) {
                dumpArray(stringer, executor, value);

            } else if (value instanceof Iterable) {
                dumpIterable(stringer, executor, (Iterable) value);

            } else {
                stringer.value(value);
            }
        }
        stringer.endArray();
    }

    public void dumpArray(JSONStringer stringer, Re_Executor executor, Object array) throws Throwable {
        if (null == array)
            return;

        stringer.array();
        int size = Array.getLength(array);
        for (int i = 0; i < size; i++) {
            Object value  = Array.get(array, i);
            if (null == value) {
                stringer.value(null);
                continue;
            }

            if (value instanceof Re_IReObject) {
                if (Re_Utilities.isReClassInstance_list(value)) {
                    dumpReList(stringer, executor, (Re_ClassInstance) value);
                } else {
                    dumpReIObject(stringer, executor, (Re_IReObject) value);
                }
                if (executor.isReturnOrThrow()) return;
            } else if (value.getClass().isArray()) {
                dumpArray(stringer, executor, value);

            } else if (value instanceof Iterable) {
                dumpIterable(stringer, executor, (Iterable) value);

            } else {
                stringer.value(value);
            }
        }
        stringer.endArray();
    }
    public void dumpReList(JSONStringer stringer, Re_Executor executor, Re_ClassInstance instance) throws Throwable {
        if (null == instance)
            return;

        stringer.array();
        Re_ZPrimitiveClass_list.Instance list = (Re_ZPrimitiveClass_list.Instance) instance;
        int size = Re_Variable.size(list);
        for (int i = 0; i < size; i++) {
            Object value  = list.getElement(executor, i);
            if (executor.isReturnOrThrow()) return;
            if (null == value) {
                stringer.value(null);
                continue;
            }

            if (value instanceof Re_IReObject) {
                if (Re_Utilities.isReClassInstance_list(value)) {
                    dumpReList(stringer, executor, (Re_ClassInstance) value);
                } else {
                    dumpReIObject(stringer, executor, (Re_IReObject) value);
                }
                if (executor.isReturnOrThrow()) return;
            } else if (value.getClass().isArray()) {
                dumpArray(stringer, executor, value);

            } else if (value instanceof Iterable) {
                dumpIterable(stringer, executor, (Iterable) value);

            } else {
                stringer.value(value);
            }
        }
        stringer.endArray();
    }
    public void dumpReIObject(JSONStringer stringer, Re_Executor executor, Re_IReObject instance) throws Throwable {
        if (null == instance)
            return;

        Iterable variableKeys = instance.getVariableKeys(executor);
        if (executor.isReturnOrThrow()) return;

        if (null == variableKeys) {
            executor.setThrow(Re_Accidents.unsupported_type(Re_Utilities.getName(instance)));
            //noinspection UnnecessaryReturnStatement
            return;

//            if (!stringer.isEmptyStack()) {
//                 stringer.tip(null);
//            }
        } else {
            stringer.object();
            for (Object key0 : variableKeys) {
                Object variableValue = instance.getVariableValue(executor, key0);
                if (executor.isReturnOrThrow()) return;


                String key = Re_Utilities.toJString(key0); // key is string
                stringer.key(key);

                if (null == variableValue) {
                    stringer.value(null);
                    continue;
                }


                if (variableValue instanceof Re_IReObject) {
                    if (Re_Utilities.isReClassInstance_list(variableValue)) {
                        dumpReList(stringer, executor, (Re_ClassInstance) variableValue);
                    } else {
                        dumpReIObject(stringer, executor, (Re_IReObject) variableValue);
                    }
                    if (executor.isReturnOrThrow()) return;
                } else if (variableValue.getClass().isArray()) {
                    dumpArray(stringer, executor, variableValue);

                } else if (variableValue instanceof Iterable) {
                    dumpIterable(stringer, executor, (Iterable) variableValue);

                } else {
                    stringer.value(variableValue);
                }
            }
            stringer.endObject();
        }
    }
    public String dumps(Re_Executor executor, Object value) throws Throwable {
        if (null == value) return null;

        JSONStringer stringer = new JSONStringer(4);
        if (value instanceof Re_IReObject) {
            if (Re_Utilities.isReClassInstance_list(value)) {
                dumpReList(stringer, executor, (Re_ZPrimitiveClass_list.Instance) value);
            } else {
                dumpReIObject(stringer, executor, (Re_IReObject) value);
            }
        } else if (value.getClass().isArray()) {
            dumpArray(stringer, executor, value);
        } else if (value instanceof Iterable) {
            dumpIterable(stringer, executor, (Iterable) value);
        } else {
            executor.setThrow(Re_Accidents.unsupported_type(Re_Utilities.getName(value)));
            return null;
        }
        return stringer.toString();
    }
}
