package top.fols.atri.util;

import top.fols.atri.lang.Finals;
import top.fols.atri.util.annotation.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Iterables {

    public static Object[] toArray(@NotNull Iterable<?> objects) {
        List<Object> list = new ArrayList<>();
        for (Object object : objects) {
            list.add(object);
        }
        return list.toArray(Finals.EMPTY_OBJECT_ARRAY);
    }




    public static <T> Iterable<T> wrapArray(final T[] array, final int astart, final int alen) {
        if (null == array || astart < 0 || alen < 0 || astart > array.length) {
            return new Iterable<T>() {
                @Override
                public Iterator<T> iterator() {
                    return Collections.emptyIterator();
                }
            };
        }
        return new Iterable<T>() {
            @Override
            public Iterator<T> iterator() {
                return new Iterator<T>() {
                    int cursor = astart;
                    final int range = astart + alen;

                    @Override
                    public boolean hasNext() {
                        return cursor != range;
                    }

                    @Override
                    public T next() {
                        return array[cursor++];
                    }

                    @Override
                    public void remove() {
                        throw new UnsupportedOperationException();
                    }
                };
            }
        };
    }

    /**
     * 类似于python的 range
     * 假设 start是0 stop是10 只会遍历到 0和 10之前的数字
     */
    public static Iterable<Integer> wrapRange(final int start, final int stop) {
        if (stop > start) {
            return wrapRange(start, stop, 1);
        } else if (stop == start) {
            return wrapRange(start, stop, 0);
        } else {
            return wrapRange(start, stop, -1);
        }
    }

    public static Iterable<Integer> wrapRange(final int start, final int stop, final int setp) {
        if (stop > start) {
            return new Iterable<Integer>() {
                @Override
                public Iterator<Integer> iterator() {
                    // TODO: Implement this method
                    return new Iterator<Integer>() {

                        boolean ed = false;
                        int key = start;

                        @Override
                        public boolean hasNext() {
                            // TODO: Implement this method
                            if (ed) {
                                return key + setp < stop;
                            } else {
                                return true;
                            }
                        }

                        @Override
                        public Integer next() {
                            // TODO: Implement this method
                            if (ed) {
                                key += setp;
                            } else {
                                key = start;
                                ed = true;
                            }
                            return key;
                        }

                        @Override
                        public void remove() {
                            throw new UnsupportedOperationException("remove");
                        }
                    };
                }

                @Override
                public String toString() {
                    Iterator<Integer> iterator = this.iterator();
                    StringBuilder sb = new StringBuilder();
                    sb.append("[");
                    while (iterator.hasNext()) {
                        sb.append(iterator.next());
                        if (iterator.hasNext()) {
                            sb.append(", ");
                        }
                    }
                    sb.append("]");
                    return sb.toString();
                }
            };
        } else if (start == stop) {
            return new Iterable<Integer>() {
                @Override
                public Iterator<Integer> iterator() {
                    // TODO: Implement this method
                    return new Iterator<Integer>() {
                        @Override
                        public boolean hasNext() {
                            // TODO: Implement this method
                            return false;
                        }

                        @Override
                        public Integer next() {
                            // TODO: Implement this method
                            return null;
                        }

                        @Override
                        public void remove() {
                            throw new UnsupportedOperationException("remove");
                        }

                    };
                }

                @Override
                public String toString() {
                    Iterator<Integer> iterator = this.iterator();
                    StringBuilder sb = new StringBuilder();
                    sb.append("[");
                    while (iterator.hasNext()) {
                        sb.append(iterator.next());
                        if (iterator.hasNext()) {
                            sb.append(", ");
                        }
                    }
                    sb.append("]");
                    return sb.toString();
                }
            };
        } else {
            return new Iterable<Integer>() {
                @Override
                public Iterator<Integer> iterator() {
                    // TODO: Implement this method
                    return new Iterator<Integer>() {

                        boolean ed = false;
                        int key = start;

                        @Override
                        public boolean hasNext() {
                            // TODO: Implement this method
                            if (ed) {
                                return key + setp > stop;
                            } else {
                                return true;
                            }
                        }

                        @Override
                        public Integer next() {
                            // TODO: Implement this method
                            if (ed) {
                                key += setp;
                            } else {
                                key = start;
                                ed = true;
                            }
                            return key;
                        }

                        @Override
                        public void remove() {
                            throw new UnsupportedOperationException("remove");
                        }

                    };
                }

                @Override
                public String toString() {
                    Iterator<Integer> iterator = this.iterator();
                    StringBuilder sb = new StringBuilder();
                    sb.append("[");
                    while (iterator.hasNext()) {
                        sb.append(iterator.next());
                        if (iterator.hasNext()) {
                            sb.append(", ");
                        }
                    }
                    sb.append("]");
                    return sb.toString();
                }
            };
        }
    }
}
