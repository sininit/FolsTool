package top.fols.box.util;


import top.fols.atri.lang.Arrayz;
import top.fols.atri.lang.Finals;
import top.fols.atri.lang.Objects;
import top.fols.atri.lang.Value;
import top.fols.box.lang.Arrayx;

import java.util.*;

@SuppressWarnings({"SpellCheckingInspection", "StatementWithEmptyBody"})
public class Collectionz {


    /**
     * @see Arrayx#sort
     */
    public static <T> void sort(List<T> cover, Comparator<T> c) {
        Collectionz.sort(cover, 0, cover.size(), c);
    }
    /**
     * @see Arrayx#sort
     */
    public static <T> void sort(List<T> cover, int off, int ed, Comparator<T> c) {
        int i, j;
        for (i = off; i < ed - 1; i++) {
            for (j = off; j < ed - 1 - i + off; j++) {
                if (c.compare(cover.get(j), cover.get(j + 1)) > 0) {
                    T temp = cover.get(j);
                    cover.set(j, cover.get(j + 1));
                    cover.set(j + 1, temp);
                }
            }
        }
    }


    /**
     * @see Arrayx#filter
     */
    public static <T> List<T> filter(List<T> origin, Objects.Call<Boolean, T> fp) {
        return Collectionz.filter(origin, 0, origin.size(), fp);
    }
    /**
     * @see Arrayx#filter(Object[], int, int, Objects.Call)
     */
    public static <T> List<T> filter(List<T> origin, int off, int len, Objects.Call<Boolean, T> fp) {
        List<T> newList = new ArrayList<T>();
        for (int i = 0; i < len; i++) {
            T content = origin.get(off + i);
            if (fp.call(content)) {
                newList.add(content);
            }
        }
        return newList;
    }



    public static <RETURN, ELEMENT> Collection<RETURN> filter(Collection<RETURN> buffer, Next<RETURN, ELEMENT> executor,
                                                              ELEMENT[] filter) {
        return filter(buffer, executor, filter, 0, null == filter ?0: filter.length);
    }
    public static <RETURN, ELEMENT> Collection<RETURN> filter(Collection<RETURN> buffer, Next<RETURN, ELEMENT> executor,
                                                              ELEMENT[] filter, int filter_offset, int filter_count) {
        Objects.requireNonNull(buffer, "null buffer");
        if (null == executor) {
        } else {
            if (null == filter) { return buffer; }
            Value<RETURN> result = new Value<>();
            for (int max = filter_offset + filter_count; filter_offset < max;) {
                Value<RETURN> n = executor.next(result, filter[filter_offset++]);
                if (null != n) {
                    buffer.add(n.get());
                }
            }
        }
        return buffer;
    }


    public static <RETURN, ELEMENT> Collection<RETURN> filter(Collection<RETURN> buffer, Next<RETURN, ELEMENT> executor,
                                                              List<ELEMENT> filter) {
        return filter(buffer, executor, filter, 0, null == filter ?0: filter.size());
    }
    public static <RETURN, ELEMENT> Collection<RETURN> filter(Collection<RETURN> buffer, Next<RETURN, ELEMENT> executor,
                                                              List<ELEMENT> filter, int filter_offset, int filter_count) {
        Objects.requireNonNull(buffer, "null buffer");
        if (null == executor) {
        } else {
            if (null == filter) { return buffer; }
            Value<RETURN> result = new Value<>();
            for (int max = filter_offset + filter_count; filter_offset < max;) {
                Value<RETURN> n = executor.next(result, filter.get(filter_offset++));
                if (null != n) {
                    buffer.add(n.get());
                }
            }
        }
        return buffer;
    }


    public static <RETURN, ELEMENT> Collection<RETURN> filter(Collection<RETURN> buffer, Next<RETURN, ELEMENT> executor,
                                                              Collection<ELEMENT> filter) {
        Objects.requireNonNull(buffer, "null buffer");
        if (null == executor) {
        } else {
            if (null == filter) { return buffer; }
            Iterator<ELEMENT> array_iterator = filter.iterator();
            Value<RETURN> result = new Value<>();
            while  (array_iterator.hasNext()) {
                Value<RETURN> n = executor.next(result, array_iterator.next());
                if (null != n) {
                    buffer.add(n.get());
                }
            }
        }
        return buffer;
    }







    /**
     * 去除重复元素
     *
     * @see Arrayx#deduplication
     */
    public static <T> Collection<T> deduplication(Collection<T> array) {
        if (null == array) {
            return null;
        }
        Map<T, Object> map = new LinkedHashMap<>();//局部变量
        for (T element : array) {
            map.put(element, null);
        }
        Collection<T> newArray = new ArrayList<>(map.keySet());
        map = null;
        return newArray;
    }
    public static <T> List<T> deduplication(List<T> array) {
        return null == array ? null : deduplication(array, 0, array.size());
    }
    public static <T> List<T> deduplication(List<T> array, int off, int len) {
        if (null == array) {
            return null;
        }
        Map<T, Object> map = new LinkedHashMap<>();//局部变量
        for (int i = 0; i < len; i++) {
            T element = array.get(off + i);
            map.put(element, null);
        }
        ArrayList<T> newArray = new ArrayList<>(map.keySet());
        map = null;
        return newArray;
    }

    public static <RETURN> Collection<RETURN> create(Collection<RETURN> buffer, Traverse<RETURN> executor) {
        Objects.requireNonNull(buffer, "null buffer");
        if (null == executor) {
        } else {
            Value<RETURN> result = new Value<>();
            while (null != (result = executor.invoke(result))) {
                buffer.add(result.get());
            }
        }
        return buffer;
    }


    public interface Next<RETURN, ELEMENT> {
        Value<RETURN> next(Value<RETURN> returnValue, ELEMENT array_element);
    }


    /*
     * try get next, If invoke return null then end
     */
    @SuppressWarnings("UnusedReturnValue")
    public static abstract class Traverse<T> {
        public abstract Value<T> invoke(Value<T> next);
    }

    /**
     * traverse all elements, whether it encounters null or not
     */
    @SuppressWarnings({"unchecked", "ForLoopReplaceableByWhile"})
    public static abstract class TraverseArray<RETURN, ELEMENT> extends Traverse<RETURN> implements Next<RETURN, ELEMENT> {
        Object[] array;
        public TraverseArray(ELEMENT[] array) {
            this.array = null == array ? Finals.EMPTY_OBJECT_ARRAY: array;
        }
        int i = 0;



        public Value<RETURN> end()    { this.i = array.length; return null; }
        public int  index()  { return this.i; }
        public int  index(int newIndex) { return this.i = newIndex;}
        public int  length() { return this.array.length; }

        Value<RETURN> next_result = new Value<>();



        @Override
        public final Value<RETURN> invoke(Value<RETURN> next) {
            for (;i < array.length;) {
                Value<RETURN> n = next(this.next_result, (ELEMENT) array[i++]);
                if (null != n) {
                    return  n;
                }
            }
            return null;
        }
    }

    public static abstract class TraverseList<RETURN, ELEMENT> extends Traverse<RETURN> implements Next<RETURN, ELEMENT> {
        List<ELEMENT> array;
        public TraverseList(List<ELEMENT> array) {
            this.array = null == array ?new ArrayList<ELEMENT>() : array;
        }
        int i = 0;


        public Value<RETURN> end()    { this.i = array.size(); return null; }
        public int  index()  { return this.i; }
        public int  index(int newIndex) { this.i = newIndex; return i;}
        public int  length() { return this.array.size(); }

        Value<RETURN> next_result = new Value<>();



        @Override
        public final Value<RETURN> invoke(Value<RETURN> next) {
            for (int size = array.size(); i < size;) {
                Value<RETURN> n = next(this.next_result, array.get(i++));
                if (null != n) {
                    return  n;
                }
            }
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    public static abstract class TraverseCollection<RETURN, ELEMENT> extends Traverse<RETURN> implements Next<RETURN, ELEMENT> {
        Collection<ELEMENT> array;
        Iterator<ELEMENT>   array_iterator;
        public TraverseCollection(Collection<ELEMENT> array) {
            this.array = null == array ?new ArrayList<ELEMENT>(): array;
            this.array_iterator = this.array.iterator();
        }

        static final Iterator EMPTY = new Iterator<Object>() {
            @Override
            public boolean hasNext() {
                return false;
            }

            @Override
            public Object next() {
                return null;
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };


        public Value<RETURN> end()    { this.array_iterator = EMPTY; return null; }
        public int  length() { return this.array.size(); }

        Value<RETURN> next_result = new Value<>();

        @Override
        public final Value<RETURN> invoke(Value<RETURN> next) {
            while  (array_iterator.hasNext()) {
                Value<RETURN> n = next(this.next_result, array_iterator.next());
                if (null != n) {
                    return  n;
                }
            }
            return null;
        }
    }
}
