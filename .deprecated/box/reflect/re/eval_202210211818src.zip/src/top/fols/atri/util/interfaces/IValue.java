package top.fols.atri.util.interfaces;

public interface IValue<T> {
    public T get();
}
