package top.fols.box.reflect.hproxy;


/*
    @SuppressWarnings("UnnecessaryModifier")
    @IRe(code =
		"toReJImport(''java.util.Date'');" +
		"toReJImport(''java.util.Arrays'');" +
		"println(Date().toString() + '': '' + call.original + '' -> '' +call.method + Arrays.toString(arguments))"
    )
    public static interface ListIntercept extends List {
        @IRe(code = "return(getattr(call.proxy, $(0))")
        public Object get(String name);

        @IRe(code = "return(setattr(call.proxy, $(0), $(1)))")
        public void set(String name, Object tip);

		public int size();

        @RegisterInterceptor(name=".*", interceptOrder = 2)
        @IRe(code="return(call.original.invoke(call.object, arguments))")
        public Object interceptMethod();

        @RegisterInterceptor(name=".*", interceptOrder = 1)//执行的add方法会拦截并执行该方法
        @IRe(code =
			"toReJImport(''java.util.Arrays'');" +
			"println(''ADD: ''+Arrays.toString(arguments));"+
			"return(false)")
        public Object _add();
		
		
    }

	
	

        {
			ListIntercept p = Proxyx.proxyObject(new ArrayList(), ListIntercept.class);

			p.set("Hello", "textends");
			p.set("Hello", "textends");
			p.set("Hello", "textends");
			System.out.println(p.get("Hello"));

			System.out.println("========Apex:size");
			System.out.println(((ListIntercept)p).size());
			System.out.println("====Apex:hashCode");
			System.out.println(p.hashCode());// >> run method Object.hashCode no annotation, can get Object interface
			System.out.println(List.class.getMethod("size").invoke(p));
			System.out.println("========");
			System.out.println(p.add(666));
			p.add(1, 666);
			List.class.getMethod("add", Object.class).invoke(p, 777);
			
			
			p.hashCode();
		}
		
		
		
		
		
		
		

 public static interface Apex extends List {
     @IInterceptMethod(name=".*")
     @IForwardMethod(cls=ApexHook.class)
     public Object handle();

     @IRe(code="println(''666'');")
     public int hashCode();
 }
 
 System.out.println(Proxyx.proxyObject(new ArrayList(), Apex.class).toString());
 System.out.println();
 System.out.println(Proxyx.proxyObject(new ArrayList(), Apex.class).hashCode());
 System.out.println();
 
 */

@SuppressWarnings({"rawtypes", "SpellCheckingInspection"})
public class HProxyx {
    static final HProxy INSTANCE = new HProxy();
    private HProxyx() {}


    public static <T> T proxyObject(Object proxyObject, Class<T> annotationInterfaceOne) {
        return INSTANCE.proxyObject(proxyObject, annotationInterfaceOne);
    }

    public static <T> T proxyObject(ClassLoader classLoader, Object proxyObject, Class<T> annotationInterfaceOne) {
        return INSTANCE.proxyObject(classLoader, proxyObject, annotationInterfaceOne);
    }

    public static <O, T> T proxyClass(Class<O> proxyClass, Class<T> annotationInterfaceOne) {
        return INSTANCE.proxyClass(proxyClass, annotationInterfaceOne);
    }

    public static <O, T> T proxyClass(ClassLoader classLoader, Class<O> proxyClass, Class<T> annotationInterfaceOne) {
        return INSTANCE.proxyClass(classLoader, proxyClass, annotationInterfaceOne);
    }

    public static <O, T> T proxy(ClassLoader classLoader, Class<O> proxyClass, Object proxyObject, Class<T> annotationInterfaceOne) {
        return INSTANCE.proxy(classLoader, proxyClass, proxyObject, annotationInterfaceOne);
    }

    public static <T> T proxiesObject(Object proxyObject, Class<T> annotationInterfaceOne, Class... interfaces) {
        return INSTANCE.proxiesObject(proxyObject, annotationInterfaceOne, interfaces);
    }

    public static <T> T proxiesObject(ClassLoader classLoader, Object proxyObject, Class<T> annotationInterfaceOne, Class... interfaces) {
        return INSTANCE.proxiesObject(classLoader, proxyObject, annotationInterfaceOne, interfaces);
    }

    public static <O, T> T proxiesClass(Class<O> proxyClass, Class<T> annotationInterfaceOne, Class... interfaces) {
        return INSTANCE.proxiesClass(proxyClass, annotationInterfaceOne, interfaces);
    }

    public static <O, T> T proxiesClass(ClassLoader classLoader, Class<O> proxyClass, Class<T> annotationInterfaceOne, Class... interfaces) {
        return INSTANCE.proxiesClass(classLoader, proxyClass, annotationInterfaceOne, interfaces);
    }

    public static <O, T> T proxies(ClassLoader classLoader, Class<O> proxyClass, Object proxyObject, Class<T> annotationInterfaceOne, Class... interfaces) {
        return INSTANCE.proxies(classLoader, proxyClass, proxyObject, annotationInterfaceOne, interfaces);
    }
}
