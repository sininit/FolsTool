package top.fols.box.reflect.hproxy;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import top.fols.atri.lang.Finals;
import top.fols.atri.reflect.ReflectMatcher;
import top.fols.atri.reflect.Reflects;

@SuppressWarnings({"UnnecessaryModifier", "rawtypes", "unused"})
@Retention(value= RetentionPolicy.RUNTIME)
@Target(value={ElementType.METHOD, ElementType.TYPE})
public @interface IInvokeForward {
    Class<?>  cls();
    String name() default "";

	int order() default 0;

    public static final Class<IInvokeForward> TYPE = IInvokeForward.class;
    Class<ForwardHook> FORWARD_HOOK_CLASS = ForwardHook.class;
    public static final HProxy.AnnotationExecutor<IInvokeForward> EXECUTOR = new HProxy.AnnotationExecutor<IInvokeForward>() {
        Integer orderCache = null;
        @Override
        public Integer order(IInvokeForward annotation) {
            // TODO: Implement this method
            if (null != orderCache && orderCache == annotation.order())
                return  orderCache;
            return orderCache = annotation.order();
        }

        @Override
        public IInvokeForward cloneAnnotation(IInvokeForward annotation) {
            Class cls0 = null;
            try { cls0 = annotation.cls();} catch (Throwable ignored) {}
            String name0 = null;
            try {  name0 = annotation.name();} catch (Throwable ignored) {}

			final Integer order = annotation.order();
            final Class type = cls0;
            final String value = name0;
            return new IInvokeForward() {

				@Override
				public int order() {
					// TODO: Implement this method
					return order;
				}
				
                @Override
                public String name() {
                    return value;
                }

                @Override
                public Class cls() {
                    return type;
                }

                @Override
                public Class<? extends Annotation> annotationType() {
                    return TYPE;
                }

                @Override
                public String toString() {
                    return "@" + TYPE.getName() + "(" + "cls=" + cls() + ", name=" + name() + ", order=" + order() + ")";
                }
            };
        }

        @Override
        public void execute(IInvokeForward annotation,
                            Class beProxyObjectClass, Object beProxyObject, Method runMethod, Method originalMethod, Object[] args, HProxy.ObjectProxy proxy, HProxy.Return result) throws Throwable {
            // TODO: Implement this method
            Class cls;
            try { cls = annotation.cls(); } catch (Throwable e) {
                throw new RuntimeException("annotation must not empty class: " + annotation + " " + annotation.annotationType());
            }

            String name = annotation.name();
            if (null == name || name.length() == 0) {
			    if (!FORWARD_HOOK_CLASS.isAssignableFrom(cls)) {
                    throw new RuntimeException("name='', but the class found does not belong to forward: " + cls);
                }
                @SuppressWarnings("unchecked")
                ForwardHook forward = (ForwardHook) Reflects.newInstance(cls);

                IInvokeForward.ForwardData<IInvokeForward> data = new IInvokeForward.ForwardData<>(annotation, beProxyObjectClass
																								   , beProxyObject, runMethod, originalMethod, args, proxy, result);

                forward.before(data);
                if (data.isReturn()) {
                    return;
                }

				try {
					Object original = data.invokeObjectEqualsMethod();
					data.setReturn(original);
				} catch (Throwable e) {
					data.setThrowable(e);
				}

                forward.after(data);

				if (data.isThrow()) {
					throw data.getThrowable();
				}
            } else {
                Class[] paramTypes = { IInvokeForward.ForwardData.class };
                Method find = Reflects.accessible(Reflects.method(cls, Finals.VOID_CLASS, name, paramTypes));
                if (null == find) {
                    throw new RuntimeException(ReflectMatcher.buildNoSuchMatch(cls, Reflects.methods(cls), Finals.VOID_CLASS, name, paramTypes));
                }
                if (Modifier.isStatic(find.getModifiers())) {
                    //noinspection unchecked
                    find.invoke(null,
								new IInvokeForward.ForwardData(annotation, beProxyObjectClass
															   , beProxyObject, runMethod, originalMethod, args, proxy, result)
								);
                    return;
                }
                throw new RuntimeException(ReflectMatcher.buildNoSuchMatch(cls, Reflects.methods(cls), Finals.VOID_CLASS, "static " +  name, paramTypes));
            }
        }
    };

    @SuppressWarnings("UnnecessaryModifier")
    public static class ForwardData<T extends Annotation> {
        T annotation;
        Class           proxyObjectClass;
        Object          proxyObject;
        Method          runMethod;
        Method          originalMethod;
        Object[]        args;
        HProxy.ObjectProxy  proxy;
        HProxy.Return       result;

        public ForwardData(T annotation,
                           Class proxyObjectClass, Object proxyObject, Method runMethod, Method originalMethod, Object[] args, HProxy.ObjectProxy proxy, HProxy.Return result) {
            this.annotation = annotation;
            this.proxyObjectClass = proxyObjectClass;
            this.proxyObject = proxyObject;
            this.runMethod = runMethod;
            this.originalMethod = originalMethod;
            this.args = null == args ? Finals.EMPTY_OBJECT_ARRAY: args;
            this.proxy = proxy;
            this.result = result;
        }

        public T getAnnotation() {
            return annotation;
        }

        public Class getProxyObjectClass() {
            return proxyObjectClass;
        }
        public Object getProxyObject() {
            return proxyObject;
        }



        public Method getRunMethod() {
            return runMethod;
        }
        public boolean isRunMethodNoReturn() {
            return runMethod.getReturnType() == Finals.VOID_CLASS;
        }
        public Object  invokeRun() throws InvocationTargetException, IllegalAccessException {
            return runMethod.invoke(proxyObject, args);
        }



        public Method  getOriginalMethod()    {
            return originalMethod;
        }
        public boolean isOriginalMethodNoReturn() {
            return originalMethod.getReturnType() == Finals.VOID_CLASS;
        }
        public Object  invokeOriginal() throws InvocationTargetException, IllegalAccessException {
            return originalMethod.invoke(proxyObject, args);
        }

        public Method getObjectEqualsMethod() {
            return HProxy.getObjectEqualsMethod(this.proxyObjectClass, this.originalMethod);
        }
        public boolean isObjectEqualsMethodNoReturn() {
            Method objectEqualsMethod = this.getObjectEqualsMethod();
            return objectEqualsMethod.getReturnType() == Finals.VOID_CLASS;
        }
        public Object  invokeObjectEqualsMethod() throws InvocationTargetException, IllegalAccessException {
            Method objectEqualsMethod = this.getObjectEqualsMethod();
            return objectEqualsMethod.invoke(proxyObject, args);
        }



        public Object[] getArguments() {
            return args;
        }

        public HProxy.ObjectProxy getProxy() {
            return proxy;
        }

        public HProxy.Return getResult() {
            return result;
        }


        public void setReturn(Object value) throws IllegalAccessException {
            result.setReturn(value);
        }

        public Object getReturn() {
            return result.getReturn();
        }

        public boolean isReturn() {
            return result.isReturn();
        }


		public void setThrowable(Throwable value) throws IllegalAccessException {
            result.setThrowable(value);
        }

        public Throwable getThrowable() {
            return result.getThrowable();
        }

        public boolean isThrow() {
            return result.isThrow();
        }
    }

    public static interface ForwardHook {
        public void before(IInvokeForward.ForwardData param) throws Throwable;
        public void after(IInvokeForward.ForwardData param) throws Throwable;
    }
}
