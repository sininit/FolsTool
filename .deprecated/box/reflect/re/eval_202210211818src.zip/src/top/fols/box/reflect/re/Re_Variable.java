package top.fols.box.reflect.re;

import top.fols.atri.lang.Objects;
import top.fols.atri.util.annotation.Nullable;
import top.fols.box.reflect.re.interfaces.Re_IReInnerVariableMap;
import top.fols.box.reflect.re.interfaces.Re_IReObject;
import top.fols.atri.util.annotation.NotNull;

import java.util.Map;

import static top.fols.box.reflect.re.Re_CodeLoader._CompileTimeCodeSourceReader.getBaseDataToDeclareString;

/**
 * 变量存储器，和对象不是一个概念
 * 变量是用来存储对象的
 *
 * 不能继承变量
 * 不能继承变量
 * 不能继承变量
 *
 * ，所有变量类型都预置好了
 */
@SuppressWarnings({"StaticInitializerReferencesSubClass", "rawtypes", "unchecked", "JavadocDeclaration", "ConstantConditions", "SameParameterValue"})
public class Re_Variable<E> implements Cloneable {
    protected Re_Variable superClone() {
        try {
            return (Re_Variable) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }


    static final Object  VALUE_NULL  = null;
    static final Boolean VALUE_TRUE  = true;
    static final Boolean VALUE_False = false;


    static public final Builtin_Compile_Null_Variable    Null  = new Builtin_Compile_Null_Variable();
    static public final Builtin_Compile_Boolean_Variable TRUE  = new Builtin_Compile_Boolean_Variable(VALUE_TRUE);
    static public final Builtin_Compile_Boolean_Variable FALSE = new Builtin_Compile_Boolean_Variable(VALUE_False);

    static Builtin_ReusingTempIntegerVariable   createReusingTempIntegerVariable(int javavalue)  {return new Builtin_ReusingTempIntegerVariable(javavalue);}
    static Builtin_ReusingTempObjectVariable    createReusingTempObjectVariable(Object javavalue){return new Builtin_ReusingTempObjectVariable(javavalue);}


    static Builtin_Compile_DynamicVariable_Environment              createCompileEnvironment()               {return Builtin_Compile_DynamicVariable_Environment.DEFAULT;}
    static Builtin_Compile_DynamicVariable_InheritExecutorArguments createCompileInheritExecutorArguments()  {return Builtin_Compile_DynamicVariable_InheritExecutorArguments.DEFAULT;}
    static Builtin_Compile_DynamicVariable_Arguments                createCompileArguments()                 {return Builtin_Compile_DynamicVariable_Arguments.DEFAULT;}
    static Builtin_Compile_DynamicVariable_Space                    createCompileSpace()                     {return Builtin_Compile_DynamicVariable_Space.DEFAULT;}
    static Builtin_Compile_DynamicVariable_This                     createCompileThis()                      {return Builtin_Compile_DynamicVariable_This.DEFAULT;}
    static Builtin_Compile_DynamicVariable_Static                   createCompileStatic()                    {return Builtin_Compile_DynamicVariable_Static.DEFAULT;}




    static Builtin_Compile_Null_Variable    createCompileNull()                 {return Null;}
    static Builtin_Compile_Boolean_Variable createCompileBoolean(boolean value) {return value? TRUE : FALSE;}
    static Builtin_Compile_Long_Variable    createCompileLong(long value)       {return new Builtin_Compile_Long_Variable(value);}
    static Builtin_Compile_Float_Variable   createCompileFloat(float value)     {return new Builtin_Compile_Float_Variable(value);}
    static Builtin_Compile_Double_Variable  createCompileDouble(double value)   {return new Builtin_Compile_Double_Variable(value);}
    static Builtin_Compile_Short_Variable   createCompileShort(short value)     {return new Builtin_Compile_Short_Variable(value);}
    static Builtin_Compile_Byte_Variable    createCompileByte(byte value)       {return new Builtin_Compile_Byte_Variable(value);}
    static Builtin_Compile_Char_Variable    createCompileChar(char value)       {return new Builtin_Compile_Char_Variable(value);}
    static Builtin_Compile_Int_Variable     createCompileInt(int value)         {return new Builtin_Compile_Int_Variable(value);}
    static Builtin_Compile_String_Variable  createCompileString(String value)   {return new Builtin_Compile_String_Variable(value);}



    public static <T> Re_Variable<T>   createVar(T object)   {return new Re_Variable<>(object);}


    /**
     * 在Java里执行
     */
    static abstract class InnerAccessor {
        public abstract Object get(Re_Variable variable);
        public abstract void   set(Re_Variable variable, Object value);
        public abstract Re_Variable cloneVariable(Re_Variable variable);

        static final InnerAccessor STATIC_VARIABLE = new InnerAccessor() {
            @Override
            public Object get(Re_Variable variable) {
                return variable.__value__;
            }
            @Override
            public void   set(Re_Variable variable, Object value) {
                variable.__value__ = value;
            }

            @Override
            public Re_Variable cloneVariable(Re_Variable variable) {
                return variable.superClone();
            }
        };


        static final InnerAccessor STATIC_VARIABLE__BUILTIN = new InnerAccessor() {
            @Override
            public Object get(Re_Variable variable) {
                return variable.__value__;
            }
            @Override public void set(Re_Variable variable, Object value) { }

            @Override
            public Re_Variable cloneVariable(Re_Variable variable) {
                return variable.superClone();
            }
        };
        static final InnerAccessor STATIC_VARIABLE__BUILTIN_COMPILE_NATIVE = new InnerAccessor() {
            @Override
            public Object get(Re_Variable variable) {
                return variable.__value__;
            }
            @Override public void set(Re_Variable variable, Object value) {}

            @Override
            public Re_Variable cloneVariable(Re_Variable variable) {
                return variable.superClone();
            }
        };
    }
    static class ____________{}

    /**
     * 静态变量必须具备一个 内部服务器
     * 动态变量（运行时变量）是没有 内部访问器， 比如 arguments 和 this static 都是根据Re_Executor获取的 所以动态变量返回null
     */
    protected  InnerAccessor getInnerAccessor() {
        return InnerAccessor.STATIC_VARIABLE;
    }
    protected boolean isStaticVariable() {
        return null != getInnerAccessor();
    }
    protected boolean isDynamicVariable() {
        return null == getInnerAccessor();
    }




    protected E __value__;




    private Re_Variable() {}
    private Re_Variable(E __value__) {
        this.__value__ = __value__;
    }


    protected Object get(Re_Executor executor) {
        return this.__value__;
    }
    protected void   set(Re_Executor executor, E value0) {
        this.__value__ = value0;
    }

    /**
     * 注意，这个非常重要 如果返回true 证明它是可以被修改和删除的
     *
     * 不可修改变量应该返回false
     */
    protected boolean modifiable() {
        return true;
    }


    @SuppressWarnings("MethodDoesntCallSuperMethod")
    @Override
    public Re_Variable clone() {
        if (isStaticVariable()) {
            InnerAccessor innerAccessor1 = this.getInnerAccessor();
            return innerAccessor1.cloneVariable(this);
        }
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (isStaticVariable()) {
            if (o instanceof Re_Variable) {
                Re_Variable other = (Re_Variable) o;
                if (other.isStaticVariable()) {
                    InnerAccessor innerAccessor1 = this. getInnerAccessor();
                    Object o1 = innerAccessor1.get(this);

                    InnerAccessor innerAccessor2 = other.getInnerAccessor();
                    Object o2 = innerAccessor2.get(other);
                    return Objects.equals(o1, o2);
                }
            }
        }
        return false;
    }
    @Override
    public int hashCode() {
        if (isStaticVariable()) {
            InnerAccessor innerAccessor1 = this. getInnerAccessor();
            Object o1 = innerAccessor1.get(this);
            return o1.hashCode();
        }
        return super.hashCode();
    }
    @Override
    public String toString() {
        return super.toString();
    }












    //no use

    /**
     *  合并所有key
     *
     * @param map1  @NotNull
     */
    public static Iterable key(@NotNull Re_IReInnerVariableMap map1) {
        return map1.innerGetVariableKeys();
    }


    public static int size(@NotNull Re_IReInnerVariableMap map1) {
        return map1.innerGetVariableCount();
    }




    /**
     * @param key @NotNull
     * @param map1  @NotNull
     *
     * 不会向上查找
     */
    public static boolean has(@NotNull Object key,
                              @NotNull Re_IReInnerVariableMap map1) {
        return map1.innerContainsVariable(key);
    }




    public static void accessClear(Re_Executor executor, @NotNull Re_IReInnerVariableMap map1) {
        for (Object key: map1.innerGetVariableKeys()) {
            Re_Variable.accessRemove(executor, key, map1);
            if (executor.isThrow()) return;
        }
    }


    /**
     *  @see Re_Variable#set(Re_Executor, Object)
     * @param key @NotNull
     * @param map1  @NotNull
     *
     * 不会向上查找
     */
    public static boolean accessRemove(Re_Executor executor, @NotNull Object key, @NotNull Re_IReInnerVariableMap map1) {
        Re_Variable variable = map1.innerGetVariable(key);
        if (null != variable && variable.modifiable()) {
            map1.innerRemoveVariable(key);
            return true;
        }
        return false;
    }


    /**
     * @see Re_Variable#set(Re_Executor, Object)
     * 如果已经存在变量 会 执行{@link Re_Variable#set(Re_Executor, Object)}
     *
     * 应该由执行时设置 因为
     * 变量名执行前都是经过 {@link String#intern()} 的
     *
     * 在 {@link Re_IReObject} 或者 {@link Re_IReInnerVariableMap} 方法中如果name没有被你改变可以直接执行该方法
     *
     * 不规则方法
     *  {@link Re_Executor#executeGVFromReObject(Re_IReObject, Re_CodeLoader.Call)}
     *  {@link Re_Executor#executeGVFromJavaArray(Object, Re_CodeLoader.Call)}
     *
     *  不会向上查找
     */
    public static void accessSetValue(Re_Executor executor, @NotNull Object key, Object value, @NotNull Re_IReInnerVariableMap map) {
        Re_Variable variable = map.innerGetVariable(key);
        if (null != variable) {
            variable.set(executor, value);
        } else {
            map.innerPutVariable(key, new Re_Variable(value));
        }
    }




    /**
     * 一般为动态添加的时候使用
     *
     * 如果不存在变量才会创建新的变量，Key将会被转换为 {@link Re_CodeLoader#intern(Object)}
     * 如果已存在将不会 {@link Re_CodeLoader#intern(Object)} 变量中的原始key将不会变化
     *
     *  不会向上查找
     */

    public static void accessPutNewVariable(Re_Executor executor, @NotNull Object key, @NotNull Re_Variable newVariable, @NotNull Re_IReInnerVariableMap map) {
        //var name not null
        Re_Variable variable = map.innerGetVariable(key);
        if (null != variable) {
            if (variable.modifiable()) {
                map.innerPutVariable(key, newVariable);
            } else {
                String s = Re_Utilities.toJString(key);
                executor.setThrow("unmodifiable variable: " + s);
            }
        } else {
            map.innerPutVariable(key, newVariable);
        }
    }




    public static Object accessGetValue(Re_Executor executor, @NotNull Object key,
                                        @NotNull Re_IReInnerVariableMap variableMap) {
        Re_Variable re_variable = variableMap.innerGetVariable(key);
        return re_variable.get(executor);
    }



    /**
     * 不会向上查询
     */
    public static Object accessGetClassValue(Re_Executor executor,
                                             @NotNull Object key,
                                             @NotNull Re_Class reClass) {
        if (Re_Utilities.isReClass(reClass)) {
            Re_Variable variable = reClass.innerGetVariable(key);
            if (null != variable) {
                return  variable.get(executor);
            }
        }
        throw new Re_Accidents.ExecuteException("not a reClass: " + Re_Utilities.getName(reClass));
    }
    /**
     * 会向上查询 实例变量和类变量表
     */
    public static Object accessGetInstanceValue(Re_Executor executor,
                                                @NotNull Object key,
                                                @NotNull Re_ClassInstance instance) {
        Re_Variable variable = instance.innerGetVariable(key);
        if (null == variable) {
            variable = instance.getReClass().innerGetVariable(key);
            if (null == variable) {
                return null;
            }
        }
        return variable.get(executor);
    }






    /**
     * 如果不存在将会设置 {@link Re_Executor#setThrow(String)} }
     * 会向上查询
     */
    public static Object accessFindMapOrParentValueRequire(@NotNull Re_Executor executor, @NotNull Object key,
                                                           @NotNull Re_IReInnerVariableMap map1) {
        Re_Variable variable = map1.innerFindMapOrParentVariable(key);
        if (null != variable) {
            return variable.get(executor);
        }
        String s = Re_Utilities.toJString(key);
        executor.setThrow(Re_Accidents.undefined(s));
        return null;
    }
    /**
     * 如果不存在将会设置 {@link Re_Executor#setThrow(String)} }
     * 会向上查询
     */
    public static Object accessFindMapOrParentValueRequire(@NotNull Re_Executor executor, @NotNull Object key,
                                                           @NotNull Re_IReInnerVariableMap map1, @NotNull Re_IReInnerVariableMap map2) {
        Re_Variable variable = map1.innerFindMapOrParentVariable(key);
        if (null != variable) {
            return variable.get(executor);
        } else {
            variable = map2.innerFindMapOrParentVariable(key);
            if (null != variable) {
                return variable.get(executor);
            }
        }
        String s = Re_Utilities.toJString(key);
        executor.setThrow(Re_Accidents.undefined(s));
        return null;
    }







    /**
     * @param key @NotNull
     * @param map1  @NotNull
     *
     *  会向上查找
     */
    public static Object accessFindMapValue(Re_Executor executor, @NotNull Object key,
                                                    @NotNull Re_IReInnerVariableMap map1) {
        Re_Variable variable = map1.innerFindMapVariable(key);
        if (null != variable) {
            return  variable.get(executor);
        }
        return null;
    }



    /**
     * 不可修改
     */
    protected static class Builtin<E> extends Re_Variable<E> {
        private Builtin() {}
        private Builtin(E value0) {
            super(value0);
        }

        @Override
        protected  InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__BUILTIN;
        }

        @Override
        protected void set(Re_Executor executor, Object value0) {
            executor.setThrow("unmodifiable builtin variable");
        }
        @Override
        protected boolean modifiable() {
            return false;
        }
    }



    @SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Builtin_ReusingTempIntegerVariable extends Builtin<Integer> {
        public int cache;

        private Builtin_ReusingTempIntegerVariable(int javavalue) {
            cache = javavalue;
            __value__ = new Integer(javavalue);
        }

        @Override
        protected Object get(Re_Executor executor) {
            return (__value__.intValue() == cache)?__value__:(__value__ = new Integer(cache));
        }

        public Object get() {
            return (__value__.intValue() == cache)?__value__:(__value__ = new Integer(cache));
        }
    }



    @SuppressWarnings("unchecked")
    public static class Builtin_ReusingTempObjectVariable extends Builtin {
        private Builtin_ReusingTempObjectVariable(Object value) {
            super(value);
        }

        public Object get() {
            return super.__value__;
        }
        public void set(Object value) {
            super.__value__ = value;
        }
    }




    static class ______________{}









    public static class Builtin_Compile_Null_Variable extends Builtin<Object> implements Re_CodeFile.IRe_CompileVariable {
        private Builtin_Compile_Null_Variable() {
            super(VALUE_NULL);
        }
        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__BUILTIN_COMPILE_NATIVE;
        }


        @Override
        protected Object get(Re_Executor executor) {
            return VALUE_NULL;
        }
        public Object get() {
            return VALUE_NULL;
        }

        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }


    @SuppressWarnings({"BooleanConstructorCall", "UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Builtin_Compile_Boolean_Variable extends Builtin<Boolean> implements Re_CodeFile.IRe_CompileVariable {
        private static final Boolean JAVA_CACHE_TRUE  = true;  //java auto boxing cache
        private static final Boolean JAVA_CACHE_FALSE = false; //java auto boxing cache
        final boolean cache;

        private Builtin_Compile_Boolean_Variable(boolean javavalue) {
            cache     = javavalue;
            __value__ = javavalue? JAVA_CACHE_TRUE : JAVA_CACHE_FALSE;
        }
        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__BUILTIN_COMPILE_NATIVE;
        }


        @Override
        protected Boolean get(Re_Executor executor) {
            return (__value__.booleanValue() == cache)?__value__:(__value__ = new Boolean(cache));
        }
        public Boolean get() {
            return (__value__.booleanValue() == cache)?__value__:(__value__ = new Boolean(cache));
        }



        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }


    @SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Builtin_Compile_Long_Variable extends Builtin<Long> implements Re_CodeFile.IRe_CompileVariable {
        final long cache;

        private Builtin_Compile_Long_Variable(long javavalue) {
            cache = javavalue;
            __value__ = new Long(javavalue);
        }

        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__BUILTIN_COMPILE_NATIVE;
        }


        @Override
        protected Long get(Re_Executor executor) {
            return (__value__.longValue() == cache)?__value__:(__value__ = new Long(cache));
        }
        public Long get() {
            return (__value__.longValue() == cache)?__value__:(__value__ = new Long(cache));
        }

        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }
    @SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Builtin_Compile_Float_Variable extends Builtin<Float> implements Re_CodeFile.IRe_CompileVariable {
        final float cache;

        private Builtin_Compile_Float_Variable(float javavalue) {
            cache = javavalue;
            __value__ = new Float(javavalue);
        }

        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__BUILTIN_COMPILE_NATIVE;
        }


        @Override
        protected Float get(Re_Executor executor) {
            return (__value__.floatValue() == cache)?__value__:(__value__ = new Float(cache));
        }
        public Float get() {
            return (__value__.floatValue() == cache)?__value__:(__value__ = new Float(cache));
        }


        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }
    @SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Builtin_Compile_Double_Variable extends Builtin<Double> implements Re_CodeFile.IRe_CompileVariable {
        final double cache;

        private Builtin_Compile_Double_Variable(double javavalue) {
            cache = javavalue;
            __value__ = new Double(javavalue);
        }

        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__BUILTIN_COMPILE_NATIVE;
        }


        @Override
        protected Double get(Re_Executor executor) {
            return (__value__.doubleValue() == cache)?__value__:(__value__ = new Double(cache));
        }
        public Double get() {
            return (__value__.doubleValue() == cache)?__value__:(__value__ = new Double(cache));
        }

        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }

    @SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Builtin_Compile_Short_Variable extends Builtin<Short> implements Re_CodeFile.IRe_CompileVariable {
        final short cache;

        private Builtin_Compile_Short_Variable(short javavalue) {
            cache = javavalue;
            __value__ = new Short(javavalue);
        }

        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__BUILTIN_COMPILE_NATIVE;
        }


        @Override
        protected Short get(Re_Executor executor) {
            return (__value__.shortValue() == cache)?__value__:(__value__ = new Short(cache));
        }
        public Short get() {
            return (__value__.shortValue() == cache)?__value__:(__value__ = new Short(cache));
        }


        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }


    @SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Builtin_Compile_Byte_Variable extends Builtin<Byte> implements Re_CodeFile.IRe_CompileVariable {
        final byte cache;

        private Builtin_Compile_Byte_Variable(byte javavalue) {
            cache = javavalue;
            __value__ = new Byte(javavalue);
        }

        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__BUILTIN_COMPILE_NATIVE;
        }


        @Override
        protected Byte get(Re_Executor executor) {
            return (__value__.byteValue() == cache)?__value__:(__value__ = new Byte(cache));
        }
        public Byte get() {
            return (__value__.byteValue() == cache)?__value__:(__value__ = new Byte(cache));
        }


        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }

    @SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Builtin_Compile_Char_Variable extends Builtin<Character> implements Re_CodeFile.IRe_CompileVariable {
        final char cache;

        private Builtin_Compile_Char_Variable(char javavalue) {
            cache = javavalue;
            __value__ = new Character(javavalue);
        }

        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__BUILTIN_COMPILE_NATIVE;
        }


        @Override
        protected Character get(Re_Executor executor) {
            return (__value__.charValue() == cache)?__value__:(__value__ = new Character(cache));
        }
        public Character get() {
            return (__value__.charValue() == cache)?__value__:(__value__ = new Character(cache));
        }


        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }



    @SuppressWarnings({"UnnecessaryBoxing", "UnnecessaryUnboxing"})
    public static class Builtin_Compile_Int_Variable extends Builtin<Integer> implements Re_CodeFile.IRe_CompileVariable {
        final int cache;

        private Builtin_Compile_Int_Variable(int javavalue) {
            cache = javavalue;
            __value__ = new Integer(javavalue);
        }
        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__BUILTIN_COMPILE_NATIVE;
        }


        @Override
        protected Integer get(Re_Executor executor) {
            return (__value__.intValue() == cache)?__value__:(__value__ = new Integer(cache));
        }
        public Integer get() {
            return (__value__.intValue() == cache)?__value__:(__value__ = new Integer(cache));
        }

        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }




    public static class Builtin_Compile_String_Variable extends Builtin<String> implements Re_CodeFile.IRe_CompileVariable {
        private Builtin_Compile_String_Variable(String string) {
            super(string);
        }
        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.STATIC_VARIABLE__BUILTIN_COMPILE_NATIVE;
        }

        @Override
        protected String get(Re_Executor executor) {
            return __value__;
        }
        public String get() {
            return __value__;
        }

        @Override
        public String getCompileDeclareValue() {
            return getBaseDataToDeclareString(get());
        }
    }













    static class ___________{}

    public static class Builtin_Compile_DynamicVariable_Environment extends Builtin implements Re_CodeFile.IRe_CompileVariable {
        private static final Builtin_Compile_DynamicVariable_Environment DEFAULT = new Builtin_Compile_DynamicVariable_Environment();

        private Builtin_Compile_DynamicVariable_Environment() {}
        @Override
        protected InnerAccessor getInnerAccessor() {
            return null;
        }

        /**
         * @param executor 默认无意义
         */
        @Override
        protected Object get(Re_Executor executor) {
            return executor.re.getEnvironmentMap();
        }

        @Override
        public String getCompileDeclareValue() {
            return Re_Keywords.INNER_VAR__ENVIRONMENT;
        }
    }

    public static class Builtin_Compile_DynamicVariable_InheritExecutorArguments extends Builtin implements Re_CodeFile.IRe_CompileVariable {
        private static final Builtin_Compile_DynamicVariable_InheritExecutorArguments DEFAULT = new Builtin_Compile_DynamicVariable_InheritExecutorArguments();


        private Builtin_Compile_DynamicVariable_InheritExecutorArguments() {}
        @Override
        protected InnerAccessor getInnerAccessor() {
            return null;
        }


        @Override
        protected Object get(Re_Executor  executor) {
            return Re_Executor.findInheritArguments(executor);
        }

        @Override
        public String getCompileDeclareValue() {
            return Re_Keywords.INNER_VAR__INHERIT_FUN_ARGUMENTS_ARGUMENTS;
        }
    }

    public static class Builtin_Compile_DynamicVariable_Arguments extends Builtin implements Re_CodeFile.IRe_CompileVariable {
        private static final Builtin_Compile_DynamicVariable_Arguments DEFAULT = new Builtin_Compile_DynamicVariable_Arguments();

        private Builtin_Compile_DynamicVariable_Arguments() {
        }
        @Override
        protected InnerAccessor getInnerAccessor() {
            return null;
        }


        @Override
        protected Object get(Re_Executor executor) {
            return executor.getArguments();
        }

        @Override
        public String getCompileDeclareValue() {
            return Re_Keywords.INNER_VAR__FUN_ARGUMENTS_ARGUMENTS;
        }
    }

    public static class Builtin_Compile_DynamicVariable_Space extends Builtin implements Re_CodeFile.IRe_CompileVariable {
        private static final Builtin_Compile_DynamicVariable_Space DEFAULT = new Builtin_Compile_DynamicVariable_Space();

        private Builtin_Compile_DynamicVariable_Space() {}
        @Override
        protected InnerAccessor getInnerAccessor() {
            return null;
        }


        @Override
        protected Object get(Re_Executor executor) {
            return executor;
        }

        @Override
        public String getCompileDeclareValue() {
            return Re_Keywords.INNER_VAR__SPACE;
        }
    }

    public static class Builtin_Compile_DynamicVariable_This extends Builtin implements Re_CodeFile.IRe_CompileVariable {
        private static final Builtin_Compile_DynamicVariable_This DEFAULT = new Builtin_Compile_DynamicVariable_This();

        private Builtin_Compile_DynamicVariable_This() {}
        @Override
        protected InnerAccessor getInnerAccessor() {
            return null;
        }

        /**
         * @param executor 默认无意义
         */
        @Override
        protected Object get(Re_Executor executor) {
            Re_ClassInstance reClassInstance = executor.reClassInstance;
            if (null != reClassInstance) {
                return  reClassInstance;
            }
            executor.setThrow(Re_Accidents.executor_no_bind_class_instance());
            return null;
        }


        @Override
        public String getCompileDeclareValue() {
            return Re_Keywords.INNER_VAR__THIS;
        }
    }

    public static class Builtin_Compile_DynamicVariable_Static extends Builtin implements Re_CodeFile.IRe_CompileVariable {
        private static final Builtin_Compile_DynamicVariable_Static DEFAULT = new Builtin_Compile_DynamicVariable_Static();


        private Builtin_Compile_DynamicVariable_Static() {}
        @Override
        protected InnerAccessor getInnerAccessor() {
            return null;
        }


        /**
         * @param executor 默认无意义
         */
        @Override
        protected Object get(Re_Executor executor) {
            Re_Class reClass = executor.reClass;
            if (null != reClass) {
                return  reClass;
            }
            executor.setThrow(Re_Accidents.executor_no_bind_class());
            return null;
        }


        @Override
        public String getCompileDeclareValue() {
            return Re_Keywords.INNER_VAR__STATIC;
        }
    }



    static class _____________{}






    /**
     * 在Java里执行
     */
    @SuppressWarnings({"rawtypes", "SpellCheckingInspection"})
    static class Unsafes {
        private Unsafes(){}

        public static <T extends Re_IReInnerVariableMap> T clone(T variableMap)  {
            return (T) variableMap.innerCloneVariableMap();
        }

        public static <K> Map<K, Re_Variable> copy(Map<K, Re_Variable> from, Map<K, Re_Variable> to) {
            for (K k : from.keySet()) {
                Re_Variable v = from.get(k);
                v = v.clone(); //克隆变量

                to.put(k, v);
            }
            return to;
        }

        /**
         * 一般为动态添加的时候使用
         *
         * 如果不存在 Key将会被转换为 {@link Re_CodeLoader#intern(Object)} 再提交
         * 如果已存在将不会 {@link Re_CodeLoader#intern(Object)} 变量中的原始key将不会变化
         */
        public static void setVariableIntern(@NotNull Object key, @NotNull Re_Variable variable, @NotNull Re_IReInnerVariableMap map1) {
            map1.innerPutVariable(Re_CodeLoader.intern(key), variable);
        }
        public static void putVariable(@NotNull Object key, @NotNull Re_Variable variable, @NotNull Re_IReInnerVariableMap map1) {
            map1.innerPutVariable(key, variable);
        }

        /**
         * @see Re_Variable#set(Re_Executor, Object)
         * 如果已经存在变量 会异常
         *
         * 一般为动态添加的时候使用
         * 如果不存在 Key将会被转换为 {@link Re_CodeLoader#intern(Object)} 再提交
         *
         * 不会向上查询
         */
        public static void addVariableIntern(@NotNull Object key, @NotNull Re_Variable value, @NotNull Re_IReInnerVariableMap map) {
            //var name not null
            Re_Variable variable = map.innerGetVariable(key);
            if (null != variable) {
                String s = Re_Utilities.toJString(key);
                throw new Re_Accidents.ExecuteException("already set variable: " + s);
            } else {
                map.innerPutVariable(Re_CodeLoader.intern(key), value);
            }
        }

        /**
         * @see Re_Variable#set(Re_Executor, Object)
         * 如果已经存在变量 会 执行{@link Re_Variable#set(Re_Executor, Object)}
         *
         * 应该由执行时设置 因为
         * 变量名执行前都是经过 {@link String#intern()} 的
         * 如果你从 {@link Re_IReObject} 中的回调中 不改变name名称 可以直接使用该方法而不使用 intern
         *
         * 不会向上查询
         */
        public static void addVariable(@NotNull Object key, @NotNull Re_Variable value, @NotNull Re_IReInnerVariableMap map) {
            Re_Variable variable = map.innerGetVariable(key);
            if (null != variable) {
                String s = Re_Utilities.toJString(key);
                throw new Re_Accidents.ExecuteException("already set variable: " + s);
            } else {
                map.innerPutVariable(key, value);
            }
        }

        /**
         * 不会向上查找
         */
        public static boolean removeVariable(@NotNull Object key,
                                             @NotNull Re_IReInnerVariableMap map1) {
            return null != map1.innerRemoveVariable(key);
        }



        /**
         * @see Re_Variable#set(Re_Executor, Object)
         * 如果已经存在变量 会抛出异常
         *
         * 一般为动态添加的时候使用
         * 如果不存在 Key将会被转换为 {@link Re_CodeLoader#intern(Object)} 再提交
         *
         * 不会向上查找
         */
        protected static void addBuiltinValueIntern(@NotNull Object key, @Nullable Object value, @NotNull Re_IReInnerVariableMap map) {
            //var name not null
            Re_Variable variable = map.innerGetVariable(key);
            if (null != variable) {
                String s = Re_Utilities.toJString(key);
                throw new Re_Accidents.ExecuteException("already set variable: " +s);
            } else {
                map.innerPutVariable(Re_CodeLoader.intern(key), new Builtin(value));
            }
        }
        protected static void addBuiltinValueIntern(@Nullable Re_IReObject.IPrimitiveCall primitiveCall, @NotNull Re_IReInnerVariableMap map) {
            addBuiltinValueIntern(primitiveCall.getName(),primitiveCall, map);
        }




        public static Re_Variable getKeywordVariable(@NotNull Object key) {
            return Re_Keywords.keyword.innerGetVariable(key);
        }

        /**
         * 不会向上搜索
         */
        public static Re_Variable getVariable(@NotNull Object key, @NotNull Re_IReInnerVariableMap map) {
            return map.innerGetVariable(key);
        }



        public static Re_Variable cloneVariable(@NotNull Object key, @NotNull Re_IReInnerVariableMap map) {
            Re_Variable re_variable = map.innerGetVariable(key);
            return null == re_variable?null:re_variable.clone();
        }











        public static Object fromUnsafeAccessorGetValue(@Nullable Object key, Re_IReInnerVariableMap map) {
            Re_Variable variable = map.innerGetVariable(key);
            if (null == variable) {
                return null;
            } else {
                InnerAccessor innerAccessor = variable.getInnerAccessor();
                if (null == innerAccessor) {
                    throw new Re_Accidents.ExecuteException("variable is not direct accessor: " + Re_Utilities.getName(variable));
                }
                return innerAccessor.get(variable);
            }
        }

        /**
         * 不会向上查询
         */
        public static Object fromUnsafeAccessorGetClassValue(@Nullable Object key,
                                                             @NotNull Re_Class reClass) {
            if (Re_Utilities.isReClass(reClass)) {
                Re_Variable variable = reClass.innerGetVariable(key);
                if (null != variable) {
                    return fromUnsafeAccessorGetValue(variable);
                }
                return null;
            }  else {
                throw new Re_Accidents.ExecuteException("not a reClass: " + Re_Utilities.getName(reClass));
            }
        }
        /**
         * 会向上查询 实例变量和类变量表
         */
        public static Object fromUnsafeAccessorGetInstanceValue(@Nullable Object key,
                                                                @NotNull Re_ClassInstance instance) {
            Re_Variable variable = instance.innerGetVariable(key);
            if (null == variable) {
                variable = instance.getReClass().innerGetVariable(key);
                if (null == variable) {
                    return null;
                }
            }
            return fromUnsafeAccessorGetValue(variable);
        }




        public static Object fromUnsafeAccessorGetValue(Re_Variable variable) {
            InnerAccessor innerAccessor = variable.getInnerAccessor();
            if (null == innerAccessor) {
                throw new Re_Accidents.ExecuteException("variable is not direct accessor: " + Re_Utilities.getName(variable));
            }
            return innerAccessor.get(variable);
        }

        public static void fromUnsafeAccessorSetValue(Re_Variable variable, Object v) {
            InnerAccessor innerAccessor = variable.getInnerAccessor();
            if (null == innerAccessor) {
                throw new Re_Accidents.ExecuteException("variable is not direct accessor: " + Re_Utilities.getName(variable));
            }
            innerAccessor.set(variable, v);
        }




        /**
         * 一般为动态添加的时候使用
         *
         * 如果不存在变量才会创建新的变量，Key将会被转换为 {@link Re_CodeLoader#intern(Object)}
         * 如果已存在将不会 {@link Re_CodeLoader#intern(Object)} 变量中的原始key将不会变化
         *
         * 不会向上查询
         */
        public static void fromUnsafeAccessorSetValueIntern(Object key, Object v, Re_IReInnerVariableMap map) {
            Re_Variable variable = map.innerGetVariable(key);
            if (null == variable) {
                map.innerPutVariable(Re_CodeLoader.intern(key), new Re_Variable(v));
            } else {
                InnerAccessor innerAccessor = variable.getInnerAccessor();
                if (null == innerAccessor) {
                    throw new Re_Accidents.ExecuteException("variable is not direct accessor: " + Re_Utilities.getName(variable));
                }
                innerAccessor.set(variable, v);
            }
        }
        /**
         * 不会向上查询
         */
        public static void fromUnsafeAccessorSetValue(Object key, Object v, Re_IReInnerVariableMap map) {
            Re_Variable variable = map.innerGetVariable(key);
            if (null == variable) {
                map.innerPutVariable(key, new Re_Variable(v));
            } else {
                InnerAccessor innerAccessor = variable.getInnerAccessor();
                if (null == innerAccessor) {
                    throw new Re_Accidents.ExecuteException("variable is not direct accessor: " + Re_Utilities.getName(variable));
                }
                innerAccessor.set(variable, v);
            }
        }
    }


}
