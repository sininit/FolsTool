package top.fols.box.reflect.re.interfaces;

import top.fols.box.reflect.re.Re_Class;

public interface Re_IReGetDeclaringClass {
    public Re_Class getReDeclareClass();
}