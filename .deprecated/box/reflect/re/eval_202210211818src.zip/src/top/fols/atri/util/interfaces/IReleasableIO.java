package top.fols.atri.util.interfaces;

import java.io.IOException;

public interface IReleasableIO {
	boolean release() throws IOException;
    boolean released() throws IOException;
}
