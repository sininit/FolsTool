package top.fols.atri.util.interfaces;

public interface IInnerStream<T> {
    public T getInnerStream();
}
