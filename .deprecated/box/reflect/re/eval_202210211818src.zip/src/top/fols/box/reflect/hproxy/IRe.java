package top.fols.box.reflect.hproxy;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Method;
import top.fols.atri.lang.Objects;
import top.fols.box.reflect.re.Re;
import top.fols.box.reflect.re.Re_CodeFile;
import top.fols.box.reflect.re.Re_Executor;

/**
 * execute code
 * not recommended
 */
@SuppressWarnings({"UnnecessaryModifier", "unused", "rawtypes"})
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.TYPE})
public @interface IRe {
    String code() default "";
	
	int order() default 0;


    public static final Class<IRe> TYPE = IRe.class;
    public static final HProxy.AnnotationExecutor<IRe> EXECUTOR = new HProxy.AnnotationExecutor<IRe>() {
        Integer orderCache = null;
		@Override
		public Integer order(IRe annotation) {
			// TODO: Implement this method
            if (null != orderCache && orderCache == annotation.order())
                return  orderCache;
			return orderCache = annotation.order();
		}

        @Override
        public IRe cloneAnnotation(IRe annotation) {
            String code0 = null;
            try {  code0 = annotation.code();} catch (Throwable ignored) {}

			final Integer order = annotation.order();
            final int hashCode = annotation.hashCode();
            final String code = code0;
            return new IRe() {
				@Override
				public int order() {
					// TODO: Implement this method
					return order;
				}
				
                @Override
                public String code() {
                    return code;
                }

                @Override
                public Class<? extends Annotation> annotationType() {
                    return TYPE;
                }


                @Override
                public int hashCode() {
                    return hashCode;
                }
                @Override
                public boolean equals(Object obj) {
                    if (obj == this)
                        return true;
                    if (!(obj instanceof IRe))
                        return false;
                    IRe other = (IRe) obj;
                    return Objects.equals(code, other.code());
                }

                @Override
                public String toString() {
                    return "@" + TYPE.getName() + "(" + "code=" + code + ", order=" + order() +  ")";
                }
            };
        }

        @SuppressWarnings("TryFinallyCanBeTryWithResources")
        @Override
        public void execute(IRe annotation,
                            Class beProxyObjectClass, Object beProxyObject, Method runMethod, Method originalMethod, Object[] args, HProxy.ObjectProxy proxy, HProxy.Return result) throws Throwable {
            // TODO: Implement this method
            String code = annotation.code();
            if (code.length() == 0) {
                return;
            }
            Param param = new Param(beProxyObjectClass, beProxyObject, runMethod, originalMethod, proxy, result);

            Re vm = new Re();
            try {
                vm.setEnvironment(PARAM_CALL, param);

                Re_CodeFile re_codeFile = vm.compileCode(code, runMethod.getDeclaringClass().getName());
                Re_Executor executor = Re_Executor.createReRootExecutor(vm, null , re_codeFile, args, vm.getEnvironmentMap());
                Object r  = executor.run();
                Re.throwStackException(executor);

                if (executor.isReturnOrThrow()) {
                    result.setReturn(r);
                }
            } finally {
                vm.close();
            }
        }
    };

    public static final String PARAM_CALL = "call";

	public static class Param {
        public Class<?>           type;
        public Object             object;
        public Method             method;
        public Method             original;
        public HProxy.ObjectProxy proxy;
        public HProxy.Return      result;

        public Param(Class<?> type, Object object, Method method, Method original, HProxy.ObjectProxy proxy, HProxy.Return result) {
            this.type = type;
            this.object = object;
            this.method = method;
            this.original = original;
            this.proxy = proxy;
            this.result = result;
        }
    }
}
