package top.fols.box.reflect.re;


public class Re_PrimitiveClassFunction extends Re_ClassFunction {
    public Re_PrimitiveClassFunction(String name,
                                     Re_Class declaringReClass, Re_ClassInstance declaringReClassInstance) {
        this(name,null,
                declaringReClass, declaringReClassInstance);
    }
    public Re_PrimitiveClassFunction(String name, String[] param,
                                     Re_Class declaringReClass, Re_ClassInstance declaringReClassInstance) {
        Re_CodeFile codeBlock = new Re_CodeFile();
        codeBlock.filePath = getClass().getName();

        Re_ClassFunction.createAfter(this, codeBlock, name, param, null,
                declaringReClass, declaringReClassInstance);
    }


    @Override
    public boolean isPrimitive() {
        return true;
    }



    public static class InheritFunction extends Re_ClassFunction.InheritFunction {
        public InheritFunction(String name,
                               Re_Class declaringReClass, Re_ClassInstance declaringReClassInstance) {
            Re_CodeFile codeBlock = new Re_CodeFile();
            codeBlock.filePath = getClass().getName();

            Re_ClassFunction.createAfter(this, codeBlock, name, null, null,
                    declaringReClass, declaringReClassInstance);
        }

        @Override
        public boolean isPrimitive() {
            return true;
        }
    }
    public static class ParamCheckerFunction extends Re_ClassFunction.ParamCheckerFunction {
        public ParamCheckerFunction(String name,
                                    String[] parameters, Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker[] paramTypes,
                                    Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker returnChecker,
                               Re_Class declaringReClass, Re_ClassInstance declaringReClassInstance) {
            Re_CodeFile codeBlock = new Re_CodeFile();
            codeBlock.filePath = getClass().getName();

            Re_ClassFunction.createAfter(this, codeBlock, name, parameters, null,
                    declaringReClass, declaringReClassInstance);

            super.paramChecker  = null == paramTypes    ? Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker.EMPTY_ARRAY     : paramTypes;
            super.returnChecker = null == returnChecker ? Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker.NOT_CHECK_RETURN: returnChecker;
        }

        @Override
        public boolean isPrimitive() {
            return true;
        }
    }
}
