package top.fols.atri.io;

import java.io.IOException;
import java.io.Reader;

import top.fols.atri.lang.Arrayz;
import top.fols.atri.lang.Finals;
import top.fols.atri.util.interfaces.IReleasable;
import top.fols.box.io.interfaces.IReadLineStream;
import top.fols.box.io.interfaces.IPrivateBuffOperat;
import top.fols.box.io.interfaces.IPrivateStreamIndexOperat;
import top.fols.box.lang.Arrayy;

import static top.fols.atri.io.BytesCodeInputStreams.SEPARATOR_INDEX_UNSET;

public class StringReaders extends Reader implements IPrivateBuffOperat<String>,
		IReadLineStream<char[]>,
		IPrivateStreamIndexOperat, IReleasable {
	private String buf;
	private int count;
	private int pos = 0;
	private int mark = 0;

	/**
	 * Creates a new string reader.
	 *
	 * @param s String providing the character stream.
	 */
	public StringReaders(String s) {
		this.buf = s;
		this.count = s.length();
	}

	/** Check to make sure that the stream has not been closed */
	private void ensureOpen() throws IOException {
		if (null == buf)
			throw new IOException("Stream closed");
	}

	/**
	 * Reads a single character.
	 *
	 * @return The character read, or -1 if the end of the stream has been reached
	 *
	 * @exception IOException If an I/O error occurs
	 */
	@Override
	public int read() throws IOException {
		ensureOpen();
		if (pos >= count)
			return -1;
		return buf.charAt(pos++);
	}
    
	/**
	 * Reads characters into a portion of an array.
	 *
	 * @param cbuf Destination buffer
	 * @param off  Offset at which to start writing characters
	 * @param len  Maximum number of characters to read
	 *
	 * @return The number of characters read, or -1 if the end of the stream has
	 *         been reached
	 *
	 * @exception IOException               If an I/O error occurs
	 * @exception IndexOutOfBoundsException {@inheritDoc}
	 */
	@Override
	public int read(char cbuf[], int off, int len) throws IOException {
		ensureOpen();
		if ((off < 0) || (off > cbuf.length) || (len < 0) || ((off + len) > cbuf.length) || ((off + len) < 0)) {
			throw new IndexOutOfBoundsException();
		} else if (len == 0) {
			return 0;
		}
		if (pos >= count)
			return -1;
		int n = Math.min(count - pos, len);
		buf.getChars(pos, pos + n, cbuf, off);
		pos += n;
		return n;
	}

	/**
	 * Skips the specified number of characters in the stream. Returns the number of
	 * characters that were skipped.
	 *
	 * <p>
	 * The <code>ns</code> parameter may be negative, even though the
	 * <code>skip</code> method of the {@link Reader} superclass throws an exception
	 * in this case. Negative values of <code>ns</code> cause the stream to skip
	 * backwards. Negative return values indicate a skip backwards. It is not
	 * possible to skip backwards past the beginning of the string.
	 *
	 * <p>
	 * If the entire string has been read or skipped, then this method has no effect
	 * and always returns 0.
	 *
	 * @exception IOException If an I/O error occurs
	 */
	@Override
	public long skip(long ns) throws IOException {
		ensureOpen();
		if (pos >= count)
			return 0;
		// Bound skip by beginning and end of the source
		long n = Math.min(count - pos, ns);
		n = Math.max(-pos, n);
		pos += n;
		return n;
	}

	/**
	 * Tells whether this stream is ready to be read.
	 *
	 * @return True if the next read() is guaranteed not to block for input
	 *
	 * @exception IOException If the stream is closed
	 */
	@Override
	public boolean ready() throws IOException {
		ensureOpen();
		return true;
	}

	/**
	 * Tells whether this stream supports the mark() operation, which it does.
	 */
	@Override
	public boolean markSupported() {
		return true;
	}

	/**
	 * Marks the present position in the stream. Subsequent calls to reset() will
	 * reposition the stream to this point.
	 *
	 * @param readAheadLimit Limit on the number of characters that may be read
	 *                       while still preserving the mark. Because the stream's
	 *                       input comes from a string, there is no actual limit, so
	 *                       this argument must not be negative, but is otherwise
	 *                       ignored.
	 *
	 * @exception IllegalArgumentException If {@code readAheadLimit < 0}
	 * @exception IOException              If an I/O error occurs
	 */
	@Override
	public void mark(int readAheadLimit) throws IOException {
		if (readAheadLimit < 0) {
			throw new IllegalArgumentException("Read-ahead limit < 0");
		}
		ensureOpen();
		mark = pos;
	}

	/**
	 * Resets the stream to the most recent mark, or to the beginning of the string
	 * if it has never been marked.
	 *
	 * @exception IOException If an I/O error occurs
	 */
	@Override
	public void reset() throws IOException {
		ensureOpen();
		pos = mark;
	}

	/**
	 * Closes the stream and releases any system resources associated with it. Once
	 * the stream has been closed, further read(), ready(), mark(), or reset()
	 * invocations will throw an IOException. Closing a previously closed stream has
	 * no effect. This method will block while there is another thread blocking on
	 * the reader.
	 */
	@Override
	public void close() {
		release();
	}
	
	@Override
	public char[] readLine(char[] splitChar) {
		return readLine(splitChar, true);
	}

	private int readLineDefaultSeparatorIndex = SEPARATOR_INDEX_UNSET;

	/**
	 * Get Next Line
	 * 
	 * @param separators         lineSeparator
	 * @param resultAddSeparator if read to separator, add return or not?
	 * 
	 * @return if the content is not read, null will be returned
	 */
	@Override
	public char[] readLine(char[] separators, boolean resultAddSeparator) {
		this.readLineDefaultSeparatorIndex = SEPARATOR_INDEX_UNSET;
		if (this.pos >= this.count) {
			return null;
		}

		int findindex = -1;
		char[] split = Finals.EMPTY_CHAR_ARRAY;
		int search = Arrayy.CharSequenceUtil.indexOf(buf, separators, this.pos, this.count);
		if (search != -1 && (findindex == -1 || search < findindex)) {
			this.readLineDefaultSeparatorIndex = 0;
			findindex = search;
			split = separators;
		}

		if (findindex == -1) {
			char[] newArray = new char[this.count - this.pos];
			Arrayz.arraycopy(buf, this.pos, newArray, 0, newArray.length);
			this.pos = this.count;
			return newArray;
		} else {
			int arrlen = findindex - this.pos;
			if (resultAddSeparator) {
				arrlen += split.length;
			}
			char[] newArray = new char[arrlen];
			Arrayz.arraycopy(buf, this.pos, newArray, 0, newArray.length);

			this.pos = findindex + split.length;
			return newArray;
		}
	}

	@Override
	public char[] readLine(char[][] separators, boolean resultAddSeparator) {
		this.readLineDefaultSeparatorIndex = SEPARATOR_INDEX_UNSET;
		if (this.pos >= this.count) {
			return null;
		}

		int endIndex = this.count;
		int offIndex = this.pos;
		String data = this.buf;

		int len = endIndex - offIndex;
		int lastIndex = this.pos;
		for (int ii = 0; ii < len; ii++) {
			char b1 = data.charAt(offIndex + ii);

			for (int ii2 = 0; ii2 < separators.length; ii2++) {
				if (separators[ii2][0] == b1 && (offIndex + ii + separators[ii2].length) <= endIndex) {
					int j = 1;
					for (int ii3 = 1; ii3 < separators[ii2].length; ii3++) {
						if (separators[ii2][ii3] == data.charAt(offIndex + ii + ii3)) {
							j++;
						} else break;
					}
					if (j == separators[ii2].length) {
						this.readLineDefaultSeparatorIndex = ii2;

						int st = lastIndex;
						int et = offIndex + ii + separators[ii2].length;
						int l = et - st;
						char[] array = new char[l - (resultAddSeparator ? 0 : separators[ii2].length)];
						Arrayz.arraycopy(data, st, array, 0, array.length);

						lastIndex = et;
						ii += separators[ii2].length;

						ii -= 1;// for (offset for self-increment)

						this.pos = lastIndex;
						return array;
					}
				}
			}
		}
		if (lastIndex != endIndex) {
			int st = lastIndex;
			int et = endIndex;
			// System.out.println(st + "," + et);
			int l = et - st;
			char[] array = new char[l];
			Arrayz.arraycopy(data, st, array, 0, array.length);
			this.pos = endIndex;
			return array;
		} else {
			return null;
		}
	}


	public char[] getNextLine(char[][] separators, boolean resultAddSeparator) {
		return this.getNextLine(pos, separators, resultAddSeparator);
	}
	public char[] getNextLine(int offIndex, char[][] separators, boolean resultAddSeparator) {
		if (offIndex >= this.count) {
			return null;
		}

		int endIndex = this.count;
		String data = this.buf;

		int len = endIndex - offIndex;
		int lastIndex = offIndex;
		for (int ii = 0; ii < len; ii++) {
			char b1 = data.charAt(offIndex + ii);

			for (int ii2 = 0; ii2 < separators.length; ii2++) {
				if (separators[ii2][0] == b1 && (offIndex + ii + separators[ii2].length) <= endIndex) {
					int j = 1;
					for (int ii3 = 1; ii3 < separators[ii2].length; ii3++) {
						if (separators[ii2][ii3] == data.charAt(offIndex + ii + ii3)) {
							j++;
						} else break;
					}
					if (j == separators[ii2].length) {
						int st = lastIndex;
						int et = offIndex + ii + separators[ii2].length;
						int l = et - st;
						char[] array = new char[l - (resultAddSeparator ? 0 : separators[ii2].length)];
						Arrayz.arraycopy(data, st, array, 0, array.length);

						lastIndex = et;
						ii += separators[ii2].length;

						ii -= 1;// for (offset for self-increment)
						return array;
					}
				}
			}
		}
		if (lastIndex != endIndex) {
			int st = lastIndex;
			int et = endIndex;
			// System.out.println(st + "," + et);
			int l = et - st;
			char[] array = new char[l];
			Arrayz.arraycopy(data, st, array, 0, array.length);
			return array;
		} else {
			return null;
		}
	}



	@Override
	public int readLineSeparatorsIndex() {
		return this.readLineDefaultSeparatorIndex;
	}

	@Override
	public boolean isReadLineReadToSeparator() {
		return this.readLineDefaultSeparatorIndex != SEPARATOR_INDEX_UNSET;
	}


	@Override
	public String buffer() {
		return buf;
	}

	@Override
	public int buffer_length() {
		// TODO: Implement this method
		return buf.length();
	}

	@Override
	public void buffer(String newBuff, int size) {
		// TODO: Implement this method
		this.buf = null == newBuff ? "" : newBuff;
		this.buffer_length(size);
	}

	@Override
	public void buffer_length(int size) throws ArrayIndexOutOfBoundsException {
		if (size > buf.length()) {
			throw new ArrayIndexOutOfBoundsException("arrayLen=" + buf.length() + ", setLen=" + size);
		}
		count = size;
	}

	@Override
	public void seekIndex(int index) {
		if (!(index > -1 && index <= count)) {
			throw new ArrayIndexOutOfBoundsException("can't set pos index=" + index + " length=" + count);
		}
		pos = index;
	}

	@Override
	public int getIndex() {
		return pos;
	}


	public int size() {
		return count;
	}





	@Override
	public boolean release() {
		buffer(null, 0);
		return true;
	}

	@Override
	public boolean released() {
		return null == buf || buf == "" ;
	}
}


