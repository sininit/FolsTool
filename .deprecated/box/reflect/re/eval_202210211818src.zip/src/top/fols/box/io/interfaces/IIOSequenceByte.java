package top.fols.box.io.interfaces;

import java.io.IOException;

@SuppressWarnings("UnnecessaryModifier")
@Deprecated
public interface IIOSequenceByte {
	public int length() throws IOException;
    public byte byteAt(int p1) throws IOException;
}
