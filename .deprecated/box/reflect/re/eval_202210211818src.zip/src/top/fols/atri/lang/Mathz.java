package top.fols.atri.lang;

@SuppressWarnings("SpellCheckingInspection")
public class Mathz {
	/**
     * Returns the tip of the {@code long} argument;
     * throwing an exception if the tip overflows an {@code int}.
     *
     * @param value the long tip
     * @return the argument as an int
     * @throws ArithmeticException if the {@code argument} overflows an int
     * @since 1.8 ...
     *
     *
     */
    public static int toIntExact(long value) {
        if ((int)value != value) {
            throw new ArithmeticException("integer overflow");
        }
        return (int)value;
    }
    public static int toIntExact(double value) {
        if ((int)value != value) {
            throw new ArithmeticException("integer overflow");
        }
        return (int)value;
    }
}
