package top.fols.box.reflect.re;

import top.fols.box.reflect.re.interfaces.Re_IReIterable;
import top.fols.box.reflect.re.interfaces.Re_IReObject;

import static top.fols.box.reflect.re.Re_Variable.*;

import java.lang.reflect.Array;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * 对象有 {@link Re_IReIterable} 和 {@link Iterable}
 */
@SuppressWarnings({"FieldMayBeFinal", "rawtypes"})
public class Re_ZPrimitiveIterables {
    Re_ZPrimitiveIterables() { }

    public static Re_IReIterable wrap(Re_Executor executor, Object object) throws Throwable {
        if (null == object) {
            executor.setThrow(Re_Accidents.unsupported_type(Re_Utilities.getName(object)));
            return null;
        }


        if (object instanceof Re_IReIterable)
            return (Re_IReIterable) object;
        if (object instanceof Re_IReObject)
            return wrapIReObject(executor, (Re_IReObject) object);


        Class<?> aClass = object.getClass();
        if (aClass.isArray())
            return wrapJavaArray(executor, object);


        //java (Set, List)
        if (object instanceof Iterable)
            return wrapJavaIterable(executor, (Set) object);

        executor.setThrow(Re_Accidents.unsupported_type(Re_Utilities.getName(object)));
        return null;
    }

    static Re_IReIterable wrapIReObject(final Re_Executor executor, final Re_IReObject map) throws Throwable {
        final Iterable keysProcess = map.getVariableKeys(executor);
        return new Re_IReIterable() {
            @Override
            public Re_AReIterator iterator() {
                // TODO: Implement this method
                return new Re_AReIterator() {

                    final Builtin_ReusingTempObjectVariable key   = Re_Variable.createReusingTempObjectVariable(null);
                    final Builtin_ReusingTempObjectVariable value = Re_Variable.createReusingTempObjectVariable(null);

                    Iterable keySet = keysProcess;
                    final Iterator iterator = keySet.iterator();


                    @Override
                    public Re_Variable key_variable() {
                        // TODO: Implement this method
                        return key;
                    }

                    @Override
                    public Re_Variable value_variable() {
                        // TODO: Implement this method
                        return value;
                    }

                    @Override
                    public boolean hasNext() {
                        // TODO: Implement this method
                        return iterator.hasNext();
                    }

                    @Override
                    public void next(Re_Executor executor) throws Throwable {
                        // TODO: Implement this method
                        Object k        = iterator.next();
                        key.set(k);
                        value.set(map.getVariableValue(executor, k));
                    }
                };
            }
        };
    }

    public static Re_IReIterable wrapJavaIterable(final Re_Executor executor, final Iterable keysProcess) throws Throwable {
        return new Re_IReIterable() {
            @Override
            public Re_AReIterator iterator() {
                // TODO: Implement this method
                return new Re_AReIterator() {

                    final Builtin_ReusingTempObjectVariable key   = Re_Variable.createReusingTempObjectVariable(null);
                    final Builtin_ReusingTempObjectVariable value = Re_Variable.createReusingTempObjectVariable(null);

                    final Iterator iterator = keysProcess.iterator();

                    int i=0;

                    @Override
                    public Re_Variable key_variable() {
                        // TODO: Implement this method
                        return key;
                    }

                    @Override
                    public Re_Variable value_variable() {
                        // TODO: Implement this method
                        return value;
                    }

                    @Override
                    public boolean hasNext() {
                        // TODO: Implement this method
                        return iterator.hasNext();
                    }

                    @Override
                    public void next(Re_Executor executor) throws Throwable {
                        // TODO: Implement this method
                        Integer index = i++;
                        key  .set(index);

                        Object next = iterator.next();
                        value.set(next);
                    }
                };
            }
        };
    }

    public static Re_IReIterable wrapJavaMap(final Re_Executor executor, final Map map) throws Throwable {
        final Set keysProcess = map.keySet();
        return new Re_IReIterable() {
            @Override
            public Re_AReIterator iterator() {
                // TODO: Implement this method
                return new Re_AReIterator() {

                    final Builtin_ReusingTempObjectVariable key   = Re_Variable.createReusingTempObjectVariable(null);
                    final Builtin_ReusingTempObjectVariable value = Re_Variable.createReusingTempObjectVariable(null);

                    Set keySet = keysProcess;
                    final Iterator iterator = keySet.iterator();


                    @Override
                    public Re_Variable key_variable() {
                        // TODO: Implement this method
                        return key;
                    }

                    @Override
                    public Re_Variable value_variable() {
                        // TODO: Implement this method
                        return value;
                    }

                    @Override
                    public boolean hasNext() {
                        // TODO: Implement this method
                        return iterator.hasNext();
                    }

                    @Override
                    public void next(Re_Executor executor) throws Throwable {
                        // TODO: Implement this method
                        Object k        = iterator.next();
                        key.set(k);
                        value.set(map.get(k));
                    }
                };
            }
        };
    }

    public static Re_IReIterable wrapJavaArray(final Re_Executor executor, final Object map) throws Throwable {
        return new Re_IReIterable() {
            @Override
            public Re_AReIterator iterator() {
                // TODO: Implement this method
                return new Re_AReIterator() {
                    final Builtin_ReusingTempIntegerVariable key  = Re_Variable.createReusingTempIntegerVariable(-1);
                    final Builtin_ReusingTempObjectVariable value = Re_Variable.createReusingTempObjectVariable(null);

                    int len = Array.getLength(map);

                    @Override
                    public Re_Variable key_variable() {
                        // TODO: Implement this method
                        return key;
                    }

                    @Override
                    public Re_Variable value_variable() {
                        // TODO: Implement this method
                        return value;
                    }

                    @Override
                    public boolean hasNext() {
                        // TODO: Implement this method
                        return key.cache + 1 < len;
                    }

                    @Override
                    public void next(Re_Executor executor) throws Throwable {
                        // TODO: Implement this method
                        int i = key.cache + 1;
                        key.cache = i;
                        value.set(Array.get(map, i));
                    }
                };
            }
        };
    }

    /**
     * 类似于python的 range
     * 假设 start是0 stop是10 只会遍历到 0和 10之前的数字
     */
    public static Re_IReIterable wrapRange(final Re_Executor executor, final int start, final int stop) throws Throwable {
        if (stop > start) {
            return wrapRange(executor, start, stop, 1);
        } else if (stop == start) {
            return wrapRange(executor, start, stop, 0);
        } else {
            return wrapRange(executor, start, stop, -1);
        }
    }

    public static Re_IReIterable wrapRange(final Re_Executor executor, final int start, final int stop, final int setp) throws Throwable {
        if (stop > start) {
            return new Re_IReIterable() {
                @Override
                public Re_AReIterator iterator() {
                    // TODO: Implement this method
                    return new Re_AReIterator() {

                        boolean ed = false;
                        final Builtin_ReusingTempIntegerVariable key  = Re_Variable.createReusingTempIntegerVariable(start);
                        final Builtin_ReusingTempObjectVariable value = Re_Variable.createReusingTempObjectVariable(null);

                        @Override
                        public Re_Variable key_variable() {
                            // TODO: Implement this method
                            return key;
                        }

                        @Override
                        public Re_Variable value_variable() {
                            // TODO: Implement this method
                            return value;
                        }

                        @Override
                        public boolean hasNext() {
                            // TODO: Implement this method
                            if (ed) {
                                return key.cache + setp < stop;
                            } else {
                                return true;
                            }
                        }

                        @Override
                        public void next(Re_Executor executor) throws Throwable {
                            // TODO: Implement this method
                            if (ed) {
                                key.cache += setp;
                                value.set(null);
                            } else {
                                key.cache = start;
                                value.set(null);
                                ed = true;
                            }
                        }
                    };
                }
            };
        } else {
            return new Re_IReIterable() {
                @Override
                public Re_AReIterator iterator() {
                    // TODO: Implement this method
                    return new Re_AReIterator() {

                        boolean ed = false;
                        final Builtin_ReusingTempIntegerVariable key  = Re_Variable.createReusingTempIntegerVariable(start);
                        final Builtin_ReusingTempObjectVariable value = Re_Variable.createReusingTempObjectVariable(null);

                        @Override
                        public Re_Variable key_variable() {
                            // TODO: Implement this method
                            return key;
                        }

                        @Override
                        public Re_Variable value_variable() {
                            // TODO: Implement this method
                            return value;
                        }

                        @Override
                        public boolean hasNext() {
                            // TODO: Implement this method
                            if (ed) {
                                return key.cache + setp > stop;
                            } else {
                                return true;
                            }
                        }

                        @Override
                        public void next(Re_Executor executor) throws Throwable {
                            // TODO: Implement this method
                            if (ed) {
                                key.cache += setp;
                                value.set(null);
                            } else {
                                key.cache = start;
                                value.set(null);
                                ed = true;
                            }
                        }
                    };
                }
            };
        }
    }




}