package top.fols.atri.util.interfaces;

import java.util.List;

public interface IInnerList<V> {
    public List<V> getInnerList();
}
