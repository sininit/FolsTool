package top.fols.box.reflect.re;

import top.fols.atri.lang.Finals;
import top.fols.atri.util.annotation.NotNull;
import top.fols.atri.util.annotation.Nullable;
import top.fols.box.reflect.re.interfaces.*;

@SuppressWarnings("rawtypes")
public class Re_ClassFunction implements Re_IReObject, Re_IReInnerVariableMap, Re_IReGetDeclaringClass, Re_IReGetClass {
    private String      name;
    private String[]    params;

    Re_CodeFile         reCodeBlock;

    Re_Class            declareReClass;
    Re_ClassInstance    declareReClassInstance;

    Re_Executor         parent;


    Re_ClassFunction() {}







    static Re_ClassFunction createReFunction(Re_CodeFile reCodeBlock,
                                             @Nullable String name, @Nullable String[] paramName,
                                             @Nullable Re_Executor parent,
                                             @Nullable Re_Class  declaringReClass, @Nullable Re_ClassInstance declaringReClassInstance) {
        return createAfter(new Re_ClassFunction(), reCodeBlock, name, paramName, parent,
                declaringReClass, declaringReClassInstance);
    }

    static Re_ClassFunction createReParamCheckerFunction(Re_CodeFile reCodeBlock,
                                                         @Nullable String name,
                                                         @Nullable String[] paramName, @Nullable Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker[] paramTypes,
                                                         @Nullable Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker returnType,
                                                         @Nullable Re_Executor parent,
                                                         @Nullable Re_Class  declaringReClass, @Nullable Re_ClassInstance declaringReClassInstance) {
        ParamCheckerFunction newFunction = (ParamCheckerFunction) createAfter(new ParamCheckerFunction(), reCodeBlock,
                name, paramName,
                parent,
                declaringReClass, declaringReClassInstance);
        newFunction.paramChecker  = null == paramTypes ? Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker.EMPTY_ARRAY : paramTypes;
        newFunction.returnChecker = null == returnType ? Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker.NOT_CHECK_RETURN: returnType;
        return newFunction;
    }

    static Re_ClassFunction createReInheritFunction(Re_CodeFile reCodeBlock,
                                                    @Nullable String name,
                                                    @Nullable Re_Executor parent,
                                                    @Nullable Re_Class  declaringReClass, @Nullable Re_ClassInstance declaringReClassInstance) {
        return createAfter(new InheritFunction(), reCodeBlock, name, null, parent,
                declaringReClass, declaringReClassInstance);
    }






    static  Re_ClassFunction createAfter(
            Re_ClassFunction reFunction, Re_CodeFile reCodeBlock,
            @Nullable String name, @Nullable String[] paramName,
            @Nullable Re_Executor parent,
            @Nullable Re_Class declaringReClass, @Nullable Re_ClassInstance declaringReClassInstance) {
        if (null == name) {
            reFunction.name                     = Re_CodeLoader.intern(
                Re_Keywords.INNER_EXPRESSION_CALL__FUNCTION + "_" + reCodeBlock.getLineOffset() + "_" + Integer.toHexString(reFunction.hashCode()));
        } else {
            reFunction.name                     = Re_CodeLoader.intern(name);
        }
        reFunction.params                   = null == paramName? Finals.EMPTY_STRING_ARRAY:paramName;
        reFunction.reCodeBlock              = reCodeBlock;
        reFunction.declareReClass = declaringReClass;
        reFunction.declareReClassInstance = declaringReClassInstance;
        reFunction.parent                   = parent;
        return reFunction;
    }







    @Override
    public Re_Class getReClass() {
        return getReDeclareClass();
    }
    @Override
    public final Re_Class getReDeclareClass() {
        return declareReClass;
    }


    @Override
    public final String getName() {
        return name;
    }


    public int      getParamCount() {
        return params.length;
    }
    public String   getParamName(int index) {
        return params[index];
    }


    public Re_Executor getParent() {
        return parent;
    }


    @Override
    public boolean equals(Object o) {
        return this == o;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public String toString() {
        if (null == getReDeclareClass())
            return "re-" + Re_Keywords.INNER_EXPRESSION_CALL__FUNCTION + " " +
                    getName();
        else
            return "re-" + Re_Keywords.INNER_EXPRESSION_CALL__FUNCTION + " " +
                    getReDeclareClass().getName() + Re_CodeLoader.CODE_OBJECT_POINT_SYMBOL + getName();
    }



    @Override
    public boolean isPrimitive() {
        return false;
    }









    @Override
    public final boolean containsVariable(Re_Executor executor, Object key) {
        return false;
    }
    @Override
    public final boolean removeVariable(Re_Executor executor, Object key) {
        return false;
    }
    @Override
    public final Object getVariableValue(Re_Executor executor, Object key) {
        return null;
    }
    @Override
    public final void putVariableValue(Re_Executor executor, Object key, Object value) {

    }
    @Override
    public final int getVariableCount(Re_Executor executor) throws Throwable {
        return 0;
    }
    @Override
    public final @NotNull Iterable getVariableKeys(Re_Executor executor) throws Throwable {
        return null;
    }
    @Override
    public final Object executePoint(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
        executor.setThrow(Re_Accidents.undefined(this, point_key));
        return null;
    }

    /**
     * 执行之前不可能已经return， 如果中间有执行了表达式应该判断表达式是否已经return 如果已经return 则返回return数据 而不是继续操作, 如果已经return返回的任何数据都是无效的
     * 只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
     * <p>
     * 假定本对象名称x
     * 那么执行的是 x()
     *
     *
     * 只有这个 {@link #invoke(Re_Executor, Re_Class, Re_ClassInstance, Object[], Re_IReInnerVariableMap)} 能保证正确的声明来源
     *
     * @param executor 父变量管理器
     * @param that_key 为当前名称，并非指子变量名称
     *                 map();
     * @param call     如果是true 则callParam 为空 ，如果false则 callParam会经过计算后传入
     */
    @Override
    public final Object executeThis(Re_Executor executor, String that_key, Re_CodeLoader.Call call) throws Throwable {
        Object[] arguments = executor.getExpressionValues(call);
        if (executor.isReturnOrThrow()) return null;

        return invokeFromDeclare(executor, arguments);
    }



    protected final Object invokeFromDeclare(Re_Executor executor, Object[] arguments) throws Throwable {
        Re_IReInnerVariableMap variableMap = getArgumentsArrayAsVariableMap(arguments, this);
        //最后一行不需要判断return
        return invoke(executor, declareReClass, declareReClassInstance, arguments, variableMap);
    }
    /**
     * 无论是静态方法还是对象方法都会继承创建时的空间变量
     * 执行后统一只会访问 executeStaticFunction executeObjectFunction
     */
    @SuppressWarnings("UnnecessaryLocalVariable")
    protected Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) throws Throwable {
        Re_Executor re_executor = Re_Executor
                .createReClassFunctionExecutor(
                        executor.re, executor.getStack(),
                        runInClass, runInInstance,
                        this, arguments, functionLocal);
        if (null == re_executor) return null;

        Object result = re_executor.run();
        return result;
    }










    @Override public final Re_Variable            innerRemoveVariable(Object key) {return null;}
    @Override public final Re_Variable            innerFindMapOrParentVariable(Object key) {
        return null;
    }
    @Override public final Re_Variable            innerFindMapVariable(Object key) {return null;}
    @Override public final Re_Variable            innerGetVariable(Object key) {
        return null;
    }
    @Override public final Re_Variable            innerPutVariable(Object key, Re_Variable value) {return null;}
    @Override public final boolean                innerContainsVariable(Object key) {return false;}
    @Override public final int                    innerGetVariableCount() {return 0;}
    @Override public final Iterable<?>            innerGetVariableKeys() {return null;}
    @Override public final Re_IReInnerVariableMap innerCloneVariableMap() {return null;}









    /**
     *
     * @param arguments  java参数数组
     * @param reClassFunction 当参数数量为0时返回 null
     */
    @Nullable
    public static Re_IReInnerVariableMap getArgumentsArrayAsVariableMap(Object[] arguments, Re_ClassFunction reClassFunction) {
        int functionParamCount = reClassFunction.getParamCount();
        if (functionParamCount > 0) {
            Re_ZVariableMap main_function_local = new Re_ZVariableMap();
            if (arguments.length >= functionParamCount) {
                for (int i = 0; i < functionParamCount; i++) {
                    String name = reClassFunction.getParamName(i);
                    Object value = arguments[i];

                    Re_Variable.Unsafes.putVariable(name, Re_Variable.createVar(value), main_function_local);
                }
            } else {
                int i = 0;
                for (; i < arguments.length; i++) {
                    String name = reClassFunction.getParamName(i);
                    Object value = arguments[i];

                    Re_Variable.Unsafes.putVariable(name, Re_Variable.createVar(value), main_function_local);
                }
                for (; i < functionParamCount; i++) {
                    String name = reClassFunction.getParamName(i);

                    Re_Variable.Unsafes.putVariable(name, Re_Variable.createVar(Re_Variable.VALUE_NULL), main_function_local);
                }
            }
            return main_function_local;
        } else {
            return null;
        }
    }





    //no parameters
    static class InheritFunction extends Re_ClassFunction {
        @SuppressWarnings("UnnecessaryLocalVariable")
        @Override
        protected Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) throws Throwable {
            Re_Executor re_executor = Re_Executor.createReInheritExecutor(executor.re, executor.getStack(), this.reCodeBlock, executor, arguments);
            if (null == re_executor) return null;

            Object result = re_executor.run();
            return result;
        }
    }
    static class ParamCheckerFunction extends Re_ClassFunction {
        @NotNull Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker[] paramChecker;
        @NotNull Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker  returnChecker;

        @Override
        protected Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) throws Throwable {
            for (Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker tc: paramChecker)	{
                Object v   = tc.index < arguments.length ? arguments[tc.index] : null;
                if (!tc.isInstanceof(v)) {
                    executor.setThrow(Re_CodeLoader_ExpressionConverts.CallFunction.unsupported_param_type(tc, v));
                    return null;
                }
            }
            Re_Executor newExecutor = Re_Executor
                    .createReClassFunctionExecutor(
                            executor.re, executor.getStack(),
                            runInClass, runInInstance,
                            this, arguments, functionLocal);
            if (null == newExecutor) return null;

            Object result = newExecutor.run();
            if (executor.isReturnOrThrow()) return null;

            if (!returnChecker.isInstanceof(result)) {
                Re_NativeStack.NativeTraceElement lastTrace = newExecutor.getStackElement();
                executor.setThrow(Re_CodeLoader_ExpressionConverts.CallFunction.unsupported_return_type(returnChecker, result) + " in " + lastTrace);
                return null;
            }
            return result;
        }
    }
}











    
