package top.fols.box.reflect.re;

import top.fols.atri.lang.Finals;
import top.fols.box.lang.Arrayx;
import top.fols.box.reflect.re.interfaces.Re_IReInnerVariableMap;
import top.fols.atri.util.annotation.NotNull;
import top.fols.atri.util.Iterables;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicInteger;

import static top.fols.box.reflect.re.Re_Variable.FALSE;
import static top.fols.box.reflect.re.Re_Variable.TRUE;

/**
 * {对象} 和 它的抽象 {类}
 */
@SuppressWarnings("rawtypes")
public class Re_ZPrimitiveClass_list extends Re_PrimitiveClass {
    @SuppressWarnings("SpellCheckingInspection")
    public static final Re_ZPrimitiveClass_list reclass = new Re_ZPrimitiveClass_list(Re_Keywords.INNER_CLASS__LIST);

    protected Re_ZPrimitiveClass_list(String className) {
        super(className);

        {
            final String name = "add";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) {
                    if (!(runInInstance instanceof Instance)) {
                        executor.setThrow("not a reListInstance");
                        return null;
                    }

                    Instance instance_ = (Instance) runInInstance;
                    int length = arguments.length;
                    if (length == 0) {
                        instance_.addElement(null);
                        return null;
                    } else {
                        //noinspection ForLoopReplaceableByForEach
                        for (int i = 0; i < arguments.length; i++) {
                            instance_.addElement(arguments[i]);
                        }
                        return arguments[arguments.length-1];
                    }
                }
            });
        }

        {
            final String name = "setSize";
            addFunctionToStatic(name, new Re_PrimitiveClassFunction(name, this, null) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, Re_IReInnerVariableMap functionLocal) {
                    if (!(runInInstance instanceof Instance)) {
                        executor.setThrow("not a reListInstance");
                        return null;
                    }

                    Instance instance_ = (Instance) runInInstance;
                    int length = arguments.length;
                    if (length == 1) {
                        int i = Re_Utilities.toJInt(arguments[0]);
                        instance_.setSize(i);
                        return TRUE.get();
                    }
                    return FALSE.get();
                }
            });
        }
    }

    public static Re_ZPrimitiveClass_list.Instance fromJavaObject(Collection map) {
        Re_ZPrimitiveClass_list.Instance instance = reclass.createInstance();
        instance.setElements(map.toArray());
        return instance;
    }
    public static Re_ZPrimitiveClass_list.Instance fromJavaArray(Object object) {
        Re_ZPrimitiveClass_list.Instance instance = reclass.createInstance();
        Class<?> aClass = object.getClass();
        if (aClass.isArray()) {
            if (aClass.getComponentType().isPrimitive()) {
                Object[] convert = Arrayx.copyOfConversion(object, Finals.EMPTY_OBJECT_ARRAY);
                instance.setElements(convert);
            } else {
                instance.setElements((Object[]) object);
            }
            return instance;
        }
        return instance;
    }



    @Override
    public Re_ZPrimitiveClass_list.Instance createInstance() {
        return createInstance(this);
    }
    @Override
    public Re_ZPrimitiveClass_list.Instance createInstance(Re_Class reClass) {
        return new Re_ZPrimitiveClass_list.Instance(reClass, new Re_ZVariableMap_Object());
    }

    @SuppressWarnings({"rawtypes", "unchecked", "UnnecessaryUnboxing"})
    public static class Instance extends Re_PrimitiveClassInstance {
        protected AtomicInteger len = new AtomicInteger();

        @Override
        public Re_ClassInstance clone() {
            Instance clone = (Instance) super.clone();
            clone.len = new AtomicInteger(len.intValue());
            return clone;
        }



        protected Instance(Re_Class reClass, Re_IReInnerVariableMap map) {
            super(reClass, map);
        }








        public Object getElement(Re_Executor executor, int index) {
            return Re_Variable.accessFindMapValue(executor, index, this);
        }

        public Object[] toArray(Re_Executor executor) {
            return toArray(executor, Finals.EMPTY_OBJECT_ARRAY);
        }
        public <T> T[] toArray(Re_Executor executor, T[] a) {
            if (null == a) {
                return null;
            }
            int size = Re_Variable.size(this);

            T[] objects = (T[]) Array.newInstance(a.getClass().getComponentType(), size);
            for (int key = 0; key < size; key++) {
                objects[key] = (T) Re_Variable.accessFindMapValue(executor, key, this);
                if (executor.isReturnOrThrow()) return null;
            }
            return objects;
        }






        /**
         * unsafe
         */
        public void setElement(Object key, Object value) {
            Re_Variable.Unsafes.putVariable(key,  Re_Variable.createVar(value), this);
        }
        /**
         * unsafe
         */
        public void setElements(@NotNull final Re_Executor current_executor, @NotNull Re_CodeLoader.Call callParamController) {
            if (current_executor.isReturnOrThrow()) return;

            int paramExpressionCount = callParamController.getParamExpressionCount();
            for (int i = 0; i < paramExpressionCount; i++) {
                Object value = current_executor.getExpressionValue(callParamController, i);
                if (current_executor.isReturnOrThrow()) return;

                Integer key = i;
                Re_Variable.Unsafes.putVariable(key, Re_Variable.createVar(value), this);
            }
            len.set(paramExpressionCount);
        }
        /**
         * unsafe
         */
        public void setElements(Object[] array) {
            for (int i = 0; i < array.length; i++) {
                Object value = array[i];

                Integer key = i;
                Re_Variable.Unsafes.putVariable(key, Re_Variable.createVar(value), this);
            }
            len.set(array.length);
        }

        public void addElement(Object value) {
            this.innerPutVariable(this.getIndexAndAddSize(), Re_Variable.createVar(value));
        }



        public final int size() {
            return len.intValue();
        }
        public final void setSize(int size) {
            len.set(size);
        }


        /**
         * 更新一个更大的值
         * 永远不会达到负数
         */
        @SuppressWarnings("ManualMinMaxCalculation")
        public final void updateLargerSize(int observed) {
            int oldValue, newValue;
            do {
                oldValue = len.get();
                newValue = (oldValue >= observed) ? oldValue : observed;
            } while (!len.compareAndSet(oldValue, newValue));
        }

        /**
         * 这里最后指针可能会 = Integer.MAX_VALUE， 但是这个没什么意义，不需要理
         */
        public final int getIndexAndAddSize() {
            for (;;) {
                int current = len.get(); // Integer.MAX_VALUE?
                int next = (current + 1 >= 0) ? current + 1 : Integer.MAX_VALUE; //如果溢出那么长度永远是  Integer.MAX_VALUE
                if (len.compareAndSet(current, next))
                    return current;
            }
        }







        //-------------------------------------------------------------------------------
        @Override
        public Re_Variable innerRemoveVariable(Object key) {
            // TODO: Implement this method
            if (key instanceof Number) {
                key = key instanceof Integer ? (Integer) key : Integer.valueOf(((Number) key).intValue());
            }
            return variable.innerRemoveVariable(key);
        }
        @Override
        public Re_Variable innerFindMapOrParentVariable(Object key) {
            // TODO: Implement this method
            if (key instanceof Number) {
                key = key instanceof Integer ? (Integer) key : Integer.valueOf(((Number) key).intValue());
            }
            return variable.innerFindMapOrParentVariable(key);
        }
        @Override
        public Re_Variable innerGetVariable(Object key) {
            // TODO: Implement this method
            if (key instanceof Number) {
                key = key instanceof Integer ? (Integer) key : Integer.valueOf(((Number) key).intValue());
            }
            return variable.innerGetVariable(key);
        }
        @Override
        public Re_Variable innerPutVariable(Object key, Re_Variable p2) {
            // TODO: Implement this method
            if (key instanceof Number) {
                Integer index = key instanceof Integer ? (Integer) key : Integer.valueOf(((Number) key).intValue());
                this.updateLargerSize(index.intValue() + 1);
                return variable.innerPutVariable(index, p2);
            }
            return variable.innerPutVariable(key, p2);
        }
        @Override
        public boolean innerContainsVariable(Object key) {
            // TODO: Implement this method
            if (key instanceof Number) {
                int index = key instanceof Integer ? ((Integer) key).intValue() : ((Number) key).intValue();
                return index >= 0 && index < len.get();
            }
            return variable.innerContainsVariable(key);
        }
        //-------------------------------------------------------------------------------
        @Override
        public int innerGetVariableCount() {
            // TODO: Implement this method
            return len.get();
        }
        @Override
        public Iterable<?> innerGetVariableKeys() {
            // TODO: Implement this method
            return Iterables.wrapRange(0, len.get(),1);
        }
        //-------------------------------------------------------------------------------

        public Iterable<?> innerGetRealKeySet() {
            return variable.innerGetVariableKeys();
        }
    }
}
