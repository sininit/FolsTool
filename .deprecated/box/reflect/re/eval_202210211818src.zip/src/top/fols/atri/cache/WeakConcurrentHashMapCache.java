package top.fols.atri.cache;

import top.fols.atri.lang.Value;
import top.fols.atri.util.annotation.NotNull;
import top.fols.atri.util.interfaces.IInnerMap;

import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Using GC to empty map automatically
 * It should be noted that your cache must be able to be regenerated at any time through the key
 */
public abstract class WeakConcurrentHashMapCache<K, V> implements IInnerMap<K, V> {
//    static final WeakConcurrentHashMapCache<Integer, int[]> cache = new WeakConcurrentHashMapCache<Integer, int[]>() {
//        @Override
//        public int[] newCache(Integer integer) {
//            return new int[100 * 10000];
//        }
//    };
//    public static  void test() {
//        synchronized (cache) {
//            int max = 10000;
//            for (int c = 0; c < max; c++) {
//                cache.get(c);
////            System.out.println(cache.size());
//            }
//            System.out.println(cache.size() != max);
//            cache.release();
//        }
//    }




    Reference<Value<Map<K, V>>> createReference(Value<Map<K, V>> value) {
        return new WeakReference<>(value);
    }
    Reference<Value<Map<K, V>>> reference = createReference(null);

    @Override
    public final Map<K, V> getInnerMap() {
        Value<Map<K, V>> vWrap;
        if (null == (vWrap = reference.get())) {
            reference = createReference(vWrap = new Value<Map<K, V>>(new ConcurrentHashMap<K, V>()));
        }
        return vWrap.get();
    }

    public final V get(@NotNull K k) {
        Map<K, V> map = getInnerMap();
        V lastCache;
        if (null ==   (lastCache = map.get(k))) {
            map.put(k, lastCache = newCache(k));
        }
        return lastCache;
    }
    public final int size() {
        return getInnerMap().size();
    }

    public final void release() {
        reference.clear();
    }

    @NotNull
    public abstract V newCache(K k);

}

