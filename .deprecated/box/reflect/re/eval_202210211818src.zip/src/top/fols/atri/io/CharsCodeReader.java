package top.fols.atri.io;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import top.fols.atri.lang.Finals;
import top.fols.atri.util.annotation.Tips;
import top.fols.atri.util.interfaces.IReleasable;
import top.fols.box.io.interfaces.IPrivateBuffOperat;
import top.fols.box.io.interfaces.IPrivateStreamIndexOperat;

import static top.fols.atri.io.BytesCodeInputStreams.SEPARATOR_INDEX_UNSET;

public class CharsCodeReader extends Reader implements IPrivateBuffOperat<char[]>,
        IPrivateStreamIndexOperat, IReleasable {

    /** 自带字符数组 */
    private char buf[];

    /** buf中下一个要被读取的字符位置 */
    private int pos;

    /** buf中被mark的字符下标 */
    private int markedPos = 0;

    /**
     * 字符数组中总数、buf中索引为count和下一个都没有字符存在。
     */
    private int count;


    public CharsCodeReader() {
        this(Finals.EMPTY_CHAR_ARRAY);
    }

    /**
     * 使用传入的buf构造CharArrayReader、并初始化CharArrayReader的buf、以及buf中将要被读取的字符的下标及总数。
     */
    public CharsCodeReader(char buf[]) {
        this.buf = buf;
        this.pos = 0;
        this.count = buf.length;
    }



    /**
     * 使用传入的buf构造CharArrayReader、并初始化CharArrayReader的buf、以及buf中将要被读取的字符的下标及总数。
     */
    public CharsCodeReader(char buf[], int offset, int length) {
        if ((offset < 0) || (offset > buf.length) || (length < 0) || ((offset + length) < 0)) {
            throw new IllegalArgumentException();
        }
        this.buf = buf;
        this.pos = offset;
        this.count = Math.min(offset + length, buf.length);
        this.markedPos = offset;
    }

    /** 检测此流是否关闭、看此流的close()方法就能明白这个方法 */
    private void ensureOpen() throws IOException {
        if (null == buf)
            throw new IOException("Stream closed");
    }

    /**
     * 读取单个字符
     */
    @Override
    public int read() throws IOException {
        ensureOpen();
        if (pos >= count)
            return -1;
        else
            return buf[pos++];
    }

    /**
     * 将buf中len个字符读取到下标从off开始的b中、返回读取的字符个数。
     */
    @Override
    public int read(char b[], int off, int len) throws IOException {
        ensureOpen();
        if ((off < 0) || (off > b.length) || (len < 0) || ((off + len) > b.length) || ((off + len) < 0)) {
            throw new IndexOutOfBoundsException();
        } else if (len == 0) {
            return 0;
        }

        // buf中没有字符
        if (pos >= count) {
            return -1;
        }
        // buf中字符不够len个
        if (pos + len > count) {
            len = count - pos;
        }
        // 传入的len<=0、返回0
        if (len <= 0) {
            return 0;
        }
        System.arraycopy(buf, pos, b, off, len);
        pos += len;
        return len;
    }



    /**
     * 丢弃buf中n个字符、返回实际丢弃的字符个数。
     */
    @Override
    public long skip(long n) throws IOException {
        ensureOpen();
        // 如果buf中剩余字符不够n个、丢弃buf中现有所有字符
        if (pos + n > count) {
            n = count - pos;
        }
        // 传入的n为负、不丢弃。
        if (n < 0) {
            return 0;
        }
        pos += n;
        return n;
    }

    /**
     * 查看CharArrayReader是否可读。判断条件是buf中是否还有字符存在。
     */
    @Override
    public boolean ready() throws IOException {
        ensureOpen();
        return (count - pos) > 0;
    }

    /**
     * 是否支持mark？是
     */
    @Override
    public boolean markSupported() {
        return true;
    }

    /**
     * 标记当前buf中下一个将要被读取的字符下标。 传入的readAheadLimit同ByteArrayInputStream一样、无效。
     */
    @Override
    public void mark(int readAheadLimit) throws IOException {
        ensureOpen();
        markedPos = pos;
    }

    /**
     * 将此流开始位置重置到最后一次调用mark是流的读取位置。
     */
    @Override
    public void reset() throws IOException {
        ensureOpen();
        pos = markedPos;
    }

    /**
     * 关闭、清空buf。
     */
    @Override
    public void close() {
        release();
    }







    @Override
    public char[] buffer() {
        return buf;
    }

    @Override
    public int buffer_length() {
        // TODO: Implement this method
        return buf.length;
    }

    @Override
    public void buffer(char[] newBuff, int size) {
        // TODO: Implement this method
        this.buf = null == newBuff ? Finals.EMPTY_CHAR_ARRAY : newBuff;
        this.buffer_length(size);
    }

    @Override
    public void buffer_length(int size) throws ArrayIndexOutOfBoundsException {
        if (size > buf.length)
            throw new ArrayIndexOutOfBoundsException("arrayLen=" + buf.length + ", setLen=" + size);
        count = size;
    }

    @Override
    public void seekIndex(int index) {
        if (!(index > -1 && index <= count))
            throw new ArrayIndexOutOfBoundsException("can't set pos index=" + index + " length=" + count);
        pos = index;
    }

    @Override
    public int getIndex() {
        return pos;
    }



    public int size() {
        return count;
    }

    @Override
    public boolean release() {
        this.buffer(null, 0);
        this.separatorIndex = SEPARATOR_INDEX_UNSET;
        this.separators = null;
        return true;
    }
    @Override
    public boolean released() {
        return  (null == buf || buf.length == 0) &&
                (null == separators && separatorIndex == SEPARATOR_INDEX_UNSET);
    }





    public boolean hasNext() {
        return (count - pos) > 0;
    }
    public boolean hasNext(int pos) {
        return (count - pos) > 0;
    }

    private char[][] separators;
    private int separatorIndex = SEPARATOR_INDEX_UNSET;

    public void sortSeparators() {
        sortSeparators(this.separators);
    }
    public static void sortSeparators(char[][] separators) {
        if (null == separators)
            return;
        Arrays.sort(separators, new Comparator<char[]>() {
            @Override
            public int compare(char[] o1, char[] o2) {
                return Integer.compare(o2.length, o1.length);
            }
        });
    }

    /**
     * you need to sort manually, and it is [max length,..., min length]
     */
    @Tips("you need to sort manually, and it is [max length,..., min length]")
    public void setSeparators(char[][] separators) {
        this.separators = separators;
    }

    public int getSeparatorsCount() {
        return this.separators.length;
    }
    public char[][] getSeparators() {
        return this.separators;
    }


    public void setSeparatorsAndSort(String... separators) {
        List<char[]> buff = new ArrayList<>();
        for (String s: separators) {
            if (null == s)
                continue;
            char[] chars = s.toCharArray();
            if (chars.length == 0)
                continue;
            buff.add(chars);
        }
        this.separators = buff.toArray(new char[][]{});
        this.sortSeparators();
    }
    public void setSeparatorsAndSort(char[]... separators) {
        List<char[]> buff = new ArrayList<>();
        for (char[] s: separators) {
            if (null == s)
                continue;
            char[] chars = s.clone();
            if (chars.length == 0)
                continue;
            buff.add(chars);
        }
        this.separators = buff.toArray(new char[][]{});
        this.sortSeparators();
    }
    public void addSeparatorsAndSort(char[]... separators) {
        List<char[]> buff = new ArrayList<>();
        if (null != this.separators)
            buff.addAll(Arrays.asList(this.separators));
        for (char[] s: separators) {
            if (null == s)
                continue;
            char[] chars = s.clone();
            if (chars.length == 0)
                continue;
            buff.add(chars);
        }
        this.separators = buff.toArray(new char[][]{});
        this.sortSeparators();
    }




    /**
     * 如果最后一次next返回的是分隔符 则return >= 0
     */
    public boolean lastIsReadReadSeparator(){
        return SEPARATOR_INDEX_UNSET != this.separatorIndex;
    }
    public int lastReadSeparatorIndex() {
        return this.separatorIndex;
    }
    public void lastReadSeparatorIndexReset() {
        this.separatorIndex = SEPARATOR_INDEX_UNSET;
    }
    public char[] lastReadSeparator() {
        return separatorIndex == SEPARATOR_INDEX_UNSET ? null: separators[separatorIndex];
    }

    /**
     * 返回分隔符 或者分隔符之前的内容
     */
    public char[] readNext() {
        this.separatorIndex = SEPARATOR_INDEX_UNSET;

        if (this.pos >= this.count) {
            return null;
        }

        int endIndex = this.count;
        int offIndex = this.pos;
        char[] data = this.buf;

        int len = endIndex - offIndex;
        int lastIndex = this.pos;
        for (int ii = 0; ii < len; ii++) {
            char b1 = data[offIndex + ii];

            for (int ii2 = 0; ii2 < separators.length; ii2++) {
                if (separators[ii2][0] == b1 && (offIndex + ii + separators[ii2].length) <= endIndex) {
                    int j = 1;
                    for (int ii3 = 1; ii3 < separators[ii2].length; ii3++) {
                        if (separators[ii2][ii3] == data[offIndex + ii + ii3]) {
                            j++;
                        } else break;
                    }
                    if (j == separators[ii2].length) {
                        if (ii == 0) { // is separator
                            this.separatorIndex = ii2;

                            int et = offIndex + separators[ii2].length;
                            char[] array = separators[ii2].clone();

                            lastIndex = et;
                            this.pos = lastIndex;
                            return array;
                        } else {
                            int st = lastIndex;
                            int et = offIndex + ii;
                            int l = et - st;
                            char[] array = new char[l];
                            System.arraycopy(data, st, array, 0, array.length);

                            lastIndex = et;
                            ii -= 1;// for (offset for self-increment)

                            this.pos = lastIndex;
                            return array;
                        }
                    }
                }
            }
        }

        if (lastIndex != endIndex) {
            int st = lastIndex;
            int et = endIndex;
            // System.out.println(st + "," + et);
            int l = et - st;
            char[] array = new char[l];
            System.arraycopy(data, st, array, 0, array.length);
            this.pos = endIndex;
            return array;
        } else {
            return null;
        }
    }


    public char[] getBuffer(int index, int len) {
        if (len <= 0)
            return Finals.EMPTY_CHAR_ARRAY;

        char[] arr = new char[len];
        System.arraycopy(this.buf, index, arr, 0, len);
        return arr;
    }
    public char[] getBuffer(int len) {
        return getBuffer(this.pos, len);
    }

    public char[] subBuffer(int startIndex, int end) {
        int len = end - startIndex;
        if (len <= 0)
            return Finals.EMPTY_CHAR_ARRAY;

        return getBuffer(startIndex, len);
    }

    public void getBuffer(int startIndex, char[] to, int toIndex, int len) {
        System.arraycopy(this.buf, startIndex, to, toIndex, len);
    }

}

