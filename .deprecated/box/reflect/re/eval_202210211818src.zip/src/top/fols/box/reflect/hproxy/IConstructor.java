package top.fols.box.reflect.hproxy;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Arrays;
import top.fols.atri.reflect.Reflects;

@SuppressWarnings({"UnnecessaryModifier", "rawtypes", "unused"})
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface IConstructor {
    Class[]  params() default {};
//    String[] params2() default {};


	
	int order() default 0;

    public static final Class<IConstructor> TYPE = IConstructor.class;
    public static final HProxy.AnnotationExecutor<IConstructor> EXECUTOR = new HProxy.AnnotationExecutor<IConstructor>() {
        Integer orderCache = null;
        @Override
        public Integer order(IConstructor annotation) {
            // TODO: Implement this method
            if (null != orderCache && orderCache == annotation.order())
                return  orderCache;
            return orderCache = annotation.order();
        }

        @Override
        public IConstructor cloneAnnotation(final IConstructor annotation) {
            Class[] value0 = null;
            try {   value0 = annotation.params().clone(); } catch (Throwable ignored) {}

			final Integer order = annotation.order();
            final int hashCode = annotation.hashCode();
            final Class[] value = value0;
            return new IConstructor() {

				@Override
				public int order() {
					// TODO: Implement this method
					return order;
				}
				
                @Override
                public Class[] params() {
                    return value;
                }

                @Override
                public Class<? extends Annotation> annotationType() {
                    return TYPE;
                }

                @Override
                public int hashCode() {
                    return hashCode;
                }
                @Override
                public boolean equals(Object obj) {
                    if (obj == this)
                        return true;
                    if (!(obj instanceof IConstructor))
                        return false;
                    IConstructor other = (IConstructor) obj;
                    return Arrays.equals(params(), other.params());
                }
                @Override
                public String toString() {
                    return "@" + TYPE.getName() + "(" + "params=" + Arrays.toString(params()) + ", order=" + order() + ")";
                }
            };
        }

        @Override
        public void execute(IConstructor annotation,
                            Class beProxyObjectClass, Object beProxyObject, Method runMethod, Method originalMethod, Object[] args, HProxy.ObjectProxy proxy, HProxy.Return result) throws Throwable {
            // TODO: Implement this method
            Class[] paramTypes = annotation.params();
            if (null == paramTypes) {
                paramTypes = runMethod.getParameterTypes();
            }

            Constructor constructor = Reflects.accessible(Reflects.constructor(beProxyObjectClass, paramTypes));
            if (null == constructor)
                throw new RuntimeException("cannot found " + Arrays.toString(paramTypes) + " from " + beProxyObjectClass);

            result.setReturn(constructor.newInstance(args));
        }
    };
}
