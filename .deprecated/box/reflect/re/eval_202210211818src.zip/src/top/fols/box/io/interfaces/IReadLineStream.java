package top.fols.box.io.interfaces;

import top.fols.atri.lang.Finals;

import java.io.IOException;


@SuppressWarnings("UnnecessaryModifier")
@Deprecated
public interface IReadLineStream<E extends Object> {

	public abstract E readLine(E separator) throws IOException;
	public abstract E readLine(E separator, boolean resultAddSeparator) throws IOException;
	public abstract E readLine(E[] separator, boolean resultAddSeparator) throws IOException;

	public abstract boolean isReadLineReadToSeparator();
	public abstract int readLineSeparatorsIndex();
	
	//public abstract E test() throws IOException;
}
