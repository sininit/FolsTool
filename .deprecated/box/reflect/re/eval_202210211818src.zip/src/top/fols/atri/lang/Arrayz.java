package top.fols.atri.lang;

import java.lang.reflect.Array;
import java.util.*;

import top.fols.box.array.ArrayObject;
import top.fols.box.util.Collectionz;

@SuppressWarnings({"unused", "SpellCheckingInspection", "unchecked", "rawtypes", "UnnecessaryLocalVariable", "SuspiciousSystemArraycopy"})
public class Arrayz {
	/**
	 * The maximum size of array to allocate. Some VMs reserve some header words in
	 * an array. Attempts to allocate larger arrays may result in OutOfMemoryError:
	 * Requested array size exceeds VM limit
	 */
	public static final int MAX_ARRAY_SIZE = Integer.MAX_VALUE - 8;

	/*
	 * all array type:
	 *
	 * Object[] byte[] long[] double[] char[] int[] boolean[] float[] short[]
	 *
	 * void[] unrealistic
	 */



	@SuppressWarnings({"rawtypes", "unchecked"})
    public static <L> L[] marge(L[] left, L[] right) {
        if (null == left) {
            if (null == right) {
                return null;
            } else {
                return java.util.Arrays.copyOf(right, right.length);
            }
        } else {
            if (null == right) {
                return java.util.Arrays.copyOf(left, left.length);
            } else {
                Class componentType = left.getClass().getComponentType();
                int length = left.length + right.length;
                L[] newInstance = (L[]) java.lang.reflect.Array.newInstance(componentType, length);
                System.arraycopy(left, 0, newInstance, 0, left.length);
                System.arraycopy(right, 0, newInstance, left.length, right.length);
                return newInstance;
            }
        }
    }





	public static <T> T[] filter(T[] array, Objects.Call<Boolean, T> filter) {
		if (null == array) {
			return null;
		}
		int length = Array.getLength(array);
		Class<?> component = array.getClass().getComponentType();
		if (null == filter) {
			T newArray = (T) Array.newInstance(component, length);
			System.arraycopy(array, 0, newArray, 0, length);
			return array;
		} else {
			Object[] newArray = new Object[length];
			int newArraySize  = 0;
			for (T element: array) {
				Boolean filte = filter.call(element);
				if (null != filte && filte) {
					newArray[newArraySize++] = element;
				}
			}
			T[] arr = (T[]) Array.newInstance(component, newArraySize);
			System.arraycopy(newArray, 0, arr, 0, arr.length);
			return arr;
		}
	}

	


























	public static <R> Iterator<R> keys(R... array) {
		return Arrays.asList(array).iterator();
	}






	public static <TO, FROM> Object cast(FROM[] src, int srcPos, TO[] dest, int destPos, int length, Objects.Call<TO, FROM> cast) {
		if (length <= 0) {
			return dest;
		}
		for (int i = 0; i < length; i++) {
			dest[i + destPos] = cast.call(src[i + srcPos]);
		}
		return dest;
	}


	public static char[] arraycopy(String src, int srcPos, char[] dest, int destPos, int length) {
		src.getChars(srcPos, srcPos + length, dest, destPos);
		return dest;
	}
	public static Object arraycopy(Object src, int srcPos, Object dest, int destPos, int length) {
		System.arraycopy(src, srcPos, dest, destPos, length);
		return dest;
	}












	public static int space(Object a) {
		if (null == a) {
			return 0;
		} else {
			int space = 0;
			Class type = a.getClass();
			do {
				if (type.isArray()) { space++; }
			} while (null != (type = type.getComponentType()));
			return space;
		}
	}

	public static boolean isArray(Object object) {
		return null != object && object.getClass().isArray();
	}
	public static boolean isPrimitiveArray(Object object) {
		if (null == object) { return false; }
		Class<?> 		 componentClass = object.getClass().getComponentType();
		return   null != componentClass && componentClass.isPrimitive();
	}
	public static boolean isObjectArray(Object object) {
		if (null == object) { return false; }
		Class<?> 		 componentClass = object.getClass().getComponentType();
		return   null != componentClass && !componentClass.isPrimitive();
	}










	public static <T> T clear(T src) {
		if (null == src) { return null; }
		Class aClass = src.getClass();
		if (aClass.isArray()) {
			if (src instanceof byte[]) {
				Arrays.fill((byte[])   src, (byte)0);
				return src;
			} else if (src instanceof short[]) {
				Arrays.fill((short[])   src, (short)0);
				return src;
			} else if (src instanceof int[]) {
				Arrays.fill((int[])   src, 0);
				return src;
			} else if (src instanceof long[]) {
				Arrays.fill((long[])   src, 0);
				return src;
			} else if (src instanceof char[]) {
				Arrays.fill((char[])   src, (char)0);
				return src;
			} else if (src instanceof float[]) {
				Arrays.fill((float[])  src, (float)0);
				return src;
			} else if (src instanceof double[]) {
				Arrays.fill((double[])  src, 0);
				return src;
			} else if (src instanceof boolean[]) {
				Arrays.fill((boolean[]) src, false);
				return src;
			} else {
				Arrays.fill((Object[])  src, null);
				return src;
			}
		} else {
			return src;
		}
	}

	public static <T> T copyOf(T src) {
		if (null == src) { return null; }
		Class aClass = src.getClass();
		if (aClass.isArray()) {
			if (src instanceof byte[]) {
				return (T) ((byte[])   src).clone();
			} else if (src instanceof short[]) {
				return (T) ((short[])  src).clone();
			} else if (src instanceof int[]) {
				return (T) ((int[])    src).clone();
			} else if (src instanceof long[]) {
				return (T) ((long[])   src).clone();
			} else if (src instanceof char[]) {
				return (T) ((char[])   src).clone();
			} else if (src instanceof float[]) {
				return (T) ((float[])  src).clone();
			} else if (src instanceof double[]) {
				return (T) ((double[]) src).clone();
			} else if (src instanceof boolean[]) {
				return (T) ((boolean[])src).clone();
			} else {
				Object[] a =  (Object[]) src;
				Object[] na = (Object[]) Array.newInstance(aClass.getComponentType(), a.length);
				for (int i = 0; i < a.length; i++) {
					na[i] = copyOf(a[i]);
				}
				return (T) na;
			}
		} else {
			return src;
		}
	}

	public static String toString(Object a) {
		if (a == null)
			return "null";
		Class aClass = a.getClass();
		if (aClass.isArray()) {
			if (aClass == byte[].class) {
				return (Arrays.toString((byte[]) a));
			} else if (aClass == short[].class) {
				return (Arrays.toString((short[]) a));
			} else if (aClass == int[].class) {
				return (Arrays.toString((int[]) a));
			} else if (aClass == long[].class) {
				return (Arrays.toString((long[]) a));
			} else if (aClass == char[].class) {
				return (Arrays.toString((char[]) a));
			} else if (aClass == float[].class) {
				return (Arrays.toString((float[]) a));
			} else if (aClass == double[].class) {
				return (Arrays.toString((double[]) a));
			} else if (aClass == boolean[].class) {
				return (Arrays.toString((boolean[]) a));
			} else { // a is an array of object references
				return Arrays.deepToString((Object[])a);
			}
		} else {  // a is non-null and not an array
			return String.valueOf(a);
		}
	}

	public static int hashCode(Object src) {
		if (null == src)
			return 0;
		if (src.getClass().isArray()) {
			if (src instanceof byte[]) {
				return Arrays.hashCode((byte[])   src);
			} else if (src instanceof short[]) {
				return Arrays.hashCode((short[])  src);
			} else if (src instanceof int[]) {
				return Arrays.hashCode((int[])    src);
			} else if (src instanceof long[]) {
				return Arrays.hashCode((long[])   src);
			} else if (src instanceof char[]) {
				return Arrays.hashCode((char[])   src);
			} else if (src instanceof float[]) {
				return Arrays.hashCode((float[])  src);
			} else if (src instanceof double[]) {
				return Arrays.hashCode((double[]) src);
			} else if (src instanceof boolean[]) {
				return Arrays.hashCode((boolean[])src);
			} else {
				return Arrays.deepHashCode((Object[]) src);
			}
		} else {
			return src.hashCode();
		}
	}






















	@SuppressWarnings("unchecked")
	public static <T, C> C convert(T array, C convertArrayType) {
		return (C) convert(array, null == convertArrayType ?null: convertArrayType.getClass());
	}
	public static <T, C> C convert(T array, Class<C> convertArrayType) {
		if (null == array) {
			return null;
		}
		if (null == convertArrayType) {
			return null;
		}
		ArrayObject oriArr = ArrayObject.wrap(array);

		Class<?> componentType = convertArrayType.getComponentType();
		ArrayObject newArr = ArrayObject.wrap(Array.newInstance(componentType, Array.getLength(array)));

		oriArr.copy(0, newArr, 0, oriArr.length());

		C inner = (C) newArr.innerArray();

		return inner;
	}





	/**
	 * @param executor If executor returns null, it means the creation process is over
	 */
	public static <RETURN> RETURN[] create(RETURN[] array, Collectionz.Traverse<RETURN> executor) {
		Objects.requireNonNull(array, "array type");
		List<RETURN> list = new ArrayList<>();
		Collectionz.create(list, executor);
		return  list.toArray(array);
	}

	public static <RETURN, ELEMENT> RETURN[] filter(RETURN[] toType,
													Collectionz.Next<RETURN, ELEMENT> executor, ELEMENT[] filter) {
		return filter(toType, executor, filter, 0, null == filter ?0: filter.length);
	}
	public static <RETURN, ELEMENT> RETURN[] filter(RETURN[] toType,
													Collectionz.Next<RETURN, ELEMENT> executor, ELEMENT[] filter,
													int filter_offset, int filter_count) {
		Objects.requireNonNull(toType, "toType");

		List<RETURN> list = new ArrayList<>();
		Collectionz.filter(list, executor, filter, filter_offset, filter_count);
		return  list.toArray(toType);
	}




	public static void leftMove(long[] data, int position, int limit,
								int leftMove) {
		if (leftMove >= (limit - position)) {
			for (int i = position; i < limit; i++) {
				data[i] = 0;
			}
		} else {
			int ind = limit - leftMove;
			if (ind - position > 0) {
				System.arraycopy(data, limit - ind + position, data, position, ind - position);
			}
			for (int i = ind, ed = ind + leftMove; i < ed; i++) {
				data[i] = 0;
			}
		}
	}
	public static void rightMove(long[] data, int position, int limit,
								 int rightMove) {
		int len = limit - position;
		if (rightMove >= len) {
			for (int i = position; i < limit; i++) {
				data[i] = 0;
			}
		} else {
			if (len - rightMove > 0) {
				System.arraycopy(data, position, data, position + rightMove, len - rightMove);
			}
			for (int i = position, ed = position + rightMove; i < ed; i++) {
				data[i] = 0;
			}
		}
	}
}
