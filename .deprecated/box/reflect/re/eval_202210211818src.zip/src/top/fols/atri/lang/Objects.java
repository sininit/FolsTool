package top.fols.atri.lang;

import top.fols.atri.util.Throwables;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class Objects {


    private static final String INFINITY_REP = "Infinity";
    private static final String NAN_REP = "NaN";

    public static boolean isBoolean(String s) {return Finals.TRUE_STRING.equalsIgnoreCase(s) || Finals.FALSE_STRING.equals(s);}
    public static Boolean getBoolean(String s) {return ((s != null) && s.equalsIgnoreCase(Finals.TRUE_STRING));}

    public static boolean isChar(String s) {return ((s != null) && s.length() == 1);}
    public static Character getChar(String s) {return ((s != null) && s.length() == 1) ? s.charAt(0) : null;}

    public static boolean isShort(String s) {return isShort(s, 10);}
    public static boolean isShort(String s, int radix) {
        if (s == null) {
            return false;
        }

        if (radix < Character.MIN_RADIX) {
            return false;
        }

        if (radix > Character.MAX_RADIX) {
            return false;
        }

        int result = 0;
        boolean negative = false;
        int i = 0, len = s.length();
        int limit = -Short.MAX_VALUE;
        int multmin;
        int digit;

        if (len > 0) {
            char firstChar = s.charAt(0);
            if (firstChar < '0') { // Possible leading "+" or "-"
                if (firstChar == '-') {
                    negative = true;
                    limit = Short.MIN_VALUE;
                } else if (firstChar != '+')
                    return false;

                if (len == 1) // Cannot have lone "+" or "-"
                    return false;
                i++;
            }
            multmin = limit / radix;
            while (i < len) {
// Accumulating negatively avoids surprises near MAX_VALUE
                digit = Character.digit(s.charAt(i++), radix);
                if (digit < 0) {
                    return false;
                }
                if (result < multmin) {
                    return false;
                }
                result *= radix;
                if (result < limit + digit) {
                    return false;
                }
                result -= digit;
            }
        } else {
            return false;
        }
        return true;
    }

    public static Short getShort(String s) {
        return getShort(s, 10);
    }
    public static Short getShort(String s, int radix) {
        if (s == null) {
            return null;
        }

        if (radix < Character.MIN_RADIX) {
            return null;
        }

        if (radix > Character.MAX_RADIX) {
            return null;
        }

        short result = 0;
        boolean negative = false;
        int i = 0, len = s.length();
        int limit = -Short.MAX_VALUE;
        int multmin;
        int digit;

        if (len > 0) {
            char firstChar = s.charAt(0);
            if (firstChar < '0') { // Possible leading "+" or "-"
                if (firstChar == '-') {
                    negative = true;
                    limit = Short.MIN_VALUE;
                } else if (firstChar != '+')
                    return null;

                if (len == 1) // Cannot have lone "+" or "-"
                    return null;
                i++;
            }
            multmin = limit / radix;
            while (i < len) {
// Accumulating negatively avoids surprises near MAX_VALUE
                digit = Character.digit(s.charAt(i++), radix);
                if (digit < 0) {
                    return null;
                }
                if (result < multmin) {
                    return null;
                }
                result *= radix;
                if (result < limit + digit) {
                    return null;
                }
                result -= digit;
            }
        } else {
            return null;
        }
        return negative ? result : (short) -result;
    }

    public static boolean isByte(String s) {
        return isByte(s, 10);
    }
    public static boolean isByte(String s, int radix) {
        if (s == null) {
            return false;
        }

        if (radix < Character.MIN_RADIX) {
            return false;
        }

        if (radix > Character.MAX_RADIX) {
            return false;
        }

        byte result = 0;
        boolean negative = false;
        int i = 0, len = s.length();
        int limit = -Byte.MAX_VALUE;
        int multmin;
        int digit;

        if (len > 0) {
            char firstChar = s.charAt(0);
            if (firstChar < '0') { // Possible leading "+" or "-"
                if (firstChar == '-') {
                    negative = true;
                    limit = Byte.MIN_VALUE;
                } else if (firstChar != '+')
                    return false;

                if (len == 1) // Cannot have lone "+" or "-"
                    return false;
                i++;
            }
            multmin = limit / radix;
            while (i < len) {
// Accumulating negatively avoids surprises near MAX_VALUE
                digit = Character.digit(s.charAt(i++), radix);
                if (digit < 0) {
                    return false;
                }
                if (result < multmin) {
                    return false;
                }
                result *= radix;
                if (result < limit + digit) {
                    return false;
                }
                result -= digit;
            }
        } else {
            return false;
        }
        return true;
    }

    public static Byte getByte(String s) {
        return getByte(s, 10);
    }
    public static Byte getByte(String s, int radix) {
        if (s == null) {
            return null;
        }

        if (radix < Character.MIN_RADIX) {
            return null;
        }

        if (radix > Character.MAX_RADIX) {
            return null;
        }

        byte result = 0;
        boolean negative = false;
        int i = 0, len = s.length();
        int limit = -Byte.MAX_VALUE;
        int multmin;
        int digit;

        if (len > 0) {
            char firstChar = s.charAt(0);
            if (firstChar < '0') { // Possible leading "+" or "-"
                if (firstChar == '-') {
                    negative = true;
                    limit = Byte.MIN_VALUE;
                } else if (firstChar != '+')
                    return null;

                if (len == 1) // Cannot have lone "+" or "-"
                    return null;
                i++;
            }
            multmin = limit / radix;
            while (i < len) {
// Accumulating negatively avoids surprises near MAX_VALUE
                digit = Character.digit(s.charAt(i++), radix);
                if (digit < 0) {
                    return null;
                }
                if (result < multmin) {
                    return null;
                }
                result *= radix;
                if (result < limit + digit) {
                    return null;
                }
                result -= digit;
            }
        } else {
            return null;
        }
        return negative ? result : (byte) -result;
    }

    public static boolean isInteger(String s) {
        return isInteger(s, 10);
    }
    public static boolean isInteger(String s, int radix) {
        if (s == null) {
            return false;
        }

        if (radix < Character.MIN_RADIX) {
            return false;
        }

        if (radix > Character.MAX_RADIX) {
            return false;
        }

        int result = 0;
        boolean negative = false;
        int i = 0, len = s.length();
        int limit = -Integer.MAX_VALUE;
        int multmin;
        int digit;

        if (len > 0) {
            char firstChar = s.charAt(0);
            if (firstChar < '0') { // Possible leading "+" or "-"
                if (firstChar == '-') {
                    negative = true;
                    limit = Integer.MIN_VALUE;
                } else if (firstChar != '+')
                    return false;

                if (len == 1) // Cannot have lone "+" or "-"
                    return false;
                i++;
            }
            multmin = limit / radix;
            while (i < len) {
// Accumulating negatively avoids surprises near MAX_VALUE
                digit = Character.digit(s.charAt(i++), radix);
                if (digit < 0) {
                    return false;
                }
                if (result < multmin) {
                    return false;
                }
                result *= radix;
                if (result < limit + digit) {
                    return false;
                }
                result -= digit;
            }
        } else {
            return false;
        }
        return true;
    }

    public static Integer getInteger(String s) {
        return getInteger(s, 10);
    }
    public static Integer getInteger(String s, int radix) {
        if (s == null) {
            return null;
        }

        if (radix < Character.MIN_RADIX) {
            return null;
        }

        if (radix > Character.MAX_RADIX) {
            return null;
        }

        int result = 0;
        boolean negative = false;
        int i = 0, len = s.length();
        int limit = -Integer.MAX_VALUE;
        int multmin;
        int digit;

        if (len > 0) {
            char firstChar = s.charAt(0);
            if (firstChar < '0') { // Possible leading "+" or "-"
                if (firstChar == '-') {
                    negative = true;
                    limit = Integer.MIN_VALUE;
                } else if (firstChar != '+')
                    return null;

                if (len == 1) // Cannot have lone "+" or "-"
                    return null;
                i++;
            }
            multmin = limit / radix;
            while (i < len) {
// Accumulating negatively avoids surprises near MAX_VALUE
                digit = Character.digit(s.charAt(i++), radix);
                if (digit < 0) {
                    return null;
                }
                if (result < multmin) {
                    return null;
                }
                result *= radix;
                if (result < limit + digit) {
                    return null;
                }
                result -= digit;
            }
        } else {
            return null;
        }
        return negative ? result : -result;
    }

    public static boolean isLong(String s) {
        return isLong(s, 10);
    }
    public static boolean isLong(String s, int radix) {
        if (s == null) {
            return false;
        }

        if (radix < Character.MIN_RADIX) {
            return false;
        }
        if (radix > Character.MAX_RADIX) {
            return false;
        }

        long result = 0;
        boolean negative = false;
        int i = 0, len = s.length();
        long limit = -Long.MAX_VALUE;
        long multmin;
        int digit;

        if (len > 0) {
            char firstChar = s.charAt(0);
            if (firstChar < '0') { // Possible leading "+" or "-"
                if (firstChar == '-') {
                    negative = true;
                    limit = Long.MIN_VALUE;
                } else if (firstChar != '+')
                    return false;

                if (len == 1) // Cannot have lone "+" or "-"
                    return false;
                i++;
            }
            multmin = limit / radix;
            while (i < len) {
// Accumulating negatively avoids surprises near MAX_VALUE
                digit = Character.digit(s.charAt(i++), radix);
                if (digit < 0) {
                    return false;
                }
                if (result < multmin) {
                    return false;
                }
                result *= radix;
                if (result < limit + digit) {
                    return false;
                }
                result -= digit;
            }
        } else {
            return false;
        }
        return true;
    }

    public static Long getLong(String s) {
        return getLong(s, 10);
    }
    public static Long getLong(String s, int radix) {
        if (s == null) {
            return null;
        }

        if (radix < Character.MIN_RADIX) {
            return null;
        }
        if (radix > Character.MAX_RADIX) {
            return null;
        }

        long result = 0;
        boolean negative = false;
        int i = 0, len = s.length();
        long limit = -Long.MAX_VALUE;
        long multmin;
        int digit;

        if (len > 0) {
            char firstChar = s.charAt(0);
            if (firstChar < '0') { // Possible leading "+" or "-"
                if (firstChar == '-') {
                    negative = true;
                    limit = Long.MIN_VALUE;
                } else if (firstChar != '+')
                    return null;

                if (len == 1) // Cannot have lone "+" or "-"
                    return null;
                i++;
            }
            multmin = limit / radix;
            while (i < len) {
// Accumulating negatively avoids surprises near MAX_VALUE
                digit = Character.digit(s.charAt(i++), radix);
                if (digit < 0) {
                    return null;
                }
                if (result < multmin) {
                    return null;
                }
                result *= radix;
                if (result < limit + digit) {
                    return null;
                }
                result -= digit;
            }
        } else {
            return null;
        }
        return negative ? result : -result;
    }

    public static boolean isDouble(String s) {
        if (null == s)
            return false;
        int len = s.length();
        if (len == 0)
            return false;
        if (INFINITY_REP.equals(s) || NAN_REP.equals(s))
            return true;

        int i = 0;
        char firstChar = s.charAt(0);
        if (firstChar < '0') { // Possible leading "+" or "-"
            if (firstChar == '-') {
            } else if (firstChar != '+')
                return false;

            if (len == 1) // Cannot have lone "+" or "-"
                return false;
            i++;
        }
        int ec = 0, pc = 0, nc = 0;
        boolean e = false, p = false;
        while (i < len) {
            char ch = s.charAt(i);
            if (ch >= '0' && ch <= '9') {
                if (e)
                    ec++;
                else if (p)
                    pc++;
                else
                    nc++;
            } else if (ch == '.') {
                if (e)
                    return false;
                if (p)
                    return false;
                p = true;
            } else if (ch == 'e' || ch == 'E') {
                if (e)
                    return false;
                e = true;

                if (i + 1 < len) {
                    firstChar = s.charAt(i + 1);
                    if (firstChar == '-' || firstChar == '+') {
                        i++;
                    }
                }

            } else if (i == len - 1) {
                if (ch == 'f' || ch == 'F' ||
                        ch == 'd' || ch == 'D') {
                    break;
                }
                return false;
            } else
                return false;
            i++;
        }
        if (nc <= 0)
            return false;
        if (e)
            return ec != 0;
        return true;
    }
    public static Double getDouble(String in) {return isDouble(in) ? Double.parseDouble(in) : null;}

    public static boolean isFloat(String in) {return isDouble(in);}
    public static Float getFloat(String in) {return isDouble(in) ? Float.parseFloat(in) : null;}










    public interface Call<R, P>  { R call(P param);}
    public interface CallbackOneParam<T> { void callback(T param);}



    public static <T> T first(T[] obj) {
        return (null != obj && obj.length > 0) ? obj[0] : null;
    }
    public static <T> T last(T[] obj) {
        return (null != obj && obj.length > 0) ? obj[obj.length-1] : null;
    }

    public static <T> T first(List<T> obj) {
        return (null != obj && obj.size() > 0) ? obj.get(0) : null;
    }
    public static <T> T last(List<T> obj) {
        if (null == obj)
            return null;
        int    size = obj.size();
        return size > 0 ? obj.get(size - 1) : null;
    }





    public static <T> T requireNonNull(T obj) {
        if (null == obj) { throw new NullPointerException(); }
        return obj;
    }
    public static <T> T requireNonNull(T obj, String errorMessage) {
        if (null == obj) { throw new NullPointerException(errorMessage); }
        return obj;
    }


    public static void requireTrue(boolean obj) throws RuntimeException {
        if (!obj) { throw new RuntimeException("tip require = true"); }
    }
    public static void requireTrue(boolean obj, String errorMessage) throws RuntimeException {
        if (!obj) { throw new RuntimeException(errorMessage); }
    }


    public static void requireFalse(boolean obj) throws RuntimeException {
        if (obj) { throw new RuntimeException("tip require = false"); }
    }
    public static void requireFalse(boolean obj, String errorMessage) throws RuntimeException {
        if (obj) { throw new RuntimeException(errorMessage); }
    }







    public static boolean equals(Object obj, Object obj2) {
        if (null == obj) {
            return null == obj2;
        } else {
            return obj.equals(obj2);
        }
    }



    public static boolean empty(Map<?,?> obj) {return null == obj || obj.size() == 0;}
    public static boolean empty(Collection<?> obj) {return null == obj || obj.size() == 0;}
    public static boolean empty(Object[] obj) {return null == obj || obj.length == 0;}
    public static boolean empty(CharSequence obj) {return null == obj || obj.length() == 0;}
    public static boolean empty(long[] obj) {
        return null == obj || obj.length == 0;
    }
    public static boolean empty(int[] obj) {
        return null == obj || obj.length == 0;
    }
    public static boolean empty(short[] obj) {
        return null == obj || obj.length == 0;
    }
    public static boolean empty(byte[] obj) {
        return null == obj || obj.length == 0;
    }
    public static boolean empty(boolean[] obj) {
        return null == obj || obj.length == 0;
    }
    public static boolean empty(double[] obj) {
        return null == obj || obj.length == 0;
    }
    public static boolean empty(float[] obj) {
        return null == obj || obj.length == 0;
    }
    public static boolean empty(char[] obj) {return null == obj || obj.length == 0;}
    public static boolean empty(Object obj) { return null == obj; }










    public static boolean isDigit(String s) {
        if (null == s)
            return false;
        int length = s.length();
        if (length == 0)
            return false;
        int  i = 0;
        char c = s.charAt(0);
        if ( c == '+' || c == '-' )
             i = 1;
        for (; i< length; i++)
            if (!Character.isDigit(s.charAt(i)))
                return false;
        return true;
    }



    public static boolean isArray(Object object) {
        return null != object && object.getClass().isArray();
    }
    public static boolean isEnum(Object object) {
        return null != object && object.getClass().isEnum();
    }
    public static boolean isInstance(Object object, Class<?> type) {
        return Classz.isInstance(object, type);
    }
    public static boolean isInstance(Class<?> object, Class<?> type) {
        return Classz.isInstance(object, type);
    }





    public static String throwOrObjectToString(Object object) {
        if (null == object) {
            return String.valueOf((Object) null);
        } else if (object instanceof Throwable) {
            return Throwables.toStrings((Throwable) object);
        }
        return object.toString();
    }



    public static int identityHashCode(Object object) {
        return System.identityHashCode(object);
    }
    public static String identityToString(Object o) {
        return o.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(o));
    }





    public static int hashCode(Object object) {
        return null != object ? object.hashCode() : 0;
    }

    public static int hashCode(String clasz) {
        if (clasz == null)
            return 0;
        return clasz.hashCode();
    }

    public static int hashCode(Class<?> clasz) {
        if (clasz == null)
            return 0;
        return clasz.getName().hashCode();
    }
    public static int hashCode(Class<?>[] classes) {
        if (classes == null)
            return 0;

        int result = 1;

        for (Class<?> element : classes)
            result = 31 * result + (element == null ? 0 : element.getName().hashCode());

        return result;
    }



    public static boolean classesEquals(Class<?>[] parameterTypes, Class<?>[] parameterTypes2) {
        if (parameterTypes.length != parameterTypes2.length) { return false;}
        for (int i = 0; i < parameterTypes.length; i++) {
            if (parameterTypes[i] != parameterTypes2[i]) {
                return false;
            }
        }
        return true;
    }




    public static boolean and(boolean... value) {
        if (null == value || value.length == 0) { return false; }
        for (boolean object: value) {
            if (!object) {
                return false;
            }
        }
        return true;
    }
    public static boolean or(boolean... value) {
        if (null == value || value.length == 0) { return false; }
        for (boolean object: value)
            if(object)
                return true;
        return false;
    }











    public static String toString(Object obj) {
        return null == obj?null:obj.toString();
    }

    public static char toChar(Object obj) {
        if (null == obj) {return (char)0;}
        if (obj instanceof Character) {return (Character) obj;}
        String str = obj.toString();
        return 0 == str.length() ?(char)0: str.charAt(0);
    }

    public static boolean toBoolean(Object obj) {
        if (null == obj) {return false;}
        if (obj instanceof Boolean) {return (Boolean) obj;}
        return Boolean.parseBoolean(obj.toString().trim());
    }



    public static byte toByte(Object obj) {
        if (null == obj) {return 0;}
        if (obj instanceof Number) {return ((Number) obj).byteValue();}
        return Byte.parseByte(obj.toString().trim());
    }

    public static int toInt(Object obj) {
        if (null == obj) {return 0;}
        if (obj instanceof Number) {return ((Number) obj).intValue();}
        return Integer.parseInt(obj.toString().trim());
    }

    public static long toLong(Object obj) {
        if (null == obj) {return 0;}
        if (obj instanceof Number) {return ((Number) obj).longValue();}
        return Long.parseLong(obj.toString().trim());
    }

    public static short toShort(Object obj) {
        if (null == obj) {return 0;}
        if (obj instanceof Number) {return ((Number) obj).shortValue();}
        return Short.parseShort(obj.toString().trim());
    }

    /**
     * xx.xxx
     **/
    public static double toDouble(Object obj) {
        if (null == obj) {return 0;}
        if (obj instanceof Number) {return ((Number) obj).doubleValue();}
        return Double.parseDouble(obj.toString().trim());
    }

    /**
     * xx.xxx
     **/
    public static float toFloat(Object obj) {
        if (null == obj) {return 0;}
        if (obj instanceof Number) {return ((Number) obj).floatValue();}
        return Float.parseFloat(obj.toString().trim());
    }










    /*
     * parse tip Object[] byte[] long[] double[] char[] int[] boolean[] float[] short[]
     */

    public static String parseString(Object value) {
        return String.valueOf(value);
    }

    public static boolean parseBoolean(Object value) {
        if (value instanceof Boolean) return (Boolean)value;
        return null != value && "true".equalsIgnoreCase(value.toString().trim());
    }

    public static byte parseByte(Object value) {
        if (null == value) { return 0; }
        if (value instanceof Number) return ((Number)value).byteValue();
        String st = retainNum(st = value.toString(), 0, st.length());
        return st.length() == 0 ? 0 : Byte.parseByte(st);
    }

    public static char parseChar(Object value) {
        if (value instanceof Character) return (Character)value;
        String st;
        return (null != value && (st = value.toString()).length() > 0) ?st.charAt(0): (char)0;
    }

    public static short parseShort(Object value) {
        if (null == value) { return 0; }
        if (value instanceof Number) return ((Number)value).shortValue();
        String st = retainNum(st = value.toString(), 0, st.length());
        return st.length() == 0 ? 0 : Short.parseShort(st);
    }

    public static int parseInt(Object value) {
        if (null == value) { return 0; }
        if (value instanceof Number) return ((Number)value).intValue();
        String st = retainNum(st = value.toString(), 0, st.length());
        return st.length() == 0 ? 0 : Integer.parseInt(st);
    }

    public static long parseLong(Object value) {
        if (null == value) { return 0; }
        if (value instanceof Number) return ((Number)value).longValue();
        String st = retainNum(st = value.toString(), 0, st.length());
        return st.length() == 0 ? 0 : Long.parseLong(st);
    }


    public static float parseFloat(Object value) {
        if (null == value) { return 0; }
        if (value instanceof Number) return ((Number)value).floatValue();
        String st = retainDouble(st = value.toString(), 0, st.length());
        return st.length() == 0 ? 0 : Float.parseFloat(st);
    }

    public static double parseDouble(Object value) {
        if (null == value) { return 0; }
        if (value instanceof Number) return ((Number)value).doubleValue();
        String st = retainDouble(st = value.toString(), 0, st.length());
        return st.length() == 0 ? 0 : Double.parseDouble(st);
    }








    /**
     *
     * read String first num
     * @see top.fols.atri.lang.Strings#retain(CharSequence, int, int, char[])
     */
    public static String retainNum(CharSequence str, int off, int len) {
        char[] buf = new char[20];// long max string len = 20
        int bufindex = 0, bufsize = 0;
        char ch;
        for (int i = off; i < off + len; i++) {
            ch = str.charAt(i);
            if (ch == '+' || ch == '-' || (ch >= '0' && ch <= '9')) {
                int minCapacity = bufindex + 1;
                if (minCapacity - buf.length > 0) {
                    int oldCapacity = buf.length;
                    int newCapacity = oldCapacity << 1;
                    if (newCapacity - minCapacity < 0) {
                        newCapacity = minCapacity;
                    }
                    if (newCapacity < 0) {
                        if (minCapacity < 0) {
                            // overflow
                            throw new OutOfMemoryError();
                        }
                        newCapacity = Integer.MAX_VALUE;
                    }
                    buf = Arrays.copyOf(buf, newCapacity);
                }

                buf[bufindex++] = ch;
                bufsize++;
            } else if (bufindex > 0) {// interrupt
                break;
            }
        }
        return new String(buf, 0, bufsize);
    }

    /**
     *
     * read String first num
     * @see top.fols.atri.lang.Strings#retain(CharSequence, int, int, char[])
     */
    public static String retainDouble(CharSequence str, int off, int len) {
        char[] buf = new char[64];
        int bufindex = 0, bufsize = 0;
        char ch;
        for (int i = off; i < off + len; i++) {
            ch = str.charAt(i);
            if (ch == '+' || ch == '-' || (ch >= '0' && ch <= '9') ||
                    ch == '.' ||
                    ch == 'e' || ch == 'E' || ch == 'f' || ch == 'F' || ch == 'd' || ch == 'D') {
                int minCapacity = bufindex + 1;
                if (minCapacity - buf.length > 0) {
                    int oldCapacity = buf.length;
                    int newCapacity = oldCapacity << 1;
                    if (newCapacity - minCapacity < 0) {
                        newCapacity = minCapacity;
                    }
                    if (newCapacity < 0) {
                        if (minCapacity < 0) {
                            // overflow
                            throw new OutOfMemoryError();
                        }
                        newCapacity = Integer.MAX_VALUE;
                    }
                    buf = Arrays.copyOf(buf, newCapacity);
                }

                buf[bufindex++] = ch;
                bufsize++;
            } else if (bufindex > 0) {// interrupt
                break;
            }
        }
        return new String(buf, 0, bufsize);
    }

}
