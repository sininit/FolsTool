package top.fols.box.reflect.re;

import top.fols.atri.lang.Value;
import top.fols.atri.util.annotation.Nullable;
import top.fols.box.reflect.re.interfaces.*;
import top.fols.atri.util.annotation.NotNull;

import static top.fols.box.reflect.re.Re_ClassFunction.getArgumentsArrayAsVariableMap;
import static top.fols.box.reflect.re.Re_CodeLoader.SUB_CLASS_SEPARATOR;
import static top.fols.box.reflect.re.Re_CodeLoader.PACKAGE_SEPARATOR_STRING;

/**
 * 理论上来讲这不是一个类 它就像是
 * import java.lang.String;
 * 里的 String, 直接操作String 的功能 比如 String.trim();
 *
 * 你可以称这个{@link Re_Class}为 {类操作}
 * 请勿重写
 */
@SuppressWarnings({"SynchronizeOnNonFinalField", "rawtypes"})
public class Re_Class implements Re_IReObject, Re_IReInnerVariableMap, Re_IReGetDeclaringClass, Re_IReGetClass {
    Re_Class() {}


    /**
     * 为空则代表是一个顶级类
     * 本类来自哪个类 一个文件里的第二个类? 也就是说 这是值上一水平的类    创建时复制 不可修改
     */
    //
    private Re_Class reClassDeclaringClass;
    /**
     * 类名, 不可改
     */
    //
    private String reClassName;







    //在什么地方声明的这个类
    private Re_Executor parent;

    private Re_CodeFile reCodeBlock;


    private Re_ClassLoader reClassLoader;
    //类变量
    private Re_IReInnerVariableMap variable;




    /**
     * 创建顶级类或者子类
     *
     * @param name             确定的类名
     * @param reCodeBlock      代码
     * @param reDeclaringClass 所属的类，也就是说是谁的子类
     */
    static Re_Class createReClass(Re_Executor parent,
                                  @Nullable String name, @NotNull Re_CodeFile reCodeBlock,
                                  Re_Class reDeclaringClass) {
        return createAfter(new Re_Class(), parent, name, reCodeBlock, reDeclaringClass);
    }

    static Re_Class createAfter(@NotNull Re_Class newReClass,

                                Re_Executor parent,
                                @Nullable String name, @NotNull Re_CodeFile reCodeBlock,
                                @Nullable Re_Class reDeclaringClass) {
        newReClass.reClassDeclaringClass = reDeclaringClass;
        if (null == name) {
            newReClass.reClassName = Re_CodeLoader.intern(
                    (null == reDeclaringClass ? "" : reDeclaringClass.getName() + SUB_CLASS_SEPARATOR) + (Re_Keywords.INNER_EXPRESSION_CALL__CLASS +"_"+reCodeBlock.getLineOffset()+"_" + Integer.toHexString(newReClass.hashCode())) );    //匿名类
            newReClass.isAnonymous = true;
        } else {
            newReClass.reClassName = Re_CodeLoader.intern(
                    (null == reDeclaringClass ? "" : reDeclaringClass.getName() + SUB_CLASS_SEPARATOR) + name);  // 主类 or 子类
            newReClass.isAnonymous = false;
        }
        newReClass.reCodeBlock = reCodeBlock;
        newReClass.parent = parent;
        newReClass.variable = new Re_ZVariableMap();

        newReClass.initializeIsRun = false;
        newReClass.initializedLock = new Object();
        newReClass.initializeStaticObject = null;
        return newReClass;
    }














    @Override
    public final Re_Class getReClass() {
        return this;
    }
    @Override
    public final Re_Class getReDeclareClass() {
        return reClassDeclaringClass;
    }


    private String simple_name0;
    public final String getReClassSimpleName() {
        if (null == simple_name0) {
            String name = reClassName;
            int index = name.lastIndexOf(PACKAGE_SEPARATOR_STRING);
            if (index > -1) {
                name = name.substring(index + PACKAGE_SEPARATOR_STRING.length(), name.length());
            }
            int i = name.lastIndexOf(SUB_CLASS_SEPARATOR);
            if (i > -1) {
                name = name.substring(i + SUB_CLASS_SEPARATOR.length(), name.length());
            }
            simple_name0 = Re_CodeLoader.intern(name);
        }
        return simple_name0;
    }

    private Value<String> package_name0;
    public final String getReClassPackageName() {
        if (null == package_name0) {
            String name = reClassName;
            int index = name.lastIndexOf(PACKAGE_SEPARATOR_STRING);
            if (index > -1) {
                name = Re_CodeLoader.intern(name.substring(0, index));
            } else {
                name = null;
            }
            package_name0 = new Value<>(Re_CodeLoader.intern(name));
        }
        return package_name0.get();
    }

    @Override
    public final String getName() {
        return reClassName;
    }

    public final Re_ClassLoader getReClassLoader() {
        return reClassLoader;
    }
    /**
     * 只是设置 并没有实际意义
     * 类加载器将不会有任何变动
     * 不可用重复执行
     *
     * @param classLoader 类加载器
     */
    protected final void        setReClassLoader(Re_ClassLoader classLoader) {
        if (null != this.reClassLoader) {
            throw new Re_Accidents.ExecuteException("already resolve loader");
        }
        this.reClassLoader = classLoader;
    }

    /**
     * 断开类加载器
     */
    protected final void disconReClassLoader() {
        reClassLoader = null;
    }

    /**
     * 获取代码块
     */
    protected final Re_CodeFile getCodeBlock() {
        return reCodeBlock;
    }















    private boolean isAnonymous;
    public boolean isAnonymous() {
        return isAnonymous;
    }




    private Re_ClassFunction initFunction = null;
    /**
     * 在类被初始化时设置
     */
    public final Re_ClassFunction getInitFunction() {
        return  initFunction;
    }
    public final void setInitFunction(Re_ClassFunction initFunction) {
        if (!initialized) {
            this.initFunction = initFunction;
        }
    }






    /**
     * 如果已经初始化过这个类 则返回null 结果
     * 一般用于class函数 和 re_classloader 编译加载类
     */
    @SuppressWarnings("ConstantConditions")
    static void runReClassInitialize0(@NotNull Re host, Re_NativeStack stack, @NotNull Re_CodeFile block,
                                      @NotNull Re_Class re_class) {
        if (stack.isThrow())
            return;  //已经异常

        if (null == re_class) {
            stack.setThrow(Re_Accidents.reclass_initialize_failed(re_class));
            return;
        }

        re_class.initializeStaticObject(host, stack, block);
        //最后一行不需要判断return
    }






    //primitive class是在Java里 的 理论上不需要初始化
    static void setPrimitiveClassInitialized(Re_PrimitiveClass primitiveClass) {
        synchronized (primitiveClass.initializedLock) {
            primitiveClass.initializeStaticObject = primitiveClass;
            primitiveClass.initializeIsRun = true;
            primitiveClass.initialized = true;
        }
    }


    boolean initialized;
    public final boolean isInitialized() {
        return initialized;
    }

    /**
     * 不要修改
     */
    Object              initializedLock;
    boolean             initializeIsRun;                //只是执行过不是代表已经初始化成功了
    Re_Class            initializeStaticObject;         //如果初始化成功则为自己
    final Object initializeStaticObject(@NotNull Re host, Re_NativeStack stack, @NotNull Re_CodeFile block) {
        if (stack.isThrow())        //一个栈只能一个线程用
            return null;

        //该类的 唯一锁
        synchronized (initializedLock) {
            Object result = null;
            if (initializeIsRun) {
                if (null == initializeStaticObject) {
                    return null;//类初始化失败
                }
            } else {
                initializeStaticObject = this;
                initializeIsRun = true;

                boolean run = false;
                try {
                    Re_Executor re_executor = Re_Executor.createReClassInitializeExecutor(host, stack, block, this);
                    if (null != re_executor) {  //获取执行器成功
                        if (!re_executor.isThrow()) {   //没有出错
                            result = re_executor.run(); //执行所有代码
                            if (!re_executor.isThrow()) {   //执行所有代码没有出错
                                run = true;
                            }
                        }
                    }
                } finally {
                    if (run) {
                        initialized = true;
                    } else {
                        initializeStaticObject = null;
                        // noinspection ConstantConditions
                        initializeIsRun = initializeIsRun;
                    }
                }
            }
            return result;
        }
    }












    public Re_ClassInstance createInstance() {
        return createInstance(this);
    }
    public Re_ClassInstance createInstance(Re_Class reClass) {
        return new Re_ClassInstance(reClass);
    }




    /**
     * @see #createInstance()
     */
    protected static void createInstanceAfter(Re_Class runClass, Re_ClassInstance instance, Re_IReInnerVariableMap variableMap) {
        instance.reClass = runClass;
        instance.variable = variableMap;
    }



    public boolean isTopClass() {
        return null == reClassDeclaringClass;
    }



    @Override
    public boolean equals(Object o) {
        return this == o;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public String toString() {
//        if (isTopClass())
//            return Re_CodeLoader.CallCreateClass.wrapTopClass(this);
//        else
//            return Re_CodeLoader.CallCreateClass.wrapSubClass(this);
        return "re-" + Re_Keywords.INNER_EXPRESSION_CALL__CLASS + ": " + getName();
    }

    @Override
    public boolean isPrimitive() {
        return false;
    }





    @Override
    public Re_Variable innerRemoveVariable(Object key) {
        return variable.innerRemoveVariable(key);
    }

    @Override
    public Re_Variable innerFindMapOrParentVariable(Object key) {
        Re_Variable re_variable = variable.innerFindMapOrParentVariable(key);
        if (null == re_variable)
            if (null != parent)
                re_variable = parent.innerFindMapOrParentVariable(key);
        return re_variable;
    }

    @Override
    public Re_Variable innerFindMapVariable(Object key) {
        return variable.innerFindMapVariable(key);
    }

    @Override
    public Re_Variable innerGetVariable(Object key) {
        return variable.innerGetVariable(key);
    }

    @Override
    public Re_Variable innerPutVariable(Object key, Re_Variable value) {
        return variable.innerPutVariable(key, value);
    }


    @Override
    public boolean innerContainsVariable(Object key) {
        return variable.innerContainsVariable(key);
    }

    @Override
    public int innerGetVariableCount() {
        return variable.innerGetVariableCount();
    }

    @Override
    public Iterable<?> innerGetVariableKeys() {
        return variable.innerGetVariableKeys();
    }

    @Override
    public Re_IReInnerVariableMap innerCloneVariableMap() {
        return variable.innerCloneVariableMap();
    }











    //------------------------------------------
    @Override
    public final Object getVariableValue(Re_Executor executor, Object key) throws Throwable {
        return Re_Variable.accessFindMapValue(executor, key, this);
    }
    @Override
    public final boolean containsVariable(Re_Executor executor, Object key) throws Throwable {
        return Re_Variable.has(key, this);
    }
    @Override
    public final boolean removeVariable(Re_Executor executor, Object key) throws Throwable {
        return Re_Variable.accessRemove(executor, key, this);
    }
    @Override
    public final void putVariableValue(Re_Executor executor, Object key, Object value) throws Throwable {
        Re_Variable.accessSetValue(executor, key, value, this);
    }

    @Override
    public final int getVariableCount(Re_Executor executor) throws Throwable {
        return Re_Variable.size(this);
    }

    @Override
    public final @NotNull Iterable getVariableKeys(Re_Executor executor) throws Throwable {
        return Re_Variable.key(this );
    }


    @Override
    public final Object executePoint(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
        Object funCall = Re_Variable.accessFindMapValue(executor, point_key, this);
        if (executor.isReturnOrThrow()) return null;

        if (Re_Utilities.isReFunction(funCall)) {
            Re_ClassFunction reClassFunction = (Re_ClassFunction) funCall;

            Object[] arguments = executor.getExpressionValues(call);
            if (executor.isReturnOrThrow()) return null;

            return invoke(executor, reClassFunction, arguments);
        }
        if (null == funCall) {
            executor.setThrow(Re_Accidents.undefined(this, point_key));
            return null;
        }
        return executor.executeCallThis(funCall, point_key, call);
    }
    @Override
    public final Re_ClassInstance executeThis(Re_Executor executor, String that_key, Re_CodeLoader.Call call) throws Throwable {
        Object[] arguments = executor.getExpressionValues(call);
        if (executor.isReturnOrThrow()) return null;

        Re_ClassFunction initFunction = getInitFunction();//获取初始化方法
        return newInstance(executor, initFunction, arguments);
    }






    protected Object invoke(Re_Executor executor, Re_ClassFunction function, Object[] arguments) throws Throwable {
        Re_IReInnerVariableMap variableMap = getArgumentsArrayAsVariableMap(arguments, function);
        //最后一行 不需要判断return
        //指定某个实例运行特定方法, 这个方法不一定是在这个类声明的 但是可以强制运行
        return function.invoke(executor, this, null, arguments, variableMap);
    }
    @SuppressWarnings("IfStatementWithIdenticalBranches")
    protected Re_ClassInstance newInstance(Re_Executor executor, Re_ClassFunction initFunction, Object[] arguments) throws Throwable {
        Re_ClassInstance newInstance  = createInstance(); //创建实例
        if (null == initFunction) {
            return newInstance;
        } else {
            Re_IReInnerVariableMap variableMap = getArgumentsArrayAsVariableMap(arguments, initFunction);
            initFunction.invoke(executor, this, newInstance, arguments, variableMap);
            return newInstance; //最后一行 不需要判断return
        }
    }

    //------------------------------------------








//    static public final String INNER_FUNCTION__FINAL                = "final";
//        Re_Variable.UnsafeVariable.addFinalValueIntern(new Re_IReObject.IPrimitiveCall(INNER_FUNCTION__FINAL) {
//        final String text =
//                "use final(variable_manager, name, tip);\n"+
//                        "use final(name, tip);"+
//                        "name is string or other";
//        @Override
//        public Object executeThis(Re_Executor executor, String that_key, Re_CodeLoader.Call call) throws Throwable {
//            int paramExpressionCount = call.getParamExpressionCount();
//            if (paramExpressionCount == 2) {
//
//                Object nameValue = executor.getExpressionValue(call, 0);
//                if (executor.isReturnOrThrow()) return null;
//                String name   = Re_Utilities.toString(nameValue);
//                if (null == name) {
//                    executor.setThrow(text);
//                    return null;
//                }
//
//                Object value = executor.getExpressionValue(call, 1);
//                if (executor.isReturnOrThrow()) return null;
//
//                Re_Variable.accessAddFinalValueIntern(executor, name, value, executor);
//                return value;
//            }
//            if (paramExpressionCount == 3) {
//                Object temp = executor.getExpressionValue(call, 0);
//                if (executor.isReturnOrThrow()) return null;
//
//                if (!(temp instanceof Re_IReInnerVariableMap)) {
//                    executor.setThrow(text);
//                    return null;
//                }
//                Re_IReInnerVariableMap iVariableMap = (Re_IReInnerVariableMap) temp;
//
//                Object nameValue = executor.getExpressionValue(call, 1);
//                if (executor.isReturnOrThrow()) return null;
//                String name   = Re_Utilities.toString(nameValue);
//                if (null == name) {
//                    executor.setThrow(text);
//                    return null;
//                }
//
//                Object value = executor.getExpressionValue(call, 2);
//                if (executor.isReturnOrThrow()) return null;
//
//                Re_Variable.accessAddFinalValueIntern(executor, name, value, iVariableMap);
//                return value;
//            }
//            executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, paramExpressionCount));
//            return null;
//        }
//    }, keyword);



    //------------------------------------------


    /**
     * 在Java里执行
     */
    public static class Unsafes {
        public static void directSetClassValue(Re_ClassInstance instance, String name, Object value) {
            if (null == instance) {
                return;
            }
            Re_Variable.Unsafes.fromUnsafeAccessorSetValueIntern(name, value, instance);
        }

        public static void directSetInstanceValue(Re_ClassInstance instance, String name, Object value) {
            if (null == instance) {
                return;
            }
            Re_Variable.Unsafes.fromUnsafeAccessorSetValueIntern(name, value, instance);
        }

        public static Object directGetInstanceOrClassValue(Re_Class reClass, Re_ClassInstance instance, String name) {
            Object v;
            if (null == instance) {
                if (null == reClass) {
                    throw new NullPointerException("reClass is null");
                }
                v = Re_Variable.Unsafes.fromUnsafeAccessorGetClassValue(name, reClass);
            } else {
                v = Re_Variable.Unsafes.fromUnsafeAccessorGetInstanceValue(name, instance);
            }
            return v;
        }








        public static Re_ClassFunction directGetFunctionValue(Re_Class reClass, Re_ClassInstance instance, String name) {
            Object v = directGetInstanceOrClassValue(reClass, instance, name);

            if (Re_Utilities.isReFunction(v)) {
                return (Re_ClassFunction) v;
            }

            throw new IllegalArgumentException("[" + Re_Utilities.getName(v) + "] is not a ReFunction: " + name);
        }


        /**
         * 非法访问
         */
        public static Object directExecuteFunction(Re re, Re_Class reClass, Re_ClassInstance instance, Re_ClassFunction function, Object[] params) throws Throwable {
            return directExecuteFunction(re, reClass, instance, function, params, null);
        }
        public static Object directExecuteFunction(Re re, Re_Class reClass, Re_ClassInstance instance, Re_ClassFunction function, Object[] params, @Nullable Re_IReInnerVariableMap variableMap) throws Throwable {
            Re_NativeStack stack = Re_NativeStack.newStack();
            return directExecuteFunction(re, stack, reClass, instance, function, params, variableMap);
        }


        public static Object directExecuteFunction(Re re, Re_NativeStack stack, Re_Class reClass, Re_ClassInstance instance, Re_ClassFunction function, Object[] params) throws Throwable {
            return directExecuteFunction(re, stack, reClass, instance, function, params, null);
        }
        /**
         * 这里会创建两次执行器
         */
        public static Object directExecuteFunction(Re re, Re_NativeStack stack,
                                                   Re_Class reClass, Re_ClassInstance reClassInstance, Re_ClassFunction invokeFunction,
                                                   Object[] params, @Nullable Re_IReInnerVariableMap variableMap) throws Throwable {
            if (null == reClass) {
                throw new NullPointerException("reClass");
            }
            if (null == variableMap) {
                variableMap = getArgumentsArrayAsVariableMap(params, invokeFunction);
            }
            //reClassExecutorAccessor executor
            Re_Executor reClassExecutorAccessor = Re_Executor.createReClassFunctionExecutor(re, stack, reClass, reClassInstance, invokeFunction, params, variableMap);
            if (stack.isThrow()) {
                Re.throwStackException(stack);
            }
            if (null == reClassExecutorAccessor) {
                throw new NullPointerException("build executor fail");
            }

            //必须调用, 否者primitiveFunction将无法执行
            Object o = invokeFunction.invoke(reClassExecutorAccessor, reClass, reClassInstance, params, variableMap);
            if (stack.isThrow()) {
                Re.throwStackException(stack);
            }
            return o;
        }


        /**
         * 非法访问
         */
        public static Re_ClassInstance directCreateInstance(Re re, Re_Class reClassz, Object[] params) throws Throwable {
            return directCreateInstance(re, reClassz, params, null);
        }
        public static Re_ClassInstance directCreateInstance(Re re, Re_Class reClassz, Object[] params, @Nullable Re_IReInnerVariableMap variableMap) throws Throwable {
            if (null == reClassz) {
                throw new NullPointerException("reClass is null");
            }
            Re_ClassInstance instance = reClassz.createInstance();

            Re_ClassFunction initFunction = reClassz.getInitFunction();
            if (null == initFunction) {
                return  instance;
            }

            directExecuteFunction(re, reClassz, instance, initFunction, params, variableMap);

            return instance;
        }




        /**
         * 创建一个实例方法
         *
         * @param reClass           类
         * @param reClassInstance   类实例
         * @param expression        方法代码不需要声明参数之类的
         */
        private static Re_ClassFunction directCreateFunction(Re re, Re_Executor parent, Re_Class reClass, Re_ClassInstance reClassInstance, String expression) {
            Re_CodeFile code = re.compileCode(expression);
            return Re_ClassFunction.createReFunction(code, null,null,
                    parent, reClass, reClassInstance);
        }
        /**
         * 直接将代码运行在类中
         *
         * @param parent          父执行器 可空
         * @param re              主体
         * @param reClass         类
         * @param reClassInstance 类实例
         * @param expression      方法内的表达式
         */
        public static Object directRunOnReClass(@Nullable Re_Executor parent,
                                                Re re, Re_NativeStack stack,
                                                @Nullable Re_Class reClass, @Nullable Re_ClassInstance reClassInstance,
                                                String expression, Object[] params) throws Throwable {
            Re_ClassFunction function = directCreateFunction(re, parent, reClass, reClassInstance, expression);
            return directExecuteFunction(re, stack, reClass, reClassInstance, function, params);
        }








        static Re_Executor createAnonymousExecutor(Re re, Re_NativeStack stack) {
            return Re_Executor.createReRootExecutor(
                    re, stack,
                    Re_CodeFile.create(Re_CodeFile.FILE_NAME__ANONYMOUS, Re_CodeFile.LINE_OFFSET),
                    null, null);
        }
        public static Object directAnonymousExecutePointFunction(Re re, Re_NativeStack stack,
                                                                 Re_Class reClass, Re_ClassInstance reClassInstance, String functionName, Object[] args) throws Throwable {
            Re_Executor executor = createAnonymousExecutor(re, stack);
            if (null == reClass && null == reClassInstance)
                throw new RuntimeException("null object");

            Re_ClassFunction function = directGetFunctionValue(reClass, reClassInstance, functionName);

            Object ret;
            if (null != reClassInstance) {
                ret = reClassInstance.invoke(executor, function, args);
            } else {
                ret = reClass.invoke(executor, function, args);
            }
            Re.throwStackException(executor);
            return ret;
        }
        public static Object directAnonymousExecuteFunction(Re re, Re_NativeStack stack,
                                                            Re_ClassFunction function, Object[] args) throws Throwable {
            Re_Executor executor = createAnonymousExecutor(re, stack);
            if (null == function)
                throw new RuntimeException("null function");

            Object o = function.invokeFromDeclare(executor, args);
            Re.throwStackException(executor);
            return o;
        }
    }









    protected void addFunctionToStatic(String name, Re_ClassFunction function) {
        Re_Variable.Unsafes.addVariableIntern(name, Re_Variable.createVar(function), this);
    }

    public static class RuntimeUtils {

        /**
         * 运行时动态创建
         */
        @NotNull
        public static Re_Class createReClassAndInitialize(final Re_Executor executor,
                                                          @Nullable String className,
                                                          int lineOffset,
                                                          @NotNull Re_CodeLoader.Expression[] expressions) {
            Re_CodeFile block        = new Re_CodeFile();
            block.expressions        = expressions;
            block.expressionsOffset  = 0;
            block.filePath           = executor.reCodes.getFilePath();
            block.lineOffset         = lineOffset;
            block.constManager       = executor.reCodes.getConstManager();

            //内部类
            Re_Class reDeclaringClass = executor.reClass;
            Re_Class newClass = createReClass(executor, className, block, reDeclaringClass);

            if (null != reDeclaringClass)
                newClass.setReClassLoader(reDeclaringClass.reClassLoader);

            if (null != className && null != reDeclaringClass) {
                Re_Variable.accessSetValue(executor, className, newClass, executor);
                if (executor.isReturnOrThrow()) return null;
            }

            runReClassInitialize0(executor.re, executor.getStack(), block, newClass);
            if (executor.isReturnOrThrow()) return null;

            return newClass;
        }

        @NotNull
        static Re_ClassFunction createReFunction(final Re_Executor executor,
                                                 int lineOffset,
                                                 @Nullable String functionName, @Nullable String[] functionParamNameArray,    @Nullable Re_CodeLoader_ExpressionConverts.CallFunction.FunParamTypesElement[] functionParamTypes,
                                                 @Nullable Re_CodeLoader.Var[] returnType,
                                                 @NotNull  Re_CodeLoader.Expression[] expressions) {
            Re_CodeFile block        = new Re_CodeFile();
            block.expressions        = expressions;
            block.expressionsOffset  = 0;
            block.filePath           = executor.reCodes.getFilePath();
            block.lineOffset         = lineOffset;
            block.constManager       = executor.reCodes.getConstManager();

            if (null == functionName || functionName.length() == 0)
                functionName = null;

            Re_Class         declaringClass           = executor.reClass;
            Re_ClassInstance declaringClassInstance   = executor.reClassInstance;

            Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker[] functionParamCheckers = Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker.createParamTypesCheckerFromExecutor(executor, functionParamTypes);
            if (executor.isReturnOrThrow()) return null;

            Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker   functionReturnChecker = Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker.createReturnTypeCheckerFromExecutor(executor, returnType);
            if (executor.isReturnOrThrow()) return null;

            Re_ClassFunction function =
                    null == functionParamCheckers && null == functionReturnChecker
                            ? Re_ClassFunction.createReFunction(block,
                                functionName, functionParamNameArray,
                                executor,
                                declaringClass, declaringClassInstance)
                            : Re_ClassFunction.createReParamCheckerFunction(block,
                                functionName, functionParamNameArray, functionParamCheckers, functionReturnChecker,
                                executor,
                                declaringClass, declaringClassInstance);
            if (null != functionName) {
                Re_Variable.accessSetValue(executor, functionName, function, executor);
                if (executor.isReturnOrThrow()) return null;
            }
            return function;
        }


        /**
         * 运行时动态创建
         */
        @NotNull
        public static Re_ClassFunction createReInheritFunction(final Re_Executor executor,
                                                               @Nullable String functionName,
                                                               int lineOffset,
                                                               @NotNull Re_CodeLoader.Expression[] expressions) {
            Re_CodeFile block        = new Re_CodeFile();
            block.expressions        = expressions;
            block.expressionsOffset  = 0;
            block.filePath           = executor.reCodes.getFilePath();
            block.lineOffset         = lineOffset;
            block.constManager       = executor.reCodes.getConstManager();

            if (null == functionName || functionName.length() == 0)
                functionName = null;

            Re_Class         declaringClass           = executor.reClass;
            Re_ClassInstance declaringClassInstance   = executor.reClassInstance;
            Re_ClassFunction function = Re_ClassFunction.createReInheritFunction(block, functionName, executor,
                    declaringClass, declaringClassInstance);

            if (null != functionName) {
                Re_Variable.accessSetValue(executor, functionName, function, executor);
                if (executor.isReturnOrThrow()) return null;
            }
            return function;
        }
    }




    static boolean  instanceOfReClass(Object instance, Re_Class c) {
        if (null != instance) {
            if (Re_Utilities.isReClassInstance(instance)) {
                Re_ClassInstance reClassInstance = (Re_ClassInstance) instance;
                return reClassInstance.reClass == c;
            }
        }
        return false;
    }
    static boolean  instanceOfReClassFromParam(Object param, Re_Class c) {
        if (null == param) {
            return true;
        }
        if (Re_Utilities.isReClassInstance(param)) {
            Re_ClassInstance reClassInstance = (Re_ClassInstance) param;
            return reClassInstance.reClass == c;
        }
        return false;
    }
}











//        /**
//         * {@link Re_CodeLoader.RuntimeUtils.Expressions}
//         */
//        public static final String INNER_MATH_FUNCTION__FAST_FUNCTION_STATEMENT  = "->";
//        Re_Variable.UnsafeVariable.addFinalValueIntern(INNER_MATH_FUNCTION__FAST_FUNCTION_STATEMENT, true, m);    //->

//        Re_Variable.UnsafeVariable.addFinalValueIntern(new Re_IReObject.IPrimitiveCall(INNER_MATH_FUNCTION__FAST_FUNCTION_STATEMENT) {
//            @Override
//            public Object executeCallProcess(Re_Executor executor, String that_key, Re_CodeLoader.Call call) throws Throwable {
//                if (call.getParamExpressionCount() == 2) {
//                    return Re_Class.RuntimeUtils.createReFastStatementFunction(executor, call);
//                }
//                executor.setThrow(Re_Accidents.unable_to_process_parameters(that_key, call.getParamExpressionCount()));
//                return null;
//            }
//        }, keyword);

//        /**
//         * 运行时动态创建
//         */
//        public static Re_ClassFunction createReFastStatementFunction(final Re_Executor executor, final Re_CodeLoader.Call callParamController) {
//            final String createReFastStatementFunction =
//                    "fast create a function:     \n" +
//                            "name(param1, param2, param3) -> {\n" +
//                            "    println(param1);\n" +
//                            "};" +
//                            "\n" +
//                            "create a function:     \n" +
//                            "(param1, param2, param3) -> {\n" +
//                            "    println(param1);\n" +
//                            "};";
//            int paramExpressionCount = callParamController.getParamExpressionCount();
//            if (paramExpressionCount > 0 && paramExpressionCount <= 2) {
//                String      fname = null;
//                String[]    fparam_names = null;
//
//                if (paramExpressionCount == 2) {
//                    Re_CodeLoader.Expression firstExpression = callParamController.getBuildParamExpressionCache(0);
//                    Re_CodeLoader.Call expressionAsCall = Re_CodeLoader.RuntimeUtils.Expressions.getExpressionAsCall(firstExpression);
//                    if (null != expressionAsCall) {
//                        fname = expressionAsCall.getName();
//                        String[]    callAsParamName = Re_CodeLoader.RuntimeUtils.Expressions.getCallParamNameArray(expressionAsCall);
//                        if (null == callAsParamName) {
//                            executor.setThrow(createReFastStatementFunction);
//                            return null;
//                        } else {
//                            fparam_names = callAsParamName;
//                        }
//                    } else {
//                        executor.setThrow(createReFastStatementFunction);
//                        return null;
//                    }
//                }
//
//                Re_CodeLoader.Expression[] createObjectExpressions = Re_CodeLoader.RuntimeUtils.Expressions.getCreateObjectExpressions(callParamController.getBuildParamExpressionCache(paramExpressionCount - 1));
//                if (null == createObjectExpressions) {
//                    executor.setThrow(createReFastStatementFunction);
//                    return null;
//                }
//
//                return createReFunction(executor, fname, fparam_names, createObjectExpressions, callParamController);
//            }
//            executor.setThrow(createReFastStatementFunction);
//            return null;
//        }