package top.fols.box.reflect.hproxy;

import java.lang.annotation.*;
import java.lang.reflect.Method;

@SuppressWarnings({"UnnecessaryModifier", "rawtypes", "unused"})
@Retention(RetentionPolicy.RUNTIME)
@Target(value={ElementType.METHOD, ElementType.TYPE})
public @interface IInvokeOriginal {
	
	int order() default 0;

    public static final Class<IInvokeOriginal> TYPE = IInvokeOriginal.class;
    public static final HProxy.AnnotationExecutor<IInvokeOriginal> EXECUTOR = new HProxy.AnnotationExecutor<IInvokeOriginal>() {
        Integer orderCache = null;
        @Override
        public Integer order(IInvokeOriginal annotation) {
            // TODO: Implement this method
            if (null != orderCache && orderCache == annotation.order())
                return  orderCache;
            return orderCache = annotation.order();
        }

        @Override
        public IInvokeOriginal cloneAnnotation(final IInvokeOriginal annotation) {
			final Integer order = annotation.order();
            final int hashCode = annotation.hashCode();
            return new IInvokeOriginal() {

				@Override
				public int order() {
					// TODO: Implement this method
					return order;
				}

                @Override
                public Class<? extends Annotation> annotationType() {
                    return TYPE;
                }

                @Override
                public int hashCode() {
                    return hashCode;
                }

                @Override
                public boolean equals(Object obj) {
                    if (obj == this)
                        return true;
                    if (!(obj instanceof IInvokeOriginal))
                        return false;
                    IInvokeOriginal other = (IInvokeOriginal) obj;
                    return true;
                }

                @Override
                public String toString() {
                    return "@" + TYPE.getName() + "(" + "order=" + order() + ")";
                }
            };
        }

        @Override
        public void execute(IInvokeOriginal annotation,
                            Class beProxyObjectClass, Object beProxyObject, Method runMethod, Method originalMethod, Object[] args, HProxy.ObjectProxy proxy, HProxy.Return result) throws Throwable {
            // TODO: Implement this method

            Method objectEqualsMethod = HProxy.getObjectEqualsMethod(beProxyObjectClass, originalMethod);
            Object original = objectEqualsMethod.invoke(beProxyObject, args);
            result.setReturn(original);
        }
    };
}
