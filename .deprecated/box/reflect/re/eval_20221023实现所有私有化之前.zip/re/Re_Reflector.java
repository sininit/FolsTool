package top.fols.box.reflect.re;

import java.lang.reflect.Member;
import java.util.*;

import top.fols.atri.cache.WeakConcurrentHashMapCache;
import top.fols.atri.lang.Finals;
import top.fols.atri.reflect.*;
import top.fols.box.reflect.re.interfaces.Re_IJavaReflector;


/**
 * Java反射器
 * 作用是可以防止直接反射私有字段
 * 这玩意一般是在re里面用的，需要防止在re里面反射 re
 * 其实没啥用 但是起码得弄一个吧
 */
@SuppressWarnings("rawtypes")
public class Re_Reflector extends ReflectMatcher<Re_Reflector.Cache> implements Re_IJavaReflector {

    static final String RE_PACKAGE = Re.class.getPackage().getName();



    @SuppressWarnings({"SameParameterValue"})
    public static class Cache extends ReflectCache {
        public Cache() {}


        //-------------------------------------------只是公开方法而已没有实际意义---------------------------------------------
        protected ClassesList 	    getClassesList(Class cls) 			 			{ return super.getClassesList(cls);      }
        protected Class             getClasses(Class cls, String simpleName) 	    { return super.getClasses(cls, simpleName); }
        protected ConstructorList   getConstructorList(Class cls)  				    { return super.getConstructorList(cls); }
        protected FieldList         getFieldList(Class cls)						    { return super.getFieldList(cls);       }
        protected FieldList         getFieldList(Class cls, String name)  		    { return super.getFieldList(cls, name); }
        protected MethodList        getMethodList(Class p1)   					    { return super.getMethodList(p1);   }
        protected MethodList        getMethodList(Class p1, String p2)    		    { return super.getMethodList(p1, p2);   }
        //------------------------------------------------------------------------------------------------------------------



        @Override
        protected String getSimpleName0(Class<?> cls) {
            return Re_CodeLoader.intern(super.getSimpleName0(cls));
        }

        @Override
        protected String getMemberName0(Member member) {
            return Re_CodeLoader.intern(super.getMemberName0(member));
        }


        public static Class[] getClassInherits(Class cls) {
            if (null == cls)
                return Finals.EMPTY_CLASS_ARRAY;

            if (cls.isAnnotation() || cls.isEnum()) // public @interface or public enum
                return new Class[] {cls};

            Class[] interfaces = cls.getInterfaces(); //public interface x extends a,b,c
            if (cls.isInterface()) { //interface
                if (interfaces.length == 0)
                    return new Class[]{cls};
                LinkedHashSet<Class> set = new LinkedHashSet<>();
                Collections.addAll(set, interfaces);
                return set.toArray(Finals.EMPTY_CLASS_ARRAY);
            }

            Class superclass = cls.getSuperclass();
            if (null == superclass || superclass == Finals.OBJECT_CLASS)
                return new Class[] {cls, Finals.OBJECT_CLASS};

            LinkedHashSet<Class> set = new LinkedHashSet<>();
            set.add(cls); //this
            for (Class inter: interfaces) {
                set.addAll(Arrays.asList(getClassInherits(inter)));
            }
            set.addAll(Arrays.asList(getClassInherits(superclass)));
            set.add(Finals.OBJECT_CLASS);

            return set.toArray(Finals.EMPTY_CLASS_ARRAY);
        }

        //reflect == hideClass
        protected Set<Class> hideProtectedClass = new HashSet<Class>() {{
            add(Class.class);
            add(String.class);
            add(Integer.class);
            add(Character.class);
            add(Byte.class);
            add(Long.class);
            add(Float.class);
            add(Double.class);
            add(Short.class);
            add(Boolean.class);

            add(Object.class);
        }};

        protected Set<Class> hideProtectedFromInheritClass = new HashSet<>();

        protected Set<String> hideProtectedFromInheritClassPackageName = new HashSet<String>() {{
            add(Reflects.class.getPackage().getName());
            add(RE_PACKAGE);
        }};


//        //faster
        protected WeakConcurrentHashMapCache<Class, Boolean> isHideProtectedReflectCache = new WeakConcurrentHashMapCache<Class, Boolean>() {
            @Override
            public Boolean newCache(Class aClass) {
                //指定某个类
                if (hideProtectedClass.contains(aClass))
                    return true;

                Class[] classInherits = getClassInherits(aClass);
                //所有继承类中如果存在需要屏蔽的类则返回true
                for (Class classInherit : classInherits)
                    if (hideProtectedFromInheritClass.contains(classInherit))
                        return true;

                //所有继承类中如果存在屏蔽的包名则返回true
                for (Class classInherit : classInherits) {
                    Package aPackage = classInherit.getPackage();
                    String name;
                    if (null == aPackage) {
                        name = null;
                    } else {
                        name = aPackage.getName();
                    }
                    if (hideProtectedFromInheritClassPackageName.contains(name))
                        return true;
                }

                return false;
            }
        };






        protected Set<String> fullHidePackageStart = new HashSet<String>() {{
            add(RE_PACKAGE);
        }};
        public boolean isFullHide(Class cls) {
            Package aPackage = cls.getPackage();
            String packageName = null == aPackage?null:aPackage.getName();
            if (null == packageName) {
                return fullHidePackageStart.contains(null);
            }
            for (String s : fullHidePackageStart) {
                if (packageName.startsWith(s)) {
                    return true;
                }
            }
            return false;
        }




        protected  ClassesList createDisableReflectAfterClassesList(Class cls) {
            return ClassesList.wrap(cls.getClasses());
        }
        protected  FieldList createDisableReflectAfterFieldList(Class cls) {
            return FieldList.wrap(cls.getFields());
        }
        protected  ConstructorList createDisableReflectAfterConstructorList(Class cls) {
            return ConstructorList.wrap(Reflects.accessible(cls.getDeclaredConstructors()));
        }
        protected  MethodList createDisableReflectAfterMethodList(Class cls) {
            return MethodList.wrap(cls.getMethods());
        }









        @Override
        protected ClassesList createClassesList(Class cls) {
            if (isFullHide(cls)) {
                return ClassesList.empty();
            }
            ClassesList list;
            if (isHideProtectedReflectCache.get(cls)) {
                list = createDisableReflectAfterClassesList(cls);
            } else {
                list = super.createClassesList(cls);
            }
            return list;
        }
        @Override
        protected ConstructorList createConstructorList(Class cls) {
            if (isFullHide(cls)) {
                return ConstructorList.empty();
            } else {
                ConstructorList list;
                if (isHideProtectedReflectCache.get(cls)) {
                    list = createDisableReflectAfterConstructorList(cls);
                } else {
                    list = super.createConstructorList(cls);
                }
                return list;
            }
        }
        @Override
        protected FieldList createFieldList(Class cls) {
            if (isFullHide(cls)) {
                return FieldList.empty();
            } else {
                FieldList list;
                if (isHideProtectedReflectCache.get(cls)) {
                    list = createDisableReflectAfterFieldList(cls);
                } else {
                    list = super.createFieldList(cls);
                }
                return list;
            }
        }
        @Override
        protected MethodList createMethodList(Class cls) {
            if (isFullHide(cls)) {
                return MethodList.empty();
            } else {
                MethodList list;
                if (isHideProtectedReflectCache.get(cls)) {
                    list = createDisableReflectAfterMethodList(cls);
                } else {
                    list = super.createMethodList(cls);
                }
                return list;
            }
        }
    }



    public Re_Reflector() {
        super(new Cache());
    }
}

class Re_ReflectorPeak extends ReflectPeakMatcher<Re_Reflector.Cache> implements Re_IJavaReflector {
    public Re_ReflectorPeak() {
        super(new Re_Reflector.Cache());
    }
}

