package top.fols.box.reflect.re;

import java.util.Map;

/**
 * {对象} 和 它的抽象 {类}
 */
@SuppressWarnings({"rawtypes"})
public class Re_ZPrimitiveClass_object extends Re_PrimitiveClass {
    @SuppressWarnings("SpellCheckingInspection")
    public static final Re_ZPrimitiveClass_object reclass = new Re_ZPrimitiveClass_object(Re_Keywords.INNER_CLASS__OBJECT);


    protected Re_ZPrimitiveClass_object(String className) {
        super(className);
    }


    public static Re_PrimitiveClassInstance fromJavaObject(Map<String, Object> map) {
        Re_PrimitiveClassInstance instance = reclass.newInstance();
        for (String key : map.keySet()) {
            Object value0 = map.get(key);
            Re_Variable value = Re_Variable.createVar(value0);

            Re_Variable.Unsafes.setVariableIntern(key, value, instance);
        }
        return instance;
    }



    @Override
    protected Re_PrimitiveClassInstance newInstance() {
        return this.newInstance(this);
    }
    @Override
    protected Re_PrimitiveClassInstance newInstance(Re_Class reClass) {
        return new Re_PrimitiveClassInstance(reClass);
    }
}
