package top.fols.box.reflect.re;

import top.fols.atri.lang.Finals;
import top.fols.atri.util.Throwables;
import top.fols.box.reflect.re.interfaces.Re_IReInnerVariableMap;
import top.fols.box.reflect.re.interfaces.Re_IReObject;
import top.fols.box.reflect.re.interfaces.Re_IJavaReflector;
import top.fols.atri.util.DoubleLinked;
import top.fols.atri.util.annotation.NotNull;
import top.fols.atri.util.annotation.Nullable;

import java.lang.reflect.Array;

import static top.fols.box.reflect.re.Re_CodeLoader.*;


/**
 * 只要执行 {@link Re_Executor} 的方法
 * 后都要手动检测是否 {@link Re_Executor#isReturnOrThrow()} 如果是直接返回null
 *
 *
 * 一个 {@link Re_Executor}不能被多个线程同时执行 因为这是非常不安全的
 * 一个 {@link Re_NativeStack}   不能被多个线程同时使用 因为这是非常不安全的
 * 会变得很糟糕
 */
@SuppressWarnings({"rawtypes", "FieldCanBeLocal", "SameParameterValue", "UnusedReturnValue", "CloneableClassWithoutClone"})
public abstract class Re_Executor implements Re_IReObject, Re_IReInnerVariableMap, Cloneable {
    //常量
    final protected Re                            re;
    final protected Re_CodeFile                   reCodes;

    final protected Re_IJavaReflector             reReflector;

    final protected Re_Class                      reClass;
    final protected Re_ClassInstance              reClassInstance; // 对象实例, 不能为空, 也不能是static实例



    //需要新创建
    private final Re_NativeStack                                reStack;
    private DoubleLinked<Re_NativeStack.NativeTraceElement>     reStackCurrentLinked;
    private Re_NativeStack.NativeTraceElement                   reStackCurrentElement;


    //使用这个变量主要是 因为有eval执行器 必须要引用真实的执行器的变量

    //private
    @NotNull
    Re_Executor mThis;
    //private
    boolean     mIsReturn;
    //private
    Object      mResult;



    /**
     * @param re            主机
     * @param stack           栈
     * @param reCodes         代码
     * @param re_class        类        其实可以为空
     * @param reClassInstance 类实例     其实可以为空
     */
    private Re_Executor(@NotNull Re re, @NotNull Re_NativeStack stack, @NotNull Re_CodeFile reCodes,
                        @Nullable Re_Class re_class, @Nullable Re_ClassInstance reClassInstance) {

        this.re = re;
        this.reReflector     = re.reflector;
        this.reCodes         = reCodes;
        this.reClass         = re_class;
        this.reClassInstance = reClassInstance;

        this.reStack = stack;
        this.reStackCurrentElement = null;
        this.reStackCurrentLinked = null;
    }





    /**
     * print(a);
     * {@link Re_IReInnerVariableMap#innerFindMapOrParentVariable(Object)} 一般是在 Executor 执行过程中获取（局部变量 或者向上查找）的时候执行的	 *
     *
     *
     * use {@link Re_Variable#accessFindMapOrParentValueRequire}
     */
    public abstract Object localValue(String key);

    /**
     * x = tip;
     * 如果异常请抛出java异常 而不是 setThrow
     */
    public abstract Object localValue(String key, Object value);


    public abstract Object[] getArguments();



    public String getFilePath() {
        return reCodes.getFilePath();
    }


    protected Re                getRe() {
        return re;
    }
    @Nullable
    public Re_Class             getReClass() {
        return reClass;
    }
    @Nullable
    public Re_ClassInstance     getReClassInstance() {
        return reClassInstance;
    }

    protected Re_NativeStack getStack() {
        return reStack;
    }
    protected Re_NativeStack.NativeTraceElement getStackElement() {
        return reStackCurrentElement;
    }























    /**
     * 禁止从外部访问本方法
     * 执行前不可以已经return状态, 如果执行时return 则会返回return结果
     * 本办法只会从{@link Re_Executor#executeExpressions0(Expression, int)} 访问
     *
     * xx.xx
     */
    public Object getPointVariableValue(@NotNull Object instance, @NotNull Base current, String currentName) throws Throwable {
        if (instance instanceof Re_IReObject) {
            Object value = ((Re_IReObject) instance).getVariableValue(this, currentName);
            if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;
            return value;
        } else {
            Object value = Re_Utilities.getJavaValue(this,  instance.getClass(), instance, currentName);
            if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;
            return value;
        }
    }

    /**
     * 禁止从外部访问本方法
     * 执行前不可以已经return状态, 如果执行时return 则会返回return结果
     * 本办法只会从{@link Re_Executor#executeExpressions0(Expression, int)} 访问
     *
     * xx.xx = ?
     */
    public Object setPointVariableValue(@NotNull Object instance, @NotNull Base current, @NotNull String currentName, Object value) throws Throwable {
        if (instance instanceof Re_IReObject) {
            ((Re_IReObject) instance).putVariableValue(this, currentName, value);
            if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;
            return value;
        } else {
            Re_Utilities.setJavaValue(this,  instance.getClass(), instance, currentName, value);
            if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;
            return value;
        }
    }




    /**
     * 执行后应该判断  {@link #isReturnOrThrow()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getResult()}
     *
     * 禁止从外部访问本方法
     * 执行前不可以已经return状态, 如果执行时return 则会返回return结果
     * 本办法只会从{@link Re_Executor#executeExpressions0(Expression, int)} 访问
     *
     * obj.point_var_name()
     * obj is obj-tip
     * point_var_name is point_var_name
     */
    public Object executeCallPoint(@NotNull Object obj, String point_var_name, Call call) throws Throwable {
        if (obj instanceof Re_IReObject) {
            Object o = ((Re_IReObject) obj).executePoint(this, point_var_name, call);
            if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;//throw or return
            return o;
        } else {
            Object[] param = getExpressionValues(call, 0, call.getParamExpressionCount());
            if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;//throw or return

            return Re_Utilities.invokeJavaMethod(this, obj, point_var_name, param);
        }
    }

    /**
     * 执行后应该判断  {@link #isReturnOrThrow()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getResult()}
     *
     * 禁止从外部访问本方法
     * 执行前不可以已经return状态, 如果执行时return 则会返回return结果
     * 本办法只会从{@link Re_Executor#executeExpressions0(Expression, int)} 访问
     *
     * var_name()
     *
     * instance is var_name-tip
     */
    public Object executeCallThis(@NotNull Object instance, @NotNull String var_name, @NotNull Call call) throws Throwable {
        if (instance instanceof Re_IReObject) {
            //re reflect
            Re_IReObject vp = ((Re_IReObject) instance);
            Object o = vp.executeThis(this, var_name, call);
            if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;//throw or return
            return o;
        } else {
            if (instance.getClass().isArray()) {
                //操作java数组
                return executeGVFromJavaArray(instance, call);
            }
            this.setThrow(Re_Accidents.cannot_execute(var_name, instance));
            return null;
        }
    }





    /**
     * variable_map()               获取长度 {@link Re_IReInnerVariableMap#innerGetVariableCount()} <br>
     * variable_map(key)            获取数据 {@link Re_IReInnerVariableMap#innerFindMapOrParentVariable(Object)} <br>
     * variable_map(key， tip)     设置数据 {@link Re_IReInnerVariableMap#innerPutVariable(Object, Re_Variable)} <br>
     *
     * 本方法是用于外部扩展访问的 本执行器不会访问该方法 <br>
     * 执行后应该判断  {@link Re_Executor#isReturnOrThrow()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link Re_Executor#getResult()} <br>
     *
     * 区别是不用code参数, 可能会抛出Java异常 <br>
     */
    public Object executeGVFromReObject(@NotNull Re_IReObject instance, @NotNull Call call) throws Throwable {
        int paramExpressionCount = call.getParamExpressionCount();
        Object key, value;
        switch (paramExpressionCount) {
            case 0:
                return instance.getVariableCount(this);
            case 1:
                key = getExpressionValue(call,0);
                if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;//throw or return

                return instance.getVariableValue(this, key);
            case 2:
                key = getExpressionValue(call,0);
                if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;//throw or return

                value = getExpressionValue(call,1);
                if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;//throw or return

                instance.putVariableValue(this, key, value); //强制提交 不 使用 intern
                return value;
        }
        return null;
    }
    /**
     * 禁止从外部访问本方法
     * 执行前不可以已经return状态, 如果执行时return 则会返回return结果
     * 本办法只会从{@link Re_Executor#executeExpressions0(Expression, int)} 访问
     */
    public Object executeGVFromJavaArray(@NotNull Object instance, @NotNull Call call) {
        int paramExpressionCount = call.getParamExpressionCount();
        Object obj;
        switch (paramExpressionCount) {
            case 0:
                return Array.getLength(instance);
            case 1:
                obj = getExpressionValue(call,0);
                if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;//throw or return

                return Array.get(instance, Re_Utilities.toJInt(obj));
            case 2:
                obj = getExpressionValue(call,0);
                if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;//throw or return

                Object value = getExpressionValue(call,1);
                if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;//throw or return

                Array.set(instance, Re_Utilities.toJInt(obj), value);
                return value;
        }
        return null;
    }
















    /**
     * 不安全的操作，必须严格使用本方法
     * 如果之前已经return 会抛出java异常, 如果执行时return 则会返回return结果
     * 执行后应该判断  {@link #isReturnOrThrow()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getResult()}
     *
     * @param call call
     * @param index no check
     */
    public Object getExpressionValue(Call call, int index) {
        if (mThis.mIsReturn || reStack.isThrow) throw new Re_Accidents.RuntimeInternalExecutorReturnedOrThrow(this.reStack.toString());//returned
        Expression expression = call.getBuildParamExpressionCache(index);
        return this.executeExpressions0(expression, 0);
    }

    /**
     * 不安全的操作，必须严格使用本方法
     * 获取参数转为java 对象， 如果之前已经return 会抛出java异常, 如果执行时return 则会中断获取并返回已经读取到的结果
     * 执行后应该判断  {@link #isReturnOrThrow()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getResult()}
     *
     * 本方法为内部方法
     *
     * @param call call         表达式的集合 (Expression, Expression, Expression...)
     * @param off, no check
     * @param len, no check
     */
    public Object[] getExpressionValues(Call call, int off, int len) {
        if (mThis.mIsReturn || reStack.isThrow) throw new Re_Accidents.RuntimeInternalExecutorReturnedOrThrow(this.reStack.toString());//returned
        Object[] paramList = new Object[len];
        Expression[] nowParam = call.getBuildParamExpressionCaches();
        for (int i = 0; i < len; i++) {
            Expression expression = nowParam[i+off];
            paramList[i] = this.executeExpressions0(expression, 0);
            if (mThis.mIsReturn || reStack.isThrow) break;
        }
        //returned?
        return paramList;
    }

    public Object[] getExpressionValues(Call call) {
        return getExpressionValues(call, 0, call.getParamExpressionCount());
    }


    /**
     * 不安全的操作，必须严格使用本方法
     * 如果之前已经return 会抛出java异常, 如果执行时return 则会返回return结果
     * 执行后应该判断  {@link #isReturnOrThrow()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getResult()}
     *
     * @param call call
     * @param off, no check
     * @param len, no check
     */
    public Object getExpressionLastValue(Call call, int off, int len) {
        if (mThis.mIsReturn || reStack.isThrow) throw new Re_Accidents.RuntimeInternalExecutorReturnedOrThrow(this.reStack.toString());//returned
        Object last = null;
        Expression[] nowParam = call.getBuildParamExpressionCaches();
        for (int i = 0; i < len; i++) {
            Expression code = nowParam[i+off];
            last = this.executeExpressions0(code, 0);
            if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;
        }
        return last;
    }











    /**
     * 不安全的操作，必须严格使用本方法
     * 如果之前已经return 会抛出java异常, 如果执行时return 则会返回return结果
     * 执行后应该判断  {@link #isReturnOrThrow()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getResult()}
     */
    public Object getExpressionValue(Expression expression) {
        if (mThis.mIsReturn || reStack.isThrow) throw new Re_Accidents.RuntimeInternalExecutorReturnedOrThrow(this.reStack.toString());//returned
        return this.executeExpressions0(expression, 0);
    }
    /**
     * 不安全的操作，必须严格使用本方法
     * 如果之前已经return 会抛出java异常, 如果执行时return 则会返回return结果
     * 执行后应该判断  {@link #isReturnOrThrow()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getResult()}
     *
     * @param expression expression
     * @param off, no check
     * @param len, no check
     */
    public Object getExpressionLastValue(Expression[] expression, int off, int len) {
        if (mThis.mIsReturn || reStack.isThrow) throw new Re_Accidents.RuntimeInternalExecutorReturnedOrThrow(this.reStack.toString());//returned
        Object last = null;
        for (int i = 0; i < len; i++) {
            Expression code = expression[i+off];
            last = this.executeExpressions0(code, 0);
            if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;
        }
        return last;
    }















    /**
     * 执行后应该判断  {@link #isReturnOrThrow()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getResult()}
     */
    protected void tryingSetLocalErrorValue(String name, Re_ZPrimitiveClass_exception.Instance instance) {
        Re_Variable.accessSetValue(this, name, instance,this);
    }


    /**
     * 如果之前已经return 会抛出java异常
     * 执行后应该判断  {@link #isReturnOrThrow()} ()} 如果返回真就不要再继续执行你的代码了 直接返回 {@link #getResult()}
     */
    protected Object trying(@NotNull Expression[] executeExp, String catchName, @Nullable Expression[] catchExp, @Nullable Expression[] finallyExp) {
        if (mThis.mIsReturn || reStack.isThrow) throw new Re_Accidents.RuntimeInternalExecutorReturnedOrThrow(this.reStack.toString());//returned

        Object execute = null;
        try {
            execute = this.getExpressionLastValue (executeExp, 0, executeExp.length);
        } catch (Throwable innerEx) {
            //inner error
            if (!this.isThrow())
                this.setThrow(innerEx);
        }
        if (isThrow()) {
            /*其中一个代码块异常了
                try{代码块}； try{代码块}finally{}； try{代码块}catch(e){}；  try{代码块}catch(e){}finally{}
            */
            if (null == catchExp && null == finallyExp) {
                /*
                    try{代码块}
                */
                this.clearReturnOrThrow();
            } else {
                /*其中一个代码块异常了
                    try{代码块}finally{}； try{代码块}catch(e){}； try{代码块}catch(e){}finally{}
                */
                if (null != catchExp) {
                    this.tryingSetLocalErrorValue(catchName, getThrow());    //set error variable error？
                    this.clearReturnOrThrow();//清除代码块的异常
                    execute = this.getExpressionLastValue(catchExp, 0, catchExp.length);
                }
                /*
                    最后如果有finally肯定要执行
                 */
                if (null != finallyExp) {
                    if (isThrow()) {
                        //这种情况可能是finally里的正常执行但是可能会覆盖之前的异常栈信息

                        //备份throw
                        int     cacheLine                                      = reStackCurrentElement.getLine();
                        Re_ZPrimitiveClass_exception.Instance  cacheThrowReason = reStack.getThrow();

                        this.clearReturnOrThrow();

                        execute = this.getExpressionLastValue(finallyExp, 0, finallyExp.length);

                        if (!isReturnOrThrow()) {
                            this.reStackCurrentElement.setLine(cacheLine);
                            this.setThrow(cacheThrowReason);
                        }
                    } else {
                        //catch执行过并且没有异常

                        //备份结果
                        boolean cacheIsReturn = this.isReturnOrThrow();
                        Object  cacheReturn   = this.getResult();

                        this.clearReturn();

                        this.getExpressionLastValue(finallyExp, 0, finallyExp.length);

                        if (!isReturnOrThrow()) {
                            this.setReturn(cacheIsReturn, cacheReturn);
                        }
                    }
                }
            }
        } else {
            //return 或者执行完毕并且未return
            if (null != catchExp) {
                this.tryingSetLocalErrorValue(catchName, null);
                if (isThrow()) {    //set error variable error？
                    this.clearReturnOrThrow();
                }
            }
            /*正常运行  catch(e){} 不会运行 只会将 e设置为null
                try{代码块}； try{代码块}finally{}； try{代码块}catch(e){}； try{代码块}catch(e){}finally{} 正常运行
             */
            if (null != finallyExp) {
                //备份结果
                boolean cacheIsReturn = this.isReturnOrThrow();
                Object  cacheReturn   = this.getResult();

                this.clearReturn();

                this.getExpressionLastValue(finallyExp, 0, finallyExp.length);

                if (!isReturnOrThrow()) {
                    this.setReturn(cacheIsReturn, cacheReturn);
                }
            }
        }
        return execute;
    }





    /**
     *    thread unsafe 线程不安全
     *    不能同时执行本（实例方法）否则 发生非常坑爹的事情
     *    每段代码都必须新建一个Executor
     *    本方法其实是一次性的， 重复执行 栈就没有了 请不要执行第二次
     */
    public Object run() {
        if (null == reStackCurrentElement) {
            Re_NativeStack.NativeTraceElement currentNativeTrace = new Re_NativeStack.NativeTraceElement(this);
            currentNativeTrace.setLine(0);
            currentNativeTrace.setFilePath(reCodes.getFilePath());

            this.reStackCurrentElement = currentNativeTrace;
            this.reStackCurrentLinked  = this.reStack.addStackElement(currentNativeTrace);//no start

            Re_CodeFile expressions          = this.reCodes;
            this.run0(expressions.getExpressions(),
                      expressions.getExpressionsOffset(),
                      expressions.getExpressionsLimit());

            if (isThrow()) {
                return null;
            } else {
                reStack.removeStackElement(this.reStackCurrentLinked);
                return mThis.mResult;
            }
        } else {
            throw new Re_Accidents.ExecuteException("exited"); //exited  or re add stack
        }
    }
    protected void run0(Expression[] expressions, int offset, int limit) {
        while (!(mThis.mIsReturn || reStack.isThrow) && offset <  limit) {
            Expression expression = expressions[offset];

            this.reStackCurrentElement.line = expression.line;
            mThis.mResult = executeExpressions0(expression, 0);

            offset++;// next line
        }
    }



    protected Object localValue(Var current) {
        return null == current.staticVariable ? localValue(current.getName()) : current.staticVariable.get(this);
    }
    /**
     * 禁止外部包访问本方法
     */
    private Object executeExpressions0(Expression expression, int offset) {
        try {
            Base[] bases = expression.getBuildCodeCache();
            Object  stack       = null;
            boolean prev  = false;
            boolean joinPoint   = false;
            int size            = bases.length;
            Base current;

            for (int i = offset; i < size; i++) {
                if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;

                current = bases[i];
                if (codeIsVar(current)) {
                    // 栈底为空值
                    int next_index = i + 1;
                    if (null == stack) {
                        if (prev) {
                            if (joinPoint) {
                                // 无法从空结果获取字段
                                this.setThrow(Re_Accidents.undefined_object_var(null, current));
                            } else {
                                this.setThrow(Re_Accidents.runtime_grammatical_error(bases, current));
                            }
                            return null;
                        }
                        Base next = next_index < bases.length?bases[next_index]:null;
                        if (codeIsAssignment(next)) {
                            // x = ...
                            Object value = this.executeExpressions0(expression, i = next_index + 1);
                            if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;

                            this.reStackCurrentElement.line = current.line;
                            stack = this.localValue(current.getName(), value); //可能会异常
                            return stack;
                        } else {
                            // x
                            this.reStackCurrentElement.line = current.line;
                            stack = null == current.staticVariable ? localValue(current.getName()) : current.staticVariable.get(this);
                            prev = true;
                        }
                    } else if (joinPoint) {
                        // 上一个元素为点
                        // 当前元素为name
                        Base next = next_index < bases.length?bases[next_index]:null;//获取下一个元素
                        if (null == next) {
                            // 数据被读完 x.x
                            this.reStackCurrentElement.line = current.line;
                            stack = this.getPointVariableValue(stack, current, current.getName());
                            return stack;
                        } else {
                            if (codeIsAssignment(next)) {
                                // x.x = ...
                                //这个i = next_index + 1 是不对 的！ 不应该是i=next_index+1 这样可能会重复执, 应该弄个代码读取器，或者I记录器, 又或者应该是直接return
                                Object value = this.executeExpressions0(expression, i = next_index + 1);
                                if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;

                                this.reStackCurrentElement.line = current.line;
                                stack = this.setPointVariableValue(stack, current, current.getName(), value);
                                return stack;//测试
                            } else if (codeIsPoint(next)) {
                                // x.x.?
                                this.reStackCurrentElement.line = current.line;
                                stack = this.getPointVariableValue(stack, current, current.getName());
                                prev = true;
                            } else {
                                this.setThrow(Re_Accidents.runtime_grammatical_error(bases, current));
                                return null;
                            }
                            joinPoint = false;
                        }
                    } else {
                        this.setThrow(Re_Accidents.runtime_grammatical_error(bases, current));
                        return null;
                    }
                } else if (codeIsCall(current)) {
                    if (null == stack) {
                        // 栈底为空值
                        Call currentCall = (Call) current;
                        if (prev) {
                            if (joinPoint) {
                                // 无法从空结果获取字段
                                this.setThrow(Re_Accidents.undefined_object_call(null, current, ((Call) current).getParamExpressionCount()));
                            } else {
                                this.setThrow(Re_Accidents.runtime_grammatical_error(bases, current));
                            }
                            return null;
                        }
                        // x();
                        String name = current.getName();
                        Object instance = null == current.staticVariable ? localValue(name) : current.staticVariable.get(this);
                        if (mThis.mIsReturn || reStack.isThrow) return mThis.mResult;
                        if (null == instance) {
                            this.setThrow(Re_Accidents.undefined(name));
                            return null;
                        }
                        this.reStackCurrentElement.line = current.line;
                        stack = this.executeCallThis(instance, name, currentCall);
                        prev = true;
                    } else if (joinPoint) {
                        // ?.x()
                        Call currentCall = (Call) current;
                        this.reStackCurrentElement.line = current.line;
                        stack = this.executeCallPoint(stack, current.getName(), currentCall);
                        prev = true;
                        joinPoint = false;
                    } else {
                        //对上个结果执行 basemethod
                        //a()()     y
                        //a()b()    x grammatical_error
                        Call call = (Call) current;
                        if (call.isEmptyName()) {
                            String name = current.getName();

                            this.reStackCurrentElement.line = current.line;
                            stack = this.executeCallThis(stack, name, call);// 这里是对栈进行调用而不是变量//xxx()()
                            prev = true;
                        } else {
                            this.setThrow(Re_Accidents.runtime_grammatical_error(bases, current));
                            return null;
                        }
                    }
                } else if (codeIsPoint(current)) {
                    joinPoint = true;
                } else {
                    this.setThrow(Re_Accidents.runtime_grammatical_error(bases, current));
                    return null;
                }
            }
            return stack;
        } catch (Throwable innerEx) {
            this.setThrow(innerEx);
            return null;
        }
    }















    public boolean isReturnOrThrow() {
        return mThis.mIsReturn || reStack.isThrow;
    }
    /**
     * 如果已经return 会抛出java异常
     */
    public void setReturn(Object result) {
        if (mThis.mIsReturn || reStack.isThrow) throw new Re_Accidents.RuntimeInternalExecutorReturnedOrThrow(this.reStack.toString());//returned

        mThis.mIsReturn = true;
        mThis.mResult = result;
    }
    public void setReturn(boolean ret, Object result) {
        if (mThis.mIsReturn || reStack.isThrow) throw new Re_Accidents.RuntimeInternalExecutorReturnedOrThrow(this.reStack.toString());//returned

        mThis.mIsReturn = ret;
        mThis.mResult = result;
    }
    public Object getResult() {
        return mThis.mResult;
    }
    protected void clearReturn() {
        mThis.mIsReturn = false;
        mThis.mResult = null;
    }





    public boolean isThrow() {
        return reStack.isThrow();
    }
    public Re_ZPrimitiveClass_exception.Instance getThrow() {
        return reStack.getThrow();
    }


    /**
     * 设置后
     * {@link #setReturn(Object)}
     * 也会一起设置
     */
    public void setThrow(String reason) {
        this.setThrow(Re_NativeStack.createExceptionInstance(this.reStack, reason));
    }
    public void setThrow(Re_ZPrimitiveClass_exception.Instance reason) {
        if (mThis.mIsReturn || reStack.isThrow) throw new Re_Accidents.ExecuteException(this.reStack.toString());//returned

        this.reStack.setThrow(reason);

        mThis.mIsReturn = true;
        mThis.mResult = null;
    }
    public void setThrow(Throwable reason) {
        this.setThrow(Throwables.toString(reason));
    }


    /**
     * 清除结果和 清除throw, 并断开新增的栈元素
     */
    public void clearReturnOrThrow() {
        if (null == reStackCurrentLinked) throw new Re_Accidents.ExecuteException("exited"); //exited  or re add stack

        this.reStack.clearThrow();
        this.reStack.disconBefore(this.reStackCurrentLinked);

        mThis.mIsReturn = false;
        mThis.mResult = null;
    }




















    /**
     * 创建一个没有绑定任何类的执行器 {@link Re#execute(String, Object...)}
     */
    @NotNull
    public static ReRootExecutor createReRootExecutor(@NotNull Re host, Re_NativeStack stack, @NotNull Re_CodeFile block,
                                                      @Nullable Object[] arguments, @NotNull Re_IReInnerVariableMap local) {
        if (stack.isThrow()) return null;

        if (null == arguments)
            arguments = Finals.EMPTY_OBJECT_ARRAY;
        if (null == local)
            local = Re.newLocalVariableMap();

        return new ReRootExecutor(host, stack,
                block,
                null, null,
                local, arguments);
    }


    /**
     * @see Re_Class#initializeStaticObject(Re, Re_NativeStack, Re_CodeFile)
     * 创建类 static 实例初始化执行器，用于初始化类的无论是顶级类还是内部类 匿名类都可以使用
     * 如果已经 throw 必定返回null;
     *
     * @param block 类的代码
     */
    @SuppressWarnings("UnnecessaryLocalVariable")
    @NotNull
    static ReClassInitializeExecutor createReClassInitializeExecutor(@NotNull Re host, Re_NativeStack stack, @NotNull Re_CodeFile block,
                                                                     @NotNull final Re_Class re_class) {
        if (stack.isThrow()) return null;

        final Object[]               arguments   = Finals.EMPTY_OBJECT_ARRAY;
        final Re_IReInnerVariableMap variable    = re_class;

        return new ReClassInitializeExecutor(host, stack,
                block,
                re_class, variable,
                arguments);
    }


    /**
     * 执行类方法 或者对象方法
     *
     * @param host     主机
     * @param stack    stack
     * @param reClass  类
     * @param instance 非静态的 类实例
     * @param function 方法
     * @param local    执行器的local变量， 注意这里不会自动转换
     */
    @NotNull
    static Re_Executor createReClassFunctionExecutor(@NotNull Re host,          @NotNull Re_NativeStack stack,
                                                     @NotNull Re_Class reClass, @Nullable final Re_ClassInstance instance,
                                                     @NotNull final Re_ClassFunction function,
                                                     Object[] arguments, Re_IReInnerVariableMap local) {
        if (stack.isThrow()) return null;

        if (null == arguments)
            arguments = Finals.EMPTY_OBJECT_ARRAY;
        if (null == local)
            local = Re_ClassFunction.argumentsAsVariableMap(function, arguments);

        Re_CodeFile reCodeBlock    = function.reCodeBlock;
        Re_Executor functionParent = function.declareExecutor;
        if (null == instance) { //类方法
            if (null == functionParent) {
                return new ReClassStaticFunctionNoParentExecutor(host, stack,
                        reCodeBlock,
                        reClass,
                        local, arguments);
            } else {
                return new ReClassStaticFunctionHasParentExecutor(host, stack,
                        reCodeBlock,
                        reClass, function, functionParent,
                        arguments, local);
            }
        } else {//实例方法
            if (null == functionParent) {
                return new ReClassObjectFunctionNoParentExecutor(host, stack,
                        reCodeBlock,
                        reClass, instance,
                        arguments, local);
            } else {
                return new ReClassObjectFunctionHasParentExecutor(host, stack,
                        reCodeBlock,
                        reClass, instance,
                        function, functionParent,
                        arguments, local);
            }
        }
    }

    /**
     * __EVAL__
     * 继承父 executor 执行 代码块
     * 一般用于eval
     *
     * @param re             主机
     * @param stack            current_executor 的stack
     * @param block            代码块
     * @param current_executor 继承当前变量
     */
    @NotNull
    private static ReInheritExecutor createReInheritExecutor(@NotNull Re re, Re_NativeStack stack, @NotNull Re_CodeFile block,
                                                             @NotNull final Re_Executor current_executor,
                                                             @Nullable Object[] inheritArguments) {
        if (stack.isThrow()) return null;

        return new ReInheritExecutor(re, stack,
                block, current_executor,
                current_executor.reClass, current_executor.reClassInstance,
                null == inheritArguments ? Finals.EMPTY_OBJECT_ARRAY : inheritArguments);
    }





    /**
     * { }
     *
     * @param executor              executor
     * @return {@link Re_ClassInstance}
     */
    static Re_PrimitiveClassInstance createReDict(@NotNull final Re_Executor executor, @NotNull Call callParamController) {
        if (executor.isReturnOrThrow()) return null;

        final Re_PrimitiveClassInstance dictInstance = Re_ZPrimitiveClass_object.reclass.newInstance();

        final Re_CodeFile block  = new Re_CodeFile();
        block.lineOffset         = callParamController.getLine();
        block.filePath           = executor.reCodes.getFilePath();
        block.constCacheManager  = executor.reCodes.constCacheManager();
        block.expressions        = callParamController.getBuildParamExpressionCaches();
        block.expressionsOffset  = 0;

        //只有这样创建字典代码才能import其他加载的类
        Re_Executor re_executor = new ReCreateDictExecutor(executor, block, executor.reClass, executor.reClassInstance,
                dictInstance);
        re_executor.run();

        return dictInstance;
    }

    /**
     * []
     *
     * @param executor executor
     * @return {@link Re_ClassInstance}
     *
     * 并没有创建Executor
     */
    static Re_PrimitiveClassInstance createReList(@NotNull final Re_Executor executor, @NotNull Call callParamController) {
        if (executor.isReturnOrThrow()) return null;

        Re_ZPrimitiveClass_list.Instance instance = Re_ZPrimitiveClass_list.reclass.newInstance();
        instance.setElements(executor, callParamController);
        return instance;
    }






    /**
     * __EVAL__
     * eval执行等同于代码执行，状态应该是同步的
     */
    @SuppressWarnings("UnnecessaryLocalVariable")
    Object eval(String code, Object[] inheritArguments) {
        if (mThis.mIsReturn || reStack.isThrow) throw new Re_Accidents.ExecuteException(this.reStack.toString());//returned

        Re_Executor executor = this;
        Re re                = executor.re;
        Re_NativeStack stack = executor.reStack;
        Re_CodeFile block    = re.compileCode(code, Re_CodeFile.FILE_NAME__INNER_EVAL);

        Re_Executor     inheritExecutor = Re_Executor.createReInheritExecutor(re, stack, block, executor, inheritArguments);
        if (null ==     inheritExecutor) return null;//re throw

        Object result = inheritExecutor.run();
        return result;
    }









    /**
     * 防止嵌套
     */
    @SuppressWarnings({"UnnecessaryModifier", "UnnecessaryInterfaceModifier"})
    public static interface IInheritExecutor {
        public Re_Executor getRealExecutor();

        public Object[] getInheritArguments();
    }
    public static Re_Executor findRealExecutor(Re_Executor current_executor) {
        while (current_executor instanceof IInheritExecutor)
            current_executor = ((IInheritExecutor) current_executor).getRealExecutor();
        return current_executor;
    }
    static Object[] findInheritArguments(Re_Executor current_executor) {
        if (current_executor instanceof IInheritExecutor)
            return ((IInheritExecutor) current_executor).getInheritArguments();
        return Finals.EMPTY_OBJECT_ARRAY;
    }






    private static class ReRootExecutor extends Re_Executor {
        Re_IReInnerVariableMap local;
        Object[] arguments;

        private ReRootExecutor(@NotNull Re re, Re_NativeStack stack, @NotNull Re_CodeFile reCodes, @Nullable Re_Class re_class, @Nullable Re_ClassInstance reClassInstance,
                              Re_IReInnerVariableMap local, Object[] arguments) {
            super(re, stack, reCodes, re_class, reClassInstance);
            this.mThis = this;

            this.local = local;
            this.arguments = arguments;
        }

        @Override
        public Object localValue(String key) {
            return Re_Variable.accessFindMapOrParentValueRequire(this, key, local);
        }
        @Override
        public Object localValue(String key, Object value) {
            Re_Variable.accessSetValue(this, key, value, local);
            return value;
        }

        @Override
        public Re_Variable innerRemoveVariable(Object key) {
            return local.innerRemoveVariable(key);
        }

        @Override
        public Re_Variable innerFindMapOrParentVariable(Object key) {
            return local.innerFindMapOrParentVariable(key);
        }

        @Override
        public Re_Variable innerFindMapVariable(Object key) {
            return local.innerFindMapVariable(key);
        }

        @Override
        public Re_Variable innerGetVariable(Object key) {
            return local.innerGetVariable(key);
        }

        @Override
        public Re_Variable innerPutVariable(Object key, Re_Variable value) {
            return local.innerPutVariable(key, value);
        }

        @Override
        public boolean innerContainsVariable(Object key) {
            return local.innerContainsVariable(key);
        }

        public int innerGetVariableCount() {
            return local.innerGetVariableCount();
        }

        @Override
        public Iterable<?> innerGetVariableKeys() {
            return local.innerGetVariableKeys();
        }

        @Override
        public Re_IReInnerVariableMap innerCloneVariableMap() {
            return local.innerCloneVariableMap();
        }

        @Override
        public Object[] getArguments() {
            return arguments;
        }

    }



    private static class ReClassInitializeExecutor extends Re_Executor {
        final Re_IReInnerVariableMap classVariable;
        final Object[] arguments;

        private ReClassInitializeExecutor(Re host, Re_NativeStack stack, Re_CodeFile block, Re_Class reClass,
                                          Re_IReInnerVariableMap classVariable, Object[] arguments) {
            super(host, stack, block, reClass, null);
            this.mThis = this;

            this.classVariable = classVariable;
            this.arguments     = arguments;
        }

        @Override
        public Object localValue(String key) {
            return Re_Variable.accessFindMapOrParentValueRequire(this, key, reClass);
        }
        @Override
        public Object localValue(String key, Object value) {
            Re_Variable.accessSetValue(this, key, value, classVariable);
            return value;
        }


        @Override
        public Re_Variable innerRemoveVariable(Object key) {
            return classVariable.innerRemoveVariable(key);
        }

        @Override
        public Re_Variable innerFindMapOrParentVariable(Object key) {
            return reClass.innerFindMapOrParentVariable(key);
        }

        @Override
        public Re_Variable innerFindMapVariable(Object key) {
            return classVariable.innerFindMapVariable(key);
        }

        @Override
        public Re_Variable innerGetVariable(Object key) {
            return classVariable.innerGetVariable(key);
        }

        @Override
        public Re_Variable innerPutVariable(Object key, Re_Variable value) {
            return classVariable.innerPutVariable(key, value);
        }

        @Override
        public boolean innerContainsVariable(Object key) {
            return classVariable.innerContainsVariable(key);
        }

        @Override
        public int innerGetVariableCount() {
            return classVariable.innerGetVariableCount();
        }

        @Override
        public Iterable<?> innerGetVariableKeys() {
            return classVariable.innerGetVariableKeys();
        }

        @Override
        public Re_IReInnerVariableMap innerCloneVariableMap() {
            return classVariable.innerCloneVariableMap();
        }


        @Override
        public Object[] getArguments() {
            return arguments;
        }
    }

    private static class ReClassStaticFunctionNoParentExecutor extends Re_Executor {
        final Object[] arguments;
        final Re_IReInnerVariableMap local;

        private ReClassStaticFunctionNoParentExecutor(Re host, Re_NativeStack stack,
                                                     Re_CodeFile block,
                                                     Re_Class reClass,
                                                     Re_IReInnerVariableMap local, Object[] arguments) {
            super(host, stack, block, reClass, null);
            this.mThis = this;

            this.local = local;
            this.arguments = arguments;
        }

        @Override
        public Object localValue(String key) {
            return Re_Variable.accessFindMapOrParentValueRequire(this, key, local);
        }
        @Override
        public Object localValue(String key, Object value) {
            Re_Variable.accessSetValue(this, key, value, local);
            return value;
        }


        @Override
        public Re_Variable innerRemoveVariable(Object key) {
            return local.innerRemoveVariable(key);
        }

        @Override
        public Re_Variable innerFindMapOrParentVariable(Object key) {
            return local.innerFindMapOrParentVariable(key);
        }

        @Override
        public Re_Variable innerFindMapVariable(Object key) {
            return local.innerFindMapVariable(key);
        }

        @Override
        public Re_Variable innerGetVariable(Object key) {
            return local.innerGetVariable(key);
        }

        @Override
        public Re_Variable innerPutVariable(Object key, Re_Variable value) {
            return local.innerPutVariable(key, value);
        }

        @Override
        public boolean innerContainsVariable(Object key) {
            return local.innerContainsVariable(key);
        }

        @Override
        public int innerGetVariableCount() {
            return local.innerGetVariableCount();
        }

        @Override
        public Iterable<?> innerGetVariableKeys() {
            return local.innerGetVariableKeys();
        }

        @Override
        public Re_IReInnerVariableMap innerCloneVariableMap() {
            return local.innerCloneVariableMap();
        }


        @Override
        public Object[] getArguments() {
            return arguments;
        }

    }

    private static class ReClassStaticFunctionHasParentExecutor extends Re_Executor {
        final Re_ClassFunction function;
        final Re_Executor      functionParentExecutor;
        final Object[]         arguments;
        final Re_IReInnerVariableMap local;

        private ReClassStaticFunctionHasParentExecutor(Re host, Re_NativeStack stack,
                                                      Re_CodeFile block,
                                                      Re_Class reClass,
                                                      Re_ClassFunction function, Re_Executor functionParentExecutor,
                                                      Object[] arguments, Re_IReInnerVariableMap local) {
            super(host, stack, block, reClass, null);
            this.mThis = this;

            this.function = function;
            this.functionParentExecutor = functionParentExecutor;
            this.arguments = arguments;
            this.local = local;
        }

        @Override
        public Object localValue(String key) {
            return Re_Variable.accessFindMapOrParentValueRequire(this, key, local, functionParentExecutor);
        }

        @Override
        public Object localValue(String key, Object value) {
            Re_Variable.accessSetValue(this, key, value, local);
            return value;
        }


        @Override
        public Re_Variable innerRemoveVariable(Object key) {
            return local.innerRemoveVariable(key);
        }

        @Override
        public Re_Variable innerFindMapOrParentVariable(Object key) {
            Re_Variable re_variable = local.innerFindMapOrParentVariable(key);
            if (null == re_variable)
                re_variable = functionParentExecutor.innerFindMapOrParentVariable(key);
            return re_variable;
        }

        @Override
        public Re_Variable innerFindMapVariable(Object key) {
            return local.innerFindMapVariable(key);
        }

        @Override
        public Re_Variable innerGetVariable(Object key) {
            return local.innerGetVariable(key);
        }

        @Override
        public Re_Variable innerPutVariable(Object key, Re_Variable value) {
            return local.innerPutVariable(key, value);
        }

        @Override
        public boolean innerContainsVariable(Object key) {
            return local.innerContainsVariable(key);
        }

        @Override
        public int innerGetVariableCount() {
            return local.innerGetVariableCount();
        }

        @Override
        public Iterable<?> innerGetVariableKeys() {
            return local.innerGetVariableKeys();
        }

        @Override
        public Re_IReInnerVariableMap innerCloneVariableMap() {
            return local.innerCloneVariableMap();
        }

        @Override
        public Object[] getArguments() {
            return arguments;
        }

    }

    private static class ReClassObjectFunctionNoParentExecutor extends Re_Executor {
        final Re_ClassInstance       instance;
        final Re_IReInnerVariableMap local;
        final Object[]               arguments;

        private ReClassObjectFunctionNoParentExecutor(Re host, Re_NativeStack stack,
                                                     Re_CodeFile block,
                                                     Re_Class reClass, Re_ClassInstance instance,
                                                     Object[] finalArguments, Re_IReInnerVariableMap local) {
            super(host, stack, block, reClass, instance);
            this.mThis = this;

            this.instance = instance;
            this.local = local;
            this.arguments = finalArguments;
        }

        @Override
        public Object localValue(String key) {
            return Re_Variable.accessFindMapOrParentValueRequire(this, key, local, instance);
        }

        @Override
        public Object localValue(String key, Object value) {
            Re_Variable.accessSetValue(this, key, value, local);
            return value;
        }


        @Override
        public Re_Variable innerRemoveVariable(Object key) {
            return local.innerRemoveVariable(key);
        }

        @Override
        public Re_Variable innerFindMapOrParentVariable(Object key) {
            Re_Variable re_variable = local.innerFindMapOrParentVariable(key);
            if (null == re_variable)
                re_variable = instance.innerFindMapOrParentVariable(key);
            return re_variable;
        }

        @Override
        public Re_Variable innerFindMapVariable(Object key) {
            return local.innerFindMapVariable(key);
        }

        @Override
        public Re_Variable innerGetVariable(Object key) {
            return local.innerGetVariable(key);
        }

        @Override
        public Re_Variable innerPutVariable(Object key, Re_Variable value) {
            return local.innerPutVariable(key, value);
        }

        @Override
        public boolean innerContainsVariable(Object key) {
            return local.innerContainsVariable(key);
        }

        @Override
        public int innerGetVariableCount() {
            return local.innerGetVariableCount();
        }

        @Override
        public Iterable<?> innerGetVariableKeys() {
            return local.innerGetVariableKeys();
        }

        @Override
        public Re_IReInnerVariableMap innerCloneVariableMap() {
            return local.innerCloneVariableMap();
        }

        @Override
        public Object[] getArguments() {
            return arguments;
        }
    }

    private static class ReClassObjectFunctionHasParentExecutor extends Re_Executor {
        final Re_ClassFunction       function;
        final Re_Executor            functionParentExecutor;
        final Object[]               arguments;
        final Re_IReInnerVariableMap local;

        private ReClassObjectFunctionHasParentExecutor(Re host, Re_NativeStack stack,
                                                      Re_CodeFile block,
                                                      Re_Class reClass, Re_ClassInstance instance,
                                                      Re_ClassFunction function, Re_Executor functionParentExecutor,
                                                      Object[] arguments, Re_IReInnerVariableMap local) {
            super(host, stack, block, reClass, instance);
            this.mThis = this;

            this.function = function;
            this.functionParentExecutor = functionParentExecutor;
            this.arguments = arguments;
            this.local = local;
        }

        @Override
        public Object localValue(String key) {
            return Re_Variable.accessFindMapOrParentValueRequire(this, key, local, functionParentExecutor);
        }

        @Override
        public Object localValue(String key, Object value) {
            Re_Variable.accessSetValue(this, key, value, local);
            return value;
        }


        @Override
        public Re_Variable innerRemoveVariable(Object key) {
            return local.innerRemoveVariable(key);
        }

        @Override
        public Re_Variable innerFindMapOrParentVariable(Object key) {
            Re_Variable re_variable = local.innerFindMapOrParentVariable(key);
            if (null == re_variable)
                re_variable = functionParentExecutor.innerFindMapOrParentVariable(key);    //不搜索实例变量 需要获取实例变量需要使用this.xx
            return re_variable;
        }

        @Override
        public Re_Variable innerFindMapVariable(Object key) {
            return local.innerFindMapVariable(key);
        }

        @Override
        public Re_Variable innerGetVariable(Object key) {
            return local.innerGetVariable(key);
        }

        @Override
        public Re_Variable innerPutVariable(Object key, Re_Variable value) {
            return local.innerPutVariable(key, value);
        }

        @Override
        public boolean innerContainsVariable(Object key) {
            return local.innerContainsVariable(key);
        }

        @Override
        public int innerGetVariableCount() {
            return local.innerGetVariableCount();
        }

        @Override
        public Iterable<?> innerGetVariableKeys() {
            return local.innerGetVariableKeys();
        }

        @Override
        public Re_IReInnerVariableMap innerCloneVariableMap() {
            return local.innerCloneVariableMap();
        }

        @Override
        public Object[] getArguments() {
            return arguments;
        }
    }























    /**
     * 继承变量以及所有功能 相当于只是个代理 这个
     * @see ReInheritExecutor
     * 的所有操作都会 操作传入的执行器
     */
    private static class ReInheritExecutor extends Re_Executor implements IInheritExecutor {
        final Object[] inheritArguments;

        private ReInheritExecutor(Re host, Re_NativeStack stack, Re_CodeFile block, Re_Executor current_executor, Re_Class reClass, Re_ClassInstance classInstanceObject,
                                 Object[] inheritArguments) {
            super(host, stack, block, reClass, classInstanceObject);
            this.mThis = findRealExecutor(current_executor);

            this.inheritArguments = inheritArguments;
        }


        @Override
        public Object localValue(String key) {
            return mThis.localValue(key);
        }

        @Override
        public Object localValue(String key, Object value) {
            return mThis.localValue(key, value);
        }

        @Override
        public Re_Variable innerRemoveVariable(Object key) {
            return mThis.innerRemoveVariable(key);
        }

        @Override
        public Re_Variable innerFindMapOrParentVariable(Object key) {
            return mThis.innerFindMapOrParentVariable(key);
        }

        @Override
        public Re_Variable innerFindMapVariable(Object key) {
            return mThis.innerFindMapVariable(key);
        }

        @Override
        public Re_Variable innerGetVariable(Object key) {
            return mThis.innerGetVariable(key);
        }

        @Override
        public Re_Variable innerPutVariable(Object key, Re_Variable value) {
            return mThis.innerPutVariable(key, value);
        }

        @Override
        public boolean innerContainsVariable(Object key) {
            return mThis.innerContainsVariable(key);
        }


        @Override
        public int innerGetVariableCount() {
            return mThis.innerGetVariableCount();
        }

        @Override
        public Iterable<?> innerGetVariableKeys() {
            return mThis.innerGetVariableKeys();
        }

        @Override
        public Re_IReInnerVariableMap innerCloneVariableMap() {
            return mThis.innerCloneVariableMap();
        }

        @Override
        public Object[] getArguments() {
            return mThis.getArguments();
        }



        @Override
        public Re_Executor getRealExecutor() {
            return mThis;
        }

        @Override
        public Object[] getInheritArguments() {
            return inheritArguments;
        }
    }




    private static class ReCreateDictExecutor extends Re_Executor implements IInheritExecutor {
        final Re_Executor supez;
        final Re_PrimitiveClassInstance dictInstance;

        private ReCreateDictExecutor(Re_Executor executor, Re_CodeFile block, Re_Class reClass, Re_ClassInstance reClassInstance,
                                    Re_PrimitiveClassInstance dictInstance) {
            super(executor.re, executor.reStack, block, reClass, reClassInstance);
            this.mThis = findRealExecutor(executor);

            this.supez = executor;
            this.dictInstance = dictInstance;
        }

        @Override
        public Object localValue(String key) {
            return Re_Variable.accessFindMapOrParentValueRequire(this, key, mThis); //不获取实例的变量
        }
        @Override
        public Object localValue(String key, Object value) {
            Re_Variable.accessSetValue(this, key, value, dictInstance);
            return value;
        }


        @Override
        public Re_Variable innerRemoveVariable(Object key) {
            return dictInstance.innerRemoveVariable(key);
        }

        @Override
        public Re_Variable innerFindMapOrParentVariable(Object key) {
            return mThis.innerFindMapOrParentVariable(key);
        }

        @Override
        public Re_Variable innerFindMapVariable(Object key) {
            return dictInstance.innerFindMapVariable(key);
        }

        @Override
        public Re_Variable innerGetVariable(Object key) {
            return dictInstance.innerGetVariable(key);
        }


        @Override
        public Re_Variable innerPutVariable(Object key, Re_Variable value) {
            return dictInstance.innerPutVariable(key, value);
        }


        @Override
        public boolean innerContainsVariable(Object key) {
            return dictInstance.innerContainsVariable(key);
        }

        @Override
        public int innerGetVariableCount() {
            return dictInstance.innerGetVariableCount();
        }

        @Override
        public Iterable<?> innerGetVariableKeys() {
            return dictInstance.innerGetVariableKeys();
        }

        @Override
        public Re_IReInnerVariableMap innerCloneVariableMap() {
            return dictInstance.innerCloneVariableMap();
        }

        @Override
        public Object[] getArguments() {
            return mThis.getArguments();
        }




        @Override
        public Re_Executor getRealExecutor() {
            return mThis;
        }

        @Override
        public Object[] getInheritArguments() {
            return findInheritArguments(supez);
        }
    }



    @Override
    public boolean equals(Object o) {
        return this == o;
    }
    @Override
    public int hashCode() {
        return super.hashCode();
    }
    @Override
    public String toString() {
        return Re_Variable.key(this).toString();
    }



    @Override
    public boolean isPrimitive() {
        return true;
    }



    @Override
    public Object getVariableValue(Re_Executor executor, Object key) {
        return Re_Variable.accessFindMapValue(executor, key, Re_Executor.this);
    }

    @Override
    public boolean containsVariable(Re_Executor executor, Object key) {
        return Re_Variable.has(key, Re_Executor.this);
    }

    @Override
    public boolean removeVariable(Re_Executor executor, Object key) throws Throwable {
        return Re_Variable.accessRemove(executor, key, Re_Executor.this);
    }

    @Override
    public void putVariableValue(Re_Executor executor, Object key, Object value) {
        Re_Variable.accessSetValue(executor, key, value, Re_Executor.this);
    }

    @Override
    public int getVariableCount(Re_Executor executor) {
        return Re_Variable.size(Re_Executor.this);
    }

    @Override
    public Iterable getVariableKeys(Re_Executor executor) throws Throwable {
        return Re_Variable.key(Re_Executor.this);
    }


    @Override
    public final Object executePoint(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
        Object funCall = Re_Variable.accessFindMapValue(executor, point_key, this);
        if (executor.isReturnOrThrow()) return null;

        if (null == funCall) {
            this.setThrow(Re_Accidents.undefined(this, point_key));
            return null;
        }
        return this.executeCallThis(funCall, point_key, call);
    }
    @Override
    public final Object executeThis(Re_Executor executor, String that_key, Call call) throws Throwable {
        return executor.executeGVFromReObject(Re_Executor.this, call);
    }



    @Override
    public String getName() {
        return Re_Keywords.INNER_VAR__SPACE + "{" + hashCode() + '}';
    }
}
