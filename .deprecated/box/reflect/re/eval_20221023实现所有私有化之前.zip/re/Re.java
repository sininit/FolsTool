package top.fols.box.reflect.re;

import top.fols.atri.lang.Objects;
import top.fols.box.reflect.re.interfaces.Re_IJavaReflector;
import top.fols.box.reflect.re.interfaces.Re_IReInnerVariableMap;
import top.fols.box.reflect.re.resource.Re_IResource;

import java.io.Closeable;
import java.io.IOException;
import java.util.*;

/**
 *
 * 2021/11/12 - 2021/11/30
 * @author GXin <a href="http://github.com/sininit">http://github.com/sininit</a>
 *
 *
 *
 *
 *
 * thread safe
 *
 * $("$1.out.println($2)", import_java_class("java.lang.System"), 666)    >> System.out.println(666)
 */
public class Re implements Closeable {
    /*@Override */protected void finalize() {this.close();}


    @Override
    public void close() {
        this.close_debugger();
    }


    @SuppressWarnings("TryFinallyCanBeTryWithResources")
    public static Object $(String expression, Object... params) throws Re_Accidents.CompileTimeGrammaticalException, Re_Accidents.ExecuteException {
        Re re = new Re();
        try {
            return re.execute(expression, params);
        } finally {
            re.close();
        }
    }
    @SuppressWarnings("TryFinallyCanBeTryWithResources")
    public static Object $(String expression, Re_IReInnerVariableMap variableMap, Object... params) throws Re_Accidents.CompileTimeGrammaticalException, Re_Accidents.ExecuteException {
        Re re = new Re();
        try {
            return re.execute(expression, variableMap, params);
        } finally {
            re.close();
        }
    }
    public static Re_CodeFile compile(String expression, String filePath, int lineOffset) throws Re_Accidents.CompileTimeGrammaticalException {
        Re_CodeLoader re_codeLoader = new Re_CodeLoader();
        return re_codeLoader.load(expression, filePath ,lineOffset);
    }



    /**
     * return class point object
     * @param type class
     */
    public static Re_ZPrimitiveObject_jimport jimport(Class<?> type) {
        return Re_Utilities.toReJImport(type);
    }

    public static Re_ZPrimitiveObject_jobject jobject(Class<?> type) {
        return Re_Utilities.toReJObject(type);
    }






    public static void throwStackException(Re_Executor executor) throws Re_Accidents.ExecuteException {
        throwStackException(executor.getStack());
    }
    public static void throwStackException(Re_NativeStack reStack) throws Re_Accidents.ExecuteException {
        if (reStack.isThrow()) {
            Re_ZPrimitiveClass_exception.Instance aThrow = reStack.getThrow();
            String stacksString = aThrow.asString();
            throw new Re_Accidents.ExecuteException(stacksString);
        }
    }










    private static final Re_IJavaReflector DEFAULT_REFLECTOR    = new Re_Reflector();
    private static final Map<String, Re_CodeFile>   compile     = new WeakHashMap<>();//写锁
    private static final Object                     compileLock = new Object();








    protected Re_IJavaReflector       reflector;          //Java反射器, 不要返回任何对象（Field,Method,Constructor）给用户,仅用于内部执行,防止用户setAccessible
    protected boolean                 noUseCompileCache;


    @SuppressWarnings("FieldMayBeFinal")
    private Re_PrimitiveClassInstance             reEnv = Re_ZPrimitiveClass_object.reclass.newInstance();
    private Re_ClassLoader.BootstrapReClassLoader reBootstrapClassLoader;
    protected volatile Re_ZDebuggerServer         reDebuggerServer;


    public Re() {
        this(DEFAULT_REFLECTOR);
    }
    public Re(Re_IJavaReflector reflector) {
        this.reflector = Objects.requireNonNull(reflector, "reflector");
    }




    /**
     * env.xxx
     */
    public Object getEnvironment(String name)               { return Re_Variable.Unsafes.fromUnsafeAccessorGetValueOrThrowEx(name, reEnv); }
    public void setEnvironment(String name, Object value)   { Re_Variable.Unsafes.fromUnsafeAccessorSetValueInternOrThrowEx(name, value, reEnv); }
    public boolean hasEnvironment(String name)              { return Re_Variable.has(name, reEnv); }
    public Re_PrimitiveClassInstance getEnvironmentMap()    { return reEnv; }



    /**
     * 默认不使用缓存
     * 因为缓存无法保证代码是否被修改了
     */
    public void setNoUseCompileCache(boolean useCompileCache) {
        this.noUseCompileCache = useCompileCache;
    }
    public boolean isNoUseCompileCache() {
        return noUseCompileCache;
    }



    public Re_CodeFile compileCode(String expression) throws Re_Accidents.CompileTimeGrammaticalException {
        return compileCode(expression, Re_CodeFile.FILE_NAME__JAVA_SOURCE);
    }
    public Re_CodeFile compileCode(String expression, String filePath) throws Re_Accidents.CompileTimeGrammaticalException {
        return compileCode(expression, filePath, 1);
    }

    /**
     *
     * @param expression     表达式
     * @param filePath      表达式所在文件
     * @param lineOffset    表达式所在文件行
     * @return 每次返回的数据可能都不一样
     */
    public Re_CodeFile compileCode(String expression, String filePath, int lineOffset) throws Re_Accidents.CompileTimeGrammaticalException {
        if (noUseCompileCache)
            return compile(expression, filePath, lineOffset);

        Re_CodeFile query = compile.get(expression);
        if (null == query) {
            synchronized (compileLock) {
                compile.put(expression, query = compile(expression, filePath, lineOffset <= 0 ? 1 : lineOffset));
            }
        }
        /*
         * 为了防止对比字符串需要的性能，直接判断是否地址相等就行了
         */
        //noinspection StringEquality
        if (filePath != query.filePath || query.lineOffset != lineOffset) {
            query = query.clone();  //克隆代码但是不克隆文件信息
            query.filePath = filePath;
            query.lineOffset = lineOffset <= 0 ? 1 : lineOffset;
        }
        return query;
    }






    public Object execute(final String expression, Object... params) throws Re_Accidents.CompileTimeGrammaticalException, Re_Accidents.ExecuteException {
        Re_CodeFile block = compileCode(expression);
        return execute(block, Re_NativeStack.newStack(), Re.newLocalVariableMap(), params);
    }
    public Object execute(final Re_CodeFile block, Object... params) throws Re_Accidents.CompileTimeGrammaticalException, Re_Accidents.ExecuteException {
        return execute(block, Re_NativeStack.newStack(), Re.newLocalVariableMap(), params);
    }
    public Object execute(final String expression, Re_IReInnerVariableMap variableMap, Object... params) throws Re_Accidents.CompileTimeGrammaticalException, Re_Accidents.ExecuteException {
        Re_CodeFile block = compileCode(expression);
        return execute(block, Re_NativeStack.newStack(), variableMap, params);
    }
    public Object execute(final Re_CodeFile block, Re_IReInnerVariableMap variableMap, Object... params) throws Re_Accidents.CompileTimeGrammaticalException, Re_Accidents.ExecuteException {
        return execute(block, Re_NativeStack.newStack(), variableMap, params);
    }
    public Object execute(final Re_CodeFile block, Re_NativeStack stack, Re_IReInnerVariableMap variableMap, Object... params) throws Re_Accidents.CompileTimeGrammaticalException, Re_Accidents.ExecuteException {
        Re_Executor executor = Re_Executor.createReRootExecutor(this, stack , block, params, variableMap);
        Re.throwStackException(stack);

        Object result  = executor.run();
        Re.throwStackException(stack);
        return result;
    }








    public void print(String str)  {
        System.out.print(str);
    }

    public void println() {
        println("");
    }
    public void println(String content) {
        print(content + "\n");
    }




    protected Re_ClassLoader.BootstrapReClassLoader createBootstrapReClassLoader() {
        return new Re_ClassLoader.BootstrapReClassLoader(this);
    }

    @SuppressWarnings("unused")
    public Re_ClassLoader openBootstrapClassLoader() {
        return null == reBootstrapClassLoader ?
                (reBootstrapClassLoader = createBootstrapReClassLoader()) :
                 reBootstrapClassLoader;
    }
    public void addBootstrapClassLoaderResource(Re_IResource resource) {
        if (null != resource) {
            openBootstrapClassLoader()
                    .addSourceManager(resource);
        }
    }
    public boolean        removeBootstrapClassLoaderResource(Re_IResource resource) {
        return null != reBootstrapClassLoader && reBootstrapClassLoader.removeSourceManager(resource);
    }
    public boolean        hasBootstrapClassLoaderResource(Re_IResource resource) {
        return null != reBootstrapClassLoader && reBootstrapClassLoader.hasSourceManager(resource);
    }
    public Re_IResource[] getBootstrapClassLoaderResources() {
        return null == reBootstrapClassLoader ? null : reBootstrapClassLoader.getSources();
    }




    public boolean is_debugger() {
        return null != reDebuggerServer;
    }
    public Re_ZDebuggerServer get_debugger() {
        synchronized (this) {
            if (null == reDebuggerServer) {
                reDebuggerServer = new Re_ZDebuggerServer(this);
            }
            return reDebuggerServer;
        }
    }
    public void close_debugger() {
        synchronized (this) {
            if (null != reDebuggerServer) {
                reDebuggerServer.close();
                reDebuggerServer = null;
            }
        }
    }
    public Re_ZDebuggerServer open_debugger() throws IOException, InterruptedException {
        Re_ZDebuggerServer debugger;
        debugger = get_debugger();
        debugger.start();
        return debugger;
    }



    static Re_IReInnerVariableMap newPrimitiveJsonVariableMap()      { return new Re_ZVariableMap_SyncLinked(); }
    static Re_IReInnerVariableMap newPrimitiveObjectVariableMap()    { return new Re_ZVariableMap_Sync(); }
    static Re_IReInnerVariableMap newObjectVariableMap()             { return new Re_ZVariableMap(); }
    static Re_IReInnerVariableMap newLocalVariableMap()              { return new Re_ZVariableMap(); }
}