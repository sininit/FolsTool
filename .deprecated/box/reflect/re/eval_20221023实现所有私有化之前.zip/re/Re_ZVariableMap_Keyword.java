package top.fols.box.reflect.re;

import top.fols.box.reflect.re.interfaces.Re_IReInnerVariableMap;

import java.util.*;

/**
 * 关键词应该是可见的
 */
// no sync lock
@SuppressWarnings({"unchecked", "rawtypes", "SynchronizeOnNonFinalField"})
public class Re_ZVariableMap_Keyword implements Re_IReInnerVariableMap {
    private Object lock = new Object();
    private HashMap<Object, Re_Variable> map = new HashMap<>();
    private IdentityHashMap<Object, Object> valueMappingKey = new IdentityHashMap<>();  //可能存在重复的value，所以用IdentityHashMap
    private Collection<?> keySetCache;

    @SuppressWarnings("unchecked")
    @Override
    public Re_IReInnerVariableMap innerCloneVariableMap() {
        Re_ZVariableMap_Keyword instance = new Re_ZVariableMap_Keyword();
        instance.lock = new Object();
        instance.map = (HashMap<Object, Re_Variable>) Re_Variable.Unsafes.copy(this.map, new HashMap<Object, Re_Variable>());
        instance.valueMappingKey = (IdentityHashMap<Object, Object>) valueMappingKey.clone();
        instance.keySetCache = null;
        return instance;
    }


    public boolean isKeywordKey(Object value) {
        return map.containsKey(value);
    }
    public boolean isKeywordValue(Object value) {
        return valueMappingKey.containsKey(value);
    }
    public Object getKeywordKey(Object value) {
        return valueMappingKey.get(value);
    }
    public Object findKeyword(Object key) {
        try {
            return Re_Variable.Unsafes.fromUnsafeAccessorGetValueOrThrowEx(key, this);
        } catch (Throwable ignored) {}
        return null;
    }
    public Object findRuntimeKeyword(Re_Executor executor, Object key) {
        return Re_Variable.accessGetValue(executor, key, this);
    }
    public boolean isRuntimeKeyword(Object key) {
        Re_Variable variable  = Re_Variable.Unsafes.getVariable(key, this);
        return null != variable && variable.isDynamicVariable();
    }

    public String[] getKeywordNames() {
        Set <Object> x = new LinkedHashSet<>();
        for (Object o : Re_Variable.key(this)) {
            x.add(o);
        }

        String[] keys = new String[x.size()];
        int i = 0;
        for (Object o: x) {
            keys[i++] = (String) o;
        }
        return keys;
    }






    @Override
    public Re_Variable innerRemoveVariable(Object key) {
        synchronized (lock) {
            Re_Variable<?> remove = map.remove(key);
            if (null != remove) {
                Object value = null;
                try {
                    value = Re_Variable.Unsafes.fromUnsafeAccessorGetValueOrThrowEx(remove);
                } catch (Throwable ignored) {}
                valueMappingKey.remove(value);
            }
            return remove;
        }
    }

    @Override
    public Re_Variable innerFindMapOrParentVariable(Object key) {
        synchronized (lock) {
            return map.get(key);
        }
    }


    /**
     * 原始获取
     * 理论上你必须使用 {@link Re_Variable} 而不是自己操作， 这些方法主要 {@link Re_Variable} 调用
     *
     */
    @Override
    public Re_Variable innerFindMapVariable(Object key) {
        synchronized (lock) {
            return map.get(key);
        }
    }

    @Override
    public Re_Variable innerGetVariable(Object key) {
        synchronized (lock) {
            return map.get(key);
        }
    }

    @Override
    public Re_Variable innerPutVariable(Object key, Re_Variable variable) {
        if (key instanceof String) {
            synchronized (lock) {
                if (null != variable) {
                    Object value = null;
                    try {
                        value = Re_Variable.Unsafes.fromUnsafeAccessorGetValueOrThrowEx(variable);
                    } catch (Throwable ignored) {}
                    valueMappingKey.put(value, key);
                }
                return map.put(key, variable);
            }
        }
        throw new IllegalArgumentException("key must be String");
    }

    @Override
    public boolean innerContainsVariable(Object key) {
        synchronized (lock) {
            return map.containsKey(key);
        }
    }

    @Override
    public int innerGetVariableCount() {
        synchronized (lock) {
            return map.size();
        }
    }


    @Override
    public Collection<?> innerGetVariableKeys() {
        synchronized (lock) {
            return null == keySetCache ? keySetCache = new ReplaceCollection(this) : keySetCache;
        }
    }



    @Override
    public int hashCode() {
        synchronized (lock) {
            return map.hashCode();
        }
    }

    @Override
    public boolean equals(Object obj) {
        synchronized (lock) {
            if (obj instanceof Re_ZVariableMap_Keyword) {
                return map.equals(((Re_ZVariableMap_Keyword) obj).map);
            }
            return map.equals(obj);
        }
    }

    @Override
    public String toString() {
        synchronized (lock) {
            return map.toString();
        }
    }





    @SuppressWarnings("rawtypes")
    public static class ReplaceCollection implements Collection {
        final Re_ZVariableMap_Keyword parent;
        final Collection<Object> objectCollection;
        public ReplaceCollection(Re_ZVariableMap_Keyword parent) {
            this.parent = parent;
            this.objectCollection = parent.map.keySet();
        }


        @Override
        public int size() {
            synchronized (parent.lock) {
                return objectCollection.size();
            }
        }

        @Override
        public boolean isEmpty() {
            synchronized (parent.lock) {
                return objectCollection.isEmpty();
            }
        }

        @Override
        public void clear() {
            synchronized (parent.lock) {
                parent.map.clear();
                parent.valueMappingKey.clear();
            }
        }

        @Override
        public int hashCode() {
            synchronized (parent.lock) {
                return objectCollection.hashCode();
            }
        }

        @Override
        public boolean equals(Object obj) {
            synchronized (parent.lock) {
                if (obj instanceof ReplaceCollection) {
                    return objectCollection.equals(((ReplaceCollection) obj).objectCollection);
                }
                return objectCollection.equals(obj);
            }
        }

        @Override
        public String toString() {
            synchronized (parent.lock) {
                return objectCollection.toString();
            }
        }

        @Override
        public Iterator<?> iterator() {
            return wrapIterator(this);
        }


        @Override
        public boolean add(Object key) {
            synchronized (parent.lock) {
                boolean b = parent.innerContainsVariable(key);
                if (b) {
                    return false;
                } else {
                    return null == parent.innerPutVariable(key, null);
                }
            }
        }
        @Override
        public boolean remove(Object key) {
            return parent.innerRemoveVariable(key) != null;
        }

        @Override
        public boolean contains(Object key) {
            return parent.innerContainsVariable(key);
        }



        @Override
        public boolean containsAll(Collection c) {
            if (c != this) {
                for (Object e : c) {
                    if (!contains(e))
                        return false;
                }
            }
            return true;
        }
        @Override
        public boolean addAll(Collection c) {
            if (c == null) return false;
            for (Object e : c) {
                add(e);
            }
            return true;
        }

        @Override
        public boolean retainAll(Collection c) {
            if (c == null) return false;
            boolean modified = false;
            for (Iterator it = iterator(); it.hasNext();) {
                Object next = it.next();
                if (!c.contains(next)) {
                    it.remove();
                    modified = true;
                }
            }
            return modified;
        }
        @Override
        public boolean removeAll(Collection c) {
            if (c == null) return true;
            boolean modified = false;
            for (Iterator this_it = iterator(); this_it.hasNext();) {
                Object this_next = this_it.next();
                if (c.contains(this_next)) {
                    this_it.remove();
                    modified = true;
                }
            }
            return modified;
        }




        @Override
        public Object[] toArray() {
            return objectCollection.toArray();
        }

        @Override
        public Object[] toArray(Object[] a) {
            return objectCollection.toArray(a);
        }
    }
    /**
     * 因为替换了null key 所以需要对Set进行过滤
     */
    public static Iterator wrapIterator(final ReplaceCollection parent) {
        if (null == parent) {
            return null;
        }

        final Iterator iterator = parent.objectCollection.iterator();
        return new Iterator() {
            final Object lock = new Object();
            Object current;

            @Override
            public boolean hasNext() {
                // TODO: Implement this method
                return iterator.hasNext();
            }


            @Override
            public Object next() {
                // TODO: Implement this method
                synchronized (lock) {
                    return current = iterator.next();
                }
            }

            @Override
            public void remove() {
                // TODO: Implement this method
                synchronized (lock) {
                    parent.remove(current);
                }
            }
        };
    }
}
