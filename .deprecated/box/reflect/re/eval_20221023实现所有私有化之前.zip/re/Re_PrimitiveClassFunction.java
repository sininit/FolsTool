package top.fols.box.reflect.re;


public class Re_PrimitiveClassFunction extends Re_ClassFunction {
    public Re_PrimitiveClassFunction(String name,
                                     Re_Class declaringReClass, Re_ClassInstance declaringReClassInstance) {
        this(name,null,
                declaringReClass, declaringReClassInstance);
    }
    public Re_PrimitiveClassFunction(String name, String[] param,
                                     Re_Class declaringReClass, Re_ClassInstance declaringReClassInstance) {
        Re_CodeFile block = new Re_CodeFile();
        block.lineOffset         = Re_CodeFile.LINE_OFFSET;
        block.filePath           = getClass().getName();
        block.expressions        = Re_CodeLoader.Expression.EMPTY_EXPRESSION;
        block.expressionsOffset  = 0;

        Re_ClassFunction.createAfter(this, block, name, param, null,
                declaringReClass, declaringReClassInstance);
    }


    @Override
    public final boolean isPrimitive() {
        return true;
    }



    public static class ParamCheckerFunction extends Re_ClassFunction.ParamCheckerFunction {
        public ParamCheckerFunction(String name,
                                    String[] parameters, Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker[] paramTypes,
                                    Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker returnChecker,
                                    Re_Class declaringReClass, Re_ClassInstance declaringReClassInstance) {
            Re_CodeFile block       = new Re_CodeFile();
            block.lineOffset         = Re_CodeFile.LINE_OFFSET;
            block.filePath           = getClass().getName();
            block.expressions        = Re_CodeLoader.Expression.EMPTY_EXPRESSION;
            block.expressionsOffset  = 0;

            Re_ClassFunction.createAfter(this, block, name, parameters, null,
                    declaringReClass, declaringReClassInstance);

            super.paramChecker  = null == paramTypes    ? Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker.EMPTY_ARRAY     : paramTypes;
            super.returnChecker = null == returnChecker ? Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker.NOT_CHECK_RETURN: returnChecker;
        }

        @Override
        public final boolean isPrimitive() {
            return true;
        }
    }
}
