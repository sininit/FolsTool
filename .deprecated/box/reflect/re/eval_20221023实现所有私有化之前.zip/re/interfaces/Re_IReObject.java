package top.fols.box.reflect.re.interfaces;

import top.fols.atri.util.annotation.NotNull;
import top.fols.box.reflect.re.*;

/**
 * 只要参数含有 {@link Re_Executor} 的方法 后都要手动检测是否 {@link Re_Executor#isReturnOrThrow()} 如果是直接返回null
 */
@SuppressWarnings("ALL")
public interface Re_IReObject {

	/**
	 * 底层实现的对象
	 */
	public boolean isPrimitive();


	/**
	 * 执行之前不可能已经return， 如果中间有执行了表达式应该判断表达式是否已经return 如果已经return 则返回return数据 而不是继续操作, 如果已经return返回的任何数据都是无效的
	 * 只要参数含有 {@link Re_Executor} 的方法 后都要手动检测是否 {@link Re_Executor#isReturnOrThrow()} 如果是直接返回null
	 */
	public Object getVariableValue(Re_Executor executor, Object key) throws Throwable;


	/**
	 * 执行之前不可能已经return， 如果中间有执行了表达式应该判断表达式是否已经return 如果已经return 则返回return数据 而不是继续操作, 如果已经return返回的任何数据都是无效的
	 * 只要参数含有 {@link Re_Executor} 的方法 后都要手动检测是否 {@link Re_Executor#isReturnOrThrow()} 如果是直接返回null
	 */
	public void putVariableValue(Re_Executor executor, Object key, Object value) throws Throwable;






	/**
	 * 执行之前不可能已经return， 如果中间有执行了表达式应该判断表达式是否已经return 如果已经return 则返回return数据 而不是继续操作, 如果已经return返回的任何数据都是无效的
	 * 只要参数含有 {@link Re_Executor} 的方法 后都要手动检测是否 {@link Re_Executor#isReturnOrThrow()} 如果是直接返回null
	 */
	public boolean containsVariable(Re_Executor executor, Object key) throws Throwable;

	/**
	 * 执行之前不可能已经return， 如果中间有执行了表达式应该判断表达式是否已经return 如果已经return 则返回return数据 而不是继续操作, 如果已经return返回的任何数据都是无效的
	 * 只要参数含有 {@link Re_Executor} 的方法 后都要手动检测是否 {@link Re_Executor#isReturnOrThrow()} 如果是直接返回null
	 */
	public boolean removeVariable(Re_Executor executor, Object key) throws Throwable;

	/**
	 * 执行之前不可能已经return， 如果中间有执行了表达式应该判断表达式是否已经return 如果已经return 则返回return数据 而不是继续操作, 如果已经return返回的任何数据都是无效的
	 * 只要参数含有 {@link Re_Executor} 的方法 后都要手动检测是否 {@link Re_Executor#isReturnOrThrow()} 如果是直接返回null
	 */
	public int getVariableCount(Re_Executor executor) throws Throwable;

	/**
	 * 执行之前不可能已经return， 如果中间有执行了表达式应该判断表达式是否已经return 如果已经return 则返回return数据 而不是继续操作, 如果已经return返回的任何数据都是无效的
	 * 只要参数含有 {@link Re_Executor} 的方法 后都要手动检测是否 {@link Re_Executor#isReturnOrThrow()} 如果是直接返回null
	 */
	public @NotNull Iterable getVariableKeys(Re_Executor executor) throws Throwable;



















	/**
	 * 执行之前不可能已经return， 如果中间有执行了表达式应该判断表达式是否已经return 如果已经return 则返回return数据 而不是继续操作, 如果已经return返回的任何数据都是无效的
	 * 只要参数含有 {@link Re_Executor} 的方法 后都要手动检测是否 {@link Re_Executor#isReturnOrThrow()} 如果是直接返回null
	 *
	 *
	 * 如果你不想处理，建议使用 {@link Re_IReObject#executePoint(Re_Executor, String, Re_CodeLoader.Call)}
	 *
	 * 假定本对象名称x
	 * 那么执行的是 x.x()
	 * @param point_key          指子变量名称，假设这是个map里面有个a
	 *                            执行的就是map.a();
	 * @param call 如果是true 则callParam 为空 ，如果false则 callParam会经过计算后传入
	 */
	public Object executePoint(Re_Executor executor, String point_key,
							   Re_CodeLoader.Call call) throws Throwable;




	/**
	 * 执行之前不可能已经return， 如果中间有执行了表达式应该判断表达式是否已经return 如果已经return 则返回return数据 而不是继续操作, 如果已经return返回的任何数据都是无效的
	 * 只要参数含有 {@link Re_Executor} 的方法 后都要手动检测是否 {@link Re_Executor#isReturnOrThrow()} 如果是直接返回null
	 *
	 * <p>
	 * 假定本对象名称x
	 * 那么执行的是 x()
	 *
	 * @param that_key 为当前名称，并非指子变量名称
	 *                 map();
	 * @param call     如果是true 则callParam 为空 ，如果false则 callParam会经过计算后传入
	 */
	public Object executeThis(Re_Executor executor, String that_key,
							  Re_CodeLoader.Call call) throws Throwable;



	public String getName();
















	public static abstract class IPrimitiveObject implements Re_IReObject {
		@Override
		public boolean isPrimitive() {
			return true;
		}

		@Override
		public String toString() {
			return getName();
		}
	}

	/**
	 * 只执行 call()
	 * 其他任何操作无效
	 *  只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
	 */
	public static abstract class IPrimitiveCall implements Re_IReObject {
		final String callName;
		public IPrimitiveCall(String callName) {
			this.callName = callName;
		}


		@Override
		public String getName() {
			return callName;
		}


		@Override
		public boolean isPrimitive() {
			return true;
		}

		@Override
		public String toString() {
			return getName();
		}




		@Override
		public final boolean containsVariable(Re_Executor executor, Object key) throws Throwable {
			return false;
		}
		@Override
		public final boolean removeVariable(Re_Executor executor, Object key) throws Throwable {
			return false;
		}
		@Override
		public final Object getVariableValue(Re_Executor executor, Object key) throws Throwable {
			return null;
		}
		@Override
		public final void putVariableValue(Re_Executor executor, Object key, Object value) throws Throwable {
			return;
		}
		@Override
		public final int getVariableCount(Re_Executor executor) throws Throwable {
			return 0;
		}
		@Override
		public @NotNull final Iterable getVariableKeys(Re_Executor executor) throws Throwable {
			return null;
		}

		@Override
		public final Object executePoint(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
			executor.setThrow(Re_Accidents.undefined(this, point_key));
			return null;
		}

	}
}
