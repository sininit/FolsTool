package top.fols.box.reflect.re;

import top.fols.atri.lang.Finals;
import top.fols.atri.util.annotation.NotNull;
import top.fols.atri.util.annotation.Nullable;
import top.fols.box.reflect.re.interfaces.*;

@SuppressWarnings("rawtypes")
public class Re_ClassFunction implements Re_IReObject, Re_IReInnerVariableMap, Re_IReGetDeclaringClass, Re_IReGetClass {
    Re_ClassFunction() {}
    Re_ClassFunction superClone() {
        try {
            return (Re_ClassFunction) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }

    @NotNull
    protected  InnerAccessor getInnerAccessor() {
        return InnerAccessor.StandardFunction;
    }





    private String              name;
    private String[]            params;
    Re_CodeFile                 reCodeBlock;

    Re_Executor                 declareExecutor; //parent
    Re_Class                    declareReClass;
    Re_ClassInstance            declareReClassInstance;









    static Re_ClassFunction createReFunction(Re_CodeFile reCodeBlock,
                                             @Nullable String name, @Nullable String[] paramName,
                                             @Nullable Re_Executor parent,
                                             @Nullable Re_Class  declaringReClass, @Nullable Re_ClassInstance declaringReClassInstance) {
        return createAfter(new Re_ClassFunction(), reCodeBlock, name, paramName, parent,
                declaringReClass, declaringReClassInstance);
    }

    static Re_ClassFunction createReParamCheckerFunction(Re_CodeFile reCodeBlock,
                                                         @Nullable String name,
                                                         @Nullable String[] paramName, @Nullable Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker[] paramTypes,
                                                         @Nullable Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker returnType,
                                                         @Nullable Re_Executor parent,
                                                         @Nullable Re_Class  declaringReClass, @Nullable Re_ClassInstance declaringReClassInstance) {
        ParamCheckerFunction newFunction = (ParamCheckerFunction) createAfter(new ParamCheckerFunction(), reCodeBlock,
                name, paramName,
                parent,
                declaringReClass, declaringReClassInstance);
        newFunction.paramChecker  = null == paramTypes ? Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker.EMPTY_ARRAY : paramTypes;
        newFunction.returnChecker = null == returnType ? Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker.NOT_CHECK_RETURN: returnType;
        return newFunction;
    }





    static  Re_ClassFunction createAfter(
            Re_ClassFunction reFunction, Re_CodeFile reCodeBlock,
            @Nullable String name, @Nullable String[] paramName,
            @Nullable Re_Executor parent,
            @Nullable Re_Class declaringReClass, @Nullable Re_ClassInstance declaringReClassInstance) {
        if (null == name) {
            reFunction.name                     = Re_CodeLoader.intern(
                Re_Keywords.INNER_EXPRESSION_CALL__FUNCTION + "_" + reCodeBlock.getLineOffset() + "_" + Integer.toHexString(reFunction.hashCode()));
        } else {
            reFunction.name                     = Re_CodeLoader.intern(name);
        }
        reFunction.params                   = null == paramName? Finals.EMPTY_STRING_ARRAY:paramName;
        reFunction.reCodeBlock              = reCodeBlock;
        reFunction.declareReClass = declaringReClass;
        reFunction.declareReClassInstance = declaringReClassInstance;
        reFunction.declareExecutor = parent;
        return reFunction;
    }







    @Override
    public final Re_Class getReClass() {
        return getReDeclareClass();
    }

    @Override
    public final Re_Class getReDeclareClass() {
        return declareReClass;
    }
    public final Re_ClassInstance getReDeclareReClassInstance() {
        return declareReClassInstance;
    }
    protected final Re_CodeFile getReCodeBlock() {
        return reCodeBlock;
    }
    protected final Re_Executor getParent() {
        return declareExecutor;
    }

    @Override
    public final String getName() {
        return name;
    }
    public final int     getParamCount() {
        return params.length;
    }
    public final String  getParamName(int index) {
        return params[index];
    }




    @Override
    public boolean equals(Object o) {
        return this == o;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public String toString() {
        if (null == declareReClass)
            return "re-" + Re_Keywords.INNER_EXPRESSION_CALL__FUNCTION + " " +
                    getName();
        else
            return "re-" + Re_Keywords.INNER_EXPRESSION_CALL__FUNCTION + " " +
                    declareReClass.getName() + Re_CodeLoader.CODE_OBJECT_POINT_SYMBOL + getName();
    }



    @Override
    public boolean isPrimitive() {
        return false;
    }




    @Override public final boolean           containsVariable(Re_Executor executor, Object key) { return false; }
    @Override public final boolean           removeVariable(Re_Executor executor, Object key) { return false; }
    @Override public final Object            getVariableValue(Re_Executor executor, Object key) { return null; }
    @Override public final void              putVariableValue(Re_Executor executor, Object key, Object value) { }
    @Override public final int               getVariableCount(Re_Executor executor) throws Throwable { return 0; }
    @Override public final @NotNull Iterable getVariableKeys(Re_Executor executor) throws Throwable { return null; }
    @Override public final Object            executePoint(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
        executor.setThrow(Re_Accidents.undefined(this, point_key));
        return null;
    }

    /**
     * 执行之前不可能已经return， 如果中间有执行了表达式应该判断表达式是否已经return 如果已经return 则返回return数据 而不是继续操作, 如果已经return返回的任何数据都是无效的
     * 只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
     * <p>
     * 假定本对象名称x
     * 那么执行的是 x()
     *
     *
     * 只有这个 {@link #authenticationAndExecuteOnRe(Re_Executor, Re_Class, Re_ClassInstance, Object[], Re_IReInnerVariableMap)} 能保证正确的声明来源
     */
    @Override
    public final Object executeThis(Re_Executor executor, String that_key, Re_CodeLoader.Call call) throws Throwable {
        Object[] arguments = executor.getExpressionValues(call);
        if (executor.isReturnOrThrow()) return null;

        //最后一行不需要判断return
        Re_IReInnerVariableMap variableMap = null; //为null 执行时自动生成
        return authenticationAndExecuteOnRe_FromDeclare(executor, arguments, variableMap);
    }


    /**
     * 这个方法除了
     * {@link Re_Class}
     * {@link Re_ClassInstance}
     * {@link Re_ClassFunction}
     *
     * 如果其他方法需要方法必须通过 {@link Re_Class.UnsafesRe}
     *
     * @see Re_Class.UnsafesRe#executeFunction(Re, Re_NativeStack, Re_ClassFunction, Object[], Re_IReInnerVariableMap)}
     */
    protected final Object authenticationAndExecuteOnRe_FromDeclare(Re_Executor executor, //这里可以进行权限检测
                                                                    Object[] arguments, @Nullable Re_IReInnerVariableMap functionLocal) throws Throwable {//permissions check
        return authenticationAndExecuteOnRe(executor,
                declareReClass, declareReClassInstance,
                arguments, functionLocal);
    }
    /**
     * 这个方法除了
     * {@link Re_Class}
     * {@link Re_ClassInstance}
     * {@link Re_ClassFunction}
     *
     * 如果其他方法需要方法必须通过 {@link Re_Class.UnsafesRe}
     */
    protected Object authenticationAndExecuteOnRe(Re_Executor executor,         //这里可以进行权限检测
                                                  Re_Class runInClass, Re_ClassInstance runInInstance,
                                                  Object[] arguments, @Nullable Re_IReInnerVariableMap functionLocal) throws Throwable {//permissions check
        return unauthenticationExecuteOnNative(executor,
                runInClass, runInInstance,
                arguments, functionLocal);
    }

    /**
     * 不要进行任何的权限检测
     */
    protected Object unauthenticationExecuteOnNative(Re_Executor executor,
                                                     Re_Class runInClass, Re_ClassInstance runInInstance,
                                                     Object[] arguments, @Nullable Re_IReInnerVariableMap functionLocal) throws Throwable {//permissions check
        Re_Executor re_executor = Re_Executor
                .createReClassFunctionExecutor(
                        executor.re, executor.getStack(),
                        runInClass, runInInstance,
                        this, arguments, functionLocal);
        if (null == re_executor) return null;//re throw

        return re_executor.run();
    }







    @Override public final Re_Variable            innerRemoveVariable(Object key) {return null;}
    @Override public final Re_Variable            innerFindMapOrParentVariable(Object key) {
        return null;
    }
    @Override public final Re_Variable            innerFindMapVariable(Object key) {return null;}
    @Override public final Re_Variable            innerGetVariable(Object key) {
        return null;
    }
    @Override public final Re_Variable            innerPutVariable(Object key, Re_Variable value) {return null;}
    @Override public final boolean                innerContainsVariable(Object key) {return false;}
    @Override public final int                    innerGetVariableCount() {return 0;}
    @Override public final Iterable<?>            innerGetVariableKeys() {return null;}
    @Override public final Re_IReInnerVariableMap innerCloneVariableMap() {return null;}








    @NotNull
    public static Re_IReInnerVariableMap argumentsAsVariableMap(Re_ClassFunction reClassFunction, Object[] arguments) {
        Re_IReInnerVariableMap variableMap = Re.newLocalVariableMap();
        String[] params = reClassFunction.params;
        int functionParamCount  = params.length;
        if (functionParamCount <= arguments.length) {
            for (int i = 0; i < functionParamCount; i++)
                Re_Variable.Unsafes.putVariable(params[i], Re_Variable.createVar(arguments[i]),           variableMap);
        } else {
            int i = 0;
            for (; i < arguments.length; i++)
                Re_Variable.Unsafes.putVariable(params[i], Re_Variable.createVar(arguments[i]),           variableMap);
            for (; i < functionParamCount; i++)
                Re_Variable.Unsafes.putVariable(params[i], Re_Variable.createVar(Re_Variable.VALUE_NULL), variableMap);
        }
        return variableMap;
    }





    static class ParamCheckerFunction extends Re_ClassFunction {
        ParamCheckerFunction(){}

        @Override
        protected InnerAccessor getInnerAccessor() {
            return InnerAccessor.StandardFunction;
        }

        @NotNull Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker[] paramChecker;
        @NotNull Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker  returnChecker;

        @Override
        protected Object unauthenticationExecuteOnNative(Re_Executor executor, Re_Class runInClass, Re_ClassInstance runInInstance, Object[] arguments, @Nullable Re_IReInnerVariableMap functionLocal) throws Throwable {
            for (Re_CodeLoader_ExpressionConverts.CallFunction.TypeChecker tc: paramChecker)	{
                Object v   = tc.index < arguments.length ? arguments[tc.index] : null;
                if (!tc.isInstanceof(v)) {
                    executor.setThrow(Re_CodeLoader_ExpressionConverts.CallFunction.unsupported_param_type(tc, v));
                    return null;
                }
            }
            Re_Executor newExecutor = Re_Executor
                    .createReClassFunctionExecutor(
                            executor.re, executor.getStack(),
                            runInClass, runInInstance,
                            this, arguments, functionLocal);
            if (null == newExecutor) return null;//re throw

            Object result = newExecutor.run();
            if (executor.isReturnOrThrow()) return null;

            if (!returnChecker.isInstanceof(result)) {
                Re_NativeStack.NativeTraceElement lastTrace = newExecutor.getStackElement();
                executor.setThrow(Re_CodeLoader_ExpressionConverts.CallFunction.unsupported_return_type(returnChecker, result) + " in " + lastTrace);
                return null;
            }
            return result;
        }
    }



    /**
     * 强制执行在某个或者某在实例上
     * 不经过任何权限检测
     *
     * 理论上不会抛出Java异常
     */
    static abstract class InnerAccessor<T extends Re_ClassFunction> {

        abstract Re_ClassFunction getUnauthenticationFunction(Re_ClassFunction reClassFunction,
                                                              Re_Class runInClass, Re_ClassInstance runInInstance);
        abstract Object invoke(T ins,
                               Re_Executor accessor,
                               Re_Class runInClass, Re_ClassInstance runInInstance,
                               Object[] arguments, Re_IReInnerVariableMap functionLocal) throws Throwable;

        static final InnerAccessor StandardFunction = new InnerAccessor() {
            @Override
            Re_ClassFunction getUnauthenticationFunction(Re_ClassFunction reClassFunction,
                                                         Re_Class runInClass, Re_ClassInstance runInInstance) {
                return reClassFunction;
            }
//                if (runInClass == reClassFunction.declareReClass) {
//                    return reClassFunction;
//                } else {
//                    Re_ClassFunction function = reClassFunction.superClone();
//                    function.declareReClass         = runInClass;
//                    function.declareReClassInstance = runInInstance;
//                    return function;
//                }

            @Override
            public Object invoke(Re_ClassFunction ins,

                                 Re_Executor accessor,
                                 Re_Class runInClass, Re_ClassInstance runInInstance,
                                 Object[] arguments, Re_IReInnerVariableMap functionLocal) throws Throwable {
                return ins.unauthenticationExecuteOnNative(accessor,
                        runInClass, runInInstance,
                        arguments, functionLocal); //如果不执行 则 primitive方法根本不会有反应
            }
        };
    }
}











    
