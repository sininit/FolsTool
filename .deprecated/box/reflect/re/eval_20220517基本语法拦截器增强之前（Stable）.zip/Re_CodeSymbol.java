package top.fols.box.reflect.re;

import top.fols.atri.lang.Strings;
import top.fols.box.reflect.re.interfaces.Re_IVariableMap;
import top.fols.box.reflect.re.primitive.util.Re_Primitive_Util_Math;

import java.util.Collection;

public class Re_CodeSymbol {
	/* -----符号----- */
	
	public static final String      CODE_NOTE_START 					= Re_CodeLoader.intern("//");//注释
	public static final String 		CODE_SEMICOLON_SEPARATOR 			= Re_CodeLoader.intern(";");//代码分隔符


	public static final String		CODE_OBJECT_POINT_SYMBOL 			= Re_CodeLoader.intern(".");//点语法

	public static final String		CODE_VARIABLE_ASSIGNMENT_SYMBOL 	= Re_CodeLoader.intern("=");//赋值


    public static final String 		CODE_CALL_PARAM_JOIN_SYMBOL 		= Re_CodeLoader.intern("(");//方法参数开始
    public static final String 		CODE_CALL_PARAM_SEPARATOR 			= Re_CodeLoader.intern(",");//方法参数分隔符
    public static final String 		CODE_CALL_PARAM_END_SYMBOL 			= Re_CodeLoader.intern(")");//方法参数结束



	public static final String 		CODE_MAP_JOIN_SYMBOL = Re_CodeLoader.intern("{");
	public static final String 		CODE_MAP_END_SYMBOL  = Re_CodeLoader.intern("}");

	public static final String 		CODE_LIST_JOIN_SYMBOL = Re_CodeLoader.intern("[");
	public static final String 		CODE_LIST_END_SYMBOL  = Re_CodeLoader.intern("]");



	public static final char      	CODE_STRING_START_CHAR 					= Re_CodeLoader.intern('\"');
	public static final String      CODE_STRING_START 						= Re_CodeLoader.intern("\"");


	public static final char      	CODE_CHAR_START_CHAR 					= Re_CodeLoader.intern('\'');
	public static final String      CODE_CHAR_START 						= Re_CodeLoader.intern("'");



	public static final String      CODE_STRING2_START 						= Re_CodeLoader.intern("\"\"\"");
	static final char[]      		CODE_STRING2_START_CHARS 				= Re_CodeLoader.intern(CODE_STRING2_START.toCharArray());


	public static final char 		CODE_LINE_SEPARATOR_CHAR 				= Re_CodeLoader.intern('\n');//换行


	/* -----运算符， 也是basemethod----- */
	/* -----用于代码加载器实现自动转换为方法， 比如 1+1转换为 +(1, 1)----- */
	@SuppressWarnings("rawtypes")
	static final Collection automaticConversionOperator = Re_Primitive_Util_Math.getAutomaticConversionOperator();

	/**
	 * @see Re_Primitive_Util_Math#addMethodToKeyword(Re_IVariableMap)
	 */
	public static boolean isAutomaticConversionOperatorSymbol(String keywords) {
		return automaticConversionOperator.contains(keywords);
	}
	/**
	 * @see #automaticConversionOperator
	 */
	public static char[][] getAutomaticConversionOperator() {
		char[][] chars = new char[automaticConversionOperator.size()][];
		int i = 0;
		for (Object key: automaticConversionOperator) {
			chars[i] = Strings.cast(key).toCharArray();
			i++;
		}
		return chars;
	}

}


