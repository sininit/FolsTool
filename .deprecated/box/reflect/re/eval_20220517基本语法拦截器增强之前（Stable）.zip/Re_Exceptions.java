package top.fols.box.reflect.re;

import top.fols.atri.assist.StringJoiner;
import top.fols.atri.util.Throwables;
import top.fols.box.lang.Classx;

import java.util.Arrays;
import java.util.List;

public class Re_Exceptions {
	public static String joinParamJavaClassName(Object[] objs) {
		StringJoiner sb = new StringJoiner(", ", "(", ")");
		if (null != objs) {
			for (Object oi : objs) {
				sb.add(getJavaClassName(oi));
			}
		}
		return sb.toString();
	}

	public static String getJavaClassName(Object cls) {
		return null == cls ?null: Classx.getClassGetNameToCanonicalName(cls.getClass());
	}






	public static String grammatical_error(Re_CodeLoader.Base[] bases, Re_CodeLoader.Base index) {
		return "grammatical errors [" + index + "] in [" + Re_CodeLoader.Base.getExpressionAsString(Arrays.asList(bases)) + "]";
	}

	public static String not_found_object_field(Object object, Re_CodeLoader.Base name) {
		return "not found object field: " + getJavaClassName(object) + '.' + name;
	}
	public static String not_found_object_method(Object object, Re_CodeLoader.Base name, Object[] args) {
		return "not found object method: " + getJavaClassName(object) + '.' + name + joinParamJavaClassName(args);
	}



	public static String not_found_object_method(Object object, String name, int count) {
		return "not found object method: " + getJavaClassName(object) + '.' + name + "(paramCount="+count+")";
	}

	public static String unable_to_process_parameters(String methodKey, Object[] args) {
		return "unable to process parameters[" + methodKey + joinParamJavaClassName(args) + "]";
	}

	public static String unable_to_process_parameters(String methodKey, int count) {
		return "unable to process parameters[" + methodKey + "(paramCount=" + count + ")" + "]";
	}

	public static String not_a_method(Object object, String name) {
		return name + " cannot execute, type[" + getJavaClassName(object) +"]";
	}





	public static class ExecuteException extends RuntimeException {
		public ExecuteException(String message)  { super(message); }
		public ExecuteException(String message, Throwable cause) {
			super(message, cause);
		}
	}
	public static class CompileTimeGrammaticalException extends RuntimeException {
		public CompileTimeGrammaticalException(String message)  { super(message); }
		public CompileTimeGrammaticalException(String message, String filePath, int line)  {
			super(message + " in " + Re_Stack.lineAddressString(filePath, line));
		}

		public CompileTimeGrammaticalException(String message, Throwable cause) {
			super(message, cause);
		}
		public CompileTimeGrammaticalException(String message, String filePath, int line, Throwable cause)  {
			super(message + " in " + Re_Stack.lineAddressString(filePath, line), cause);
		}
	}





	/**
	 * 没有栈的异常
	 */
	public static class InternalExecutorReturnedOrThrow extends Throwables.NullStackException {
		public InternalExecutorReturnedOrThrow(String message) {
			super(message);
		}
	}

	/**
	 * 没有栈的异常
	 */
	public static class InternalExecuteError extends Throwables.NullStackException {
		public InternalExecuteError(String message)  { super(message); }
	}





	public static class ReClassDefineException extends RuntimeException {
		public ReClassDefineException(String message) {
			super(message);
		}
		public ReClassDefineException(String message, Throwable cause) {
			super(message, cause);
		}
	}

	public static class ReClassNotFoundException extends RuntimeException {
		public ReClassNotFoundException(String message) {
			super(message);
		}
		public ReClassNotFoundException(String message, Throwable cause) {
			super(message, cause);
		}
	}
}

