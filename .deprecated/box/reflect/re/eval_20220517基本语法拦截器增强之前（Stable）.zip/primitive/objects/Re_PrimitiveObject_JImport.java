package top.fols.box.reflect.re.primitive.objects;

import top.fols.atri.lang.Objects;
import top.fols.box.reflect.re.Re_CodeLoader;
import top.fols.box.reflect.re.Re_Executor;
import top.fols.box.reflect.re.Re_Util;
import top.fols.box.reflect.re.interfaces.Re_IGetJavaClass;
import top.fols.box.reflect.re.interfaces.Re_IObject;
import top.fols.box.reflect.re.primitive.util.Re_Primitive_Util_Array;

import java.lang.reflect.*;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * java class static opt
 * 这玩意是一个很重要的类
 * 数组也是通过它创建的
 *
 * @see Re_IObject
 */
@SuppressWarnings("rawtypes")
public class Re_PrimitiveObject_JImport extends Re_IObject.IPrimitiveObject implements Re_IGetJavaClass {

    @Override
    public boolean hasVariableProcess(Re_Executor executor, Object key) throws Throwable {
        String s = Re_Util.toString(key);
        Field member = executor.reReflector.field(__class__, null, s);
        return null != member && Modifier.isStatic(member.getModifiers());
    }

    @Override
    public boolean removeVariableProcess(Re_Executor executor, Object key) throws Throwable {
        String s = Re_Util.toString(key);
        Field member = executor.reReflector.requireField(__class__, null, s);
        if (!Modifier.isStatic(member.getModifiers()) ) {
            return false;
        }
        member.set(null, null);
        return true;
    }

    @Override
    public Object getVariableProcess(Re_Executor executor, Object key) throws Throwable {
        // TODO: Implement this method

        String s = Re_Util.toString(key);
        Field member = executor.reReflector.requireField(__class__, null, s);
        if (!Modifier.isStatic(member.getModifiers())) {
            executor.setThrow("not a static member: " + member);
            return null;
        }
        return member.get(null);
    }

    @Override
    public void setVariableProcess(Re_Executor executor, Object key, Object value) throws Throwable {
        // TODO: Implement this method
        String s = Re_Util.toString(key);
        Field member = executor.reReflector.requireField(__class__, null, s);
        if (!Modifier.isStatic(member.getModifiers())) {
            executor.setThrow("not a static member: " + member);
            return;
        }
        member.set(null, value);
    }



    @Override
    public int getSizeProcess(Re_Executor executor) throws Throwable {
        int count = 0;
        Field[] fields = executor.reReflector.cacher().fields(__class__);
        if (null != fields)
            for (Field field: fields)
                if (Modifier.isStatic(field.getModifiers()))
                    count++;
        return count;
    }

    @Override
    public Iterable getKeysProcess(Re_Executor executor) throws Throwable {
        Field[] fields = executor.reReflector.cacher().fields(__class__);
        Set<String> objects = new LinkedHashSet<>();
        if (null != fields)
            for (Field field: fields)
                if (Modifier.isStatic(field.getModifiers()))
                    objects.add(field.getName());
        return objects;
    }




    @Override
    public Object executePointMethodProcess(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
        // TODO: Implement this method
        Object[] callParam = executor.getExpressionValues(call, 0, call.getParamExpressionCount());
        if (executor.isReturn()) return executor.getReturn();

        String s = Re_Util.toString(point_key);
        Method member = executor.reReflector.requireMethod(__class__, null, s, callParam);
        if (!Modifier.isStatic(member.getModifiers())) {
            executor.setThrow("not a static member: " + member);
            return null;
        }
        return member.invoke(null, callParam);
    }


    @Override
    public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
        if (__ia_array__) {
            return Re_Primitive_Util_Array._array(executor, __class__, call);
        } else {
            Object[] callParam = executor.getExpressionValues(call, 0, call.getParamExpressionCount());
            if (executor.isReturn()) return executor.getReturn();

            Constructor<?> constructor = executor.reReflector.requireConstructor(__class__, callParam);
            return constructor.newInstance(callParam);
        }
    }





    final boolean  __ia_array__;
    final Class<?> __class__;
    public Re_PrimitiveObject_JImport(Class<?> type) {
        this.__class__ = type;
        this.__ia_array__ = null != __class__ && __class__.isArray();
    }

    @Override
    public Class getJavaClass() {
        return __class__;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Re_PrimitiveObject_JImport re_import = (Re_PrimitiveObject_JImport) o;
        return Objects.equals(__class__, re_import.__class__);
    }

    @Override
    public int hashCode() {
        return __class__ != null ? __class__.hashCode() : 0;
    }
    @Override
    public String toString() {
        return "Re_JImport{" + __class__ + '}';
    }


    @Override
    public boolean isPrimitive() {
        return true;
    }




    public static class Call extends Re_PrimitiveObject_JImport {
        public Call(Class<?> type) {
            super(type);
        }

        @Override
        public final boolean hasVariableProcess(Re_Executor executor, Object key) throws Throwable {
            executor.setThrow("unsupported has var");
            return false;
        }

        @Override
        public final boolean removeVariableProcess(Re_Executor executor, Object key) throws Throwable {
            executor.setThrow("unsupported remove var");
            return false;
        }

        @Override
        public final Object getVariableProcess(Re_Executor executor, Object key) throws Throwable {
            executor.setThrow("unsupported get var");
            return null;
        }

        @Override
        public final void setVariableProcess(Re_Executor executor, Object key, Object value) throws Throwable {
            executor.setThrow("unsupported set var");
        }

        @Override
        public final int getSizeProcess(Re_Executor executor) throws Throwable {
            executor.setThrow("unsupported size var");
            return 0;
        }

        @Override
        public final Iterable getKeysProcess(Re_Executor executor) throws Throwable {
            executor.setThrow("unsupported key var");
            return null;
        }

        @Override
        public final Object executePointMethodProcess(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
            executor.setThrow(point_key + " undefined");
            return null;
        }
    }
}
