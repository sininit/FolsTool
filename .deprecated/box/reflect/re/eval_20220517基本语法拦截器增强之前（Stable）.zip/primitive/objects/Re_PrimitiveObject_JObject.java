package top.fols.box.reflect.re.primitive.objects;

import top.fols.atri.lang.Objects;
import top.fols.box.reflect.re.Re_CodeLoader;
import top.fols.box.reflect.re.Re_Executor;
import top.fols.box.reflect.re.Re_Util;
import top.fols.box.reflect.re.interfaces.Re_IGetJavaClass;
import top.fols.box.reflect.re.interfaces.Re_IObject;
import top.fols.box.reflect.re.Re_Exceptions;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * java instance opt
 *
 * @see Re_IObject
 */
@SuppressWarnings("rawtypes")
public class Re_PrimitiveObject_JObject extends Re_IObject.IPrimitiveObject implements Re_IGetJavaClass {

        @Override
    public boolean hasVariableProcess(Re_Executor executor, Object key) throws Throwable {
        String s = Re_Util.toString(key);
        Field member = executor.reReflector.field(__class__, null, s);
        return null != member;
    }

    @Override
    public boolean removeVariableProcess(Re_Executor executor, Object key) throws Throwable {
        String s = Re_Util.toString(key);
        Field member = executor.reReflector.requireField(__class__, null, s);
        member.set(__value__, null);
        return true;
    }

    @Override
    public Object getVariableProcess(Re_Executor executor, Object key) throws Throwable {
        // TODO: Implement this method
        String s = Re_Util.toString(key);
        Field member = executor.reReflector.requireField(__class__, null, s);
        return member.get(__value__);
    }

    @Override
    public void setVariableProcess(Re_Executor executor, Object key, Object value) throws Throwable {
        // TODO: Implement this method
        String s = Re_Util.toString(key);
        Field member = executor.reReflector.requireField(__class__, null, s);
        member.set(__value__, value);
    }


    @Override
    public int getSizeProcess(Re_Executor executor) throws Throwable {
        int count = 0;
        Field[] fields = executor.reReflector.cacher().fields(__class__);
        if (null != fields)
            for (Field field: fields)
                if (!Modifier.isStatic(field.getModifiers()))
                    count++;
        return count;
    }


    @Override
    public Iterable getKeysProcess(Re_Executor executor) throws Throwable {
        Field[] fields = executor.reReflector.cacher().fields(__class__);
        Set<String> objects = new LinkedHashSet<>();
        if (null != fields)
            for (Field field: fields)
                if (!Modifier.isStatic(field.getModifiers()))
                    objects.add(field.getName());
        return objects;
    }



    @Override
    public Object executePointMethodProcess(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
        // TODO: Implement this method
        Object[] callParam = executor.getExpressionValues(call, 0, call.getParamExpressionCount());
        if (executor.isReturn()) return executor.getReturn();

        Method member = executor.reReflector.requireMethod(__class__, null, point_key, callParam);
        return member.invoke(__value__, callParam);
    }


    @Override
    public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
        int paramExpressionCount = call.getParamExpressionCount();
        if (paramExpressionCount == 0) {
            return __value__;
        }
        executor.setThrow(Re_Exceptions.unable_to_process_parameters(var_key, paramExpressionCount));
        return null;
    }




    final Object __value__;
    final Class<?>  __class__;

    public Re_PrimitiveObject_JObject(Object __value__) {
        this.__class__  = __value__.getClass();
        this.__value__  = __value__;
    }

    @Override
    public Class getJavaClass() {
        return __class__;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (null == o) return null == __value__;
        if (getClass() != o.getClass()) return false;

        Re_PrimitiveObject_JObject re_import = (Re_PrimitiveObject_JObject) o;
        return Objects.equals(__value__, re_import.__value__);
    }

    @Override
    public int hashCode() {
        return __value__ != null ? __value__.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "Re_JObject{" + __class__ + '}';
    }
}
