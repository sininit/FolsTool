package top.fols.box.reflect.re.primitive.util;

import top.fols.atri.lang.Arrayz;
import top.fols.atri.lang.Finals;
import top.fols.box.reflect.re.Re_CodeLoader;
import top.fols.box.reflect.re.Re_Executor;
import top.fols.box.reflect.re.Re_Util;
import top.fols.box.reflect.re.primitive.objects.Re_PrimitiveObject_JImport;
import top.fols.box.reflect.re.Re_Exceptions;

import java.lang.reflect.Array;

/**
 * @see Re_PrimitiveObject_JImport
 */
public class Re_Primitive_Util_Array {


    public static Object _array(Re_Executor executor, Re_CodeLoader.Call callParamController) {
        return _array(executor, Finals.OBJECT_ARRAY_CLASS, callParamController);
    }
    /**
     * @param type 执行前确保是个数组
     */
    public static Object _array(Re_Executor executor, Class<?> type, Re_CodeLoader.Call callParamController) {
        if ((type = type.getComponentType()).isPrimitive()) {
            //str(), int(), char(), float(), double)(short(), boolean(), long(), byte()
            if (type == Finals.INT_CLASS) {
                int dataCount = callParamController.getParamExpressionCount();
                int arrLen = dataCount;

                int[] array = (int[]) Array.newInstance(type, arrLen);
                for (int i = 0; i < dataCount; i++) {
                    Object expressionValue = executor.getExpressionValue(callParamController, i);
                    if (executor.isReturn()) return executor.getReturn();

                    array[i] = Re_Util.toInt(expressionValue);
                }
                return array;
            } else if (type == Finals.CHAR_CLASS) {
                int dataCount = callParamController.getParamExpressionCount();
                int arrLen = dataCount;

                char[] array = (char[]) Array.newInstance(type, arrLen);
                for (int i = 0; i < dataCount; i++) {
                    Object expressionValue = executor.getExpressionValue(callParamController, i);
                    if (executor.isReturn()) return executor.getReturn();

                    array[i] = Re_Util.toChar(expressionValue);
                }
                return array;
            } else if (type == Finals.FLOAT_CLASS) {
                int dataCount = callParamController.getParamExpressionCount();
                int arrLen = dataCount;

                float[] array = (float[]) Array.newInstance(type, arrLen);
                for (int i = 0; i < dataCount; i++) {
                    Object expressionValue = executor.getExpressionValue(callParamController, i);
                    if (executor.isReturn()) return executor.getReturn();

                    array[i] = Re_Util.toFloat(expressionValue);
                }
                return array;
            } else if (type == Finals.DOUBLE_CLASS) {
                int dataCount = callParamController.getParamExpressionCount();
                int arrLen = dataCount;

                double[] array = (double[]) Array.newInstance(type, arrLen);
                for (int i = 0; i < dataCount; i++) {
                    Object expressionValue = executor.getExpressionValue(callParamController, i);
                    if (executor.isReturn()) return executor.getReturn();

                    array[i] = Re_Util.toDouble(expressionValue);
                }
                return array;
            } else if (type == Finals.SHORT_CLASS) {
                int dataCount = callParamController.getParamExpressionCount();
                int arrLen = dataCount;

                short[] array = (short[]) Array.newInstance(type, arrLen);
                for (int i = 0; i < dataCount; i++) {
                    Object expressionValue = executor.getExpressionValue(callParamController, i);
                    if (executor.isReturn()) return executor.getReturn();

                    array[i] = Re_Util.toShort(expressionValue);
                }
                return array;
            } else if (type == Finals.BOOLEAN_CLASS) {
                int dataCount = callParamController.getParamExpressionCount();
                int arrLen = dataCount;

                boolean[] array = (boolean[]) Array.newInstance(type, arrLen);
                for (int i = 0; i < dataCount; i++) {
                    Object expressionValue = executor.getExpressionValue(callParamController, i);
                    if (executor.isReturn()) return executor.getReturn();

                    array[i] = Re_Util.toBoolean(expressionValue);
                }
                return array;
            } else if (type == Finals.LONG_CLASS) {
                int dataCount = callParamController.getParamExpressionCount();
                int arrLen = dataCount;

                long[] array = (long[]) Array.newInstance(type, arrLen);
                for (int i = 0; i < dataCount; i++) {
                    Object expressionValue = executor.getExpressionValue(callParamController, i);
                    if (executor.isReturn()) return executor.getReturn();

                    array[i] = Re_Util.toLong(expressionValue);
                }
                return array;
            } else if (type == Finals.BYTE_CLASS) {
                int dataCount = callParamController.getParamExpressionCount();
                int arrLen = dataCount;

                byte[] array = (byte[]) Array.newInstance(type, arrLen);
                for (int i = 0; i < dataCount; i++) {
                    Object expressionValue = executor.getExpressionValue(callParamController, i);
                    if (executor.isReturn()) return executor.getReturn();

                    array[i] = Re_Util.toByte(expressionValue);
                }
                return array;
            }
        } else {
            int dataCount = callParamController.getParamExpressionCount();
            int arrLen = dataCount;

            Object[] array = (Object[]) Array.newInstance(type, arrLen);
            for (int i = 0; i < dataCount; i++) {
                Object expressionValue = executor.getExpressionValue(callParamController, i);
                if (executor.isReturn()) return executor.getReturn();

                array[i] = expressionValue;
            }
            return array;
        }
        return null;
    }



    public static Object _newarray(Re_Executor executor, Re_CodeLoader.Call callParamController) throws ClassNotFoundException {
        int paramExpressionCount = callParamController.getParamExpressionCount();
        if (paramExpressionCount == 0) {
            return new Object[]{};
        } else if (paramExpressionCount == 1) {
            Object expressionValue = executor.getExpressionValue(callParamController, 0);
            if (executor.isReturn()) return null;

            if (expressionValue instanceof Number) {
                int size = ((Number) expressionValue).intValue();
                return new Object[size];
            }
            executor.setThrow("(int:length)");
            return null;
        } else if (paramExpressionCount == 2) {
            Object typeValue = executor.getExpressionValue(callParamController, 0);
            if (executor.isReturn()) return null;

            Class<?> aClass = Re_Util.jforNameFindClass(typeValue);
            if (null != aClass) {
                Object size0 = executor.getExpressionValue(callParamController, 1);
                if (executor.isReturn()) return null;

                if (size0 instanceof Number) {
                    int size = ((Number) size0).intValue();
                    return Array.newInstance(aClass, size);
                } else if (null != size0) {
                    Class<?> sizeClass = size0.getClass();
                    if (sizeClass.isArray()) {
                        int[] convert = Arrayz.convert(size0, new int[]{});
                        return Array.newInstance(aClass, convert);
                    }
                }
            }
            executor.setThrow("(java.lang.Class:class, int:length | int[]:length)");
            return null;
        }
        executor.setThrow(Re_Exceptions.unable_to_process_parameters("?", paramExpressionCount));
        return null;
    }

}
