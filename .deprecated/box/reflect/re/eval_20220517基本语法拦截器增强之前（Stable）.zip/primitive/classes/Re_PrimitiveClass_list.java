package top.fols.box.reflect.re.primitive.classes;

import top.fols.atri.lang.Arrayz;
import top.fols.atri.lang.Finals;
import top.fols.box.reflect.re.*;
import top.fols.box.reflect.re.interfaces.Re_IVariableMap;
import top.fols.atri.util.annotation.NotNull;
import top.fols.box.reflect.re.variables.Re_ObjectVariableMap;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * {对象} 和 它的抽象 {类}
 */
public class Re_PrimitiveClass_list extends Re_PrimitiveClass_object {
    public static final Re_PrimitiveClass_list factory = new Re_PrimitiveClass_list("list");
    protected Re_PrimitiveClass_list(String className) {
        super(className);

        {
            final String name = "add";
            super.addFunctionToStaticFinal(name, new Re_PrimitiveClassFunction(name, this) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class aClass, Re_Class.Instance instance, Object[] arguments, Re_IVariableMap functionLocal) {
                    int length = arguments.length;
                    if (length == 1) {
                        Object object = arguments[0];
                        Re_PrimitiveClass_list.Instance instance_ = (Re_PrimitiveClass_list.Instance) instance;
                        return instance_.addElement(object);
                    }
                    executor.setThrow(Re_Exceptions.unable_to_process_parameters(name, length));
                    return null;
                }
            });
        }
    }

    public Re_PrimitiveClass_list.Instance fromJavaObject(Collection map) {
        Re_PrimitiveClass_list.Instance instance = this.createInstance();
        instance.setElements(map.toArray());
        return instance;
    }
    public Re_PrimitiveClass_list.Instance fromJavaArray(Object object) {
        Re_PrimitiveClass_list.Instance instance = this.createInstance();
        Class<?> aClass = object.getClass();
        if (aClass.isArray()) {
            if (aClass.getComponentType().isPrimitive()) {
                Object[] convert = Arrayz.convert(object, Finals.OBJECT_ARRAY_CLASS);
                instance.setElements(convert);
            } else {
                instance.setElements((Object[]) object);
            }
            return instance;
        }
        return instance;
    }



    @Override
    public Re_PrimitiveClass_list.Instance createInstance() {
        return new Instance(this);
    }

    public static class Instance extends Re_PrimitiveClass_object.Instance {
        protected Re_IVariableMap map;

        protected Instance(Re_Class reClass) {
            super(reClass, new Re_ObjectVariableMap());

            this.map = super.getVariableMap();
        }
        protected Instance(Re_Class reClass, Re_IVariableMap map) {
            super(reClass, map);

            this.map = super.getVariableMap();
        }



        @Override
        public boolean isPrimitive() {
            return true;
        }



        public Object getElement(Re_Executor executor, int index) {
            return Re_Variable.accessFindValue(executor, index, map);
        }




        /**
         * unsafe
         */
        public void setElement(Object key, Object value) {
            Re_Variable.Unsafe.putNewVariable(key,  new Re_Variable(value), map);
        }
        /**
         * unsafe
         */
        public void setElements(@NotNull final Re_Executor current_executor, @NotNull Re_CodeLoader.Call callParamController) {
            if (current_executor.isReturn()) return;

            int paramExpressionCount = callParamController.getParamExpressionCount();
            for (int i = 0; i < paramExpressionCount; i++) {
                Object value = current_executor.getExpressionValue(callParamController, i);
                if (current_executor.isReturn()) return;

                Integer key = i;
                Re_Variable.Unsafe.putNewVariable(key, new Re_Variable(value), map);
            }
            len.set(paramExpressionCount);
        }
        /**
         * unsafe
         */
        public void setElements(Object[] array) {
            for (int i = 0; i < array.length; i++) {
                Object value = array[i];

                Integer key = i;
                Re_Variable.Unsafe.putNewVariable(key, new Re_Variable(value), this);
            }
            len.set(array.length);
        }




        public <T> T[] toArray(Re_Executor executor, T[] a) {
            if (null == a) {
                return null;
            }
            Re_Variable[] re_variables = Re_Variable.Unsafe.values(map);

            T[] objects = (T[]) Array.newInstance(a.getClass().getComponentType(), re_variables.length);
            for (int i = 0; i < objects.length; i++) {
                objects[i] = (T) Re_Variable.accessFindValue(executor, i, map);
                if (executor.isReturn()) return null;
            }
            return objects;
        }







        protected AtomicInteger len = new AtomicInteger();

        public Object addElement(Object value) {
            map.put(this.getIndexAndAddSize(), new Re_Variable(value)); //永远不会达到负数
            return value;
        }

        /**
         * 更新一个更大的值
         * 永远不会达到负数
         */
        @SuppressWarnings("ManualMinMaxCalculation")
        public final void updateSize(int observed) {
            int oldValue, newValue;
            do {
                oldValue = len.get();
                newValue = (oldValue >= observed) ? oldValue : observed;
            } while (!len.compareAndSet(oldValue, newValue));
        }

        /**
         * 这里最后指针可能会 = Integer.MAX_VALUE， 但是这个没什么意义，不需要理
         */
        public final int getIndexAndAddSize() {
            for (;;) {
                int current = len.get(); // Integer.MAX_VALUE?
                int next = (current + 1 >= 0) ? current + 1 : Integer.MAX_VALUE; //如果溢出那么长度永远是  Integer.MAX_VALUE
                if (len.compareAndSet(current, next))
                    return current;
            }
        }








        @Override
        public Re_Variable remove(Object key) {
            // TODO: Implement this method
            if (key instanceof Number)
                key = key instanceof Integer ? (Integer) key : Integer.valueOf(((Number) key).intValue());
            return map.remove(key);
        }

        @Override
        public Re_Variable find(Object key) {
            // TODO: Implement this method
            if (key instanceof Number)
                key = key instanceof Integer ? (Integer) key : Integer.valueOf(((Number) key).intValue());
            return map.find(key);
        }

        @Override
        public Re_Variable get(Object key) {
            // TODO: Implement this method
            if (key instanceof Number)
                key = key instanceof Integer ? (Integer) key : Integer.valueOf(((Number) key).intValue());
            return map.get(key);
        }

        @Override
        public Re_Variable put(Object key, Re_Variable p2) {
            // TODO: Implement this method
            if (key instanceof Number) {
                Integer index = key instanceof Integer ? (Integer) key : Integer.valueOf(((Number) key).intValue());
                this.updateSize(index.intValue() + 1);
                return map.put(index, p2);
            }
            return map.put(key, p2);
        }

        @Override
        public boolean containsKey(Object key) {
            // TODO: Implement this method
            if (key instanceof Number) {
                Integer index = key instanceof Integer ? (Integer) key : Integer.valueOf(((Number) key).intValue());
                return index >= 0 && index < len.get();
            }
            return map.containsKey(key);
        }

        @Override
        public int size() {
            // TODO: Implement this method
            return len.get();
        }

        @Override
        public Collection<?> keySet() {
            // TODO: Implement this method
            return map.keySet();
        }
    }
}
