package top.fols.box.reflect.re.primitive.classes;

import top.fols.atri.assist.json.*;
import top.fols.box.reflect.re.*;
import top.fols.box.reflect.re.interfaces.Re_IVariableMap;
import top.fols.box.reflect.re.Re_Exceptions;
import top.fols.box.reflect.re.variables.Re_LinkedVariableMap;

import java.lang.reflect.Array;
import java.util.Iterator;
import java.util.Map;

/**
 * {对象} 和 它的抽象 {类}
 */
@SuppressWarnings({"rawtypes"})
public class Re_PrimitiveClass_json extends Re_PrimitiveClass_object {

    public static final Re_PrimitiveClass_json factory = new Re_PrimitiveClass_json("json");


    protected Re_PrimitiveClass_json(String className) {
        super(className);

        {
            final String name = "loads";
            super.addFunctionToStaticFinal(name, new Re_PrimitiveClassFunction(name, this) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class aClass, Re_Class.Instance instance, Object[] arguments, Re_IVariableMap functionLocal) {
                    int length = arguments.length;
                    if (length == 1) {
                        String str = Re_Util.toString(arguments[0]);
                        return Re_PrimitiveClass_json.this.loads(executor, str);
                    }
                    executor.setThrow(Re_Exceptions.unable_to_process_parameters(name, length));
                    return null;
                }
            });
        }

        {
            final String name = "dumps";
            super.addFunctionToStaticFinal(name, new Re_PrimitiveClassFunction(name, this) {
                @Override
                public Object invoke(Re_Executor executor, Re_Class aClass, Re_Class.Instance instance, Object[] arguments, Re_IVariableMap functionLocal) {
                    int length = arguments.length;
                    if (length == 1) {
                        Object json = arguments[0];
                        return Re_PrimitiveClass_json.this.dumps(executor, json);
                    }
                    executor.setThrow(Re_Exceptions.unable_to_process_parameters(name ,arguments));
                    return null;
                }
            });
        }
    }



    public Re_PrimitiveClass_json.Instance fromJavaObject(Map<String, Object> map) {
        Re_PrimitiveClass_json.Instance instance = this.createInstance();
        for (String key : map.keySet()) {
            Object value0 = map.get(key);
            Re_Variable value = new Re_Variable(value0);

            Re_Variable.Unsafe.putNewVariableIntern(key, value, instance);
        }
        return instance;
    }



    @Override
    public Re_PrimitiveClass_json.Instance createInstance() {
        return new Instance(this);
    }

    public static class Instance extends Re_PrimitiveClass_object.Instance {
        protected Instance(Re_Class reClass) {
            super(reClass, new Re_LinkedVariableMap());
        }
        protected Instance(Re_Class reClass, Re_IVariableMap variableMap) {
            super(reClass, variableMap);
        }


        @Override
        public boolean isPrimitive() {
            return true;
        }

        @Override
        public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
            return Re_Executor.executeCallVariableMap(executor, this, call);
        }
    }






    public Re_PrimitiveClass_list.Instance loadToReList(Re_Executor executor, JSONArray object) {
        if (null == object) return null;
        Object[] array = new Object[object.length()];
        for (int i = 0; i < object.length(); i++) {
            Object value = object.get(i);
            if (value instanceof JSONObject) {
                value = loadToReInstance(executor, (JSONObject) value);
            } else if (value instanceof JSONArray) {
                value = loadToReList(executor, (JSONArray) value);
            }
            array[i] = value;
        }
        Re_PrimitiveClass_list.Instance instance = Re_PrimitiveClass_list.factory.createInstance();
        instance.setElements(array);
        if (executor.isReturn()) return null;
        return instance;
    }

    public Re_PrimitiveClass_json.Instance loadToReInstance(Re_Executor executor, JSONObject object) {
        if (null == object) return null;
        Re_PrimitiveClass_json.Instance instance =  this.createInstance();
        for (String s : object.keySet()) {
            Object value = object.get(s);
            if (value instanceof JSONObject) {
                value = loadToReInstance(executor, (JSONObject) value);
            } else if (value instanceof JSONArray) {
                value = loadToReList(executor, (JSONArray) value);
            }
            Re_Util.setattr(executor, instance, s, value);
            if (executor.isReturn()) return null;
        }
        return instance;
    }

    public Object loads(Re_Executor executor, String str) {
        if (null == str || str.length() == 0) return null;

        Object object = JSON.parseJSON(str);
        if (object instanceof JSONObject) {
            return loadToReInstance(executor, (JSONObject) object);
        } else if (object instanceof JSONArray) {
            return loadToReList(executor, (JSONArray) object);
        }

        return object;
    }





    public void dumpIterable(JSONStringer stringer, Re_Executor executor, Iterable array) {
        if (null == array)
            return;

        Iterator iterator = array.iterator();
        stringer.array();
        while (iterator.hasNext()) {
            Object value  = iterator.next();

            if (null == value) {
                stringer.value(null);
                continue;
            }

            if (value.getClass().isArray()) {
                dumpArray(stringer, executor, value);

            } else if (value instanceof Iterable) {
                dumpIterable(stringer, executor, (Iterable) value);

            } else if (Re_Keywords.isReListInstance(value)) {
                dumpReList(stringer, executor, (Re_Class.Instance) value);
                if (executor.isReturn()) return;

            } else if (Re_Keywords.isReClassInstance(value)) {
                dumpReInstance(stringer, executor, (Re_Class.Instance) value);
                if (executor.isReturn()) return;

            } else {
                stringer.value(value);
            }
        }
        stringer.endArray();
    }

    public void dumpArray(JSONStringer stringer, Re_Executor executor, Object array) {
        if (null == array)
            return;

        stringer.array();
        int size = Array.getLength(array);
        for (int i = 0; i < size; i++) {
            Object value  = Array.get(array, i);
            if (null == value) {
                stringer.value(null);
                continue;
            }

            if (value.getClass().isArray()) {
                dumpArray(stringer, executor, value);

            } else if (value instanceof Iterable) {
                dumpIterable(stringer, executor, (Iterable) value);

            } else if (Re_Keywords.isReListInstance(value)) {
                dumpReList(stringer, executor, (Re_Class.Instance) value);
                if (executor.isReturn()) return;

            } else if (Re_Keywords.isReClassInstance(value)) {
                dumpReInstance(stringer, executor, (Re_Class.Instance) value);
                if (executor.isReturn()) return;

            } else {
                stringer.value(value);
            }
        }
        stringer.endArray();
    }
    public void dumpReList(JSONStringer stringer, Re_Executor executor, Re_Class.Instance instance) {
        if (null == instance)
            return;

        stringer.array();
        Re_PrimitiveClass_list.Instance list = (Re_PrimitiveClass_list.Instance) instance;
        int size = Re_Variable.size(list);
        for (int i = 0; i < size; i++) {
            Object value  = list.getElement(executor, i);
            if (executor.isReturn()) return;
            if (null == value) {
                stringer.value(null);
                continue;
            }

            if (value.getClass().isArray()) {
                dumpArray(stringer, executor, value);

            } else if (value instanceof Iterable) {
                dumpIterable(stringer, executor, (Iterable) value);

            } else if (Re_Keywords.isReListInstance(value)) {
                dumpReList(stringer, executor, (Re_Class.Instance) value);
                if (executor.isReturn()) return;

            } else if (Re_Keywords.isReClassInstance(value)) {
                dumpReInstance(stringer, executor, (Re_Class.Instance) value);
                if (executor.isReturn()) return;

            } else {
                stringer.value(value);
            }
        }
        stringer.endArray();
    }
    public void dumpReInstance(JSONStringer stringer, Re_Executor executor, Re_Class.Instance instance) {
        if (null == instance)
            return;

        Iterable keysProcess = Re_Variable.key(executor, instance);
        if (executor.isReturn()) return;

        stringer.object();
        for (Object key : keysProcess) {
            Object value = Re_Variable.accessFindValue(executor, key, instance);
            if (executor.isReturn()) return;


            key = Re_Util.toString(key); // key is string
            stringer.key((String) key);

            if (null == value) {
                stringer.value(null);
                continue;
            }


            if (value.getClass().isArray()) {
                dumpArray(stringer, executor, value);

            } else if (value instanceof Iterable) {
                dumpIterable(stringer, executor, (Iterable) value);

            } else if (Re_Keywords.isReListInstance(value)) {
                dumpReList(stringer, executor, (Re_Class.Instance) value);
                if (executor.isReturn()) return;

            } else if (Re_Keywords.isReClassInstance(value)) {
                dumpReInstance(stringer, executor, (Re_Class.Instance) value);
                if (executor.isReturn()) return;
            } else {
                stringer.value(value);
            }
        }
        stringer.endObject();
    }
    public String dumps(Re_Executor executor, Object value) {
        if (null == value) return null;

        JSONStringer stringer = new JSONStringer(4);
        if (value.getClass().isArray()) {
            dumpArray(stringer, executor, value);
        } else if (value instanceof Iterable) {
            dumpIterable(stringer, executor, (Iterable) value);
        } else if (Re_Keywords.isReListInstance(value)) {
            dumpReList(stringer, executor, (Re_PrimitiveClass_list.Instance) value);
        } else if (Re_Keywords.isReClassInstance(value)) {
            dumpReInstance(stringer, executor, (Re_PrimitiveClass_object.Instance) value);
        } else {
            throw new Re_Exceptions.ExecuteException("dumps: not supported type: " + value.getClass());
        }
        return stringer.toString();
    }
}
