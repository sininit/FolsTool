package top.fols.box.reflect.re.primitive.classes;

import top.fols.box.reflect.re.*;
import top.fols.box.reflect.re.interfaces.Re_IVariableMap;
import top.fols.box.reflect.re.variables.Re_ObjectVariableMap;

import java.util.Map;

/**
 * {对象} 和 它的抽象 {类}
 */
public class Re_PrimitiveClass_object extends Re_PrimitiveClass {

    public static final Re_PrimitiveClass_object factory = new Re_PrimitiveClass_object("object");


    protected Re_PrimitiveClass_object(String className) {
        super(className);
    }


    public Re_PrimitiveClass_object.Instance fromJavaObject(Map<String, Object> map) {
        Instance instance = this.createInstance();
        for (String key : map.keySet()) {
            Object value0 = map.get(key);
            Re_Variable value = new Re_Variable(value0);

            Re_Variable.Unsafe.putNewVariableIntern(key, value, instance);
        }
        return instance;
    }



    @Override
    public Re_PrimitiveClass_object.Instance createInstance() {
        return new Instance(this);
    }

    public static class Instance extends Re_Class.Instance {
        protected Instance(Re_Class reClass) {
            super(reClass, new Re_ObjectVariableMap());
        }
        protected Instance(Re_Class reClass, Re_IVariableMap variableMap) {
            super(reClass, variableMap);
        }


        @Override
        public boolean isPrimitive() {
            return true;
        }

        @Override
        public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
            return Re_Executor.executeCallVariableMap(executor, this, call);
        }
    }
}
