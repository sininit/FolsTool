package top.fols.box.reflect.re.primitive.lang;

import top.fols.box.reflect.re.Re_Executor;
import top.fols.box.reflect.re.interfaces.Re_IObject;
import top.fols.box.reflect.re.Re_Variable;

import java.lang.reflect.Array;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * 对象有 {@link Re_Iterable} 和 {@link Iterable}
 */
@SuppressWarnings({"FieldMayBeFinal", "rawtypes"})
public class Re_Iterables {
    Re_Iterables() {    }


    public static class Re {

        public static Re_Iterable wrap(Re_Executor executor, Object object) throws Throwable {
            if (null != object) {
                if (object instanceof Re_Iterable)
                    return (Re_Iterable) object;
                if (object instanceof Re_IObject)
                    return wrapIReObject(executor, (Re_IObject) object);

                //java (Set, List)
                if (object instanceof Iterable)
                    return wrapJavaIterable(executor, (Set) object);

                Class<?> aClass = object.getClass();
                if (aClass.isArray())
                    return wrapJavaArray(executor, object);
            }
            executor.setThrow("unsupported type: "+(null==object?null:object.getClass()));
            return null;
        }

        static Re_Iterable wrapIReObject(final Re_Executor executor, final Re_IObject map) throws Throwable {
            final Iterable keysProcess = map.getKeysProcess(executor);
            return new Re_Iterable() {
                @Override
                public Re_Iterator iterator() {
                    // TODO: Implement this method
                    return new Re_Iterator() {

                        final ObjectElement key   = new ObjectElement(null);
                        final ObjectElement value = new ObjectElement(null);

                        Iterable keySet = keysProcess;
                        final java.util.Iterator iterator = keySet.iterator();


                        @Override
                        public Re_Variable key_variable() {
                            // TODO: Implement this method
                            return key;
                        }

                        @Override
                        public Re_Variable value_variable() {
                            // TODO: Implement this method
                            return value;
                        }

                        @Override
                        public boolean hasNext() {
                            // TODO: Implement this method
                            return iterator.hasNext();
                        }

                        @Override
                        public void next(Re_Executor executor) throws Throwable {
                            // TODO: Implement this method
                            Object k        = iterator.next();
                            key.set(k);
                            value.set(map.getVariableProcess(executor, k));
                        }
                    };
                }
            };
        }

        public static Re_Iterable wrapJavaIterable(final Re_Executor executor, final Iterable keysProcess) throws Throwable {
            return new Re_Iterable() {
                @Override
                public Re_Iterator iterator() {
                    // TODO: Implement this method
                    return new Re_Iterator() {

                        final ObjectElement key   = new ObjectElement(null);
                        final ObjectElement value = new ObjectElement(null);

                        final java.util.Iterator iterator = keysProcess.iterator();


                        @Override
                        public Re_Variable key_variable() {
                            // TODO: Implement this method
                            return key;
                        }

                        @Override
                        public Re_Variable value_variable() {
                            // TODO: Implement this method
                            return value;
                        }

                        @Override
                        public boolean hasNext() {
                            // TODO: Implement this method
                            return iterator.hasNext();
                        }

                        @Override
                        public void next(Re_Executor executor) throws Throwable {
                            // TODO: Implement this method
                            key.set(iterator.next());
                            value.set(key.get());
                        }
                    };
                }
            };
        }


        public static Re_Iterable wrapJavaMap(final Re_Executor executor, final Map map) throws Throwable {
            final Set keysProcess = map.keySet();
            return new Re_Iterable() {
                @Override
                public Re_Iterator iterator() {
                    // TODO: Implement this method
                    return new Re_Iterator() {

                        final ObjectElement key   = new ObjectElement(null);
                        final ObjectElement value = new ObjectElement(null);

                        Set keySet = keysProcess;
                        final java.util.Iterator iterator = keySet.iterator();


                        @Override
                        public Re_Variable key_variable() {
                            // TODO: Implement this method
                            return key;
                        }

                        @Override
                        public Re_Variable value_variable() {
                            // TODO: Implement this method
                            return value;
                        }

                        @Override
                        public boolean hasNext() {
                            // TODO: Implement this method
                            return iterator.hasNext();
                        }

                        @Override
                        public void next(Re_Executor executor) throws Throwable {
                            // TODO: Implement this method
                            Object k        = iterator.next();
                            key.set(k);
                            value.set(map.get(k));
                        }
                    };
                }
            };
        }

        public static Re_Iterable wrapJavaArray(final Re_Executor executor, final Object map) throws Throwable {
            return new Re_Iterable() {
                @Override
                public Re_Iterator iterator() {
                    // TODO: Implement this method
                    return new Re_Iterator() {

                        final IntElement key   = new IntElement(-1);
                        final ObjectElement value = new ObjectElement(null);

                        int len = Array.getLength(map);

                        @Override
                        public Re_Variable key_variable() {
                            // TODO: Implement this method
                            return key;
                        }

                        @Override
                        public Re_Variable value_variable() {
                            // TODO: Implement this method
                            return value;
                        }

                        @Override
                        public boolean hasNext() {
                            // TODO: Implement this method
                            return key.value + 1 < len;
                        }

                        @Override
                        public void next(Re_Executor executor) throws Throwable {
                            // TODO: Implement this method
                            int i = key.value + 1;
                            key.value = i;
                            value.set(Array.get(map, i));
                        }
                    };
                }
            };
        }




        /**
         * 类似于python的 range
         * 假设 start是0 stop是10 只会遍历到 0和 10之前的数字
         */
        public static Re_Iterable wrapRange(final Re_Executor executor, final int start, final int stop) throws Throwable {
            if (stop > start) {
                return wrapRange(executor, start, stop, 1);
            } else if (stop == start) {
                return wrapRange(executor, start, stop, 0);
            } else {
                return wrapRange(executor, start, stop, -1);
            }
        }
        public static Re_Iterable wrapRange(final Re_Executor executor, final int start, final int stop, final int setp) throws Throwable {
            if (stop > start) {
                return new Re_Iterable() {
                    @Override
                    public Re_Iterator iterator() {
                        // TODO: Implement this method
                        return new Re_Iterator() {

                            boolean ed = false;
                            final IntElement key   = new IntElement(start);
                            final ObjectElement value = new ObjectElement(null);

                            @Override
                            public Re_Variable key_variable() {
                                // TODO: Implement this method
                                return key;
                            }

                            @Override
                            public Re_Variable value_variable() {
                                // TODO: Implement this method
                                return value;
                            }

                            @Override
                            public boolean hasNext() {
                                // TODO: Implement this method
                                if (ed) {
                                    return key.value + setp < stop;
                                } else {
                                    return true;
                                }
                            }

                            @Override
                            public void next(Re_Executor executor) throws Throwable {
                                // TODO: Implement this method
                                if (ed) {
                                    key.value += setp;
                                    value.set(null);
                                } else {
                                    key.value = start;
                                    value.set(null);
                                    ed = true;
                                }
                            }
                        };
                    }
                };
            } else {
                return new Re_Iterable() {
                    @Override
                    public Re_Iterator iterator() {
                        // TODO: Implement this method
                        return new Re_Iterator() {

                            boolean ed = false;
                            final IntElement key   = new IntElement(start);
                            final ObjectElement value = new ObjectElement(null);

                            @Override
                            public Re_Variable key_variable() {
                                // TODO: Implement this method
                                return key;
                            }

                            @Override
                            public Re_Variable value_variable() {
                                // TODO: Implement this method
                                return value;
                            }

                            @Override
                            public boolean hasNext() {
                                // TODO: Implement this method
                                if (ed) {
                                    return key.value + setp > stop;
                                } else {
                                    return true;
                                }
                            }

                            @Override
                            public void next(Re_Executor executor) throws Throwable {
                                // TODO: Implement this method
                                if (ed) {
                                    key.value += setp;
                                    value.set(null);
                                } else {
                                    key.value = start;
                                    value.set(null);
                                    ed = true;
                                }
                            }
                        };
                    }
                };
            }
        }


        static class ObjectElement extends Re_Variable {
            public ObjectElement(Object value) {
                __value__ = value;
            }

            public Object get() {
                return __value__;
            }
            public void set(Object value) {
                __value__ = value;
            }
        }

        public static class IntElement extends Re_Variable<Integer> {
            int value;

            public IntElement(int javavalue) {
                value = javavalue;
                __value__ = new Integer(javavalue);
            }

            @Override
            public Integer get(Re_Executor executor) {
                return (__value__.intValue() == value)?__value__:(__value__ = new Integer(value));
            }


            public Integer get() {
                return (__value__.intValue() == value)?__value__:(__value__ = new Integer(value));
            }
        }
    }


    public static class Java {

        /**
         * 类似于python的 range
         * 假设 start是0 stop是10 只会遍历到 0和 10之前的数字
         */
        public static Iterable wrapRange(final int start, final int stop) {
            if (stop > start) {
                return wrapRange(start, stop, 1);
            } else if (stop == start) {
                return wrapRange(start, stop, 0);
            } else {
                return wrapRange(start, stop, -1);
            }
        }
        public static Iterable wrapRange(final int start, final int stop, final int setp) {
            if (stop > start) {
                return new Iterable() {
                    @Override
                    public Iterator iterator() {
                        // TODO: Implement this method
                        return new Iterator() {

                            boolean ed = false;
                            int key   = start;

                            @Override
                            public boolean hasNext() {
                                // TODO: Implement this method
                                if (ed) {
                                    return key + setp < stop;
                                } else {
                                    return true;
                                }
                            }

                            @Override
                            public Integer next() {
                                // TODO: Implement this method
                                if (ed) {
                                    key += setp;
                                } else {
                                    key = start;
                                    ed = true;
                                }
                                return key;
                            }

                            @Override
                            public void remove() {
                                throw new UnsupportedOperationException("remove");
                            }
                        };
                    }

                    @Override
                    public String toString() {
                        Iterator iterator = this.iterator();
                        StringBuilder sb = new StringBuilder();
                        sb.append("[");
                        while (iterator.hasNext()) {
                            sb.append(iterator.next());
                            if (iterator.hasNext()) {
                                sb.append(", ");
                            }
                        }
                        sb.append("]");
                        return sb.toString();
                    }
                };
            } else if (start == stop) {
                return new Iterable() {
                    @Override
                    public Iterator iterator() {
                        // TODO: Implement this method
                        return new Iterator() {
                            @Override
                            public boolean hasNext() {
                                // TODO: Implement this method
                                return false;
                            }

                            @Override
                            public Integer next() {
                                // TODO: Implement this method
                                return null;
                            }

                            @Override
                            public void remove() {
                                throw new UnsupportedOperationException("remove");
                            }

                        };
                    }

                    @Override
                    public String toString() {
                        Iterator iterator = this.iterator();
                        StringBuilder sb = new StringBuilder();
                        sb.append("[");
                        while (iterator.hasNext()) {
                            sb.append(iterator.next());
                            if (iterator.hasNext()) {
                                sb.append(", ");
                            }
                        }
                        sb.append("]");
                        return sb.toString();
                    }
                };
            } else {
                return new Iterable() {
                    @Override
                    public Iterator iterator() {
                        // TODO: Implement this method
                        return new Iterator() {

                            boolean ed = false;
                            int key = start;

                            @Override
                            public boolean hasNext() {
                                // TODO: Implement this method
                                if (ed) {
                                    return key + setp > stop;
                                } else {
                                    return true;
                                }
                            }

                            @Override
                            public Integer next() {
                                // TODO: Implement this method
                                if (ed) {
                                    key += setp;
                                } else {
                                    key = start;
                                    ed = true;
                                }
                                return key;
                            }

                            @Override
                            public void remove() {
                                throw new UnsupportedOperationException("remove");
                            }

                        };
                    }

                    @Override
                    public String toString() {
                        Iterator iterator = this.iterator();
                        StringBuilder sb = new StringBuilder();
                        sb.append("[");
                        while (iterator.hasNext()) {
                            sb.append(iterator.next());
                            if (iterator.hasNext()) {
                                sb.append(", ");
                            }
                        }
                        sb.append("]");
                        return sb.toString();
                    }
                };
            }
        }
    }




}