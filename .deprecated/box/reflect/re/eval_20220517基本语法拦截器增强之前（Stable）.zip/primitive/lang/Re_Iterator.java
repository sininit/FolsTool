package top.fols.box.reflect.re.primitive.lang;

import top.fols.box.reflect.re.Re_Executor;
import top.fols.box.reflect.re.Re_Variable;

public abstract class Re_Iterator {
    public abstract Re_Variable key_variable();
    public abstract Re_Variable value_variable();

    public abstract boolean hasNext();

    public abstract void next(Re_Executor executor) throws Throwable;    //每次 next都会 设置key和value
}
