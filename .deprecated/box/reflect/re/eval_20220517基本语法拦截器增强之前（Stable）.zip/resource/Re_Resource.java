package top.fols.box.reflect.re.resource;

import top.fols.atri.util.annotation.Nullable;

import java.net.URI;
import java.nio.charset.Charset;

public interface Re_Resource {
	public URI toURI();

	
	public Charset defaultCharset()              ; //默认charset


	/**
	 *
	 * @param path 文件路径
	 * @return 为空则代表没有这个资源或者没有办法读取
	 */
	@Nullable
	public Re_ResourceFile 	 findFileResource(String path); //为空则找不到该资源



	/**
	 *
	 * @param className 类名
	 * @return 为空则代表没有这个资源或者没有办法读取
	 */
	@Nullable
	public Re_ResourceFile   findClassResource(String className); //为空则找不到该资源
}
