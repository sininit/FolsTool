package top.fols.box.reflect.re.resource;

import java.net.URI;
import java.nio.charset.Charset;
import java.io.InputStream;

public interface Re_ResourceFile {
	public URI toURI();
	
	//统一名称
	public String name();
	public String path();
	
	public Charset charset();


	public byte[]      bytes();
	public InputStream stream();
}
