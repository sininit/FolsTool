package top.fols.box.reflect.re;

import top.fols.atri.util.annotation.Nullable;
import top.fols.box.reflect.re.interfaces.Re_IObject;
import top.fols.box.reflect.re.interfaces.Re_IVariableMap;
import top.fols.atri.util.annotation.NotNull;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * 变量存储器，和对象不是一个概念
 * 变量是用来存储对象的
 */
public class Re_Variable<E> implements Re_IObject {

    public static abstract class DirectAccessor<E> {
        public abstract E    get(Re_Variable<E> variable);
        public abstract void set(Re_Variable<E> variable, E value);


        @SuppressWarnings("rawtypes")
        public static final DirectAccessor VARIABLE = new DirectAccessor() {
            @Override
            public Object get(Re_Variable variable) {
                return variable.__value__;
            }
            @Override
            public void   set(Re_Variable variable, Object value) {
                variable.__value__ = value;
            }
        };
    }
    /**
     * 动态变量（运行时变量）没有 内部访问器， 比如 arguments 和 this static 都是根据Re_Executor获取的
     */
    @SuppressWarnings("unchecked")
    protected DirectAccessor<E> getDirectAccessor() {
        return DirectAccessor.VARIABLE;
    }

    protected E __value__;




    public Re_Variable() {}
    public Re_Variable(E __value__) {
        this.__value__ = __value__;
    }



    public E    get(Re_Executor executor) {
        return this.__value__;
    }

    public void   set(Re_Executor executor, E value0) {
        this.__value__ = value0;
    }



    /**
     * 注意，这个非常重要 如果返回true 证明它是可以被修改和删除的
     *
     * final变量应该返回false 并将set直接重写为抛出异常
     */
    public boolean modifiable() {
        return true;
    }


    /**
     * 实际上 re执行获取该变量值的时候永远不会访问到这个方法
     * 只会访问 get() 获取存储的对象
     */
    @Override
    public final boolean isPrimitive() {
        return false;
    }





















    //no use

    public static Iterable margeKey(@NotNull Re_IVariableMap... map1) {
        if (null == map1) {
            return new LinkedHashSet();
        } else {
            if (map1.length == 1) {
                return map1[0].keySet();
            }
            Set list = new LinkedHashSet();
            for (int i = map1.length-1; i > 0; i--) {
                for (Object o : map1[i].keySet()) {
                    list.add(o);
                }
            }
            return list;
        }
    }
    /**
     *  合并所有key
     *
     * @param map1  @NotNull
     */
    public static Iterable key(@NotNull Re_IVariableMap map1) {
        return map1.keySet();
    }
    public static Iterable key(@NotNull Re_IVariableMap map1, @NotNull Re_IVariableMap map2) {
        return margeKey(map1, map2);
    }
    public static Iterable key(@NotNull Re_IVariableMap map1, @NotNull Re_IVariableMap map2, @NotNull Re_IVariableMap map3) {
        return margeKey(map1, map2, map3);
    }
    public static Iterable key(@NotNull Re_IVariableMap map1, @NotNull Re_IVariableMap map2, @NotNull Re_IVariableMap map3, @NotNull Re_IVariableMap map4) {
        return margeKey(map1, map2, map3, map4);
    }



    public static int size(@NotNull Re_IVariableMap map1) {
        return map1.size();
    }







    public static void accessClear(Re_Executor executor, @NotNull Re_IVariableMap map1) {
        for (Object key: map1.keySet()) {
            Re_Variable.accessRemove(executor, key, map1);
            if (executor.isThrow()) return;
        }
    }


    /**
     * @param key @NotNull
     * @param map1  @NotNull
     *
     * 不会向上查找
     */
    public static boolean has(@NotNull Object key,
                              @NotNull Re_IVariableMap map1) {
        return map1.containsKey(key);
    }

    /**
     *  @see Re_Variable#set(Re_Executor, Object)
     * @param key @NotNull
     * @param map1  @NotNull
     *
     * 不会向上查找
     */
    public static boolean accessRemove(Re_Executor executor, @NotNull Object key, @NotNull Re_IVariableMap map1) {
        Re_Variable variable = map1.get(key);
        if (null != variable && variable.modifiable()) {
            map1.remove(key);
            return true;
        }
        return false;
    }


    /**
     * @see Re_Variable#set(Re_Executor, Object)
     * 如果已经存在变量 会 执行{@link Re_Variable#set(Re_Executor, Object)}
     *
     * 应该由执行时设置 因为
     * 变量名执行前都是经过 {@link String#intern()} 的
     *
     * 在 {@link Re_IObject} 或者 {@link Re_IVariableMap} 方法中如果name没有被你改变可以直接执行该方法
     *
     * 不规则方法
     *  {@link Re_Executor#executeCallVariableMap(Re_Executor, Re_IVariableMap, Re_CodeLoader.Call)}
     *  {@link Re_Executor#executeCallJavaArrayMethod(Object, Re_CodeLoader.Call)}
     *
     *  不会向上查找
     */
    public static void accessSetValue(Re_Executor executor, @NotNull Object key, Object value, @NotNull Re_IVariableMap map) {
        Re_Variable variable = map.get(key);
        if (null != variable) {
            variable.set(executor, value);
        } else {
            map.put(key, new Re_Variable(value));
        }
    }




    /**
     * 一般为动态添加的时候使用
     *
     * 如果不存在变量才会创建新的变量，Key将会被转换为 {@link Re_CodeLoader#intern(Object)}
     * 如果已存在将不会 {@link Re_CodeLoader#intern(Object)} 变量中的原始key将不会变化
     *
     *  不会向上查找
     */
    public static void accessSetValueFromNewVariableIntern(Re_Executor executor, @NotNull Object key, @NotNull Re_Variable newVariable, @NotNull Re_IVariableMap map) {
        //var name not null
        Re_Variable variable = map.get(key);
        if (null != variable) {
            if (variable.modifiable()) {
                map.put(key, newVariable);
            } else {
                String s = Re_Util.toString(key);
                executor.setThrow("final variable value cannot be set: "+s);
            }
        } else {
            map.put(Re_CodeLoader.intern(key), newVariable);
        }
    }


    /**
     * @see Re_Variable#set(Re_Executor, Object)
     * 如果已经存在变量 会抛出异常
     * 一般为动态添加的时候使用
     *
     * 如果不存在变量才会创建新的变量，Key将会被转换为 {@link Re_CodeLoader#intern(Object)}
     *
     *  不会向上查找
     */
    public static void accessAddFinalValueIntern(Re_Executor executor, @NotNull Object key, Object value, @NotNull Re_IVariableMap map) {
        //var name not null
        Re_Variable variable = map.get(key);
        if (null != variable) {
            String s = Re_Util.toString(key);
            executor.setThrow("already set variable: " + s);
        } else {
            map.put(Re_CodeLoader.intern(key), new FinalVariable(value));
        }
    }









    /**
     * @param key @NotNull
     * @param map1  @NotNull
     *
     *  会向上查找
     */
    public static Object accessFindValue(Re_Executor executor, @NotNull Object key,
                                         @NotNull Re_IVariableMap map1) {
        Re_Variable variable = map1.find(key);
        if (null != variable) {
            return  variable.get(executor);
        }
        return null;
    }
    /**
     *  会向上查找
     */
    public static Object accessFindValue(Re_Executor executor, @NotNull Object key,
                                         @NotNull Re_IVariableMap map1, @NotNull Re_IVariableMap map2) {
        Re_Variable variable = map1.find(key);
        if (null != variable) {
            return variable.get(executor);
        } else {
            variable = map2.find(key);
            if (null != variable) {
                return variable.get(executor);
            }
        }
        return null;
    }



    /**
     * 不会向上查询
     */
    public static Object accessGetClassValue(Re_Executor executor, @NotNull Object key,
                                             @NotNull Re_Class reClass) {
        if (Re_Keywords.isReClass(reClass)) {
            Re_Variable variable = reClass.variable.find(key);
            if (null != variable) {
                return  variable.get(executor);
            }
        }
        throw new Re_Exceptions.ExecuteException("not a reClass: " +(null == reClass?null:reClass.getClass()));
    }
    /**
     * 会向上查询 实例变量和类变量表
     */
    public static Object accessGetInstanceValue(Re_Executor executor, @NotNull Object key,
                                                @NotNull Re_Class.Instance instance) {
        Re_Variable variable = instance.variable.find(key);
        if (null == variable) {
            variable = instance.getStatic().variable.find(key);
            if (null == variable) {
                return null;
            }
        }
        return variable.get(executor);
    }




    /**
     * 如果不存在将会设置 {@link Re_Executor#setThrow(String)} }
     * 会向上查询
     */
    public static Object accessFindValueRequire(@NotNull Re_Executor executor, @NotNull Object key,
                                                @NotNull Re_IVariableMap map1) {
        Re_Variable variable = map1.find(key);
        if (null != variable) {
            return variable.get(executor);
        }
        String s = Re_Util.toString(key);
        executor.setThrow("var["+s+"] undefine");
        return null;
    }
    /**
     * 如果不存在将会设置 {@link Re_Executor#setThrow(String)} }
     * 会向上查询
     */
    public static Object accessFindValueRequire(@NotNull Re_Executor executor, @NotNull Object key,
                                                @NotNull Re_IVariableMap map1, @NotNull Re_IVariableMap map2) {
        Re_Variable variable = map1.find(key);
        if (null != variable) {
            return variable.get(executor);
        } else {
            variable = map2.find(key);
            if (null != variable) {
                return variable.get(executor);
            }
        }
        String s = Re_Util.toString(key);
        executor.setThrow("var["+s+"] undefine");
        return null;
    }



    static final Re_Variable[]  EMPTY_ARRAY  = {};

    public static class Unsafe {
        public static Re_Variable[] values(@NotNull Re_IVariableMap map1) {
            List<Object> list = new ArrayList<>();
            for (Object o : map1.keySet()) {
                list.add(map1.get(o));
            }
            return list.toArray(EMPTY_ARRAY);
        }


        /**
         * 一般为动态添加的时候使用
         *
         * 如果不存在 Key将会被转换为 {@link Re_CodeLoader#intern(Object)} 再提交
         * 如果已存在将不会 {@link Re_CodeLoader#intern(Object)} 变量中的原始key将不会变化
         */
        public static void putNewVariableIntern(@NotNull Object key, @NotNull Re_Variable variable, @NotNull Re_IVariableMap map1) {
            map1.put(Re_CodeLoader.intern(key), variable);
        }
        public static void putNewVariable(@NotNull Object key, @NotNull Re_Variable variable, @NotNull Re_IVariableMap map1) {
            map1.put(key, variable);
        }

        /**
         * @see Re_Variable#set(Re_Executor, Object)
         * 如果已经存在变量 会异常
         *
         * 一般为动态添加的时候使用
         * 如果不存在 Key将会被转换为 {@link Re_CodeLoader#intern(Object)} 再提交
         *
         * 不会向上查询
         */
        public static void addVariableIntern(@NotNull Object key, @NotNull Re_Variable value, @NotNull Re_IVariableMap map) {
            //var name not null
            Re_Variable variable = map.get(key);
            if (null != variable) {
                String s = Re_Util.toString(key);
                throw new Re_Exceptions.ExecuteException("already set variable: " + s);
            } else {
                map.put(Re_CodeLoader.intern(key), value);
            }
        }

        /**
         * @see Re_Variable#set(Re_Executor, Object)
         * 如果已经存在变量 会 执行{@link Re_Variable#set(Re_Executor, Object)}
         *
         * 应该由执行时设置 因为
         * 变量名执行前都是经过 {@link String#intern()} 的
         * 如果你从 {@link Re_IObject} 中的回调中 不改变name名称 可以直接使用该方法而不使用 intern
         *
         * 不会向上查询
         */
        public static void addVariable(@NotNull Object key, @NotNull Re_Variable value, @NotNull Re_IVariableMap map) {
            Re_Variable variable = map.get(key);
            if (null != variable) {
                String s = Re_Util.toString(key);
                throw new Re_Exceptions.ExecuteException("already set variable: " + s);
            } else {
                map.put(key, value);
            }
        }

        /**
         * 不会向上查找
         */
        public static boolean removeVariable(@NotNull Object key,
                                             @NotNull Re_IVariableMap map1) {
            return null != map1.remove(key);
        }



        /**
         * @see Re_Variable#set(Re_Executor, Object)
         * 如果已经存在变量 会抛出异常
         *
         * 一般为动态添加的时候使用
         * 如果不存在 Key将会被转换为 {@link Re_CodeLoader#intern(Object)} 再提交
         *
         * 不会向上查找
         */
        public static void addFinalValueIntern(@NotNull Object key, @Nullable Object value, @NotNull Re_IVariableMap map) {
            //var name not null
            Re_Variable variable = map.get(key);
            if (null != variable) {
                String s = Re_Util.toString(key);
                throw new Re_Exceptions.ExecuteException("already set variable: " +s);
            } else {
                map.put(Re_CodeLoader.intern(key), new FinalVariable(value));
            }
        }

        /**
         * @see Re_Variable#set(Re_Executor, Object)
         * 如果已经存在变量 会抛出异常
         *
         * 应该由执行时设置 因为
         * 变量名执行前都是经过 {@link String#intern()} 的
         * 如果你从 {@link Re_IObject} 中的回调中 不改变name名称 可以直接使用该方法而不使用 intern
         *
         * 不会向上查找
         */
        private static void addFinalValue(@NotNull Object key, @Nullable Object value, @NotNull Re_IVariableMap map) {
            Re_Variable variable = map.get(key);
            if (null != variable) {
                String s = Re_Util.toString(key);
                throw new Re_Exceptions.ExecuteException("already set variable: " +s);
            } else {
                map.put(key, new FinalVariable(value));
            }
        }
        /**
         * 不会向上查找
         */
        public static boolean getDirectAccessor(@NotNull Object key, @NotNull Re_IVariableMap map) {
            Re_Variable variable = map.get(key);
            if (null != variable) {
                return  variable.getDirectAccessor() != null;
            }
            return false;
        }




        /**
         * 会向上搜索
         */
        public static Re_Variable findVariable(@NotNull Object key, @NotNull Re_IVariableMap map) {
            return map.find(key);
        }

        /**
         * 会向上查询
         */
        public static <E> E fromDirectAccessorFindValue(@Nullable Object key, Re_IVariableMap map) {
            Re_Variable<E> variable = map.find(key);
            if (null == variable) {
                return null;
            } else {
                DirectAccessor<E> directAccessor = variable.getDirectAccessor();
                if (null == directAccessor) {
                    throw new Re_Exceptions.ExecuteException("variable is not direct accessor: " + variable.getClass());
                }
                return directAccessor.get(variable);
            }
        }


        /**
         * 不会向上查询
         */
        public static Object fromDirectAccessorGetClassValue(@Nullable Object key,
                                                             @NotNull Re_Class reClass) {
            if (Re_Keywords.isReClass(reClass)) {
                Re_Variable<?> variable = reClass.variable.find(key);
                if (null != variable) {
                    return fromDirectAccessorGetValue(variable);
                }
            }
            throw new Re_Exceptions.ExecuteException("not a reClass: " +(null == reClass?null:reClass.getClass()));
        }
        /**
         * 会向上查询 实例变量和类变量表
         */
        public static Object fromDirectAccessorGetInstanceValue(@Nullable Object key,
                                                                @NotNull Re_Class.Instance instance) {
            Re_Variable<?> variable = instance.variable.find(key);
            if (null == variable) {
                variable = instance.getStatic().variable.find(key);
                if (null == variable) {
                    return null;
                }
            }
            return fromDirectAccessorGetValue(variable);
        }




        public static <E> E fromDirectAccessorGetValue(Re_Variable<E> variable) {
            DirectAccessor<E> directAccessor = variable.getDirectAccessor();
            if (null == directAccessor) {
                throw new Re_Exceptions.ExecuteException("variable is not direct accessor: " + variable.getClass());
            }
            return directAccessor.get(variable);
        }

        public static <E> void fromDirectAccessorSetValue(Re_Variable<E> variable, E v) {
            DirectAccessor<E> directAccessor = variable.getDirectAccessor();
            if (null == directAccessor) {
                throw new Re_Exceptions.ExecuteException("variable is not direct accessor: " + variable.getClass());
            }
            directAccessor.set(variable, v);
        }




        /**
         * 一般为动态添加的时候使用
         *
         * 如果不存在变量才会创建新的变量，Key将会被转换为 {@link Re_CodeLoader#intern(Object)}
         * 如果已存在将不会 {@link Re_CodeLoader#intern(Object)} 变量中的原始key将不会变化
         *
         * 不会向上查询
         */
        public static <E> void fromDirectAccessorSetValueIntern(Object key, E v, Re_IVariableMap map) {
            Re_Variable<E> variable = map.get(key);
            if (null == variable) {
                map.put(Re_CodeLoader.intern(key), new Re_Variable<>(v));
            } else {
                DirectAccessor<E> directAccessor = variable.getDirectAccessor();
                if (null == directAccessor) {
                    throw new Re_Exceptions.ExecuteException("variable is not direct accessor: " + variable.getClass());
                }
                directAccessor.set(variable, v);
            }
        }
        /**
         * 不会向上查询
         */
        public static <E> void fromDirectAccessorSetValue(Object key, E v, Re_IVariableMap map) {
            Re_Variable<E> variable = map.get(key);
            if (null == variable) {
                map.put(key, new Re_Variable<>(v));
            } else {
                DirectAccessor<E> directAccessor = variable.getDirectAccessor();
                if (null == directAccessor) {
                    throw new Re_Exceptions.ExecuteException("variable is not direct accessor: " + variable.getClass());
                }
                directAccessor.set(variable, v);
            }
        }




        /**
         * 一般为动态添加的时候使用
         *
         * 如果不存在变量才会创建新的变量，Key将会被转换为 {@link Re_CodeLoader#intern(Object)}
         * 如果已存在将不会 {@link Re_CodeLoader#intern(Object)} 变量中的原始key将不会变化, 如果已存在的变量不是final将会把变量转换为final
         *
         * 不会向上查询
         */
        public static <E> void fromDirectAccessorSetFinalValueIntern(Object key, E v, Re_IVariableMap map) {
            Re_Variable<E> variable = map.get(key);
            if (null == variable) {
                map.put(Re_CodeLoader.intern(key), new FinalVariable<>(v));
            } else {
                DirectAccessor<E> directAccessor = variable.getDirectAccessor();
                if (null == directAccessor) {
                    throw new Re_Exceptions.ExecuteException("variable is not direct accessor: " + variable.getClass());
                }
                if (variable.modifiable()) {
                    variable = new FinalVariable<>(v);
                    map.put(key, variable);
                } else {
                    directAccessor.set(variable, v);
                }
            }
        }

        /**
         * 不会向上查询
         */
        public static <E> void fromDirectAccessorSetFinalValue(Object key, E v, Re_IVariableMap map) {
            Re_Variable<E> variable = map.get(key);
            if (null == variable) {
                map.put(key, new FinalVariable<>(v));
            } else {
                DirectAccessor<E> directAccessor = variable.getDirectAccessor();
                if (null == directAccessor) {
                    throw new Re_Exceptions.ExecuteException("variable is not direct accessor: " + variable.getClass());
                }
                if (variable.modifiable()) {
                    variable = new FinalVariable<>(v);
                    map.put(key, variable);
                } else {
                    directAccessor.set(variable, v);
                }
            }
        }

    }



    /**
     * 不可修改变量
     */
    public static class FinalVariable<E> extends Re_Variable<E> {
        public FinalVariable() {}
        public FinalVariable(E value0) {
            __value__ = value0;
        }



        @Override public void set(Re_Executor executor, E value0) {
            executor.setThrow("final variable value cannot be set");
        }
        @Override public boolean modifiable() {
            return false;
        }
    }







    @Override final public Object  getVariableProcess(Re_Executor executor, Object key) throws Throwable {
        executor.setThrow("unsupported get var");
        return null;
    }
    @Override final public boolean hasVariableProcess(Re_Executor executor, Object key) throws Throwable {
        executor.setThrow("unsupported has var");
        return false;
    }
    @Override final public boolean removeVariableProcess(Re_Executor executor, Object key) throws Throwable {
        executor.setThrow("unsupported remove var");
        return false;
    }
    @Override final public void    setVariableProcess(Re_Executor executor, Object key, Object value) throws Throwable {
        executor.setThrow("unsupported set var");
    }
    @Override public int getSizeProcess(Re_Executor executor) throws Throwable {
        executor.setThrow("unsupported size var");
        return 0;
    }
    @Override public Iterable getKeysProcess(Re_Executor executor) throws Throwable {
        executor.setThrow("unsupported key var");
        return null;
    }

    @Override final public Object  executePointMethodProcess(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
        executor.setThrow(point_key + " undefined");
        return null;
    }
    @Override final public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
        executor.setThrow("unsupported base method");
        return null;
    }
}
