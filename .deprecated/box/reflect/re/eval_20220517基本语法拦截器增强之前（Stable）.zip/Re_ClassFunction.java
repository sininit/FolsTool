package top.fols.box.reflect.re;

import top.fols.atri.lang.Finals;
import top.fols.atri.util.annotation.Nullable;
import top.fols.box.reflect.re.interfaces.Re_IObject;
import top.fols.box.reflect.re.interfaces.Re_IGetDeclaringClass;
import top.fols.box.reflect.re.interfaces.Re_IVariableMap;
import top.fols.box.reflect.re.variables.Re_VariableMap;

public class Re_ClassFunction implements Re_IObject, Re_IGetDeclaringClass {
    private String      name;
    private String[]    params;

    Re_CodeFile         reCodeBlock;
    Re_Class            reDeclaringClass;


    Re_ClassFunction() {}

    Re_Executor parent = null;


    /**
     * @param reCodeBlock       代码块
     * @param reDeclaringClass  所属类
     */
    static Re_ClassFunction createAnonymousFunction(Re_Executor parent, Re_CodeFile reCodeBlock, Re_Class  reDeclaringClass, @Nullable String[] paramName) {
        return createAnonymousFunctionAfter(new Re_ClassFunction(),
                parent, reCodeBlock, reDeclaringClass, paramName);
    }
    static Re_ClassFunction createAnonymousFunctionAfter(Re_ClassFunction reFunction, Re_Executor parent, Re_CodeFile reCodeBlock, Re_Class  reDeclaringClass, @Nullable String[] paramName) {
        reFunction.name                     = Re_CodeLoader.intern(
                Re_Keywords.INNER_FUNCTION__FUNCTION0 + "_" + reCodeBlock.getLineOffset() + "_" + Integer.toHexString(reFunction.hashCode()));
        reFunction.params                   = null == paramName? Finals.EMPTY_STRING_ARRAY:paramName;
        reFunction.reCodeBlock              = reCodeBlock;
        reFunction.reDeclaringClass         = reDeclaringClass;
        reFunction.parent                   = parent;
        return reFunction;
    }


    static Re_ClassFunction createFunction(Re_Executor parent, String name, Re_CodeFile reCodeBlock, Re_Class  reDeclaringClass, @Nullable String[] paramName) {
        return createFunctionAfter(new Re_ClassFunction(),
                parent, name, reCodeBlock, reDeclaringClass, paramName);
    }
    static Re_ClassFunction createFunctionAfter(Re_ClassFunction reFunction, Re_Executor parent, String name, Re_CodeFile reCodeBlock, Re_Class  reDeclaringClass, @Nullable String[] paramName) {
        if (null == name)
            name = String.valueOf((Object)null);

        reFunction.name                     = Re_CodeLoader.intern(name);
        reFunction.params                   = null == paramName? Finals.EMPTY_STRING_ARRAY:paramName;
        reFunction.reCodeBlock              = reCodeBlock;
        reFunction.reDeclaringClass         = reDeclaringClass;
        reFunction.parent                   = parent;
        return reFunction;
    }



    @Override
    public final Re_Class getReDeclaringClass() {
        return reDeclaringClass;
    }
    public final String getReClassFunctionName() {
        return name;
    }


    public int      getParamCount() {
        return params.length;
    }
    public String   getParamName(int index) {
        return params[index];
    }


    @Override
    public String toString() {
        if (null == getReDeclaringClass())
            return "re-" + Re_Keywords.INNER_FUNCTION__FUNCTION0 + " " +
                    getReClassFunctionName();
        else
            return "re-" + Re_Keywords.INNER_FUNCTION__FUNCTION0 + " " +
                    getReDeclaringClass().getReClassName() + Re_CodeSymbol.CODE_OBJECT_POINT_SYMBOL + getReClassFunctionName();
    }



    @Override
    public boolean isPrimitive() {
        return false;
    }


    /**
     * 执行之前不可能已经return， 如果中间有执行了表达式应该判断表达式是否已经return 如果已经return 则返回return数据 而不是继续操作, 如果已经return返回的任何数据都是无效的
     * 只要用了{@link Re_Executor#getExpressionValue(Re_CodeLoader.Call, int)} 后都要手动检测是否return
     * <p>
     * 假定本对象名称x
     * 那么执行的是 x()
     * @param executor            父变量管理器
     * @param var_key            为当前名称，并非指子变量名称
     *                            map();
     * @param call 如果是true 则callParam 为空 ，如果false则 callParam会经过计算后传入
     */
    @Override
    public Object executeCallProcess(Re_Executor executor, String var_key, Re_CodeLoader.Call call) throws Throwable {
        Object[] arguments = executor.getExpressionValues(call);
        if (executor.isReturn()) return executor.getReturn();

        Re_IVariableMap re_iReVariableMap = getArgumentsArrayAsVariableMap(arguments, this);
        if (executor.isReturn()) return executor.getReturn();

        return invoke(executor, reDeclaringClass, null, arguments, re_iReVariableMap);
    }




    /**
     * 无论是静态方法还是对象方法都会继承创建时的空间变量
     * 执行后统一只会访问 executeStaticFunction executeObjectFunction
     */
    public Object invoke(Re_Executor executor, Re_Class aClass, Re_Class.Instance instance, Object[] arguments, Re_IVariableMap functionLocal) {
        Re_Executor re_executor = Re_Executor.buildReClassObjectOrStaticFunction0(executor.host, executor.getStack(), this, aClass, instance, functionLocal, arguments);
        if (null == re_executor) return null;
        return re_executor.run();
    }








    @Override
    public final boolean hasVariableProcess(Re_Executor executor, Object key) {
        executor.setThrow("this is function");
        return false;
    }
    @Override
    public final boolean removeVariableProcess(Re_Executor executor, Object key) {
        executor.setThrow("this is function");
        return false;
    }
    @Override
    public final Object getVariableProcess(Re_Executor executor, Object key) {
        executor.setThrow("this is function");
        return null;
    }
    @Override
    public final void setVariableProcess(Re_Executor executor, Object key, Object value) {
        executor.setThrow("this is function");
    }

    @Override
    public int getSizeProcess(Re_Executor executor) throws Throwable {
        executor.setThrow("this is function");
        return 0;
    }

    @Override
    public Iterable getKeysProcess(Re_Executor executor) throws Throwable {
        executor.setThrow("this is function");
        return null;
    }

    @Override
    public final Object executePointMethodProcess(Re_Executor executor, String point_key, Re_CodeLoader.Call call) throws Throwable {
        executor.setThrow("this is function");
        return null;
    }












    public static Re_IVariableMap getArgumentsArrayAsVariableMap(Object[] arguments, Re_ClassFunction reFunction) {
        int functionParamCount = reFunction.getParamCount();
        if (functionParamCount > 0) {
            Re_VariableMap main_function_local = new Re_VariableMap();
            if (arguments.length >= functionParamCount) {
                for (int i = 0; i < functionParamCount; i++) {
                    String name = reFunction.getParamName(i);
                    Object value = arguments[i];

                    Re_Variable valueVariable = new Re_Variable(value);
                    Re_Variable.Unsafe.putNewVariable(name, valueVariable, main_function_local);
                }
            } else {
                int i = 0;
                for (; i < arguments.length; i++) {
                    String name = reFunction.getParamName(i);
                    Object value = arguments[i];

                    Re_Variable valueVariable = new Re_Variable(value);
                    Re_Variable.Unsafe.putNewVariable(name, valueVariable, main_function_local);
                }
                for (; i < functionParamCount; i++) {
                    String name = reFunction.getParamName(i);

                    Re_Variable valueVariable = new Re_Variable(null);
                    Re_Variable.Unsafe.putNewVariable(name, valueVariable, main_function_local);
                }
            }
            return main_function_local;
        } else {
            return null;
        }
    }
}











    
