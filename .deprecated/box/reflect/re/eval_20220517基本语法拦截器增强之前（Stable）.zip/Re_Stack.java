
package top.fols.box.reflect.re;

import java.util.ArrayList;
import java.util.List;

import top.fols.atri.lang.Strings;
import top.fols.atri.util.DoubleLinked;

public class Re_Stack {
	public static String lineAddressString(String fileName, int line) {
		return '(' + fileName + ":" + line + ')';
	}





	public static class StackElement implements Cloneable{
		protected String filePath;
		protected int line;
		public StackElement(int line) {
			this.line = line;
		}


		public void setFilePath(String reName) {
			this.filePath = reName;
		}
		public String getFilePath() {
			return filePath;
		}


		public void setLine(int line) {
			this.line = line;
		}
		public int getLine() {
			return line;
		}

		@Override
		public StackElement clone() {
			// TODO: Implement this method
			try {
				return (StackElement) super.clone();
			} catch (CloneNotSupportedException e) {
				throw new RuntimeException(e);
			}
		}


		@Override
		public String toString() {
			// TODO: Implement this method
			return lineAddressString(this.filePath, this.line).toString();
		}
	}






	DoubleLinked<StackElement> top, bottom;
	int max_size = 8 * 1024 * 1024;// 8M
	int now_size = 0;
	boolean isThrow = false;
	String throwReason = null;

	public boolean isEmpty() {
		return null == top;
	}





	private Re_Stack(StackElement threadStartStackElement) {
		if (null != threadStartStackElement) {
			this.top = this.bottom = new DoubleLinked<>(threadStartStackElement.clone());
		}
	}
	private Re_Stack(Re_Stack beCloneStack) {
		if (null != beCloneStack.top) {
			this.top = this.bottom = new DoubleLinked<>(beCloneStack.top.content().clone());//克隆第一个元素

			DoubleLinked<StackElement> next = beCloneStack.top.getNext();//获取第二个
			for (;null != next; next = next.getNext()) {
				StackElement current = next.content();
				if (null != current) {
					DoubleLinked<StackElement> clone_next = new DoubleLinked<>(current.clone());
					this.bottom.addNext(clone_next);
					this.bottom = clone_next; //
				}
			}
		}

		this.max_size = beCloneStack.max_size;
		this.now_size = beCloneStack.now_size;
		this.isThrow = beCloneStack.isThrow;
		this.throwReason = beCloneStack.throwReason;
	}



	public boolean isThrow() {
		return this.isThrow;
	}

	/**
	 * @see Re_Executor#executeTry0(Re_CodeLoader.CTExpression, Re_CodeLoader.CTExpression, Re_CodeLoader.CTExpression)
	 */
	public String getThrow() {
		return this.throwReason;
	}

	public void setThrow(String reason) {
		this.isThrow = true;
		this.throwReason = reason;
	}

	public void clearThrow() {
		this.isThrow = false;
		this.throwReason = null;
	}




	public static Re_Stack newStack() {
		return new Re_Stack((StackElement) null);
	}
	public static Re_Stack newThreadStack(StackElement threadStartStackElement) {
		return new Re_Stack(threadStartStackElement);
	}
	public static Re_Stack cloneStack(Re_Stack originStack) {
		return new Re_Stack(originStack);
	}




	protected DoubleLinked<StackElement> addStackElement(StackElement current) {
		DoubleLinked<StackElement> c = new DoubleLinked<StackElement>(current);
		if (null == this.bottom) {
			this.top = this.bottom = c;
		} else {
			//top
			this.top.addPrev(c);
			this.top = c;
		}
		this.now_size++;
		if (this.now_size >= this.max_size) {
			this.setThrow("stack overflow, max=" + this.max_size);
		}
		return c;
	}
	//无法保证栈元素是当前栈的 所以请不要执行
	protected void removeStackElement(DoubleLinked<StackElement> current) {
		//假定current是当前栈的
		//假设current是栈顶
		if (current == this.bottom) {
			if (this.top == this.bottom) {
				this.now_size = 0;
				this.top = this.bottom = null;
				current.remove();
			} else {
				DoubleLinked<StackElement> prev = this.bottom.getNext();
				this.now_size -= 1;
				current.remove();
				this.bottom = prev;
			}
		} else if (current == this.top) {
			DoubleLinked<StackElement> next = current.getNext();
			this.now_size--;
			current.remove();
			this.top = next;
		} else {
			current.remove();
		}
	}
	//删除某个栈之前的所有栈
	@SuppressWarnings("UnnecessaryReturnStatement")
	protected void disconBefore(DoubleLinked<StackElement> current) {
		if (current == this.top) {
			return;
		} else if (current == this.bottom) {
			this.top = current;
			current.disconAfter();
			this.now_size = 1;
		} else {
			DoubleLinked<StackElement> stackElementDoubleLinked = current.disconBefore();
			if (null != stackElementDoubleLinked) {
				int size = 0;
				for (DoubleLinked<StackElement> c = stackElementDoubleLinked; null != c; c= c.getPrev()) {
					size++;
				}
				this.top = current;
				this.now_size -= size;
			}
		}


	}






	public StackElement[] stacks() {
		List<StackElement> cs = new ArrayList<>();
		for (DoubleLinked<StackElement> now = this.top; null != now; now = now.getNext()) {
			StackElement current = now.content();
			if (null != current) {
				cs.add(current.clone());
			}
		}
		return cs.toArray(new StackElement[]{});
	}

	public StackElement now() {
		DoubleLinked<StackElement> now = this.top;
		StackElement n = null == now ? null : now.content();
		return null == n ? null : n.clone();
	}

	@SuppressWarnings("MethodDoesntCallSuperMethod")
	@Override
	public Re_Stack clone() {
		// TODO: Implement this method
		return new Re_Stack(this);
	}



	public String buildStacksString() {
		StringBuilder sb = new StringBuilder();
		String reason = this.getThrow();
		sb.append("Reason: ") .append(Strings.tabs(Re_CodeSymbol.CODE_LINE_SEPARATOR_CHAR + reason)).append(Re_CodeSymbol.CODE_LINE_SEPARATOR_CHAR);
		sb.append("Traces: ") .append(Re_CodeSymbol.CODE_LINE_SEPARATOR_CHAR);
		for(DoubleLinked<StackElement> now = this.top; null != now; now= now.getNext()){
			StackElement current = now.content();
			if (null != current) {
				sb.append("\tin ").append(current).append(Re_CodeSymbol.CODE_LINE_SEPARATOR_CHAR);
			}
		}
		if (sb.length() > String.valueOf(Re_CodeSymbol.CODE_LINE_SEPARATOR_CHAR).length())
			sb.setLength(sb.length()- String.valueOf(Re_CodeSymbol.CODE_LINE_SEPARATOR_CHAR).length());
		return sb.toString();
	}

	@Override
	public String toString() {
		return this.buildStacksString();
	}



}
