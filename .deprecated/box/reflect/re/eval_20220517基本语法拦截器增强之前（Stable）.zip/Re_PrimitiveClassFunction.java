package top.fols.box.reflect.re;


import top.fols.atri.lang.Finals;

public class Re_PrimitiveClassFunction extends Re_ClassFunction {
    public Re_PrimitiveClassFunction(String name, Re_Class  reDeclaringClass) {
        Re_CodeFile codeBlock;
        codeBlock = new Re_CodeFile();
        codeBlock.filePath = getClass().getName();

        Re_ClassFunction.createFunctionAfter(this, null, name, codeBlock, reDeclaringClass, Finals.EMPTY_STRING_ARRAY);
    }
}
