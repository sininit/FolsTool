package top.fols.box.reflect.re.interfaces;

import top.fols.atri.reflect.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * 主要处理Java的反射
 */
@SuppressWarnings({"rawtypes", "UnusedReturnValue"})
public interface Re_IJavaReflector {

    public Field matchField(Field[] list, Class returnClass, String name);

    public Constructor matchConstructor(Constructor[] list, Class[][] listParameterTypes, boolean nullObjectCanCastToClass, Class... paramClassArr);

    public Constructor[] matchConstructors(Constructor[] list, Class[][] listParameterTypes, boolean nullObjectCanCastToClass, Class... paramClassArr);

    public Method matchMethod(Method[] list, Class[][] listParameterTypes, Class returnClass, String name, boolean nullObjectCanCastToClass, Class... paramClassArr);

    public Method[] matchMethods(Method[] list, Class[][] listParameterTypes, Class returnClass, String name, boolean nullObjectCanCastToClass, Class... paramClassArr);

    public Constructor matchConstructor(Constructor[] list, Class[][] listParameterTypes, boolean nullObjectCanCastToClass, Object... paramInstanceArr) ;

    public Constructor[] matchConstructors(Constructor[] list, Class[][] listParameterTypes, boolean nullObjectCanCastToClass, Object... paramInstanceArr);

    public Method matchMethod(Method[] list, Class[][] listParameterTypes, Class returnClass, String name, boolean nullObjectCanCastToClass, Object... paramInstanceArr);

    public Method[] matchMethods(Method[] list, Class[][] listParameterTypes, Class returnClass, String name, boolean nullObjectCanCastToClass, Object... paramInstanceArr);

    public ReflectCache cacher();



    Class requireClasses(Class cls, String name) throws RuntimeException;
    Class classes(Class cls, String name) throws RuntimeException;

    Field requireField(Class cls, Class type, String name) throws RuntimeException;
    Field field(Class cls, Class type, String name) throws RuntimeException;

    Constructor requireConstructor(Class<?> cls, Object... paramInstanceArr) throws RuntimeException;
    Constructor constructor(Class<?> cls, Object... paramInstanceArr) throws RuntimeException;

    Constructor requireConstructor(Class<?> cls, Class... paramClass) throws RuntimeException;
    Constructor constructor(Class<?> cls, Class... paramClass) throws RuntimeException;

    Constructor[] requireConstructors(Class<?> cls, Object... paramInstanceArr) throws RuntimeException;
    Constructor[] constructors(Class<?> cls, Object... paramInstanceArr) throws RuntimeException;

    Constructor[] requireConstructors(Class<?> cls, Class... paramClass) throws RuntimeException;
    Constructor[] constructors(Class<?> cls, Class... paramClass) throws RuntimeException;

    Method requireMethod(Class cls, Class returnClass, String name, Object... paramInstanceArr) throws RuntimeException;
    Method method(Class cls, Class returnClass, String name, Object... paramInstanceArr) throws RuntimeException;

    Method requireMethod(Class cls, Class returnClass, String name, Class... paramClass) throws RuntimeException;
    Method method(Class cls, Class returnClass, String name, Class... paramClass) throws RuntimeException;

    Method[] requireMethods(Class cls, Class returnClass, String name, Object... paramInstanceArr) throws RuntimeException;
    Method[] methods(Class cls, Class returnClass, String name, Object... paramInstanceArr) throws RuntimeException;

    Method[] requireMethods(Class cls, Class returnClass, String name, Class... paramClass) throws RuntimeException;
    Method[] methods(Class cls, Class returnClass, String name, Class... paramClass) throws RuntimeException;
}
