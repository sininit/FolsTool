package top.fols.box.reflect.re.interfaces;

public interface Re_IGetJavaClass {
    public Class getJavaClass();
}
