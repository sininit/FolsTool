package top.fols.box.reflect.re;

import java.util.*;

import top.fols.atri.assist.ArrList;
import top.fols.atri.assist.StringJoiner;
import top.fols.atri.io.CharCodeReader;
import top.fols.atri.io.file.Filex;
import top.fols.atri.lang.Finals;
import top.fols.atri.lang.Strings;
import top.fols.atri.lang.Objects;
import top.fols.atri.io.CharArrayWriters;
import top.fols.box.reflect.re.interfaces.Re_IObject;
import top.fols.box.reflect.re.interfaces.Re_IVariableMap;
import top.fols.box.reflect.re.primitive.lang.Re_Iterable;
import top.fols.box.reflect.re.primitive.lang.Re_Iterables;
import top.fols.box.reflect.re.primitive.lang.Re_Iterator;

@SuppressWarnings({"UnnecessaryLocalVariable", "IfCanBeSwitch", "UnnecessaryContinue"})
public class Re_CodeLoader {

    /**
     * 获取所有字符串的 intern, 花里胡哨还不如直接用java的字符池快 花里胡哨
     * 经过测试发现如果用自己的缓存 跑起来会更慢，，，，我也不知道为什么
     */
    public static <T> T intern(T keywords) {
        //noinspection unchecked
        return keywords instanceof String? (T) ((String)keywords).intern(): keywords;
    }


    public static final String FILE_EXTENSION_SYMBOL  = intern(".");
    public static final String RE_FILE_EXTENSION_NAME = intern("re");


    public static final char   PACKAGE_SEPARATOR            = intern('.');
    public static final String PACKAGE_SEPARATOR_STRING     = intern("" + PACKAGE_SEPARATOR);

    public static final String SUB_CLASS_SEPARATOR          = intern("$");


    private static final char[] FILE_SEPARATOR              = intern(Filex.separator_all());



    private static final char   lineSeparatorChar  = intern(           Re_CodeSymbol.CODE_LINE_SEPARATOR_CHAR);
    private static final char[] lineSeparatorChars = intern(new char[]{Re_CodeSymbol.CODE_LINE_SEPARATOR_CHAR} );

    static final char[][] separate = new CharCodeReader() {{
        this.addSeparatorsAndSort(
                " ".toCharArray(),

                Re_CodeSymbol.CODE_NOTE_START.toCharArray(),                    // //
                Re_CodeSymbol.CODE_SEMICOLON_SEPARATOR.toCharArray(),           // ;

                Re_CodeSymbol.CODE_OBJECT_POINT_SYMBOL.toCharArray(),           // .

                Re_CodeSymbol.CODE_VARIABLE_ASSIGNMENT_SYMBOL.toCharArray(),    // =


                Re_CodeSymbol.CODE_CALL_PARAM_JOIN_SYMBOL.toCharArray(),            // (
                Re_CodeSymbol.CODE_CALL_PARAM_SEPARATOR.toCharArray(),              // ,
                Re_CodeSymbol.CODE_CALL_PARAM_END_SYMBOL.toCharArray(),             // )


                //_object
                Re_CodeSymbol.CODE_MAP_JOIN_SYMBOL.toCharArray(),              // {
                Re_CodeSymbol.CODE_MAP_END_SYMBOL.toCharArray(),               // }
                //_list
                Re_CodeSymbol.CODE_LIST_JOIN_SYMBOL.toCharArray(),              // [
                Re_CodeSymbol.CODE_LIST_END_SYMBOL.toCharArray(),               // ]


                Re_CodeSymbol.CODE_STRING_START.toCharArray(),                 // "
                Re_CodeSymbol.CODE_CHAR_START.toCharArray(),                   // '
                Re_CodeSymbol.CODE_STRING2_START.toCharArray(),                // ''  [two ']


                lineSeparatorChars                                             // \n
        );
        this.addSeparatorsAndSort(
            Re_CodeSymbol.getAutomaticConversionOperator()                     //+ - * / ...
        );
        //__println("symbol: " + Arrays.deepToString(getSeparators()) + ", size=" + separate.length);
    }}.getSeparators();






    public static final char CONST_LONG_PREFIX      = intern('L');
    public static final char CONST_FLOAT_PREFIX     = intern('F');
    public static final char CONST_DOUBLE_PREFIX    = intern('D');

    public static final char CONST_SHORT_PREFIX     = intern('S');
    public static final char CONST_BYTE_PREFIX      = intern('B');
    public static final char CONST_CHAR_PREFIX      = intern('C');





    public static boolean codeIsVar(Base object) {
        return object instanceof Var;
    }
    /**
     * =
     */
    public static boolean codeIsAssignment(Base object) {
        return object instanceof Assignment;
    }
    /**
     * ()
     */
    public static boolean codeIsCall(Base object) {
        return object instanceof Call;
    }
    /**
     * .
     */
    public static boolean codeIsPoint(Base object) {
        return object instanceof Point;
    }



    //-------------------------------------------------

    /**
     * 运算符
     * 在运行时不会出现
     */
    public static boolean codeIsCTSymbol(Base object) {
        return object instanceof CTSymbol;
    }

    /**
     * ;
     * 在运行时不会出现
     */
    public static boolean codeIsCTSemicolon(Base object) {
        return object instanceof CTSemicolon;
    }

    /**
     * (Expression)
     */
    public static boolean codeIsCTExpression(Base object) {
        return object instanceof CTExpression;
    }




    //-------------------------------------------------

    /**
     * @param object code
     * @return {@link #codeIsAssignment(Base)} ||
     *         {@link #codeIsCTSymbol(Base)}}  ||
     *         {@link #codeIsCTSemicolon(Base)};
     */
    public static boolean codeIsDiscon(Base object) {
        return  codeIsAssignment(object) ||
                codeIsCTSymbol(object) ||
                codeIsCTSemicolon(object);
    }

    /**
     *
     * @param object code
     * @return {@link #codeIsAssignment(Base)} ||
     *         {@link #codeIsCTSymbol(Base)}}  ||
     *         {@link #codeIsCTSemicolon(Base)} ? null : object;
     */
    public static <C extends Base> C notDiscon(C object) {
        return  codeIsAssignment(object) ||
                codeIsCTSymbol(object) ||
                codeIsCTSemicolon(object) ? null :object;
    }















    /**
     * 运算符
     */
    public static boolean isSymbolDeclare(String name) {
        return Re_CodeSymbol.isAutomaticConversionOperatorSymbol(name);
    }
    /**
     * 是否是注释 [//]
     */
    public static boolean isNotesDeclare(String str) {
        return Re_CodeSymbol.CODE_NOTE_START.equals(str);
    }
    /**
     * "
     */
    public static boolean isStringDeclare(String str) {
        return Re_CodeSymbol.CODE_STRING_START.equals(str);
    }
    /**
     * '
     */
    public static boolean isCharDeclare(String str) {
        return Re_CodeSymbol.CODE_CHAR_START.equals(str);
    }
    /**
     * ''
     */
    public static boolean isString2Declare(String str) {
        return Re_CodeSymbol.CODE_STRING2_START.equals(str);
    }


    /**
     * ^([0-9]+)
     */
    public static boolean isDigitDeclareStartWith(String str) {
        char   ch;
        return(ch = str.charAt(0)) >= '0' && ch <= '9';
    }


    /**
     * 运行时 不会存在这个类型的數據
     */
    public static class Base {
        public static final CTExpression[]  EMPTY_EXPRESSION = {};
        public static final Base[]          EMPTY_BASE = {};

        static final int CLASS_HASH = Base.class.hashCode();
        @Override
        public int hashCode() {
            return CLASS_HASH * (name == null ? 0 : name.hashCode());
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Base base = (Base) o;
            return  Objects.equals(name, base.name);
        }




        @SuppressWarnings("rawtypes")
        Re_Variable staticValue;//修改名称一定要更新 value
        String      name;       //修改名称一定要更新 value
        int         line;

        public String getName() {
            return this.name;
        }
        Base setName(String name) {
            this.name = name;
            return this;
        }
        public boolean equalsName(String name) {
            return this.name.equals(name);
        }


        public int getLine() {
            return this.line;
        }
        Base setLine(int line) {
            this.line = line;
            return this;
        }


        public static String getExpressionAsString(CTExpression expression) {
            List<Base> list = expression.getInnerListOrBuildCodeCacheAsList();
            return getExpressionAsString(list, 0, list.size());
        }
        public static String getExpressionAsString(List<Base> baseList) {
            return getExpressionAsString(baseList, 0, baseList.size());
        }
        public static String getExpressionAsString(List<Base> baseList, int startIndex, int len) {
            if (startIndex + len > baseList.size())
                return "";

            StringBuilder stringBuilder = new StringBuilder();
            Base prev = null;
            for (int i = 0; i < len; i++) {
                Base base = baseList.get(i);
                if (null != base) {
                    if (codeIsVar(base) && codeIsVar(prev))
                        stringBuilder.append(' ');

                    stringBuilder.append(base);

                    prev = base;
                }
            }

            return stringBuilder.toString();
        }



        @Override
        public String toString() {
            return name;
        }
    }



    /**
     * 运行时 会存在这个类型的code
     * 变量名
     */
    public static class Var extends Base {
        static final int CLASS_HASH = Var.class.hashCode();
        @Override
        public int hashCode() {
            return CLASS_HASH * (name == null ? 0 : name.hashCode());
        }
    }

    /**
     * 运行时 会存在这个类型的code
     * 等号
     */
    public static class Assignment extends Base {
        static final int CLASS_HASH = Assignment.class.hashCode();
        @Override
        public int hashCode() {
            return CLASS_HASH * (name == null ? 0 : name.hashCode());
        }


        public Assignment() {
            super.name = Re_CodeSymbol.CODE_VARIABLE_ASSIGNMENT_SYMBOL;//=
        }

        public static Assignment createAssignment(int len) {
            Assignment assignment = new Assignment();
            assignment.setLine(len);
            return assignment;
        }

        @Override
        public String toString() {
            return super.name;
        }
    }

    /**
     * 运行时 会存在这个类型的code
     * 点
     */
    public static class Point extends Base {
        static final int CLASS_HASH = Point.class.hashCode();
        @Override
        public int hashCode() {
            return CLASS_HASH * (name == null ? 0 : name.hashCode());
        }


        public Point() {
            super.name = Re_CodeSymbol.CODE_OBJECT_POINT_SYMBOL;
        }
        //.

        public static Point createPoint(int len) {
            Point Point = new Point();
            Point.setLine(len);
            return Point;
        }

        @Override
        public String toString() {
            return super.name;
        }
    }



    /**
     * 运行时 会存在这个类型的code
     * ()
     * 函数
     */
    @SuppressWarnings({"UnusedReturnValue"})
    public static class Call extends Base {
        static final int CLASS_HASH = Call.class.hashCode();
        @Override
        public int hashCode() {
            return CLASS_HASH * (name == null ? 0 : name.hashCode());
        }


        ArrList<CTExpression> tempInnerParamList = new ArrList<>(CTExpression.EMPTY_EXPRESSION);
        int tempInnerParamCount = 0;




        void addToParamInnerTempListLast(CTExpression newTop) {
            this.tempInnerParamList.add(newTop);
            this.tempInnerParamCount++;
        }
        void removeParamInnerTempListElement(CTExpression element) {
            for (int i = tempInnerParamCount - 1; i > 0; i--) {
                Base base = tempInnerParamList.get(i);
                if  (base.equals(element)) {
                    tempInnerParamList.remove(i);
                    tempInnerParamCount--;
                    return;
                }
            }
        }



//-------------------------------------------------------
        //将列表转换为数组， 如果在这之后列表还被添加删除 数组将不会有变动， 速度更快 也便于使用

        public int getParamExpressionCount() {
            return tempInnerParamCount;
        }


        public boolean isEmptyNameCall() {
            return null == super.name || super.name.length() == 0;
        }



        CTExpression[] cache0;
        /**
         * 不要修改
         */
        CTExpression[] getBuildParamExpressionCaches() {
            if (null != cache0) {
                return  cache0;
            }
            cache0 = tempInnerParamList.toArray(CTExpression.EMPTY_EXPRESSION);
            tempInnerParamList = null;
            return cache0;
        }
        CTExpression getBuildParamExpressionCache(int index) {
            if (null != cache0) {
                return  cache0[index];
            }
            cache0 = tempInnerParamList.toArray(CTExpression.EMPTY_EXPRESSION);
            tempInnerParamList = null;
            return cache0[index];
        }


        /**
         * @return 可能会生成一个新的列表
         */
        List<CTExpression> getParamInnerTempListOrBuildParamExpressionCachesAsList() {
            return null == tempInnerParamList ?Arrays.asList(cache0) : tempInnerParamList;
        }
        @Override
        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(null == name?"":name);
            stringBuilder.append(Re_CodeSymbol.CODE_CALL_PARAM_JOIN_SYMBOL);

            StringJoiner stringJoiner = new StringJoiner(Re_CodeSymbol.CODE_CALL_PARAM_SEPARATOR +' ');
            for (Base e: getParamInnerTempListOrBuildParamExpressionCachesAsList()) {
                if (null != e) {
                    stringJoiner.add(e.toString());
                }
            }
            stringBuilder.append(stringJoiner);
            stringBuilder.append(Re_CodeSymbol.CODE_CALL_PARAM_END_SYMBOL);
            return stringBuilder.toString();
        }





        public static class CallCreateDict  extends Call {
            static final int CLASS_HASH = CallCreateDict.class.hashCode();
            @Override
            public int hashCode() {
                return CLASS_HASH * (name == null ? 0 : name.hashCode());
            }

            @Override
            public String toString() {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(Re_CodeSymbol.CODE_MAP_JOIN_SYMBOL);

                StringJoiner stringJoiner = new StringJoiner(Re_CodeSymbol.CODE_CALL_PARAM_SEPARATOR + ' ');
                for (Base e: getParamInnerTempListOrBuildParamExpressionCachesAsList()) {
                    if (null != e) {
                        stringJoiner.add(e.toString());
                    }
                }
                stringBuilder.append(stringJoiner);
                stringBuilder.append(Re_CodeSymbol.CODE_MAP_END_SYMBOL);
                return stringBuilder.toString();
            }
        }
        public static boolean codeIsCallCreateDict(Base call) {
            return call instanceof CallCreateDict;
        }

        public static class CallCreateList  extends Call {
            static final int CLASS_HASH = CallCreateList.class.hashCode();
            @Override
            public int hashCode() {
                return CLASS_HASH * (name == null ? 0 : name.hashCode());
            }

            @Override
            public String toString() {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(Re_CodeSymbol.CODE_LIST_JOIN_SYMBOL);

                StringJoiner stringJoiner = new StringJoiner(Re_CodeSymbol.CODE_CALL_PARAM_SEPARATOR + ' ');
                for (Base e: getParamInnerTempListOrBuildParamExpressionCachesAsList()) {
                    if (null != e) {
                        stringJoiner.add(e.toString());
                    }
                }
                stringBuilder.append(stringJoiner);
                stringBuilder.append(Re_CodeSymbol.CODE_LIST_END_SYMBOL);
                return stringBuilder.toString();
            }
        }
        public static boolean codeIsCallCreateList(Base call) {
            return call instanceof CallCreateList;
        }

        public static class CallSymbol      extends Call {
            static final int CLASS_HASH = CallSymbol.class.hashCode();
            @Override
            public int hashCode() {
                return CLASS_HASH * (name == null ? 0 : name.hashCode());
            }

            @Override
            public String toString() {
                List<CTExpression> tempInnerParamList1 = super.getParamInnerTempListOrBuildParamExpressionCachesAsList();
                int size1 = tempInnerParamList1.size();
                if (size1 < 1)
                    return super.toString(); //-()  ?
                if (size1 == 1)
                    return super.toString(); //-(1) ?

                StringJoiner stringJoiner = new StringJoiner(super.getName());
                for (CTExpression ctExpression : tempInnerParamList1) {
                    stringJoiner.add(ctExpression.toString());
                }
                return stringJoiner.toString();
            }
        }
        public static boolean codeIsCallSymbol(Base call) {
            return call instanceof CallSymbol;
        }
    }


    /**
     * 运算符
     */
    public static class CTSymbol extends Base {
        static final int CLASS_HASH = CTSymbol.class.hashCode();
        @Override
        public int hashCode() {
            return CLASS_HASH * (name == null ? 0 : name.hashCode());
        }


        public CTSymbol(String name) {
            super.name = name;
        }

        @Override
        public String toString() {
            return super.name;
        }
    }


    /**
     * 分号
     */
    public static class CTSemicolon extends Base {
        static final int CLASS_HASH = CTSemicolon.class.hashCode();
        @Override
        public int hashCode() {
            return CLASS_HASH * (name == null ? 0 : name.hashCode());
        }


        public CTSemicolon() {
            super.name = Re_CodeSymbol.CODE_SEMICOLON_SEPARATOR;//;
        }

        @Override
        public String toString() {
            return super.name;
        }
    }

    /**
     * (Expression, Expression, ...)
     * </br>
     * Expression1; Expression2;
     */
    @SuppressWarnings({"FieldMayBeFinal", "UnusedReturnValue"})
    public static class CTExpression extends Base {
        static final int CLASS_HASH = CTExpression.class.hashCode();
        @Override
        public int hashCode() {
            return CLASS_HASH * (name == null ? 0 : name.hashCode());
        }


        ArrList<Base> tempInnerBaseList = new ArrList<>(CTExpression.EMPTY_BASE);

        void addToInnerTempListLast(Base newTop) {
            this.tempInnerBaseList.add(newTop);
        }
        Base getInnerTempListFirst() {
            return tempInnerBaseList.getOrNull(0);
        }
        Base getInnerTempListLast() {
            int size = tempInnerBaseList.size();
            return tempInnerBaseList.getOrNull(size - 1);
        }
        Base getInnerTempListElement(int index) {
            return tempInnerBaseList.getOrNull(index);
        }


        int getInnerTempListSize() {
            return tempInnerBaseList.size();
        }

        ArrList<Base> getInnerTempList() {
            return this.tempInnerBaseList;
        }
        void removeInnerTempListCode(Base element) {
            if (null == element) {
                return;
            }
            for (int i = getInnerTempListSize() - 1; i >= 0; i--) {
                Base base = tempInnerBaseList.get(i);
                if (element == base) {
                    tempInnerBaseList.remove(i);
                    return;
                }
            }
            throw new Re_Exceptions.CompileTimeGrammaticalException("not fount: " + element);
        }


        @Override
        CTExpression setLine(int line) {
            super.line = line;
            return this;
        }
        void setLineFromFirstElement() {
            int siz = tempInnerBaseList.size();
            if (siz == 0)
                return;
            //noinspection ForLoopReplaceableByForEach
            for (int i = 0; i < siz; i++) {
                Base base_;
                if ((base_ = tempInnerBaseList.get(i)).line > 0) {
                    super.line = base_.line;
                    break;
                }
            }
        }




//-------------------------------------------------------
        //将列表转换为数组， 如果在这之后列表还被添加删除 数组将不会有变动



        Base[] cache0;
        Base[] getBuildCodeCache() {
            if (null != cache0) {
                return  cache0;
            }
            cache0 = tempInnerBaseList.toArray(CTExpression.EMPTY_BASE);
            tempInnerBaseList = null;
            return cache0;
        }




        /**
         * @return 可能会生成一个新的列表
         */
        List<Base> getInnerListOrBuildCodeCacheAsList() {
            return null == tempInnerBaseList ?Arrays.asList(cache0) : tempInnerBaseList;
        }

        @Override
        public String toString() {
            return Base.getExpressionAsString(this);
        }
    }














    /*
     * 读取string 的思路是 在load前 处理字符串 将所有字符串替换为 变量名，
     * 执行时将从 常量管理器中获取常量
     */
    public Re_CodeFile load(String expression,
                            String filePath, int lineOffset) throws Re_Exceptions.CompileTimeGrammaticalException  {
        {
            Re_CodeFile block = new Re_CodeFile();
            block.filePath = filePath;
            block.lineOffset = lineOffset;

            //行 跟踪器
            LineTracker lineTracker = new LineTracker();
            lineTracker.line        = lineOffset;

            //代码读取器
            CharCodeReader reader = new CharCodeReader();
            char[] chars = expression.toCharArray();
            reader.buffer(chars, chars.length);
            reader.setSeparators(separate);

            CompileTimeCodeSourceReader compileTimeCodeSourceReader = new CompileTimeCodeSourceReader(block, lineTracker, reader);
            CTExpression[] expressions = compileTimeCodeSourceReader.readAllExpression();
            block.setExpressions(expressions);

            //System.out.println(TabPrint.wrap(block.getExpressions()));

            return block;
        }
    }





    static Var loadConst0(Re_CodeFile block, CTExpression ctExpression, LineTracker lineTracker, CharCodeReader lineCharCodeReader, int str_prev_index) throws Re_Exceptions.CompileTimeGrammaticalException {
        String prefix = "";
        Var result;
        int stLine       = lineTracker.getLine();
        int elementCount = ctExpression.getInnerTempListSize();

        //获取前缀符号
        Base prev_element = ctExpression.getInnerTempListElement(elementCount - 1); //倒数第一个
        if (codeIsCTSymbol(prev_element)) {
            if (prev_element.equalsName("+") || prev_element.equalsName("-")) {
                prefix = prev_element.getName();
            }
            if (null == notDiscon(ctExpression.getInnerTempListElement(elementCount - 2))) {//倒数第二个
                if (prefix.isEmpty()) {
                    throw new Re_Exceptions.CompileTimeGrammaticalException(Base.getExpressionAsString(ctExpression),
                            block.getFilePath(), lineTracker.getLine());
                }
                ctExpression.removeInnerTempListCode(prev_element);//删除最后一个符号
            } else {
                prefix = "";
            }
        }

        char[] buffer = lineCharCodeReader.buffer();
        int count     = lineCharCodeReader.size();
        int end = str_prev_index + 1;
        boolean haspoint = false;
        for (; end < count; end++) {
            char ch = buffer[end];
            if (!(ch >= '0' && ch <= '9')) {
                if (ch == '.') {
                    haspoint = true;
                } else {
                    break;
                }
            }
        }

        //(1, 2L, 4f, 65535c,5.5d, 6s, 7b, true, false, null, ‘3’, "")
        char type = end < count ? Character.toUpperCase(buffer[end]) : '\0';
        String content = prefix + new String(lineCharCodeReader.buffer(), str_prev_index, end - str_prev_index);

        //__println("prev_index=" + prev_index + ", " + "end=" + end);
        //__println("content=" + content);
        //__println("type=" + type);



        boolean next = true;
        if (type == CONST_LONG_PREFIX)          result = block.createConst(ctExpression, stLine, Long.parseLong(content));
        else if (type == CONST_FLOAT_PREFIX)    result = block.createConst(ctExpression, stLine, Float.parseFloat(content));
        else if (type == CONST_DOUBLE_PREFIX)   result = block.createConst(ctExpression, stLine, Double.parseDouble(content));

        else if (type == CONST_SHORT_PREFIX)    result = block.createConst(ctExpression, stLine, Short.parseShort(content));
        else if (type == CONST_BYTE_PREFIX)     result = block.createConst(ctExpression, stLine, Byte.parseByte(content));
        else if (type == CONST_CHAR_PREFIX)     result = block.createConst(ctExpression, stLine, (char)Integer.parseInt(content));
        else {
            //未知的下一个字符类型 直接跳过这个不跳过这个字符
            if (haspoint) {
                result = block.createConst(ctExpression, stLine, Double.parseDouble(content)); //double
            } else {
                long javavalue = Long.parseLong(content);
                if ((int)javavalue == javavalue) {
                    result = block.createConst(ctExpression, stLine, (int)javavalue);   //integer
                } else {
                    result = block.createConst(ctExpression, stLine, javavalue);        //long
                }
            }
            next = false;
        }
        int index = end + (next ? 1 : 0);

        //__println("seek: " + index);
        lineCharCodeReader.seekIndex(index);

        return result;
    }


    static Var loadString00(Re_CodeFile block, CTExpression ctExpression, LineTracker lineTracker, CharCodeReader lineCharCodeReader, int str_prev_index) throws Re_Exceptions.CompileTimeGrammaticalException {
        char symbol   = Re_CodeSymbol.CODE_STRING_START_CHAR;
        char[] buffer = lineCharCodeReader.buffer();
        int count     = lineCharCodeReader.size();
        int stLine    = lineTracker.getLine();

        CharArrayWriters out = new CharArrayWriters(0);
        CharArrayWriters unicode = new CharArrayWriters(4);
        boolean hadSlash = false;
        boolean inUnicode = false;
        int end = str_prev_index + 1;
        for (; end < count; end++) {
            char ch = buffer[end];
            if (ch == lineSeparatorChar) {
                lineTracker.nextLine();
            }
            if (inUnicode) {
                // if in unicode, then we're reading unicode
                // values in somehow
                unicode.append(ch);
                if (unicode.size() == 4) {
                    // unicode now contains the four hex digits
                    // which represents our unicode character
                    try {
                        int value = Integer.parseInt(unicode.toString(), 16);
                        out.write((char) value);
                        unicode.buffer_length(0);
                        inUnicode = false;
                        hadSlash = false;
                    } catch (NumberFormatException nfe) {
                        throw new Re_Exceptions.CompileTimeGrammaticalException("[line:"+stLine+"-"+lineTracker.getLine()+"]"+" " +"Unable to parse unicode value: " + unicode +": "+ (String.valueOf(symbol) + new String(buffer, str_prev_index, end-str_prev_index) + String.valueOf(symbol))
                                , block.getFilePath(), stLine, nfe);
                    }
                }
                continue;
            }
            if (hadSlash) {
                // handle an escaped value
                hadSlash = false;
                switch (ch) {
                    case '\\':
                        out.write('\\');
                        break;
                    case '\'':
                        out.write('\'');
                        break;
                    case '\"':
                        out.write('"');
                        break;
                    case 'r':
                        out.write('\r');
                        break;
                    case 'f':
                        out.write('\f');
                        break;
                    case 't':
                        out.write('\t');
                        break;
                    case 'n':
                        out.write('\n');
                        break;
                    case 'b':
                        out.write('\b');
                        break;
                    case 'u': {
                        // uh-oh, we're in unicode country....
                        inUnicode = true;
                        break;
                    }
                    default:
                        out.write(ch);
                        break;
                }
                continue;
            } else if (ch == '\\') {
                hadSlash = true;
                continue;
            }
            if (ch == symbol) {
                // String element
                String element = out.toString();
                // //__println("@" + element + "@" + joinStringLineCount + "@");
                // //__println("------");
                end++;
                lineCharCodeReader.seekIndex(end);

                Var aConst = block.createConst(ctExpression, stLine, element);
                return aConst;
            } else {
                out.write(ch);
            }
        }
        throw new Re_Exceptions.CompileTimeGrammaticalException("[line:"+stLine+"-"+lineTracker.getLine()+"]"+" " +"error string declaration"+ ": "+ (String.valueOf(symbol) + new String(buffer, str_prev_index, end-str_prev_index) + String.valueOf(symbol)),
                block.getFilePath(), stLine);
    }

    static Var loadChar00(Re_CodeFile block, CTExpression ctExpression, LineTracker lineTracker, CharCodeReader lineCharCodeReader, int str_prev_index) throws Re_Exceptions.CompileTimeGrammaticalException {
        char symbol = Re_CodeSymbol.CODE_CHAR_START_CHAR;
        char[] buffer = lineCharCodeReader.buffer();
        int count     = lineCharCodeReader.size();
        int stLine    = lineTracker.getLine();

        CharArrayWriters out = new CharArrayWriters(0);
        CharArrayWriters unicode = new CharArrayWriters(4);
        boolean hadSlash = false;
        boolean inUnicode = false;
        int end = str_prev_index + 1;
        for (; end < count; end++) {
            char ch = buffer[end];
            if (ch == lineSeparatorChar) {
                lineTracker.nextLine();
            }
            if (inUnicode) {
                // if in unicode, then we're reading unicode
                // values in somehow
                unicode.append(ch);
                if (unicode.size() == 4) {
                    // unicode now contains the four hex digits
                    // which represents our unicode character
                    try {
                        int value = Integer.parseInt(unicode.toString(), 16);
                        out.write((char) value);
                        unicode.buffer_length(0);
                        inUnicode = false;
                        hadSlash = false;
                    } catch (NumberFormatException nfe) {
                        throw new Re_Exceptions.CompileTimeGrammaticalException("[line:"+stLine+"-"+lineTracker.getLine()+"]"+" "+ "Unable to parse unicode value: [" + unicode +"] "+ (String.valueOf(symbol) + new String(buffer, str_prev_index, end-str_prev_index) + String.valueOf(symbol)),
                                block.getFilePath(), stLine, nfe);
                    }
                }
                continue;
            }
            if (hadSlash) {
                // handle an escaped value
                hadSlash = false;
                switch (ch) {
                    case '\\':
                        out.write('\\');
                        break;
                    case '\'':
                        out.write('\'');
                        break;
                    case '\"':
                        out.write('"');
                        break;
                    case 'r':
                        out.write('\r');
                        break;
                    case 'f':
                        out.write('\f');
                        break;
                    case 't':
                        out.write('\t');
                        break;
                    case 'n':
                        out.write('\n');
                        break;
                    case 'b':
                        out.write('\b');
                        break;
                    case 'u': {
                        // uh-oh, we're in unicode country....
                        inUnicode = true;
                        break;
                    }
                    default:
                        out.write(ch);
                        break;
                }
                continue;
            } else if (ch == '\\') {
                hadSlash = true;
                continue;
            }
            if (ch == symbol) {
                // String contnet
                String contnet = out.toString();
                if (contnet.length() != 1) {
                    throw new Re_Exceptions.CompileTimeGrammaticalException("[line:"+stLine+"-"+lineTracker.getLine()+"]"+" " +"error char declaration"+ ": "+ (String.valueOf(symbol) + new String(buffer, str_prev_index, end-str_prev_index) + String.valueOf(symbol)),
                            block.getFilePath(), stLine);
                }
                // //__println("@" + contnet + "@" + joinStringLineCount + "@");
                // //__println("------");
                end++;
                lineCharCodeReader.seekIndex(end);

                char c1 = contnet.charAt(0);
                Var aConst = block.createConst(ctExpression, stLine, c1);
                return aConst;
            } else {
                out.write(ch);
            }
        }
        throw new Re_Exceptions.CompileTimeGrammaticalException("[line:"+stLine+"-"+lineTracker.getLine()+"]"+" " +"error string declaration"+ ": "+ (String.valueOf(symbol) + new String(buffer, str_prev_index, end-str_prev_index) + Strings.cast(symbol)),
                block.getFilePath(), stLine);
    }
    // ''
    static Var loadString20(Re_CodeFile block, CTExpression ctExpression, LineTracker lineTracker, CharCodeReader lineCharCodeReader, int str_prev_index) throws Re_Exceptions.CompileTimeGrammaticalException {
        char[] symbol = Re_CodeSymbol.CODE_STRING2_START_CHARS;
        char[] buffer = lineCharCodeReader.buffer();
        int count     = lineCharCodeReader.size();
        int stLine    = lineTracker.getLine();

        CharArrayWriters out = new CharArrayWriters(0);
        CharArrayWriters unicode = new CharArrayWriters(4);
        boolean hadSlash = false;
        boolean inUnicode = false;
        int end = str_prev_index + symbol.length;
        for (; end < count; end++) {
            char ch = buffer[end];
            if  (ch == lineSeparatorChar) {
                lineTracker.nextLine();
            }
            if (inUnicode) {
                // if in unicode, then we're reading unicode
                // values in somehow
                unicode.append(ch);
                if (unicode.size() == 4) {
                    // unicode now contains the four hex digits
                    // which represents our unicode character
                    try {
                        int value = Integer.parseInt(unicode.toString(), 16);
                        out.write((char) value);
                        unicode.buffer_length(0);
                        inUnicode = false;
                        hadSlash = false;
                    } catch (NumberFormatException nfe) {
                        throw new Re_Exceptions.CompileTimeGrammaticalException("[line:"+stLine+"-"+lineTracker.getLine()+"]"+" "+ "Unable to parse unicode value: [" + unicode +"] "+ new String(buffer, str_prev_index, end - str_prev_index),
                                block.getFilePath(), stLine, nfe);
                    }
                }
                continue;
            }
            if (hadSlash) {
                // handle an escaped value
                hadSlash = false;
                switch (ch) {
                    case '\\':
                        out.write('\\');
                        break;
                    case '\'':
                        out.write('\'');
                        break;
                    case '\"':
                        out.write('"');
                        break;
                    case 'r':
                        out.write('\r');
                        break;
                    case 'f':
                        out.write('\f');
                        break;
                    case 't':
                        out.write('\t');
                        break;
                    case 'n':
                        out.write('\n');
                        break;
                    case 'b':
                        out.write('\b');
                        break;
                    case 'u': {
                        // uh-oh, we're in unicode country....
                        inUnicode = true;
                        break;
                    }
                    default:
                        out.write(ch);
                        break;
                }
                continue;
            } else if (ch == '\\') {
                hadSlash = true;
                continue;
            }
            if (ch == symbol[0] && (buffer[end+1] == symbol[1])) {
                // String element
                String element = out.toString();
                // //__println("@" + element + "@" + joinStringLineCount + "@");
                // //__println("------");
                end += symbol.length;
                lineCharCodeReader.seekIndex(end);

                Var aConst = block.createConst(ctExpression, stLine, element);
                return aConst;
            } else {
                out.write(ch);
            }
        }
        throw new Re_Exceptions.CompileTimeGrammaticalException("[line:"+stLine+"-"+lineTracker.getLine()+"]"+" "+ "unable to parse string2 value: [" + out +"] "+ new String(buffer, str_prev_index, end - str_prev_index),
                block.getFilePath(), stLine);
    }

    static void skipNote0(Re_CodeFile block, CTExpression ctExpression, LineTracker lineTracker, CharCodeReader lineCharCodeReader, int str_prev_index) throws Re_Exceptions.CompileTimeGrammaticalException {
        char[] buffer = lineCharCodeReader.buffer();
        int count = lineCharCodeReader.size();
        int end = count;
        for (int i = str_prev_index; i < count; i++) {
            char c1 = buffer[i];
            if (c1 == lineSeparatorChar) {
                end = i;
                break;
            }
        }
        lineCharCodeReader.seekIndex(end);
    }











    //自动符号转方法
    static void convertExpressionSymbolAsCallSymbol0(Re_CodeFile block, CompileTimeCodeListEditor reader) throws Re_Exceptions.CompileTimeGrammaticalException {
        //算数表达式转方法 1+1 >> +(1, 1)
        //println(reader.size());
        for (Base current; reader.hasNext();) {
            //将符号转为function  比如 6 +7 转换为 +(6,7)
            if (null != (current = reader.next())) {
                if (codeIsCTSymbol(current)) {
                    convertExpressionSymbolAsCallSymbol1(block, reader, (CTSymbol) current);
                }
            }
        }
        //__println(Expression.formatCodeFromRoot(that, 0, that.size()));
    }

    /**
     *
     * @param block         代码块
     * @param reader        读取器
     * @param currentCode   元素指针必须等于 {@link  CompileTimeCodeListEditor#index()}
     * @throws Re_Exceptions.CompileTimeGrammaticalException 表达式异常
     */
    static Call.CallSymbol convertExpressionSymbolAsCallSymbol1(Re_CodeFile block, CompileTimeCodeListEditor reader, CTSymbol currentCode) throws Re_Exceptions.CompileTimeGrammaticalException {
//        __println("*index=" + reader.index() + ", var=" + currentCode.getName() + ", type=" + currentCode.getClass());
        ArrList<Base> that = reader.list;

        int current = reader.index();
//        __println("*current: " + reader.now()); //
        int prev = reader.findSymbolPrevOverallStartIndex(current);
        int end  = reader.findSymbolNextOverallEndIndex(current);
//        __println("*find_prev_overall_offset: " + prev);
//        __println("*find_next_overall_offset: " + end);
        if (prev == -1 || end == -1) {
            int st = prev == -1 ? current : prev;
            int len = end == -1 ? current - prev : end - prev;

            throw new Re_Exceptions.CompileTimeGrammaticalException("[" + CTExpression.getExpressionAsString(that, st, len + 1) + "]" + "["+((prev == -1 ? "no-prev-element":"") + " " + (end == -1 ? "no-next-element":"")).trim()+"]",
                    block.getFilePath(), currentCode.getLine());
        }
        String name = currentCode.getName();

        Call.CallSymbol call = new Call.CallSymbol();
        call.setName(name);
        call.setLine(currentCode.getLine());
        call.staticValue = Re_Variable.Unsafe.findVariable(name, Re_Keywords.keyword);//将关键字值直接加入代码 以后将不在获取keyword

        CTExpression prev_expression = new CTExpression();
        prev_expression.setLine(currentCode.getLine());
        for (int i = prev; i < current; i++) {
            Base s = that.get(i);
            if (null != s) {
//                __println("prev: " + s.getName());
                that.set(i, null);
                prev_expression.addToInnerTempListLast(s);
            }
        }
        call.addToParamInnerTempListLast(prev_expression);

//        __println("symbol: " + currentCode.getName());
        that.set(current, null);

        CTExpression next_expression = new CTExpression();
        next_expression.setLine(currentCode.getLine());
        for (int i = current + 1; i <= end; i++) {
            Base s = that.get(i);
            if (null != s) {
//                __println("next: " + s.getName());
                that.set(i, null);
                next_expression.addToInnerTempListLast(s);
            }
        }
        call.addToParamInnerTempListLast(next_expression);

//        __println(TabPrint.wrap(that.toArray()));
        that.set(end, call);
//        __println(TabPrint.wrap(that.toArray()));
//        __println(Code.getExpressionAsString(block, that));
//        __println("----");
        return call;
    }














    static boolean log = true;
    public static void __println(Object content) {
        if (log)
            System.out.println(content);
    }











    @SuppressWarnings("StatementWithEmptyBody")
    public static class CompileTimeCodeSourceReader {
        Re_CodeFile block;
        LineTracker lineTracker;
        CharCodeReader reader;
        public CompileTimeCodeSourceReader(Re_CodeFile block, LineTracker lineTracker, CharCodeReader reader) {
            this.block = block;
            this.lineTracker = lineTracker;
            this.reader = reader;
        }




        static boolean isFlag(int ret) {
            return ret < 0;
        }



        static final int FLAG_EXIT_CALL = -1;
        static final int FLAG_EXIT_DICT = -2;
        static final int FLAG_EXIT_LIST = -3;

        static boolean isFlagExit(int ret) {
            return ret <= FLAG_EXIT_CALL && ret >= FLAG_EXIT_LIST;
        }

        static boolean isFlagExitCall(int ret) {
            return ret == FLAG_EXIT_CALL;
        }
        static boolean isFlagExitDict(int ret) {
            return ret == FLAG_EXIT_DICT;
        }
        static boolean isFlagExitList(int ret) {
            return ret == FLAG_EXIT_LIST;
        }


        static final int FLAG_SEMICOLON = -4;
        static final int FLAG_PARAM_SEPARATOR = -5;

        static boolean isFlagSemicolonOrParamSeparator(int ret) {
            return ret <= FLAG_SEMICOLON && ret >= FLAG_PARAM_SEPARATOR;
        }









        public CTExpression[] readAllExpression() throws Re_Exceptions.CompileTimeGrammaticalException {
            List<CTExpression> expressionList = new ArrayList<>();
            while (reader.hasNext()) {
                CTExpression expression;
                if (null == (expression = this.readExpression()))
                    continue;
                expressionList.add(expression);
            }
            return expressionList.toArray(CTExpression.EMPTY_EXPRESSION);
        }

        public CTExpression readExpression() throws Re_Exceptions.CompileTimeGrammaticalException {
            CTExpression expression = new CTExpression();
            while (reader.hasNext()) {
                int s = this.readNextSection(expression);
                if (isFlag(s)) {
                    if (isFlagSemicolonOrParamSeparator(s)) {
                        // semicolon
                        break;
                    } else {
                        throw new Re_Exceptions.CompileTimeGrammaticalException("[error-flag]",
                                block.getFilePath(), lineTracker.getLine());
                    }
                }
            }
            if (expression.getInnerTempListSize() == 0) {
                return null;
            } else {
                expression.setLineFromFirstElement();
            }
            return expression;
        }



        /**
         * 读取一个连续的表达式子 遇到 ; symbol = 会断开
         * 可以返回flag 获取读取的数量， 读取的数量不一定是准确的 也可以是0
         */
        public int readNextSection(CTExpression toExpression) throws Re_Exceptions.CompileTimeGrammaticalException {
            boolean hasSymbol = false;
            char[]  chars;
            String  var_name;
            int     flag = 0;

            for (;;) {
                int prev_index = reader.getIndex();
                if (null == (chars = reader.readNext())) {
                    break;
                } else {
                    if (Arrays.equals(chars, lineSeparatorChars)) {
                        lineTracker.nextLine();
                        continue;
                    }
                    if ((var_name = new String(chars).trim()).length() == 0) {
                        continue;
                    }
                    var_name = intern(var_name);
                }


                if (isStringDeclare(var_name)) {
                    Base c = loadString00(block, toExpression, lineTracker, reader, prev_index);
                    toExpression.addToInnerTempListLast(c);
                    flag++;
                    continue;
                }
                if (isCharDeclare(var_name)) {
                    Base c = loadChar00(block, toExpression, lineTracker, reader, prev_index);
                    toExpression.addToInnerTempListLast(c);
                    flag++;
                    continue;
                }
                if (isString2Declare(var_name)) {
                    Base c = loadString20(block, toExpression, lineTracker, reader, prev_index);
                    toExpression.addToInnerTempListLast(c);
                    flag++;
                    continue;
                }


                if (isNotesDeclare(var_name)) {
                    //跳过
                    skipNote0(block, toExpression, lineTracker, reader, prev_index);
                    continue;
                }
                if (isDigitDeclareStartWith(var_name)) {
                    Base c = loadConst0(block, toExpression, lineTracker, reader, prev_index);
                    toExpression.addToInnerTempListLast(c);
                    flag++;
                    continue;
                }
                if (isSymbolDeclare(var_name)) {    //symbol
                    Base c = new CTSymbol(var_name).setLine(lineTracker.getLine());
                    toExpression.addToInnerTempListLast(c);
                    hasSymbol = true;
                    continue;
                }

                if (var_name.equals(Re_CodeSymbol.CODE_VARIABLE_ASSIGNMENT_SYMBOL)) {//=
                    Assignment c = Assignment.createAssignment(lineTracker.getLine());
                    toExpression.addToInnerTempListLast(c);
                    flag++;
                    continue;
                } else if (var_name.equals(Re_CodeSymbol.CODE_OBJECT_POINT_SYMBOL)) {//.
                    Point c = Point.createPoint(lineTracker.getLine());
                    toExpression.addToInnerTempListLast(c);
                    flag++;
                    continue;
                } else if (var_name.equals(Re_CodeSymbol.CODE_CALL_PARAM_JOIN_SYMBOL)) {//(
                    Base lastContent = null == toExpression ? null : notDiscon(toExpression.getInnerTempListLast());//上个集合的最后一个

                    Call c = new Call();
                    c.setLine(lineTracker.getLine());
                    if (codeIsVar(lastContent)) {
                        c.name = lastContent.name;
                        toExpression.removeInnerTempListCode(lastContent); //***** 删除上一个var 并且现在的新元素将名称设置为方法名
                    } else {
                        if (null == lastContent || null == lastContent.name) {
                            //a = (b);
                            //(b);
                            c.name = "";
                        } else {
                            if (codeIsCall(lastContent)) {
                                //(true, false)()       > 第二个(
                                //field(true, false)()  > 第二个(
                                c.name = "";
                            } else {
                                throw new Re_Exceptions.CompileTimeGrammaticalException("[ " + lastContent + "(...) ]" ,
                                        block.getFilePath(), lineTracker.getLine());
                            }
                        }
                    }
                    c.staticValue = Re_Variable.Unsafe.findVariable(c.name, Re_Keywords.keyword);//将关键字值直接加入代码 以后将不在获取keyword

                    CTExpression exp = new CTExpression();
                    try {
                        while (reader.hasNext()) {
                            int s;
                            if (isFlag(s = readNextSection(exp))) {
                                if (isFlagExit(s)) {
                                    if (isFlagExitCall(s)) {
                                        break;
                                    } else {
                                        throw new Re_Exceptions.CompileTimeGrammaticalException("[ (...? ]",
                                                block.getFilePath(), lineTracker.getLine());
                                    }
                                } else if (isFlagSemicolonOrParamSeparator(s)) {
                                    //pass
                                }
                            }
                            if (exp.getInnerTempListSize() != 0) {
                                exp.setLineFromFirstElement();
                                c.addToParamInnerTempListLast(exp);

                                exp = new CTExpression();
                            }
                        }
                    } finally {
                        if (exp.getInnerTempListSize() != 0) {
                            exp.setLineFromFirstElement();
                            c.addToParamInnerTempListLast(exp);
                        }
                    }
                    toExpression.addToInnerTempListLast(c);
                    flag++;
                    continue;
                } else if (var_name.equals(Re_CodeSymbol.CODE_CALL_PARAM_END_SYMBOL)) {//)
                    flag = FLAG_EXIT_CALL;
                    break;
                } else if (var_name.equals(Re_CodeSymbol.CODE_MAP_JOIN_SYMBOL)) {//{
                    Call c = new Call.CallCreateDict();
                    c.name = Re_Keywords.INNER_CONVERT_FUNCTION__CREATE_OBJECT;
                    c.staticValue = Re_Variable.Unsafe.findVariable(c.name, Re_Keywords.keyword);;//将关键字值直接加入代码 以后将不在获取keyword
                    c.setLine(lineTracker.getLine());

                    CTExpression exp = new CTExpression();
                    try {
                        while (reader.hasNext()) {
                            int s;
                            if (isFlag(s = readNextSection(exp))) {
                                if (isFlagExit(s)) {
                                    if (isFlagExitDict(s)) {
                                        break;
                                    } else {
                                        throw new Re_Exceptions.CompileTimeGrammaticalException("[ {...? ]",
                                                block.getFilePath(), lineTracker.getLine());
                                    }
                                } else if (isFlagSemicolonOrParamSeparator(s)) {
                                    //pass
                                }
                            }
                            if (exp.getInnerTempListSize() != 0) {
                                exp.setLineFromFirstElement();
                                c.addToParamInnerTempListLast(exp);

                                exp = new CTExpression();
                            }
                        }
                    } finally {
                        if (exp.getInnerTempListSize() != 0) {
                            exp.setLineFromFirstElement();
                            c.addToParamInnerTempListLast(exp);
                        }
                    }
                    toExpression.addToInnerTempListLast(c);
                    flag++;
                    continue;
                } else if (var_name.equals(Re_CodeSymbol.CODE_MAP_END_SYMBOL)) {//}
                    flag = FLAG_EXIT_DICT;
                    break;
                } else if (var_name.equals(Re_CodeSymbol.CODE_LIST_JOIN_SYMBOL)) {//[
                    Call c = new Call.CallCreateList();
                    c.name = Re_Keywords.INNER_CONVERT_FUNCTION__CREATE_LIST; //_list();
                    c.staticValue = Re_Variable.Unsafe.findVariable(c.name, Re_Keywords.keyword);;//将关键字值直接加入代码 以后将不在获取keyword
                    c.setLine(lineTracker.getLine());

                    CTExpression exp = new CTExpression();
                    try {
                        while (reader.hasNext()) {
                            int s;
                            if (isFlag(s = readNextSection(exp))) {
                                if (isFlagExit(s)) {
                                    if (isFlagExitList(s)) {
                                        break;
                                    } else {
                                        throw new Re_Exceptions.CompileTimeGrammaticalException("[ [...? ]",
                                                block.getFilePath(), lineTracker.getLine());
                                    }
                                } else if (isFlagSemicolonOrParamSeparator(s)) {
                                    //pass
                                }
                            }
                            if (exp.getInnerTempListSize() != 0) {
                                exp.setLineFromFirstElement();
                                c.addToParamInnerTempListLast(exp);

                                exp = new CTExpression();
                            }
                        }
                    } finally {
                        if (exp.getInnerTempListSize() != 0) {
                            exp.setLineFromFirstElement();
                            c.addToParamInnerTempListLast(exp);
                        }
                    }

                    Base lastContent = null == toExpression ? null : notDiscon(toExpression.getInnerTempListLast());//上个集合的最后一个
                    if (codeIsVar(lastContent)) {
                        if (c.getParamExpressionCount() == 0) {
                            lastContent.name += (Re_CodeSymbol.CODE_LIST_JOIN_SYMBOL + Re_CodeSymbol.CODE_LIST_END_SYMBOL);
                            lastContent.staticValue = Re_Variable.Unsafe.findVariable(lastContent.name, Re_Keywords.keyword);
                            continue;
                        }
                    }

                    toExpression.addToInnerTempListLast(c);
                    flag++;
                    continue;
                } else if (var_name.equals(Re_CodeSymbol.CODE_LIST_END_SYMBOL)) {//]
                    flag = FLAG_EXIT_LIST;
                    break;
                } else if (var_name.equals(Re_CodeSymbol.CODE_SEMICOLON_SEPARATOR) )    {//;
                    flag = FLAG_SEMICOLON;
                    break;
                } else if (var_name.equals(Re_CodeSymbol.CODE_CALL_PARAM_SEPARATOR)) {//,
                    flag = FLAG_PARAM_SEPARATOR;
                    break;
                } else {
                    Base c = new Var();
                    c.name = var_name;
                    c.line = lineTracker.getLine();
                    c.staticValue = Re_Variable.Unsafe.findVariable(var_name, Re_Keywords.keyword);//将关键字值直接加入代码 以后将不在获取keyword
                    toExpression.addToInnerTempListLast(c);
                    flag++;
                    continue;
                }
                // println(var_name + "<" + cline.line + ">");
            }

            CompileTimeCodeListEditor reader = null;

            //Interceptors
            if (hasFilterInterceptor()) {
                reader = this.changeEditorAndResetIndex(block, toExpression);
                while (reader.hasNext()) {
                    Base current;
                    FilterInterceptor filterInterceptor;
                    if (null != (current = reader.next())) {
                        if (null != (filterInterceptor = getFilterInterceptor(current))) {
                            filterInterceptor.intercept(reader, current);
                        }
                    }
                }
            }

            //Convert Expression Symbol As SymbolCall
            if (hasSymbol) {
                reader = this.changeEditorAndResetIndex(block, toExpression);
                convertExpressionSymbolAsCallSymbol0(block, reader);
            }

            if (null != reader) {
                reader.removeNull();
            }


            return flag;
        }


        /**
         * 编译时运行
         * 转换符号，和过滤拦截器等
         * 一个读取器 只有一个实例
         * 不可同时进行编辑
         */
        protected CompileTimeCodeListEditor compileTimeCodeListEditor = new CompileTimeCodeListEditor();
        protected CompileTimeCodeListEditor changeEditorAndResetIndex(Re_CodeFile block, CTExpression expression) {
            compileTimeCodeListEditor.block = block;
            compileTimeCodeListEditor.list  = expression.getInnerTempList();
            compileTimeCodeListEditor.resetIndex();
            return compileTimeCodeListEditor;
        }



        @SuppressWarnings("UnnecessaryModifier")
        static protected interface FilterInterceptor {
            /**
             * 加入你需要删除元素可以直接setNull即可
             */
            public void intercept(CompileTimeCodeListEditor compileTimeCodeListEditor, Base now) throws Re_Exceptions.CompileTimeGrammaticalException;
        }
        static protected FilterInterceptor getFilterInterceptor(Base next) {
            return interceptors.get(next);
        }
        static protected void addFilterInterceptor(Base next, FilterInterceptor filterInterceptor) {
            if (codeIsCTSymbol(next) || Call.codeIsCallSymbol(next))
                throw new Re_Exceptions.CompileTimeGrammaticalException("cannot add filter interceptor: " + next);
            FilterInterceptor last;
            if (null == (last = interceptors.get(next))) {
                interceptors.put(next, filterInterceptor);
            } else {
                throw new Re_Exceptions.CompileTimeGrammaticalException("already filter interceptor: " + last);
            }
        }
        static boolean hasFilterInterceptor() {
            return interceptors.size() != 0;
        }
        static protected final Map<Base, FilterInterceptor> interceptors = new HashMap<>();




        static {
            injectionClassCall();
            injectionInitFunctionCall();
            injectionFunctionCall();
            injectionForCall();
            injectionWhileCall();
            injectionForeachCall();
            injectionIsolateCall();
            injectionTryCall();
        }
        static class ClassCall extends Call {
            static final int CLASS_HASH = ClassCall.class.hashCode();
            @Override
            public int hashCode() {
                return CLASS_HASH * (name == null ? 0 : name.hashCode());
            }

            String              className;
            Call.CallCreateDict executeExpressions;

            public String getClassName() {
                return className;
            }

            public Call.CallCreateDict getClassExpression() {
                return executeExpressions;
            }

            @Override
            public String toString() {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(super.getName());
                if (null == className) {
                    //匿名 class {}
                } else {
                    //class A {}
                    stringBuilder.append(' ');
                    stringBuilder.append(className);
                }
                stringBuilder.append(executeExpressions.toString());
                return stringBuilder.toString();
            }
        }
        static public void injectionClassCall() {
            {
                final String name = Re_Keywords.INNER_FUNCTION__CLASS;
                final Var var0;
                var0 = new Var();
                var0.name = name;

                final String help = "use " + var0 + " {} " + " or " + var0 + " name {}" ;

                //cls a {} ...
                addFilterInterceptor(var0, new FilterInterceptor() {
                    @Override
                    public void intercept(CompileTimeCodeListEditor editor, Base now) throws Re_Exceptions.CompileTimeGrammaticalException {
                        // TODO: Implement this method

                        int currentIndex = editor.index();
                        Var current      = (Var) now;

                        int  twoIndex    = editor.findNext();
                        Base two        = editor.getOrNull(twoIndex);

                        Re_CodeLoader.Call.CallCreateDict dict;
                        String className;
                        if (codeIsVar(two)) {
                            className = two.getName();
                            int  threeIndex   = editor.findNext(twoIndex + 1);
                            Base three0       = editor.getOrNull(threeIndex);

                            if (Call.codeIsCallCreateDict(three0)) {
                                dict = (Call.CallCreateDict) three0;

                                ClassCall c = new ClassCall();
                                c.setLine(current.getLine());
                                c.setName(current.getName());
                                c.staticValue = Re_Variable.Unsafe.findVariable(current.name, Re_Keywords.keyword);

                                c.className  = className;
                                c.executeExpressions = dict;

                                editor.set(currentIndex,    null);
                                editor.set(twoIndex,       null);
                                editor.set(threeIndex,   c);

                                editor.seek(threeIndex + 1);
                                return;

                            }
                        } else if (Call.codeIsCallCreateDict(two)) {
                            className = null;
                            dict = (Re_CodeLoader.Call.CallCreateDict) two;

                            ClassCall c = new ClassCall();
                            c.setLine(current.getLine());
                            c.setName(current.getName());
                            c.staticValue = Re_Variable.Unsafe.findVariable(current.name, Re_Keywords.keyword);

                            c.className  = className;
                            c.executeExpressions = dict;

                            editor.set(currentIndex,    null);
                            editor.set(twoIndex,       c);

                            editor.seek(twoIndex + 1);
                            return;
                        }

                        throw new Re_Exceptions.CompileTimeGrammaticalException(
                                "expression:[ " + Base.getExpressionAsString(editor.list) + " ]" +
                                "help:[ " + help + " ]",
                                editor.block.getFilePath(), now.getLine());
                    }
                });
            }
            {
                Re_Variable.Unsafe.addFinalValueIntern(Re_Keywords.INNER_FUNCTION__CLASS, new Re_IObject.IPrimitiveCall() {
                    @Override
                    public Object executeCallProcess(Re_Executor executor, String var_name, Re_CodeLoader.Call call) throws Throwable {
                        // TODO: Implement this method
                        ClassCall c = (ClassCall) call;
                        CTExpression[] expressions = c.getClassExpression().getBuildParamExpressionCaches();
                        return Re_Keywords.ReClassUtils.dynamicCreateInnerReClassAndInitialize(executor, c.className, expressions, call);
                    }
                }, Re_Keywords.keyword);
            }
        }





        static class InitFunctionCall extends Call {
            static final int CLASS_HASH = InitFunctionCall.class.hashCode();
            @Override
            public int hashCode() {
                return CLASS_HASH * (name == null ? 0 : name.hashCode());
            }

            String[]            functionParam = Finals.EMPTY_STRING_ARRAY;
            Call.CallCreateDict executeExpressions;

            public int      getParamCount() {
                return  functionParam.length;
            }
            public String   getParamName(int index) {
                return functionParam[index];
            }

            public Call.CallCreateDict getFunctionExpression() {
                return executeExpressions;
            }

            @Override
            public String toString() {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(super.getName());
                StringJoiner paramStr = new StringJoiner(Re_CodeSymbol.CODE_CALL_PARAM_SEPARATOR + " ", Re_CodeSymbol.CODE_CALL_PARAM_JOIN_SYMBOL, Re_CodeSymbol.CODE_CALL_PARAM_END_SYMBOL);
                for (String s : functionParam) {
                    paramStr.add(s);
                }
                stringBuilder.append(paramStr);
                stringBuilder.append(executeExpressions.toString());
                return stringBuilder.toString();
            }
        }
        static public void injectionInitFunctionCall() {
            {
                final String name = Re_Keywords.INNER_FUNCTION__SET_INIT_FUNCTION;
                final Call call0;
                call0 = new Call();
                call0.name = name;

                final Var var0;
                var0 = new Var();
                var0.name = name;

                final String help = "use " + var0 + "(param) {}" ;

                //init() {}
                addFilterInterceptor(call0, new FilterInterceptor() {
                    @Override
                    public void intercept(CompileTimeCodeListEditor editor, Base now) throws Re_Exceptions.CompileTimeGrammaticalException {
                        // TODO: Implement this method

                        int currentIndex = editor.index();
                        Call current     = (Call) now;

                        int  twoIndex = editor.findNext();
                        Base two    = editor.getOrNull(twoIndex);

                        if (Call.codeIsCallCreateDict(two)) {
                            Re_CodeLoader.Call.CallCreateDict twoDict = (Re_CodeLoader.Call.CallCreateDict) two;

                            InitFunctionCall c = new InitFunctionCall();
                            c.setLine(current.getLine());
                            c.setName(current.getName());
                            c.staticValue = Re_Variable.Unsafe.findVariable(current.name, Re_Keywords.keyword);

                            if (null != (c.functionParam = CompileTimeUtils.Expressions.getCallParamNameArray(current))) {
                                c.executeExpressions = twoDict;

                                editor.set(currentIndex, null);
                                editor.set(twoIndex , c);

                                editor.seek(twoIndex  + 1);
                                return;
                            }
                        }

                        throw new Re_Exceptions.CompileTimeGrammaticalException(
                                "expression:[" + Base.getExpressionAsString(editor.list) + "], " +
                                "help:[" + help + "]",
                                editor.block.getFilePath(), now.getLine());
                    }
                });
                //init ...
                addFilterInterceptor(var0, new FilterInterceptor() {
                    @Override
                    public void intercept(CompileTimeCodeListEditor editor, Base now) throws Re_Exceptions.CompileTimeGrammaticalException {
                        // TODO: Implement this method
                        throw new Re_Exceptions.CompileTimeGrammaticalException(
                                "expression:[" + Base.getExpressionAsString(editor.list) + "], " +
                                "help:[" + help + "]",
                                editor.block.getFilePath(), now.getLine());
                    }
                });
            }
            {
                Re_Variable.Unsafe.addFinalValueIntern(Re_Keywords.INNER_FUNCTION__SET_INIT_FUNCTION, new Re_IObject.IPrimitiveCall() {
                    @Override
                    public Object executeCallProcess(Re_Executor executor, String var_name, Re_CodeLoader.Call call) throws Throwable {
                        // TODO: Implement this method
                        InitFunctionCall c = (InitFunctionCall) call;
                        CTExpression[] expressions = c.getFunctionExpression().getBuildParamExpressionCaches();
                        Object o = Re_Keywords.ReClassUtils.dynamicCreateInnerReFunction(executor, var_name, c.functionParam, expressions, call);
                        if (executor.isReturn()) return executor.getReturn();

                        Re_Class reClass = executor.getReClass();
                        if (null == reClass) {
                            executor.setThrow("executor no bind class");
                            return null;
                        }

                        Re_ClassFunction function = (Re_ClassFunction) o;
                        if (null == function) {
                            executor.setThrow("create function fail");
                            return null;
                        }
                        if (reClass.isInitialize()) {
                            executor.setThrow("class initialize");
                            return null;
                        }
                        reClass.setInitFunction(function);
                        return null;
                    }
                }, Re_Keywords.keyword);
            }
        }








        static class FunctionCall extends Call {
            static final int CLASS_HASH = FunctionCall.class.hashCode();
            @Override
            public int hashCode() {
                return CLASS_HASH * (name == null ? 0 : name.hashCode());
            }

            String              functionName;
            String[]            functionParam = Finals.EMPTY_STRING_ARRAY;
            Call.CallCreateDict executeExpressions;

            public String getFunctionName() {
                return functionName;
            }

            public int      getParamCount() {
                return  functionParam.length;
            }
            public String   getParamName(int index) {
                return functionParam[index];
            }

            public Call.CallCreateDict getFunctionExpression() {
                return executeExpressions;
            }

            @Override
            public String toString() {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(super.getName());
                if (null == functionName) {
                    //匿名方法 function() {}
                } else {
                    //方法 function a() {}
                    stringBuilder.append(' ');
                    stringBuilder.append(functionName);
                }
                StringJoiner paramStr = new StringJoiner(Re_CodeSymbol.CODE_CALL_PARAM_SEPARATOR + " ", Re_CodeSymbol.CODE_CALL_PARAM_JOIN_SYMBOL, Re_CodeSymbol.CODE_CALL_PARAM_END_SYMBOL);
                for (String s : functionParam) {
                    paramStr.add(s);
                }
                stringBuilder.append(paramStr);
                stringBuilder.append(executeExpressions.toString());
                return stringBuilder.toString();
            }
        }
        static public void injectionFunctionCall() {
            {
                final String name = Re_Keywords.INNER_FUNCTION__FUNCTION;
                final Call call0;
                call0 = new Call();
                call0.name = name;

                final Var var0;
                var0 = new Var();
                var0.name = name;

                final String help = "use " + call0 + " {} " + " or " + var0 + " name(param) {}" ;

                //fun(){} 匿名
                addFilterInterceptor(call0, new FilterInterceptor() {
                    @Override
                    public void intercept(CompileTimeCodeListEditor editor, Base now) throws Re_Exceptions.CompileTimeGrammaticalException {
                        // TODO: Implement this method

                        int  currentIndex = editor.index();
                        Call current     = (Call) now;

                        int  twoIndex   = editor.findNext();
                        Base two        = editor.getOrNull(twoIndex);

                        if (Call.codeIsCallCreateDict(two)) {
                            Re_CodeLoader.Call.CallCreateDict twoDict = (Re_CodeLoader.Call.CallCreateDict) two;

                            FunctionCall c = new FunctionCall();
                            c.setLine(current.getLine());
                            c.setName(current.getName());
                            c.staticValue = Re_Variable.Unsafe.findVariable(current.name, Re_Keywords.keyword);

                            c.functionName  = null;
                            if (null != (c.functionParam = CompileTimeUtils.Expressions.getCallParamNameArray(current))) {
                                c.executeExpressions = twoDict;

                                editor.set(currentIndex, null);
                                editor.set(twoIndex, c);

                                editor.seek(twoIndex + 1);
                                return;
                            }
                        }


                        throw new Re_Exceptions.CompileTimeGrammaticalException(
                                "expression:[" + Base.getExpressionAsString(editor.list) + "], " +
                                "help:[" + help + "]",
                                editor.block.getFilePath(), now.getLine());
                    }
                });
                //fun a() {}
                addFilterInterceptor(var0, new FilterInterceptor() {
                    @Override
                    public void intercept(CompileTimeCodeListEditor editor, Base now) throws Re_Exceptions.CompileTimeGrammaticalException {
                        // TODO: Implement this method

                        int currentIndex = editor.index();
                        Var current      = (Var) now;

                        int nextIndex    = editor.findNext();
                        Base next        = editor.getOrNull(nextIndex);

                        if (codeIsCall(next)) {
                            Call nextCall = (Call) next;

                            int nextNextIndex   = editor.findNext(nextIndex + 1);
                            Base nextNext       = editor.getOrNull(nextNextIndex);

                            if (Call.codeIsCallCreateDict(nextNext)) {
                                Re_CodeLoader.Call.CallCreateDict nextNextDict = (Re_CodeLoader.Call.CallCreateDict) nextNext;

                                FunctionCall c = new FunctionCall();
                                c.setLine(current.getLine());
                                c.setName(current.getName());
                                c.staticValue = Re_Variable.Unsafe.findVariable(current.name, Re_Keywords.keyword);

                                c.functionName  = nextCall.getName();
                                if (null != (c.functionParam = CompileTimeUtils.Expressions.getCallParamNameArray(nextCall))) {
                                    c.executeExpressions = nextNextDict;

                                    editor.set(currentIndex,    null);
                                    editor.set(nextIndex,       null);
                                    editor.set(nextNextIndex,   c);

                                    editor.seek(nextNextIndex + 1);
                                    return;
                                }
                            }
                        }


                        throw new Re_Exceptions.CompileTimeGrammaticalException(
                                "expression:[" + Base.getExpressionAsString(editor.list) + "], " +
                                "help:[" + help + "]",
                                editor.block.getFilePath(), now.getLine());
                    }
                });
            }
            {
                Re_Variable.Unsafe.addFinalValueIntern(Re_Keywords.INNER_FUNCTION__FUNCTION, new Re_IObject.IPrimitiveCall(){
                    @Override
                    public Object executeCallProcess(Re_Executor executor, String var_name, Re_CodeLoader.Call call) throws Throwable {
                        // TODO: Implement this method
                        FunctionCall c = (FunctionCall) call;
                        CTExpression[] expressions = c.getFunctionExpression().getBuildParamExpressionCaches();
                        return Re_Keywords.ReClassUtils.dynamicCreateInnerReFunction(executor, c.functionName, c.functionParam, expressions, call);
                    }
                }, Re_Keywords.keyword);
            }
        }










        static class ForCall extends Call {
            static final int CLASS_HASH = ForCall.class.hashCode();
            @Override
            public int hashCode() {
                return CLASS_HASH * (name == null ? 0 : name.hashCode());
            }


            //for(i=0; i<1; i=i+1);
            CTExpression initExpression;
            CTExpression conditionalExpression;
            CTExpression afterExpression;

            Call.CallCreateDict executeExpressions;

            @Override
            public String toString() {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(super.getName());


                StringJoiner paramStr = new StringJoiner(Re_CodeSymbol.CODE_SEMICOLON_SEPARATOR + " ", Re_CodeSymbol.CODE_CALL_PARAM_JOIN_SYMBOL, Re_CodeSymbol.CODE_CALL_PARAM_END_SYMBOL);
                paramStr.add(initExpression.toString());
                paramStr.add(conditionalExpression.toString());
                paramStr.add(afterExpression.toString());
                stringBuilder.append(paramStr);

                stringBuilder.append(executeExpressions.toString());
                return stringBuilder.toString();
            }
        }
        static public void injectionForCall() {

            {
                final String name = Re_Keywords.INNER_FUNCTION__FOR;
                final Call call0;
                call0 = new Call();
                call0.name = name;

                final Var var0;
                var0 = new Var();
                var0.name = name;

                final String help = "use " + var0.toString() + "(initExpression; conditionalExpression; afterExpression) {}";

                //init() {}
                addFilterInterceptor(call0, new FilterInterceptor() {
                    @Override
                    public void intercept(CompileTimeCodeListEditor editor, Base now) throws Re_Exceptions.CompileTimeGrammaticalException {
                        // TODO: Implement this method

                        int currentIndex = editor.index();
                        Call current = (Call) now;

                        if (current.getParamExpressionCount() == 3) {
                            int  twoIndex   = editor.findNext();
                            Base two        = editor.getOrNull(twoIndex);

                            if (Call.codeIsCallCreateDict(two)) {
                                Re_CodeLoader.Call.CallCreateDict twoDict = (Re_CodeLoader.Call.CallCreateDict) two;

                                ForCall c = new ForCall();
                                c.setLine(current.getLine());
                                c.setName(current.getName());
                                c.staticValue = Re_Variable.Unsafe.findVariable(current.name, Re_Keywords.keyword);


                                c.initExpression = current.tempInnerParamList.get(0);
                                c.conditionalExpression = current.tempInnerParamList.get(1);
                                c.afterExpression = current.tempInnerParamList.get(2);

                                c.executeExpressions = twoDict;

                                editor.set(currentIndex, null);
                                editor.set(twoIndex, c);

                                editor.seek(twoIndex + 1);
                                return;
                            }
                        }


                        throw new Re_Exceptions.CompileTimeGrammaticalException(
                                "expression:[" + Base.getExpressionAsString(editor.list) + "], " +
                                "help:[" + help + "]",
                                editor.block.getFilePath(), now.getLine());
                    }
                });
                //init ...
                addFilterInterceptor(var0, new FilterInterceptor() {
                    @Override
                    public void intercept(CompileTimeCodeListEditor editor, Base now) throws Re_Exceptions.CompileTimeGrammaticalException {
                        // TODO: Implement this method


                        throw new Re_Exceptions.CompileTimeGrammaticalException(
                                "expression:[" + Base.getExpressionAsString(editor.list) + "], " +
                                "help:[" + help + "]",
                                editor.block.getFilePath(), now.getLine());
                    }
                });
            }
            {
                Re_Variable.Unsafe.addFinalValueIntern(Re_Keywords.INNER_FUNCTION__FOR, new Re_IObject.IPrimitiveCall() {
                    @Override
                    public Object executeCallProcess(Re_Executor executor, String var_name, Re_CodeLoader.Call call) throws Throwable {
                        // TODO: Implement this method
                        ForCall c = (ForCall) call;
                        CTExpression[] buildParamExpressionCaches = c.executeExpressions.getBuildParamExpressionCaches();

                        executor.getExpressionValue(c.initExpression);//init
                        if (executor.isReturn()) return executor.getReturn();

                        while (true) {
                            Object v = executor.getExpressionValue(c.conditionalExpression);
                            if (executor.isReturn()) return executor.getReturn();

                            if (!Re_Util.ifTrue(v)) return null;

                            executor.getExpressionLastValue(buildParamExpressionCaches, 0, buildParamExpressionCaches.length);     //expression
                            if (executor.isReturn()) {
                                Object aReturn = executor.getReturn();
                                if (Re_Keywords.Continue.isContinue(aReturn)) {
                                    executor.clearReturn();
//                              	continue;   //Java里不能直接 continue 因为后面的第三段代码还需要执行， 这里直接省略continue 即可， 第三段代码会执行
                                } else if (Re_Keywords.Break.isBreak(aReturn)) {
                                    executor.clearReturn();
                                    return aReturn;
                                } else {
                                    return aReturn;
                                }
                            }

                            executor.getExpressionValue(c.afterExpression);
                            if (executor.isReturn()) return executor.getReturn();
                        }
                    }
                }, Re_Keywords.keyword);
            }
        }






        static class WhileCall extends Call {
            static final int CLASS_HASH = WhileCall.class.hashCode();
            @Override
            public int hashCode() {
                return CLASS_HASH * (name == null ? 0 : name.hashCode());
            }


            //while(i < 1);
            CTExpression conditionalExpression;

            Call.CallCreateDict executeExpressions;

            @Override
            public String toString() {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(super.getName());

                StringJoiner paramStr = new StringJoiner(Re_CodeSymbol.CODE_SEMICOLON_SEPARATOR + " ", Re_CodeSymbol.CODE_CALL_PARAM_JOIN_SYMBOL, Re_CodeSymbol.CODE_CALL_PARAM_END_SYMBOL);
                paramStr.add(conditionalExpression.toString());
                stringBuilder.append(paramStr);

                stringBuilder.append(executeExpressions.toString());
                return stringBuilder.toString();
            }
        }
        static public void injectionWhileCall() {
            {
                final String name = Re_Keywords.INNER_FUNCTION__WHILE;
                final Call call0;
                call0 = new Call();
                call0.name = name;

                final Var var0;
                var0 = new Var();
                var0.name = name;

                final String help = "use " + var0 + "() {}";

                //while() {}
                addFilterInterceptor(call0, new FilterInterceptor() {
                    @Override
                    public void intercept(CompileTimeCodeListEditor editor, Base now) throws Re_Exceptions.CompileTimeGrammaticalException {
                        // TODO: Implement this method

                        int currentIndex = editor.index();
                        Call current = (Call) now;

                        if (current.getParamExpressionCount() == 1) {
                            int  twoIndex   = editor.findNext();
                            Base two        = editor.getOrNull(twoIndex);

                            if (Call.codeIsCallCreateDict(two)) {
                                Re_CodeLoader.Call.CallCreateDict twoDict = (Re_CodeLoader.Call.CallCreateDict) two;

                                WhileCall c = new WhileCall();
                                c.setLine(current.getLine());
                                c.setName(current.getName());
                                c.staticValue = Re_Variable.Unsafe.findVariable(current.name, Re_Keywords.keyword);

                                c.conditionalExpression = current.tempInnerParamList.get(0);

                                c.executeExpressions = twoDict;

                                editor.set(currentIndex, null);
                                editor.set(twoIndex, c);

                                editor.seek(twoIndex + 1);
                                return;
                            }
                        }


                        throw new Re_Exceptions.CompileTimeGrammaticalException(
                                "expression:[" + Base.getExpressionAsString(editor.list) + "], " +
                                "help:[" + help + "]",
                                editor.block.getFilePath(), now.getLine());
                    }
                });
                //init ...
                addFilterInterceptor(var0, new FilterInterceptor() {
                    @Override
                    public void intercept(CompileTimeCodeListEditor editor, Base now) throws Re_Exceptions.CompileTimeGrammaticalException {
                        // TODO: Implement this method


                        throw new Re_Exceptions.CompileTimeGrammaticalException(
                                "expression:[" + Base.getExpressionAsString(editor.list) + "], " +
                                "help:[" + help + "]",
                                editor.block.getFilePath(), now.getLine());
                    }
                });
            }
            {
                Re_Variable.Unsafe.addFinalValueIntern(Re_Keywords.INNER_FUNCTION__WHILE, new Re_IObject.IPrimitiveCall() {
                    @Override
                    public Object executeCallProcess(Re_Executor executor, String var_name, Re_CodeLoader.Call call) throws Throwable {
                        // TODO: Implement this method
                        WhileCall c = (WhileCall) call;
                        CTExpression[] buildParamExpressionCaches = c.executeExpressions.getBuildParamExpressionCaches();
                        while (true) {
                            Object v = executor.getExpressionValue(c.conditionalExpression);
                            if (executor.isReturn()) return executor.getReturn();

                            if (!Re_Util.ifTrue(v)) return null;

                            executor.getExpressionLastValue(buildParamExpressionCaches, 0, buildParamExpressionCaches.length);    //expression
                            if (executor.isReturn()) {
                                Object aReturn = executor.getReturn();
                                if (Re_Keywords.Continue.isContinue(aReturn)) {
                                    executor.clearReturn();
                                    continue;
                                } else if (Re_Keywords.Break.isBreak(aReturn)) {
                                    executor.clearReturn();
                                    return aReturn;
                                } else {
                                    return aReturn;
                                }
                            }
                        }
                    }
                }, Re_Keywords.keyword);
            }
        }







        static class ForeachCall extends Call {
            static final int CLASS_HASH = ForeachCall.class.hashCode();
            @Override
            public int hashCode() {
                return CLASS_HASH * (name == null ? 0 : name.hashCode());
            }


            //foreach(k, v, []) {};
            String kName;
            String vName;
            CTExpression objectExpression;

            Call.CallCreateDict executeExpressions;

            @Override
            public String toString() {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(super.getName());


                StringJoiner paramStr = new StringJoiner(Re_CodeSymbol.CODE_SEMICOLON_SEPARATOR + " ", Re_CodeSymbol.CODE_CALL_PARAM_JOIN_SYMBOL, Re_CodeSymbol.CODE_CALL_PARAM_END_SYMBOL);
                paramStr.add(kName);
                paramStr.add(vName);
                paramStr.add(objectExpression.toString());
                stringBuilder.append(paramStr);

                stringBuilder.append(executeExpressions.toString());
                return stringBuilder.toString();
            }
        }
        static public void injectionForeachCall() {
            {
                Re_Variable.Unsafe.addFinalValueIntern(Re_Keywords.INNER_FUNCTION__FOREACH, new Re_IObject.IPrimitiveCall() {
                    @Override
                    public Object executeCallProcess(Re_Executor executor, String var_name, Re_CodeLoader.Call call) throws Throwable {
                        // TODO: Implement this method
                        ForeachCall c = (ForeachCall) call;

                        String k_var_name   = c.kName;
                        String v_var_name   = c.vName;

                        Object iterable = executor.getExpressionValue(c.objectExpression);
                        if (executor.isReturn()) return executor.isReturn();

                        Re_Iterable iterableWrap = Re_Iterables.Re.wrap(executor, iterable);
                        if (executor.isReturn()) return executor.isReturn();

                        Re_Iterator iterator = iterableWrap.iterator();
                        Re_Variable key_variable   = iterator.key_variable();
                        Re_Variable value_variable = iterator.value_variable();

                        Re_Variable.accessSetValueFromNewVariableIntern(executor, k_var_name, key_variable,   executor);
                        if (executor.isReturn()) return executor.isReturn();

                        Re_Variable.accessSetValueFromNewVariableIntern(executor, v_var_name, value_variable, executor);
                        if (executor.isReturn()) return executor.isReturn();

                        CTExpression[] buildParamExpressionCaches = c.executeExpressions.getBuildParamExpressionCaches();

                        while (iterator.hasNext()) {
                            iterator.next(executor);
                            if (executor.isReturn()) return executor.getReturn();

                            executor.getExpressionLastValue(buildParamExpressionCaches, 0, buildParamExpressionCaches.length);    //expression
                            if (executor.isReturn()) {
                                Object aReturn = executor.getReturn();
                                if (Re_Keywords.Continue.isContinue(aReturn)) {
                                    executor.clearReturn();
                                    continue;
                                } else if (Re_Keywords.Break.isBreak(aReturn)) {
                                    executor.clearReturn();
                                    return aReturn;
                                } else {
                                    return aReturn;
                                }
                            }
                        }
                        return null;
                    }
                }, Re_Keywords.keyword);
            }
            {
                final String name = Re_Keywords.INNER_FUNCTION__FOREACH;
                final Call call0;
                call0 = new Call();
                call0.name = name;

                final Var var0;
                var0 = new Var();
                var0.name = name;

                final String help = "use " + var0 + "(k; v; objectExpression) {}";

                //foreach() {}
                addFilterInterceptor(call0, new FilterInterceptor() {
                    @Override
                    public void intercept(CompileTimeCodeListEditor editor, Base now) throws Re_Exceptions.CompileTimeGrammaticalException {
                        // TODO: Implement this method

                        int currentIndex = editor.index();
                        Call current = (Call) now;

                        if (current.getParamExpressionCount() == 3) {
                            int  twoIndex = editor.findNext();
                            Base two      = editor.getOrNull(twoIndex);

                            String kName = Re_CodeLoader.CompileTimeUtils.Expressions.getExpressionAsLocalName(current.tempInnerParamList.get(0));
                            String vName = Re_CodeLoader.CompileTimeUtils.Expressions.getExpressionAsLocalName(current.tempInnerParamList.get(1));
                            CTExpression objectExpression = current.tempInnerParamList.get(2);

                            if (null != kName && null != vName && Call.codeIsCallCreateDict(two)) {
                                Re_CodeLoader.Call.CallCreateDict twoDict = (Re_CodeLoader.Call.CallCreateDict) two;

                                ForeachCall c = new ForeachCall();
                                c.setLine(current.getLine());
                                c.setName(current.getName());
                                c.staticValue = Re_Variable.Unsafe.findVariable(current.name, Re_Keywords.keyword);


                                c.kName = kName;
                                c.vName = vName;
                                c.objectExpression   = objectExpression;

                                c.executeExpressions = twoDict;

                                editor.set(currentIndex, null);
                                editor.set(twoIndex, c);

                                editor.seek(twoIndex + 1);
                                return;
                            }
                        }


                        throw new Re_Exceptions.CompileTimeGrammaticalException(
                                "expression:[" + Base.getExpressionAsString(editor.list) + "], " +
                                "help:[" + help + "]",
                                editor.block.getFilePath(), now.getLine());
                    }
                });
                addFilterInterceptor(var0, new FilterInterceptor() {

                    @Override
                    public void intercept(CompileTimeCodeListEditor editor, Base now) throws Re_Exceptions.CompileTimeGrammaticalException {
                        // TODO: Implement this method


                        throw new Re_Exceptions.CompileTimeGrammaticalException(
                                "expression:[" + Base.getExpressionAsString(editor.list) + "], " +
                                "help:[" + help + "]",
                                editor.block.getFilePath(), now.getLine());
                    }
                });
            }
        }




        static class IsolateCall extends Call {
            static final int CLASS_HASH = IsolateCall.class.hashCode();
            @Override
            public int hashCode() {
                return CLASS_HASH * (name == null ? 0 : name.hashCode());
            }

            String[]            functionParam = Finals.EMPTY_STRING_ARRAY;
            Call.CallCreateDict executeExpressions;

            public int      getParamCount() {
                return  functionParam.length;
            }
            public String   getParamName(int index) {
                return functionParam[index];
            }

            public Call.CallCreateDict getFunctionExpression() {
                return executeExpressions;
            }

            @Override
            public String toString() {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(super.getName());
                StringJoiner paramStr = new StringJoiner(Re_CodeSymbol.CODE_CALL_PARAM_SEPARATOR + " ", Re_CodeSymbol.CODE_CALL_PARAM_JOIN_SYMBOL, Re_CodeSymbol.CODE_CALL_PARAM_END_SYMBOL);
                for (String s : functionParam) {
                    paramStr.add(s);
                }
                stringBuilder.append(paramStr);
                stringBuilder.append(executeExpressions.toString());
                return stringBuilder.toString();
            }
        }
        static public void injectionIsolateCall() {
            {
                final String name = Re_Keywords.INNER_FUNCTION__ISOLATE;
                final Call call0;
                call0 = new Call();
                call0.name = name;

                final Var var0;
                var0 = new Var();
                var0.name = name;


                final String help = "use " + var0 + "(param) {}" ;

                //isolate() {}
                addFilterInterceptor(call0, new FilterInterceptor() {
                    @Override
                    public void intercept(CompileTimeCodeListEditor editor, Base now) throws Re_Exceptions.CompileTimeGrammaticalException {
                        // TODO: Implement this method

                        int currentIndex = editor.index();
                        Call current     = (Call) now;

                        int  twoIndex  = editor.findNext();
                        Base two       = editor.getOrNull(twoIndex);

                        if (Call.codeIsCallCreateDict(two)) {
                            Re_CodeLoader.Call.CallCreateDict twoDict = (Re_CodeLoader.Call.CallCreateDict) two;

                            IsolateCall c = new IsolateCall();
                            c.setLine(current.getLine());
                            c.setName(current.getName());
                            c.staticValue = Re_Variable.Unsafe.findVariable(current.name, Re_Keywords.keyword);

                            if (null != (c.functionParam = CompileTimeUtils.Expressions.getCallParamNameArray(current))) {
                                c.executeExpressions = twoDict;

                                editor.set(currentIndex, null);
                                editor.set(twoIndex, c);

                                editor.seek(twoIndex + 1);
                                return;
                            }
                        }


                        throw new Re_Exceptions.CompileTimeGrammaticalException(
                                "expression:[" + Base.getExpressionAsString(editor.list) + "], " +
                                "help:[" + help + "]",
                                editor.block.getFilePath(), now.getLine());
                    }
                });
                addFilterInterceptor(var0, new FilterInterceptor() {
                    @Override
                    public void intercept(CompileTimeCodeListEditor editor, Base now) throws Re_Exceptions.CompileTimeGrammaticalException {
                        // TODO: Implement this method


                        throw new Re_Exceptions.CompileTimeGrammaticalException(
                                "expression:[" + Base.getExpressionAsString(editor.list) + "], " +
                                "help:[" + help + "]",
                                editor.block.getFilePath(), now.getLine());
                    }
                });
            }
            {
                Re_Variable.Unsafe.addFinalValueIntern(Re_Keywords.INNER_FUNCTION__ISOLATE, new Re_IObject.IPrimitiveCall() {
                    @Override
                    public Object executeCallProcess(Re_Executor executor, String var_name, Re_CodeLoader.Call call) throws Throwable {
                        // TODO: Implement this method
                        IsolateCall c = (IsolateCall) call;
                        CTExpression[] expressions = c.getFunctionExpression().getBuildParamExpressionCaches();

                        Object o = Re_Keywords.ReClassUtils.dynamicCreateInnerReFunction(executor, null, c.functionParam, expressions, call);
                        if (executor.isReturn()) return executor.isReturn();

                        final Re_ClassFunction function = (Re_ClassFunction) o;
                        if (null == function) {
                            executor.setThrow("create function fail");
                            return null;
                        }

                        return new IPrimitiveCall() {
                            @Override
                            public Object executeCallProcess(Re_Executor executor, String var_key, Call call) throws Throwable {
                                Object[] expressionValues = executor.getExpressionValues(call);
                                Re_IVariableMap local = Re_ClassFunction.getArgumentsArrayAsVariableMap(expressionValues, function);
                                Re_Executor re_executor = Re_Executor.buildReHostExecutor(executor.host, executor.getStack(), function.reCodeBlock, local, expressionValues);
                                Object run = re_executor.run();
                                return run;
                            }
                        };
                    }
                }, Re_Keywords.keyword);
            }
        }





        static class TryCall extends Call {
            static final int CLASS_HASH = TryCall.class.hashCode();
            @Override
            public int hashCode() {
                return CLASS_HASH * (name == null ? 0 : name.hashCode());
            }

            Call.CallCreateDict executeExpressions;
            String              catchName;
            Call.CallCreateDict catchExpressions;
            Call.CallCreateDict finallyExpressions;


            @Override
            public String toString() {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(super.getName());
                stringBuilder.append(executeExpressions);
                if (null != catchExpressions) {
                    stringBuilder.append(Re_Keywords.INNER_FUNCTION__CATCH)
                            .append(Re_CodeSymbol.CODE_CALL_PARAM_JOIN_SYMBOL)
                            .append(catchName)
                            .append(Re_CodeSymbol.CODE_CALL_PARAM_END_SYMBOL);
                    stringBuilder.append(catchExpressions);
                }
                if (null != finallyExpressions) {
                    stringBuilder.append(Re_Keywords.INNER_FUNCTION__FINALLY);
                    stringBuilder.append(finallyExpressions);
                }
                return stringBuilder.toString();
            }
        }
        static public void injectionTryCall() {
            {
                final String name = Re_Keywords.INNER_FUNCTION__TRY;
                final Call call0;
                call0 = new Call();
                call0.name = name;

                final Var var0;
                var0 = new Var();
                var0.name = name;


                final String help = "use try{}catch(e){}finally{}";

                //try{}catch(e){}finally{}
                addFilterInterceptor(call0, new FilterInterceptor() {
                    @Override
                    public void intercept(CompileTimeCodeListEditor editor, Base now) throws Re_Exceptions.CompileTimeGrammaticalException {
                        // TODO: Implement this method
                        throw new Re_Exceptions.CompileTimeGrammaticalException(
                                "expression:[" + Base.getExpressionAsString(editor.list) + "], " +
                                "help:[" + help + "]",
                                editor.block.getFilePath(), now.getLine());
                    }
                });
                addFilterInterceptor(var0, new FilterInterceptor() {

                    public Call.CallCreateDict getAsCallCreateDict(CompileTimeCodeListEditor editor, int index) {
                        Base two         = editor.getOrNull(index);
                        if (Call.codeIsCallCreateDict(two)) {
                            return (Call.CallCreateDict) two;
                        }
                        return null;
                    }
                    public Var getAsVar(CompileTimeCodeListEditor editor, int index) {
                        Base two         = editor.getOrNull(index);
                        if (codeIsVar(two)) {
                            return (Var) two;
                        }
                        return null;
                    }


                    @Override
                    public void intercept(CompileTimeCodeListEditor editor, Base now) throws Re_Exceptions.CompileTimeGrammaticalException {
                        // TODO: Implement this method
                        int currentIndex = editor.index();
                        Var current      = (Var) now; //try

                        Call.CallCreateDict executeExpression = null;
                        String catchName                      = null;
                        Call.CallCreateDict catchExpression   = null;
                        Call.CallCreateDict finallyExpression = null;

                        int endIndex;

                        int  twoIndex               = editor.findNext();
                        Call.CallCreateDict twoDict = getAsCallCreateDict(editor, twoIndex);//{}

                        T: if (null != twoDict) {
                            executeExpression = twoDict;
                                endIndex = twoIndex;

                            int  threeIndex = editor.findNext(twoIndex + 1);
                            Base three      = editor.getOrNull(threeIndex);

                            if (codeIsCall(three) && three.equalsName(Re_Keywords.INNER_FUNCTION__CATCH)) {//catch(e)
                                Call threeCall = (Call) three;
                                if (threeCall.getParamExpressionCount() == 1) {
                                    if (null == (catchName = Re_CodeLoader.CompileTimeUtils.Expressions.getExpressionAsLocalName(threeCall.tempInnerParamList.get(0)))) {
                                        break T;
                                    };
                                        endIndex = threeIndex;
                                    int  fourIndex = editor.findNext(threeIndex + 1);
                                    Call.CallCreateDict fourDict  = getAsCallCreateDict(editor, fourIndex);//{}
                                    if (null == fourDict) {
                                        break T;
                                    } else {
                                        catchExpression = fourDict;
                                            endIndex = fourIndex;

                                        int fiveIndex = editor.findNext(fourIndex + 1);
                                        Var asVar = getAsVar(editor, fiveIndex);
                                        if (null != asVar && asVar.equalsName(Re_Keywords.INNER_FUNCTION__FINALLY)) {
                                            int  sixIndex = editor.findNext(fiveIndex + 1);
                                            Call.CallCreateDict sixDict  = getAsCallCreateDict(editor, sixIndex);//{}
                                            if (null == sixDict) {
                                                break T;
                                            } else {
                                                finallyExpression = sixDict;
                                                    endIndex = sixIndex;
                                            }
                                        } else {
                                            // pass
                                        }
                                    }
                                } else break T;
                            } else if (codeIsVar(three) && three.equalsName(Re_Keywords.INNER_FUNCTION__FINALLY)) {   //finally
                                int  fourIndex = editor.findNext(threeIndex + 1);
                                Call.CallCreateDict fourDict  = getAsCallCreateDict(editor, fourIndex);//{}
                                if (null == fourDict) {
                                    break T;
                                } else {
                                    finallyExpression = fourDict;
                                        endIndex = fourIndex;
                                }
                            }

                            TryCall c = new TryCall();
                            c.setLine(current.getLine());
                            c.setName(current.getName());
                            c.staticValue = Re_Variable.Unsafe.findVariable(current.name, Re_Keywords.keyword);

                            c.executeExpressions = executeExpression;
                            c.catchName          = catchName;
                            c.catchExpressions   = catchExpression;
                            c.finallyExpressions = finallyExpression;

                            for (int i = currentIndex; i <= endIndex; i++) {
                                editor.set(i, null);
                            }
                            editor.set(endIndex, c);
                            return;
                        }

                        throw new Re_Exceptions.CompileTimeGrammaticalException(
                                "expression:[" + Base.getExpressionAsString(editor.list) + "], " +
                                "help:[" + help + "]",
                                editor.block.getFilePath(), now.getLine());

                    }
                });
            }
            {
                Re_Variable.Unsafe.addFinalValueIntern(Re_Keywords.INNER_FUNCTION__TRY, new Re_IObject.IPrimitiveCall() {
                    @Override
                    public Object executeCallProcess(Re_Executor executor, String var_name, Re_CodeLoader.Call call) throws Throwable {
                        // TODO: Implement this method
                        TryCall c = (TryCall) call;
                        CTExpression[] executeExpressions = c.executeExpressions.getBuildParamExpressionCaches();
                        String catchName                  = c.catchName;
                        CTExpression[] catchExpressions   = null == c.catchExpressions ? null : c.catchExpressions.getBuildParamExpressionCaches();
                        CTExpression[] finallyExpressions = null == c.finallyExpressions ? null : c.finallyExpressions.getBuildParamExpressionCaches();
                        return executor.executeTry(executeExpressions, catchName, catchExpressions, finallyExpressions);
                    }
                }, Re_Keywords.keyword);
            }
        }

    }



    public static class CompileTimeCodeListEditor {
        Re_CodeFile block;
        ArrList<Base> list;
        int index = -1;

        public CompileTimeCodeListEditor(Re_CodeFile block, ArrList<Base> now) {
            this.block = block;
            this.list  = now;
        }
        private CompileTimeCodeListEditor() {}


        /**
         * 获取上一段开始指针, 当前必须是一个整体
         */
        public int findSymbolPrevOverallStartIndex(int index) {
            Base current = list.get(index);
            //当前是符号 符号不能连接比如 - - -
            if (codeIsCTSymbol(current)) {
                for (int i = index - 1; i >= -1; i--) {
                    if (i == -1) {
                        return i + 1 == index ? -1 : i + 1;
                    }
                    Base c = list.get(i);
                    if (codeIsDiscon(c)) {
                        return i + 1 == index ? -1 : i + 1;
                    }
                }
                return -1;
            }
            throw new Re_Exceptions.CompileTimeGrammaticalException("unsupported current-type: " + current.getClass());
        }
        /**
         * 获取下一段结束指针， 当前必须是一个整体
         */
        public int findSymbolNextOverallEndIndex(int index) {
            Base current = list.get(index);
            //当前是符号 符号不能连接比如 - - -
            if (codeIsCTSymbol(current)) {
                for (int i = index + 1; i <= size(); i++) {
                    if (i == size()) {
                        return i - 1 == index ? -1 : i - 1;
                    }
                    Base c = list.get(i);
                    if (codeIsDiscon(c)) {
                        return i - 1 == index ? -1 : i - 1;
                    }
                }
                return -1;
            }
            throw new Re_Exceptions.CompileTimeGrammaticalException("unsupported current-type: " + current.getClass());
        }


        /**
         * 其实可能不需要Gc工作
         */
        public void removeNull() {
            int set = 0;
            ArrList<Base> that = this.list;
            for (Base base : that)
                if (null != base)
                    that.set(set++, base);
            that.setSize(set);
        }

        public void setNull(int index) {
            this.list.set(index, null);
        }
        public void set(int index, Base element) {
            this.list.set(index, element);
        }

        public Base get(int index) {
            return this.list.get(index);
        }
        public Base getOrNull(int index) {
            return this.list.getOrNull(index);
        }

        public boolean isStarted() {
            return this.index >= 0;
        }

        public void resetIndex() {
            this.index = -1;
        }
        public int seek(int index) {
            return this.index = index < 0 ? -1 : index;
        }
        public int index() {
            return this.index;
        }

        public int size() {
            return this.list.size();
        }

        public Base now() {
            return index >= 0 ? list.getOrNull(index): null;
        }
        public boolean isLast() {
            return null == this.getNext();
        }


        public int findNext() {
            return list.indexOfNonNull(this.index + 1);
        }
        public int findNext(int index) {
            return list.indexOfNonNull(index);
        }

        public boolean hasNext() {
            return list.size() > index + 1;
        }
        public Base getNext() {
            return list.getOrNull(index + 1);
        }
        public Base next() {
            return list.getOrNull(++index);
        }
    }

    /**
     * line of var tracker
     */
    private static class LineTracker {
        int line = 1;

        public void setLine(int line) {
            this.line = line;
        }

        public int getLine() {
            return line;
        }

        public void nextLine() {
            this.line++;
        }
    }




    public static class CompileTimeUtils {
        public static class Expressions {

            /**
             * @return 如果某个表达式只有变量名则返回变量名 否则返回null
             */
            public static String getExpressionAsLocalName(CTExpression expression) {
                ArrList<Base> param = expression.getInnerTempList();
                if (param.size() == 1) {
                    Base object = param.get(0);
                    if (codeIsVar(object))
                        return object.getName();
                    else return null;
                } else {
                    return null;
                }
            }

            /**
             * call必须符合 name(param);
             */
            public static String[] getCallParamNameArray(Call expr) {
                ArrList<CTExpression> expressionList = expr.tempInnerParamList;
                int count = expressionList.size(); //倒数第二个
                if (count == 0) {
                    return Finals.EMPTY_STRING_ARRAY;
                }
                String[] paramNames = new String[count];
                for (int i = 0; i < paramNames.length; i++) {
                    Re_CodeLoader.CTExpression expression = expressionList.get(i);
                    ArrList<Base> param = expression.getInnerTempList();
                    if (param.size() == 1) {
                        Base object = param.get(0);
                        if (codeIsVar(object))
                            paramNames[i] = object.getName();
                        else return null;
                    } else {
                        return null;
                    }
                }
                return paramNames;
            }

        }
    }
    public static class RuntimeUtils {
        static String formatClassName(String name) {
            if (null == name)
                return null;
            if (name.length() == 0)
                return null;

            int st = 0;
            int len = name.length();
            for (int i = 0; i < len; i++) {
                char ch = name.charAt(i);
                if (ch == Filex.NAME_CURRENT_DIRECTORY) {
                    st++;
                } else {
                    A:{
                        for (char c : FILE_SEPARATOR) {
                            if (ch == c) {
                                st++;
                                break A;
                            }
                        }
                        break;
                    }
                }
            }
            if (st != 0) {
                return name.substring(st, name.length());
            }
            return name;
        }

        /**
         * @param path 文件路径 支持 \ / 扩展名
         * @return 将文件路径转换为类名
         */
        public static String pathToClassName(String path) {
            if ((null == path) || path.length() == 0) {
                return null;
            }

            int len = path.length();
            String extendName = Filex.getExtensionName(path, FILE_EXTENSION_SYMBOL);
            if (null != extendName) {
                len = len - extendName.length() - FILE_EXTENSION_SYMBOL.length();
            }

            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < len; i++){
                char ch = path.charAt(i);
                boolean sep = false;
                for (char c : FILE_SEPARATOR) {
                    if (ch == c){
                        sep = true;
                        break;
                    }
                }
                if (sep) {
                    int b_length = stringBuilder.length();
                    if (b_length != 0) {
                        char last = stringBuilder.charAt(b_length - 1);
                        if  (last != ch) {
                            stringBuilder.append(PACKAGE_SEPARATOR);
                        }
                    }
                } else {
                    if (ch == PACKAGE_SEPARATOR) {
                        throw new UnsupportedOperationException("invalid name: " + path+" "+" "+"["+i+"]");
                    }
                    stringBuilder.append(ch);
                }
            }
            return stringBuilder.toString();
        }

        public static String classNameToPath(String name) {
            if ((null == name) || name.length() == 0) {
                return null;
            }

            int len = name.length();
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < len; i++){
                char ch = name.charAt(i);
                boolean sep = false;
                for (char c : FILE_SEPARATOR) {
                    if (ch == c){
                        sep = true;
                        break;
                    }
                }
                if (sep) {
                    throw new UnsupportedOperationException("invalid name: " + name+" "+" "+"["+i+"]");
                } else {
                    if (ch == PACKAGE_SEPARATOR) {
                        stringBuilder.append(Filex.system_separator);
                        continue;
                    }
                    stringBuilder.append(ch);
                }
            }
            return stringBuilder
                    .append(FILE_EXTENSION_SYMBOL).append(RE_FILE_EXTENSION_NAME).toString();
        }




        /**
         * 运行时方法，表达式必须编译后才能使用
         */
        public static class Expressions {

            /**
             * @return 如果某个表达式只有变量名则返回变量名 否则返回null
             */
            public static String getExpressionAsLocalName(CTExpression expression) {
                Base[] param = expression.getBuildCodeCache();
                if (param.length == 1 && codeIsVar(param[0])) {
                    return param[0].getName();
                }
                return null;
            }

            public static Call getExpressionAsCall(CTExpression expression) {
                Base[] param = expression.getBuildCodeCache();
                if (param.length == 1 && codeIsCall(param[0])) {
                    return (Call) param[0];
                }
                return null;
            }



            public static Re_CodeLoader.CTExpression getBaseToExpression(Base base) {
                if (null == base) {
                    return null;
                }
                Re_CodeLoader.CTExpression expression = new Re_CodeLoader.CTExpression();
                expression.addToInnerTempListLast(base);
                expression.setLineFromFirstElement();
                return expression;
            }


            /**
             * call必须符合 name(param);
             */
            public static String[] getCallParamNameArray(Call expr) {
                CTExpression[] expressionList = expr.getBuildParamExpressionCaches();
                int count = expressionList.length; //倒数第二个
                if (count == 0) {
                    return Finals.EMPTY_STRING_ARRAY;
                }
                String[] paramNames = new String[count];
                for (int i = 0; i < paramNames.length; i++) {
                    Re_CodeLoader.CTExpression expression = expressionList[i];
                    Base[] param = expression.getBuildCodeCache();
                    if (param.length == 1) {
                        Base object = param[0];
                        if (codeIsVar(object))
                            paramNames[i] = object.getName();
                        else return null;
                    } else {
                        return null;
                    }
                }
                return paramNames;
            }









            /**
             * 如果参数的某个表达式为 {}  则 返回 {} 里面的表达式 不包括 {}
             */
            public static CTExpression[] getCreateObjectExpressions(CTExpression paramExpression) {
                if (null != paramExpression) {
                    Base[] param = paramExpression.getBuildCodeCache();
                    if (param.length == 1) {
                        if (codeIsCall(param[0])) {
                            Call   call = (Call) param[0];
                            return call.equalsName(Re_Keywords.INNER_CONVERT_FUNCTION__CREATE_OBJECT) ? call.getBuildParamExpressionCaches() : null;
                        }
                    }
                }
                return null;
            }

            /**
             * 如果参数的某个表达式为 []   则 返回 [] 里面的表达式 不包括 []
             */
            public static CTExpression[] getCreateListExpressions(CTExpression paramExpression) {
                if (null != paramExpression) {
                    Base[] param = paramExpression.getBuildCodeCache();
                    if (param.length == 1) {
                        if (codeIsCall(param[0])) {
                            Call   call = (Call) param[0];
                            return call.equalsName(Re_Keywords.INNER_CONVERT_FUNCTION__CREATE_LIST) ? call.getBuildParamExpressionCaches() : null;
                        }
                    }
                }
                return null;
            }

        }
    }


}

