package top.fols.box.reflect.re;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import top.fols.atri.reflect.ReflectCache;
import top.fols.atri.reflect.ReflectMatcher;
import top.fols.atri.reflect.ReflectPeakMatcher;
import top.fols.atri.reflect.Reflects;
import top.fols.box.reflect.re.interfaces.Re_IObject;
import top.fols.box.reflect.re.interfaces.Re_IJavaReflector;
import top.fols.atri.lang.Finals;
import top.fols.box.reflect.re.primitive.classes.Re_PrimitiveClass_object;
import top.fols.box.reflect.re.primitive.lang.Re_Iterable;
import top.fols.box.reflect.re.primitive.objects.Re_PrimitiveObject_JImport;
import top.fols.box.reflect.re.primitive.util.Re_Primitive_Util_Array;
import top.fols.box.reflect.re.resource.Re_Resource;
import top.fols.box.reflect.re.variables.Re_VariableMap;


/**
 * Java反射器
 * 作用是可以防止直接反射私有字段
 * 这玩意一般是在re里面用的，需要防止在re里面反射 re
 * 其实没啥用 但是起码得弄一个吧
 */
@SuppressWarnings("rawtypes")
public class Re_Reflector extends ReflectMatcher<ReflectCache> implements Re_IJavaReflector {

    @SuppressWarnings("unused")
    public static String[] getDisableReflectPackage() {
        return new HashMap<String, Object>() {
            @SuppressWarnings("SameParameterValue")
            void addPackage(Class<?> packageHeader) {
                put(packageHeader.getPackage().getName(), true);
            }
            @SuppressWarnings("SameParameterValue")
            void addClass(Class<?> packageHeader) {
                put(packageHeader.getName(), true);
            }


            {
                addPackage(Reflects.class);
            }
            {
                addPackage(Re_IObject.class);


                addPackage(Re_PrimitiveClass_object.class);

                addPackage(Re_Iterable.class);

                addPackage(Re_PrimitiveObject_JImport.class);

                addPackage(Re_Primitive_Util_Array.class);

                addPackage(Re_Resource.class);

                addPackage(Re_VariableMap.class);


                addPackage(Re.class);
            }
            {
                addClass(Class.class);

                addClass(String.class);

                addClass(Integer.class);
                addClass(Character.class);
                addClass(Byte.class);
                addClass(Long.class);
                addClass(Float.class);
                addClass(Double.class);
                addClass(Short.class);
                addClass(Boolean.class);

                addClass(Object.class);
            }
        }.keySet().toArray(Finals.EMPTY_STRING_ARRAY);
    }






    @SuppressWarnings("SameParameterValue")
    protected static class Cache extends ReflectCache {
        protected ClassesList 	    getClassesList(Class cls) 			 			{ return super.getClassesList(cls);      }
        protected Class             getClassesList(Class cls, String simpleName) 	{ return super.getClassesList(cls, simpleName); }
        protected ConstructorList   getConstructorsList(Class cls)  				{ return super.getConstructorsList(cls); }
        protected FieldList 	    getFieldsList(Class cls)						{ return super.getFieldsList(cls);       }
        protected FieldList         getFieldsList(Class cls, String name)  		    { return super.getFieldsList(cls, name); }
        protected MethodList 	    getMethodsList(Class p1)   					    { return super.getMethodsList(p1);   }
        protected MethodList 	    getMethodsList(Class p1, String p2)    		    { return super.getMethodsList(p1, p2);   }

        @Override
        protected String getSimpleName0(Class<?> name) {
            return Re_CodeLoader.intern(name.getSimpleName());
        }

        @Override
        protected String getMemberName0(Member member) {
            return Re_CodeLoader.intern(member.getName());
        }

        /**
         * safe reflect
         * 禁止访问私有字段
         */
        private static final HashMap<String, Object> filterPackage  = new HashMap<String, Object>() {{//不会增量
            for (String aClass: getDisableReflectPackage()) {
                put(aClass, null);
            }
        }};

        private static boolean isDisableReflectPackage(Map<String, Object> map, Class<?> reflectClass) {
//			for (String key: map.keySet()) {
//				if (key.equals(reflectClass.getName()) ||
//					reflectClass.getPackage().getName().startsWith(key))
//					return true;
//			}
//			return false;

            Package aPackage = reflectClass.getPackage();
            return map.containsKey(reflectClass.getName()) || (null != aPackage && map.containsKey(aPackage.getName()));
        }




        public Cache() {}

        @Override
        protected Class[] listClassesProcess(Class cls) {
            if (isDisableReflectPackage(filterPackage, cls))
                return cls.getClasses();
            return super.listClassesProcess(cls);
        }
        @Override
        protected Constructor[] listConstructorListProcess(Class cls) {
            if (isDisableReflectPackage(filterPackage, cls))
                return cls.getConstructors();
            return super.listConstructorListProcess(cls);
        }
        @Override
        protected Field[] listFieldListProcess(Class cls) {
            if (isDisableReflectPackage(filterPackage, cls))
                return cls.getFields();
            return super.listFieldListProcess(cls);
        }
        @Override
        protected Method[] listMethodListProcess(Class cls) {
            if (isDisableReflectPackage(filterPackage, cls))
                return cls.getMethods();
            return super.listMethodListProcess(cls);
        }
    }


    public Re_Reflector() {
        super(new Cache());
    }

    /**
     * 这玩意一般是在re里面用的，需要防止在re里面反射 re
     */
    public static class Re_ReflectorPeak extends ReflectPeakMatcher<ReflectCache> implements Re_IJavaReflector {
        public Re_ReflectorPeak() {
            super(new Cache());
        }

    }



}

