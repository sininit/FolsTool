package top.fols.box.reflect.re.variables;

import top.fols.box.reflect.re.Re_Executor;
import top.fols.box.reflect.re.Re_Variable;
import top.fols.box.reflect.re.interfaces.Re_IVariableMap;
import java.util.*;

/**
 * 关键词应该是可见的
 */

public class Re_KeywordVariableMap implements Re_IVariableMap {
    protected final Object lock = new Object();
    protected Map<Object, Re_Variable<?>> map     = new HashMap<>();
    protected Map<Object, Object> valueMappingKey = new IdentityHashMap<>();  //可能存在重复的value，所以用IdentityHashMap


    // no sync lock
    public boolean isKeywordKey(Object value) {
        return map.containsKey(value);
    }
    public boolean isKeywordValue(Object value) {
        return valueMappingKey.containsKey(value);
    }
    // no sync lock
    public Object getKeywordKey(Object value) {
        return valueMappingKey.get(value);
    }



    public Object findKeyword(Object key) {
        try {
            return Re_Variable.Unsafe.fromDirectAccessorFindValue(key, this);
        } catch (Throwable ignored) {}
        return null;
    }




    public Object findRuntimeKeyword(Re_Executor executor, Object key) {
        return Re_Variable.accessFindValue(executor, key, this);
    }
    public boolean isRuntimeKeyword(Object key) {
        return !Re_Variable.Unsafe.getDirectAccessor(key, this);
    }




    public String[] getKeywordNames() {
        Set x = new LinkedHashSet();
        for (Object o : keySet()) {
            x.add(o);
        }
        int size = x.size();
        String[] keys = new String[size];
        int i = 0;
        for (Object o: x) {
            keys[i++] = (String) o;
        }
        return keys;
    }



    @Override
    public Re_Variable remove(Object key) {
        synchronized (lock) {
            Re_Variable<?> remove = map.remove(key);
            if (null != remove) {
                Object value = null;
                try {
                    value = Re_Variable.Unsafe.fromDirectAccessorGetValue(remove);
                } catch (Throwable ignored) {}
                valueMappingKey.remove(value);
            }
            return remove;
        }
    }

    @Override
    public Re_Variable find(Object key) {
        synchronized (lock) {
            return map.get(key);
        }
    }

    @Override
    public Re_Variable get(Object key) {
        synchronized (lock) {
            return map.get(key);
        }
    }

    @Override
    public Re_Variable put(Object key, Re_Variable variable) {
        if (key instanceof String) {
            synchronized (lock) {
                if (null != variable) {
                    Object value = null;
                    try {
                        value = Re_Variable.Unsafe.fromDirectAccessorGetValue(variable);
                    } catch (Throwable ignored) {}
                    valueMappingKey.put(value, key);
                }
                return map.put(key, variable);
            }
        }
        throw new IllegalArgumentException("key must be String");
    }

    @Override
    public boolean containsKey(Object key) {
        synchronized (lock) {
            return map.containsKey(key);
        }
    }

    @Override
    public int size() {
        synchronized (lock) {
            return map.size();
        }
    }


    Collection<?> collection;
    @Override
    public Collection<?> keySet() {
        synchronized (lock) {
            return null == collection ? collection = new ReplaceCollection(this) : collection;
        }
    }


    @Override
    public int hashCode() {
        synchronized (lock) {
            return map.hashCode();
        }
    }

    @Override
    public boolean equals(Object obj) {
        synchronized (lock) {
            if (obj instanceof Re_KeywordVariableMap) {
                return map.equals(((Re_KeywordVariableMap) obj).map);
            }
            return map.equals(obj);
        }
    }

    @Override
    public String toString() {
        synchronized (lock) {
            return map.toString();
        }
    }





    @SuppressWarnings("rawtypes")
    public static class ReplaceCollection implements Collection {
        final Re_KeywordVariableMap parent;
        final Collection<Object> objectCollection;
        public ReplaceCollection(Re_KeywordVariableMap parent) {
            this.parent = parent;
            this.objectCollection = parent.map.keySet();
        }


        @Override
        public int size() {
            synchronized (parent.lock) {
                return objectCollection.size();
            }
        }

        @Override
        public boolean isEmpty() {
            synchronized (parent.lock) {
                return objectCollection.isEmpty();
            }
        }

        @Override
        public void clear() {
            synchronized (parent.lock) {
                parent.map.clear();
                parent.valueMappingKey.clear();
            }
        }

        @Override
        public int hashCode() {
            synchronized (parent.lock) {
                return objectCollection.hashCode();
            }
        }

        @Override
        public boolean equals(Object obj) {
            synchronized (parent.lock) {
                if (obj instanceof ReplaceCollection) {
                    return objectCollection.equals(((ReplaceCollection) obj).objectCollection);
                }
                return objectCollection.equals(obj);
            }
        }

        @Override
        public String toString() {
            synchronized (parent.lock) {
                return objectCollection.toString();
            }
        }

        @Override
        public Iterator<?> iterator() {
            return wrapIterator(this);
        }


        @Override
        public boolean add(Object key) {
            synchronized (parent.lock) {
                boolean b = parent.containsKey(key);
                if (b) {
                    return false;
                } else {
                    return null == parent.put(key, null);
                }
            }
        }
        @Override
        public boolean remove(Object key) {
            return parent.remove(key) != null;
        }

        @Override
        public boolean contains(Object key) {
            return parent.containsKey(key);
        }



        @Override
        public boolean containsAll(Collection c) {
            if (c != this) {
                for (Object e : c) {
                    if (!contains(e))
                        return false;
                }
            }
            return true;
        }
        @Override
        public boolean addAll(Collection c) {
            if (c == null) return false;
            for (Object e : c) {
                add(e);
            }
            return true;
        }

        @Override
        public boolean retainAll(Collection c) {
            if (c == null) return false;
            boolean modified = false;
            for (Iterator it = iterator(); it.hasNext();) {
                Object next = it.next();
                if (!c.contains(next)) {
                    it.remove();
                    modified = true;
                }
            }
            return modified;
        }
        @Override
        public boolean removeAll(Collection c) {
            if (c == null) return true;
            boolean modified = false;
            for (Iterator this_it = iterator(); this_it.hasNext();) {
                Object this_next = this_it.next();
                if (c.contains(this_next)) {
                    this_it.remove();
                    modified = true;
                }
            }
            return modified;
        }




        @Override
        public Object[] toArray() {
            return objectCollection.toArray();
        }

        @Override
        public Object[] toArray(Object[] a) {
            return objectCollection.toArray(a);
        }
    }
    /**
     * 因为替换了null key 所以需要对Set进行过滤
     */
    public static Iterator wrapIterator(final ReplaceCollection parent) {
        if (null == parent) {
            return null;
        }

        final Iterator iterator = parent.objectCollection.iterator();
        return new Iterator() {
            final Object lock = new Object();
            Object current;

            @Override
            public boolean hasNext() {
                // TODO: Implement this method
                return iterator.hasNext();
            }


            @Override
            public Object next() {
                // TODO: Implement this method
                synchronized (lock) {
                    return current = iterator.next();
                }
            }

            @Override
            public void remove() {
                // TODO: Implement this method
                synchronized (lock) {
                    parent.remove(current);
                }
            }
        };
    }
}
