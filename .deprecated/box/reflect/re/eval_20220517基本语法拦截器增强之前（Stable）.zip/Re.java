package top.fols.box.reflect.re;

import top.fols.atri.lang.Objects;
import top.fols.box.reflect.re.interfaces.Re_IJavaReflector;
import top.fols.box.reflect.re.interfaces.Re_IVariableMap;
import top.fols.box.reflect.re.primitive.objects.Re_PrimitiveObject_JImport;
import top.fols.box.reflect.re.resource.Re_Resource;
import top.fols.box.reflect.re.resource.Re_ResourceFile;
import top.fols.box.reflect.re.variables.Re_VariableMap;

import java.nio.charset.Charset;
import java.util.*;

/**
 *
 * 2021/11/12 - 2021/11/30
 * @author GXin <a href="http://github.com/sininit">http://github.com/sininit</a>
 *
 *
 *
 *
 *
 * thread safe
 *
 * $("$1.out.println($2)", import_java_class("java.lang.System"), 666)    >> System.out.println(666)
 */
public class Re {
    public static Object $(String expression, Object... params) throws Re_Exceptions.CompileTimeGrammaticalException, Re_Exceptions.ExecuteException {
        return new Re().exec(expression, params);
    }


    private static final Re_IJavaReflector          DEFAULT_REFLECTOR    = new Re_Reflector();

    private static final Map<String, Re_CodeFile>   compile     = new WeakHashMap<>();//写锁
    private static final Object                     compileLock = new Object();


    protected static boolean hasCompileCache(String expression) {
        return null != compile.get(expression);
    }

    protected Re_CodeFile compileCode(String expression, String filePath) throws Re_Exceptions.CompileTimeGrammaticalException {
        return compileCode(expression, filePath, 1);
    }

    /**
     *
     * @param expression     表达式
     * @param filePath      表达式所在文件
     * @param lineOffset    表达式所在文件行
     * @return 每次返回的数据可能都不一样
     */
    protected Re_CodeFile compileCode(String expression, String filePath, int lineOffset) throws Re_Exceptions.CompileTimeGrammaticalException {
        if (noUseCompileCache)
            return compile(expression, filePath, lineOffset);

        Re_CodeFile query = compile.get(expression);
        if (null == query) {
            synchronized (compileLock) {
                compile.put(expression, query = compile(expression, filePath, lineOffset<=0?1:lineOffset));
            }
        }
        /*
         * 为了防止对比字符串需要的性能，直接判断是否地址相等就行了
         */
        //noinspection StringEquality
        if (filePath != query.filePath || query.lineOffset != lineOffset) {
            query = query.clone();  //克隆代码但是不克隆文件信息
            query.filePath = filePath;
            query.lineOffset = lineOffset <= 0 ? 1 : lineOffset;
        }
        return query;
    }


    public static Re_CodeFile compile(String expression, String filePath, int lineOffset) throws Re_Exceptions.CompileTimeGrammaticalException {
        Re_CodeLoader re_codeLoader = new Re_CodeLoader();
        return re_codeLoader.load(expression, filePath ,lineOffset);
    }




    /**
     * return class point object
     * @param type class name
     */
    public static Re_PrimitiveObject_JImport jimport(String type) throws ClassNotFoundException {
        return jimport(Re_Util.jforNameFindClass(type));
    }
    /**
     * return class point object
     * @param type class
     */
    public static Re_PrimitiveObject_JImport jimport(Class<?> type) {
        return Re_Util.jimport(type);
    }








    private final Re_IVariableMap   host_local = new Re_VariableMap();

    protected Re_IJavaReflector     reReflect;          //Java反射器
    protected boolean               noUseCompileCache;  //默认使用缓存


    public Re() {
        this(DEFAULT_REFLECTOR);
    }
    public Re(Re_IJavaReflector reReflect) {
        this.reReflect = Objects.requireNonNull(reReflect, "reflector");
    }





    /**
     * 默认不使用缓存
     * 因为缓存无法保证代码是否被修改了
     */
    public void setNoUseCompileCache(boolean useCompileCache) {
        this.noUseCompileCache = useCompileCache;
    }
    public boolean isNoUseCompileCache() {
        return noUseCompileCache;
    }



    /**
     * 每次执行都会创建一个新的类
     */
    public Object exec(final String expression, Object... params) throws Re_Exceptions.CompileTimeGrammaticalException, Re_Exceptions.ExecuteException {
        Re_CodeFile block = compileCode(expression, Re_CodeFile.JAVA_SOURCE__FILE_NAME);//代码是从第一行开始的 没有第0行这种说法
        return exec(block, params);
    }
    /**
     * 每次执行都会创建一个新的类
     */
    public Object exec(final Re_CodeFile block, Object... params) throws Re_Exceptions.CompileTimeGrammaticalException, Re_Exceptions.ExecuteException {
        Re_Executor executor = Re_Executor.buildReHostExecutor(this, null , block, host_local, params);
        Object result  = executor.run();
        throwStackException(executor);
        return result;
    }


    public static void throwStackException(Re_Executor executor) throws Re_Exceptions.ExecuteException {
        throwStackException(executor.getStack());
    }
    public static void throwStackException(Re_Stack reStack) throws Re_Exceptions.ExecuteException {
        if (reStack.isThrow()) {
            String stacksString = reStack.buildStacksString();
            throw new Re_Exceptions.ExecuteException(stacksString);
        }
    }




    public Object exec_try(String expression, Object... params) throws Re_Exceptions.CompileTimeGrammaticalException {
        Re_CodeFile block = compileCode(expression, Re_CodeFile.JAVA_SOURCE__FILE_NAME);//代码是从第一行开始的 没有第0行这种说法
        return exec_try(block, params);
    }
    public Object exec_try(Re_CodeFile block, Object... params) throws Re_Exceptions.CompileTimeGrammaticalException {
        try {
            return exec(block, params);
        } catch (Re_Exceptions.CompileTimeGrammaticalException e) {
            throw e;
        } catch (Throwable ignored) {
            return null;
        }
    }



    /**
     * or("field.var1.set", "field.var1.put")
     *
     * @return first nonnull object expression
     */
    public boolean or(String... expression) throws Re_Exceptions.CompileTimeGrammaticalException {
        if (null == expression || expression.length == 0) {
            return false;
        }
        for (String exp: expression) {
            Object o = exec_try(exp);
            if (null != o) {
                return true;
            }
        }
        return false;
    }
    public boolean test(String expression, Object... params) throws Re_Exceptions.CompileTimeGrammaticalException {
        return !(null == exec_try(expression, params));
    }









    public Object  getHostValue(String name) {
        return Re_Variable.Unsafe.fromDirectAccessorFindValue(name, host_local);
    }
    public void    setHostValue(String name, Object value) {
        Re_Variable.Unsafe.fromDirectAccessorSetValueIntern(name, value, host_local);
    }
    public boolean hasHostValue(String name) {
        return Re_Variable.has(name, host_local);
    }



    protected Re_IVariableMap getInnerHostValueMap() {
        return host_local;
    }














    BootstrapReClassLoader bootstrapReClassLoader;


    @SuppressWarnings("unused")
    public Re_ClassLoader getBootstrapClassLoader() {
        return bootstrapReClassLoader;
    }
    public void addBootstrapClassLoaderResource(Re_Resource resource) {
        if (null != resource) {
            if (null == bootstrapReClassLoader) {
                bootstrapReClassLoader = createBootstrapReClassLoader();
            }
            bootstrapReClassLoader.addSourceManager(resource);
        }
    }
    public boolean removeBootstrapClassLoaderResource(Re_Resource resource) {
        if (null == bootstrapReClassLoader) {
            return false;
        } else {
            return bootstrapReClassLoader.removeSourceManager(resource);
        }
    }
    public Re_Resource[] getBootstrapClassLoaderResources() {
        if (null == bootstrapReClassLoader) {
            return null;
        } else {
            return bootstrapReClassLoader.getSources();
        }
    }
    protected BootstrapReClassLoader createBootstrapReClassLoader() {
        return new BootstrapReClassLoader(this);
    }







    /**
     * 使用re 进行类编译
     */
    public static class DefaultReClassLoader extends Re_ClassLoader {
        public DefaultReClassLoader(Re re) {
            this(Objects.requireNonNull(re, "host"), null);
        }
        public DefaultReClassLoader(Re re, Re_ClassLoader parent) {
            super(re, parent);
        }

        //顶级类
        @Override
        protected final Re_CodeFile compileReClass(String filePath, byte[] data, Charset charset) throws Re_Exceptions.CompileTimeGrammaticalException, Re_Exceptions.ReClassDefineException {
            String code = new String(data, charset);
            return re.compileCode(code, filePath);
        }

        @Override
        protected void initReClass(Re_Class define) throws Re_Exceptions.ReClassDefineException {
            Re_CodeFile block = define.reCodeBlock;
            Re_Stack re_stack = Re_Stack.newStack();
            Re_Executor.runReClassInitialize0(re, re_stack, block, define);
            if (re_stack.isThrow()) {
                Re.throwStackException(re_stack); //错误的初始化类
            }
        }
    }
    /**
     * 使用re 进行类编译
     */
    public static class DefaultReClassLoaderPublic extends DefaultReClassLoader {
        public DefaultReClassLoaderPublic(Re re) {
            super(re);
        }
        public DefaultReClassLoaderPublic(Re re, Re_ClassLoader parent) {
            super(re, parent);
        }

        @Override
        public void addSourceManager(Re_Resource resource) {
            super.addSourceManager(resource);
        }

        @Override
        public boolean removeSourceManager(Re_Resource resource) {
            return super.removeSourceManager(resource);
        }

        @Override
        public boolean hasSourceManager(Re_Resource resource) {
            return super.hasSourceManager(resource);
        }

        @Override
        public Re_ResourceFile getFileSource(String path) {
            return super.getFileSource(path);
        }

        @Override
        public Re_ResourceFile getClassSource(String className) {
            return super.getClassSource(className);
        }

        @Override
        public Re_Resource[] getSources() {
            return super.getSources();
        }
    }




    //默认引导类加载器
    public static class BootstrapReClassLoader extends DefaultReClassLoaderPublic {
        public BootstrapReClassLoader(Re re) {
            super(re, null);
        }
    }
}